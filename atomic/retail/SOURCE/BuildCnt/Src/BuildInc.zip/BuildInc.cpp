// BuildInc.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <string.h>
#include <stdlib.h>

#define MAX_PATH 260
#define FILE_LOCATION "\\LIB.IRA\\"
#define FILE_NAME "PartialV.h"
#define SEARCH_STRING "#define NAV_PARTIAL_BUILD_STRING \""
#define TOOL_VERSION "1.0"

int main(int argc, char* argv[])
{	FILE *fp;
	const char *pEnvString;
	char szFilePath[MAX_PATH];
	char Buffer[4096];
	char *pSubstring;
	char c;
	size_t count, count2;

	printf("NAV Retail Version updater tool, version %s\r\n", TOOL_VERSION);
	pEnvString = getenv("PROJ");
	if(pEnvString == NULL)
	{	printf("**********Error, environment not set up!**********\r\n\r\n");
		return 1;
	}
	strcpy(szFilePath, pEnvString);
	strcat(szFilePath, FILE_LOCATION);
	strcat(szFilePath, FILE_NAME);
	fp = fopen(szFilePath, "rb");
	if(!fp)
	{	printf("**********Error, unable to open file!**********\r\n\r\n");
		return 2;
	}
	count = fread(Buffer, 1, 4096, fp);
	fclose(fp);
	if(count == 0)
	{	printf("**********Error, unable to read file!**********\r\n\r\n");
		return 3;
	}
	pSubstring = strstr(Buffer, SEARCH_STRING);
	if(!pSubstring)
	{	printf("**********Error, unable to find string!**********\r\n\r\n");
		return 4;
	}
	// Increment revision number
	if(*(pSubstring + strlen(SEARCH_STRING)) == ' ')
		*(pSubstring + strlen(SEARCH_STRING)) = 'A';
	else
		++(*(pSubstring + strlen(SEARCH_STRING)));
	c = *(pSubstring + strlen(SEARCH_STRING));
	fp = fopen(szFilePath, "wb");
	if(!fp)
	{	printf("**********Error, unable to open output file!**********\r\n\r\n");
		return 5;
	}
	count2 = fwrite(Buffer, 1, count, fp);
	fclose(fp);
	if(count2 < count)
	{	printf("**********Error writing output file!**********\r\n\r\n");
		return 6;
	}
	printf("Partial code successfully updated to \"%c\".\r\n\r\n", c);

	return 0;
}

