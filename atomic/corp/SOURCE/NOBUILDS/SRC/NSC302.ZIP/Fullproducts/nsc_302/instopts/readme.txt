******************************************************************
INSTOPTS.EXE                                            README.TXT
Copyright (c) 1998 Symantec Corporation                 June 1998
******************************************************************

INSTOPTS.EXE is a utility program used by NSC. As part of NSC
installation, separate versions of INSTOPTS.EXE are copied to
the following folders on the NSC console machine:

   ...\NSC Repository\Products\Nav\Nav95\Options
   ...\NSC Repository\Products\Nav\Navntsrv\Options\Intel
   ...\NSC Repository\Products\Nav\Navntsrv\Options\Alpha
   ...\NSC Repository\Products\Nav\Navntwks\Options\Intel

The only function of INSTOPTS.EXE is to read the registry on target
machines to locate Norton AntiVirus, then copy files from the folder
where INSTOPTS resides to the Norton AntiVirus folder on the
target. For example, INSTOPTS is used with options files (.DAT) 
distribution jobs. See the Norton AntiVirus Solution Implementation
Guide, Chapter 2 for more information about creating a Norton
AntiVirus options distribution job.

Do not run INSTOPTS.EXE at any other time or all files located
in the same folder as INSTOPTS.EXE will be copied to the Norton 
AntiVirus folder.
******************************************************************
			    End of File
******************************************************************
