//------------------------------------------------------------------------------
//
//      Version.h 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#ifdef _MSC_VER
	#if _MSC_VER == 800	/* MSC v1.52 */
		#pragma warning(disable: 4001)	/* C++ Comments */
	#endif
#endif // _MSC_VER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined __cplusplus
extern "C" {
#endif // __cplusplus

#if defined NLM // || defined WIN32 || defined DOS
typedef char		*Vstr;
typedef const char	*Cstr;
#else
typedef char _far	*Vstr;
typedef const char	*Cstr;
#endif

// VDBVersion --------------------------------------------------------------------------
// Returns the version number of the Virus DataBase.

// Input:
//	name:	VDB container file name (with or without a path) or a version string
//		IBM:	"VPnnvv",		e.g., "Vp30bs"		"C:\Program Files\nav\vp30bs.vdb"
//		NAV:	"VDnnnnnn"		e.g., "vd00fe00"	"C:\Program Files\nav\vd00fe00.vdb"
//		Trend:	"LPT$VPN.nnn"	e.g., "LPT$VPN.364"	"C:\Program Files\nav\LPT$VPN.364"

// Return:
//	0:		name is invalid or NULL
//	version

unsigned long			 VDBVersion(
	Cstr					 name);

// VDBVersionString --------------------------------------------------------------------
// Returns file name for the version number of the Virus DataBase.

// Input:
//	version:	Version number of the Virus DataBase
//	vendor:		Vendor string, "NAV" or ""
//	maxLen:		The size of the output buffer, MUST be >= 50 (for NLS)
//	fileName:	If non zero return VDB file name; otherwise return version string

// Return:
//	0:			Success, out contains VDB version converted to a file name
//	1:			Returns 1 if version is 0
//	2:			Returns 2 if vendor and/or version is invalid

unsigned char			 VDBVersionString(
	unsigned long			 version,
	Cstr					 vendor,
	Vstr					 out,
	int						 maxLen,
	int						 fileName);

// VEVersionString ---------------------------------------------------------------------
// Returns the version number of the Virus Engine as a string

// Input:
//	version:	Version number of the Virus Engine
//	vendor:		Vendor string, i.e., "IBM", "NAV", or ""
//	maxLen:		The size of the output buffer, MUST be >= 8

// Return:
//	0:			Success, out contains engine version converted to a string
//	1:			Returns 1 if version is 0
//	2:			Returns 2 if vendor and/or version is invalid

unsigned char			 VEVersionString(
	unsigned long			 version,
	Cstr					 vendor,
	Vstr					 out,
	int						 maxLen);

#if defined __cplusplus
}
#endif // __cplusplus

////////////////////////////////////////////////////////////////////////////////////////
