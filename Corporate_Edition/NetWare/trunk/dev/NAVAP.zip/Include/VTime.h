// VTime.h: interface for the CVTime class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VTIME_H__171ABA31_AC22_11D0_BF89_00A0C926E0E1__INCLUDED_)
#define AFX_VTIME_H__171ABA31_AC22_11D0_BF89_00A0C926E0E1__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "transman.h"
#include "VPString.h"	// Added by ClassView

#if !defined( __CLNTCON ) && !defined( __SRVCON) && !defined(__LDVPOCX)
#define CVPString	CString
#endif

class CVTime  
{
public:
	CVPString ConvertToDateString();
	CVPString ConvertToTimeString();
	static int vtimecmp(CVTime t1, CVTime t2);
	CVPString ConvertToTimeDateString();
	BOOL ConvertFromCtrlStrings( CVPString date, CVPString time );
	BOOL ConvertToCtrlStrings( CVPString& date, CVPString& time );
	
	CVTime();
	CVTime(DATE);
	CVTime(CVPString);
	CVTime(VTIME *time);
	CVTime(DWORD t);
	
	operator CVPString();
	operator DATE();
    operator VTIME();

	virtual ~CVTime();

	BYTE m_Year;
	BYTE m_Month;
	BYTE m_Day;
	BYTE m_Hour;
	BYTE m_Min;
	BYTE m_Sec;
	BYTE m_padding1;
	BYTE m_padding2;
};

#endif // !defined(AFX_VTIME_H__171ABA31_AC22_11D0_BF89_00A0C926E0E1__INCLUDED_)
