#ifndef __THREAD_POOL_H_
#define __THREAD_POOL_H_

#define MIN_UPDATE_CLIENT_FILE_THREADS  1
#define DEFAULT_UPDATE_CLIENT_FILE_THREADS  5
#define MAX_UPDATE_CLIENT_FILE_THREADS  40

// client performance counters

typedef struct tagTHREAD_POOL
{
    int     nThreadNumber;
    int    *lpnMaxThreadNumber;

    char    szThreadName[58];
    
    DWORD   dwThreadId;
    HANDLE  hThread;

    time_t  tStartTime;
    time_t  tStopTime;

    BOOL    bRunning;
    BOOL    bExited;

}   THREAD_POOL, 
  *PTHREAD_POOL;

void CreateThreadPool( char *szBaseThreadName, THREAD fThreadProc, 
                       char *RegKeyForThreadCount, int nMinThreadCount, int nDefaultThreadCount, int nMaxThreadCount, 
                       THREAD_POOL ThreadPool[], int *lpnMaxPoolThreads );
void ThreadPoolThreadStarting( THREAD_POOL *ThreadPoolEntry );
void ThreadPoolThreadEnding( THREAD_POOL *ThreadPoolEntry );
BOOL ThreadPoolThreadShouldExit( THREAD_POOL *ThreadPoolEntry );

#endif // __THREAD_POOL_H_


