//------------------------------------------------------------------------------
//
//      FileTime.h 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#ifndef __FINE_TIME_H_
#define __FINE_TIME_H_

enum FineLinearTimeModes { TICKS, MILLISECONDS, DECIMILLISECONDS };

void SetFineLinearTimeMode( int nMode );
//DWORD ElapsedFineLinearTime( DWORD dwStartTime, DWORD dwEndTime );
DWORD GetFineLinearTime( VOID );

#endif // __FINE_TIME_H_


