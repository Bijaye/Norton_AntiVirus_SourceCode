////////////////////////////////////////////////////////////
// NAV Global Macro Header File	
//
// Copyright (C) 1999 Symantec Corporation. 
//          All rights reserved.

#ifndef _NAV_GLOBAL_MACROS
#define _NAV_GLOBAL_MACROS


// Generic useful macros
#define NAVFree(p)				{if (p) {free(p); p = NULL;}}


#endif // _NAV_GLOBAL_MACROS 
