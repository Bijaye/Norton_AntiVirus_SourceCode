//------------------------------------------------------------------------------
//
//      TrckAllc.h 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#if !defined _TckAlloc_h_
#define _TckAlloc_h_

#if defined TrackAlloc
#if !defined VENG
	#define pVOID			void *
	#define pVESTR			char *
	#define VEuint4			unsigned long
#endif // VENG

	#define calloc(n, s)			 TAcalloc(n, s, __FILE__, __LINE__)
	#define malloc(s)				 TAmalloc(s, __FILE__, __LINE__)
	#define realloc(o, s)			 TArealloc(o, s, __FILE__, __LINE__)
	#define strdup(s)				 TAstrdup(s, __FILE__, __LINE__)
	#define free(p)					 TAfree(p, __FILE__, __LINE__)
	#define locTAP				   , pVESTR fileName, VEuint4 lineNumber

pVOID						 TAcalloc(
	size_t						 number,
	size_t						 size,
	pVESTR						 fileName,
	VEuint4						 lineNumber);

void						 TAfree(
	pVOID						 address,
	pVESTR						 fileName,
	VEuint4						 lineNumber);

pVOID						 TAmalloc(
	size_t						 size,
	pVESTR						 fileName,
	VEuint4						 lineNumber);

pVOID						 TArealloc(
	pVOID						 oldAddress,
	size_t						 size,
	pVESTR						 fileName,
	VEuint4						 lineNumber);

pVESTR						 TAstrdup(
	const pVESTR				 string,
	pVESTR						 fileName,
	VEuint4						 lineNumber);

#else // !TrackAlloc
/*
#if defined WIN16 && !defined DoNotDefinemallocAsAllocGlobal
	#define calloc(x, y)			 GlobalAllocPtr(GHND, (DWORD)x * (DWORD)y)
	#define free(x) 				 GlobalFreePtr((LPVOID)x)
	#define malloc(x)				 GlobalAllocPtr(GHND, (DWORD)x)
	#define realloc					 Cannot_Realloc_In_Win16
	#define strdup					 Cannot_Strdup_In_Win16
#endif // WIN16
*/
	#define locTAP

#endif // TrackAlloc
#endif // _TckAlloc_h_
