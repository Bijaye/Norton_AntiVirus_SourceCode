//------------------------------------------------------------------------------
//
//      Misc.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

//#ifndef NLM
//#include <rpc.h>
//#endif

//#include <tchar.h>
#include "pscan.h"
//#include "pushmult.h" // client stuff
#include "finetime.h"

#define _SPV(z) #z
#define SPV(z) _SPV(z)

#define UUID_SIZE 64

//#ifdef NLM
BOOL IsWinNT() { return FALSE ; };
//#endif


//#ifdef SERVER
static HANDLE Mutex = 0;

/**
#ifdef WIN32

#ifdef NLM
#include <nwenvrn.h>
//BOOL IsWinNT() { return FALSE ; };
#endif


//============================================================================
static void StartCS(void)
{
    if ( Mutex == 0 )
        Mutex = CreateMutex(NULL,FALSE,NULL);

    WaitForSingleObject(Mutex,INFINITE);
}
//============================================================================
static void EndCS(void)
{

    ReleaseMutex(Mutex);
}

#endif  // WIN32
#endif  // SERVER

*/

char version[]= "VeRsIoN=" SPV(MAINPRODUCTVERSION) "." SPV(SUBPRODUCTVERSION) " Build (" SPV(BUILDNUMBER) ")\n   Norton AntiVirus";
//#include "commisc.c"

/*
#ifdef WIN32
#include "language.c"

#ifndef COPYSRV

// Windows 2000 related

#include "shfolder.h"
#include "sharedver.h"

typedef HRESULT (WINAPI *PFNSHGetFoldPathA)(HWND hwndOwner, int nFolder, HANDLE hToken, DWORD dwFlags, LPTSTR pszPath);


#if defined(WIN32) 
#if defined(SERVER) || defined(CLISCAN) || defined(CLIPROXY)
BOOL CreateUserDataPath(LPTSTR szUserDataDir);
//BOOL    DirectoryExists(LPTSTR lpDir);
extern char CurrentUserName[NAME_SIZE];
#endif // defined(SERVER) || defined(CLISCAN)
#endif // defined(WIN32) 

#endif // COPYSRV

// End Windows 2000

#endif  // WIN32
**/

//#include "PerfCounters.h"       // symantec performance counter structures

//VPREG VpRegBase[30] = VP_REG_BASE_TABLE;
//VPREG VpRegBaseOld[30] = VP_REG_BASE_TABLE_OLD;

// static performance and tracking data - this is accessible
// via Get*PerfCounters() and Clear*PerfCounters()

//static CLIENT_CHECKIN_PERF_CNTRS ClientCheckIn = {sizeof(ClientCheckIn), 0};

DWORD ResumableFileCopy(char *FromComputer,char *FromPath,char *ToComputer,char *ToPath,DWORD Flags);

/********************************************************************************************************/


int _my_chmod(const char *path, int func , int attrib)
{
/*
#ifdef WIN32
    DWORD old = GetFileAttributes(path);

    if ( func )
        SetFileAttributes(path,attrib);
    return old;
#endif
*/

//#ifdef NLM
    if ( func )
    {
        return chmod(path,attrib);
    }
    else
    {
        struct stat s;
        if ( stat(path,&s) != 0 )
            return 0;

        return s.st_mode; // needs fixing must return currecy value stat
    }
//#endif
}



// ksr
//#if defined(SERVER) || defined(CLISCAN) || defined(TRANSMAN) || defined(CLIPROXY) || defined(NLMCGI)

/***********************************************************************************************************/
/****************************************************************************************/

void maketimeout(char *str)
{

    DWORD t = time(NULL);
    char num[32];

    t /= 60L*60L*24L;

    wsprintf(num,"%07u",t);
    // ??? ksr  MakeLicense(str,num,5);
}


//============================================================================

DWORD CheckTimeOut(BOOL *timeout)
{
/**
#ifdef WIN32
    HKEY hkey;
    HKEY hkey2;
#endif // WIN32
**/
    DWORD cc = 0;
    char szLicense[32];
    char num[16];
    //HKEY hmkey;

/**
    //cc = RegOpenKey(HKEY_LOCAL_MACHINE,REGHEADER,&hmkey);

    //if ( cc != ERROR_SUCCESS )
    //    bad:
    //    return 0x80000000;

    //PutVal(hmkey,"CopyControl",
#ifdef TDK
           1
#else
           0
#endif
          );

#ifndef TDK

    GetStr(hmkey, "LicenseNumber",szLicense,sizeof(szLicense),"");
    RegCloseKey(hmkey);

    cc = GetLicenseType(szLicense);

    if ( !cc )
        goto bad;

    switch ( cc )
    {
        case LIC_60_CLIENT_TDK:
        case LIC_60_TDK:
#endif

#ifdef WIN32

            if ( RegCreateKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\VersionControl",&hkey) != ERROR_SUCCESS )
                goto bad;

            GetStr(hkey, TDKBUILD, szLicense,sizeof(szLicense),"");
            if ( NumBytes(szLicense) != 16 || szLicense[6] != '-' || szLicense[11] != '-' )
            {
                if ( RegCreateKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer",&hkey2) != ERROR_SUCCESS )
                    goto bad;

                GetStr(hkey2,"",szLicense,sizeof(szLicense),"");
                if ( szLicense[0] == 0 )
                {
                    maketimeout(szLicense);
                    PutStr(hkey, TDKBUILD, szLicense);
                    PutStr(hkey2,"","1");
                }
                else
                    StrCopy(szLicense,"000nt4-82bn-07nv");
                RegCloseKey(hkey2);
            }

            RegCloseKey(hkey);
#endif // WIN32

**/

    switch ( cc )
    {
        case LIC_60_CLIENT_TDK:
        case LIC_60_TDK:

//#ifdef NLM
            {
                FILE *file = fopen(NW_SYSTEM_DIR"\\NV"TDKBUILD".DAT","rt");
                if ( file )
                {
                    fgets(szLicense,32,file);
                    fclose(file);
                    szLicense[16]=0;
                    if ( szLicense[6] != '-' || szLicense[11] != '-' )
                    { // check for corruption
                        unlink(NW_SYSTEM_DIR"\\NV"TDKBUILD".DAT");
                        //goto xx;
                    }
                }
                else
                {
                    xx:             file = fopen(NW_SYSTEM_DIR"\\NV"TDKBUILD".DAT","wt");
                    if ( !file )
                        // goto bad;
                        ;
                    maketimeout(szLicense);
                    fputs(szLicense,file);
                    fclose(file);
                }
            }
//#endif // NLM
/*
#ifdef WIN16
            GetPrivateProfileString("VersionControl",TDKBUILD,"",szLicense,sizeof(dzLicense));
            szLicense[16]=0;
            if ( szLicense[0] = 0 || szLicense[6] != '-' || szLicense[11] != '-' )
            { // check for corruption
                maketimeout(szLicense);
                WriteProfileString("VersionControl",TDKBUILD,szLicense);
//              WriteProfileString("intl","iRzero",szLicense,"WINVTDKI.BIN");
            }

#endif // WIN16
*/
            if ( !StrComp(szLicense,"000nt4-82bn-07nv") )
            {
                return 0xc0000000;
            }


            // ??? ksr   cc = GetLicenseType(szLicense);

            memcpy(&num[0],&szLicense[0] ,3);
            memcpy(&num[3],&szLicense[12],2);
            memcpy(&num[5],&szLicense[7] ,2);
            num[7] = 0;

            if ( cc != LIC_TIMEOUT )
                //goto bad;
                ;

            cc = atoi(num);
            cc *= 24*60*60;
            if ( cc + DAYS*60L*60L*24L < (DWORD)time(NULL) )
            {
                StrCopy(szLicense,"000nt4-82bn-07nv");
/**
#ifdef WIN32
                RegCreateKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\VersionControl",&hkey);
                if ( hkey == 0 )
                    goto bad;

                PutStr(hkey, TDKBUILD, szLicense);
                RegCloseKey(hkey);
#endif
**/
//#ifdef NLM
                {
                    FILE *file = fopen(NW_SYSTEM_DIR"\\NV"TDKBUILD".DAT","wt");
                    if ( file )
                    {
                        fputs(szLicense,file);
                        fclose(file);
                    }
                }
//#endif

/*
#ifdef WIN16
                WriteProfileString("VersionControl",TDKBUILD,szLicense);
#endif
*/
                if ( timeout )
                    *timeout = 1;
                return 0xc0000000;
            }

            if ( timeout )
                *timeout = 1;
            return DAYS - ((time(NULL)-cc)/(60L*60L*24L));
// ksr ???            
//#ifndef TDK
        case LIC_60_REAL:  // normal
            return 0;

//      case LIC_60_BETA:
//          if  (time(NULL) > 846831600) { // 8-31-97
//              if (timeout)
//                  *timeout = 1;
//              return -1;
//              }

        case LIC_60_CLIENT_OEM:
        case LIC_60_CLIENT_GOLD:
        case LIC_60_CLIENT:
        case LIC_60_GOLD:
        case LIC_60_20PACK:
            return 0;

    // goto bad;
//#endif

    }
}


/******************************************************************************/
BOOL ScanRunning(DWORD Status)
{

    if ( Status == S_DONE ||Status == S_NEVER_RUN || Status == S_ABORTED )
        return FALSE;
    return TRUE;
}
/****************************************************************************************/



//#if defined(SERVER) || defined(CLISCAN) || defined(TRANSMAN) || defined(CLIPROXY) || defined(NLMCGI)

/******************************************************************/
/*
VOID VPSendMessage(MESSAGES *mess,char *format,...)
{

    va_list marker;
    char line[1024];

    va_start(marker, format);
    vsprintf(line,format,marker);
    mess->Table->Send(mess,line);
    va_end(marker);
}
*/


DWORD MakeSidFalse(PSID sid)
{

    char user[NAME_SIZE],computer[NAME_SIZE];

    if ( sid )
    {
        if ( *(DWORD*)sid == 0xffffffff )
            return ERROR_SUCCESS;

        GetNames(sid,user,computer);
        MakeFalseSid(sid,user,computer);
    }

    return ERROR_SUCCESS;
}

/****************************************************************************************/

DWORD MakeFalseSid(PSID sid,char *User,char *Computer)
{

    int size = sizeof(mSID)-sizeof(DWORD); // 252 bytes
    char line[sizeof(mSID)-sizeof(DWORD)+5]; // 257 bytes
    char user[NAME_SIZE],computer[NAME_SIZE]; // 48 bytes each
    //int len;

    /*if ((int)(strlen(User) + strlen(Computer)) <= size-1)
        len = size;
    else {
        len = size/2;
        }*/

    strncpy(user,User,NAME_SIZE);
    strncpy(computer,Computer,NAME_SIZE);

    // Make sure we have terminating NULLs since strncpy
    // doesn't do this if the source is longer than the
    // dest buffer
    if ( strlen(User) > (NAME_SIZE-1) )
        user[NAME_SIZE-1] = '\0';
    if ( strlen(Computer) > (NAME_SIZE-1) )
        computer[NAME_SIZE-1] = '\0';

    WSprintf(line,"%s\x1%s",user,computer);

    *(DWORD *)sid = 0xffffffff;
    strncpy((char *)sid + sizeof(DWORD),line,size);

    return ERROR_SUCCESS;
}



#if 0




/******************************************************************************/
DWORD T_BlockToProgress(PT_SCAN_STATUS block,PROGRESSBLOCK *pb)
{

    memset(pb,0,sizeof(PROGRESSBLOCK));

    pb->Size = sizeof(PROGRESSBLOCK);
    pb->Status = block->Status;
    pb->StartTime = block->StartTime;
    pb->Dirs = block->Dirs;
    pb->Files = block->Files;
    pb->Scanned = block->Scanned;
    pb->Infected = block->Infected;
    pb->Viruses = block->Viruses;
    pb->NotOpen = block->NotOpen;
   // pb->logger = block->logger;
    strcpy(pb->CurrentFile,block->CurrentFile);

    return ERROR_SUCCESS;
}
/******************************************************************************/
DWORD ProgressToBlock(PROGRESSBLOCK *pb,PSCAN_STATUS block)
{

    block->Status = pb->Status;
    block->StartTime = pb->StartTime;
    block->Dirs = pb->Dirs;
    block->Files = pb->Files;
    block->Scanned = pb->Scanned;
    block->Infected = pb->Infected;
    block->Viruses = pb->Viruses;
    block->NotOpen = pb->NotOpen;
   // block->logger = pb->logger;
    strcpy(block->CurrentFile,pb->CurrentFile);

    return ERROR_SUCCESS;
}




#endif 0



/**************************************************************************************
/  void GetNames(PSID pSid,char *UserName,char *ComputerName)
/
/
/   mmendon 05-17-2000   local and passed in buffers are now initialized to empty strings
/                        All current uses of GetNames() have been checked, and are okay
/                        with this change.
/
***************************************************************************************/
void GetNames(PSID pSid,char *UserName,char *ComputerName)
{
    SID_NAME_USE peUse;
    DWORD namesize;
    DWORD domainsize;
    char ubuf[NAME_SIZE] = {0};  // MMENDON 02-17-2000: fix for STS defect 332912

    char dbuf[NAME_SIZE] = {0};  //                    initing buffers
    char str[IMAX_PATH]  = {0};  // MMENDON 02-17-2000: end fix for STS defect 332912
//#if defined(SERVER) || defined (CLISCAN)
    mSID SID;

    if ( !pSid )
    {
        if ( GetSid((PSID)&SID) )
            pSid = (PSID)&SID;
    }
//#endif

    namesize = NAME_SIZE;
    domainsize = NAME_SIZE;
    // MMENDON 02-17-2000: fix for STS defect 332912
    //                     If valid buffers are passed in,initing them to
    //                     empty strings so if we fail in this function
    //                     weird values are not returned.

    if ( UserName )
        UserName[0] = '\0';
    if ( ComputerName )
        ComputerName[0] = '\0';
    // MMENDON 02-17-2000: end fix for STS defect 332912

    if ( pSid )
    {
        if ( *(DWORD *)pSid == 0xffffffff )
        {  // it's a false sid
            char *line = (char *)pSid + sizeof(DWORD);
            char *q;
            StrNCopy(str,line,IMAX_PATH);
            q = StrChar(str,1);
            if ( q )
            {
                *q = 0;
                if ( ComputerName )
                    strncpy(ComputerName,q+1,NAME_SIZE);
            }
            if ( UserName )
                strncpy(UserName,str,NAME_SIZE);
            if ( q )
                *q = 1;
        }
        else
        {
            LookupAccountSid(NULL,pSid,UserName==NULL?ubuf:UserName,&namesize,ComputerName==NULL?dbuf:ComputerName,&domainsize,&peUse);
            if ( ComputerName )
            {
/*
//#ifdef CLISCAN  // removing CLISCAN's dependency on NTS.lib

                DWORD s = NAME_SIZE;

                GetComputerName(ComputerName,&s);
//#else
*/
					 // ksr
                //NTSGetComputerName(ComputerName,NULL);
                GetFileServerName( 0, ComputerName );
//#endif
            }

        }
    }

}
/*************************************************************************************************************************************/





#if 0


//#if defined(SERVER) || defined(CLISCAN)
/*************************************************************************************************************************************/
DWORD VerifyPatternType(DWORD Type)
{

    char szLicense[32];
    DWORD cc;

    //GetStr(hMainKey, "LicenseNumber",szLicense,sizeof(szLicense),"");
   // ??? ksr    cc = GetLicenseType(szLicense);

    dprintf("Product Type = %u, Pattern Type = %u\n",cc,Type);

    switch ( cc )
    {
        case LIC_CLIENT_SIG:      cc = 0;   break;
        case LIC_60_TDK:          cc = 0;   break;
        case LIC_60_REAL:         cc = 0;   break;
        case LIC_60_GOLD:         cc = 0;   break;
        case LIC_60_BETA:         cc = 0;   break;
        case LIC_60_20PACK:       cc = 0;   break;
        case LIC_60_CLIENT_OEM:   cc = Type==62?0:ERROR_PATTERN_NOT_ALLOWED; break;
        case LIC_60_CLIENT_OEM_FREE:  cc = 0; break;
        case LIC_60_CLIENT_TDK:   cc = 0;   break;
        case LIC_60_CLIENT_GOLD:  cc = 0;   break;
        case LIC_60_CLIENT:       cc = 0;   break;
        case LIC_60_CLIENT_WEB:   cc = Type==64?0:ERROR_PATTERN_NOT_ALLOWED; break;
        case LIC_60_CLIENT_WEB_FREE:   cc = 0; break;
        default:                  cc = ERROR_PATTERN_NOT_ALLOWED;   break;
    }

    return cc;
}
/******************************************************************/
/*
int maccess(char *path)
{

    HANDLE han;
    WIN32_FIND_DATA fd;

    han = FindFirstFile(path,&fd);
    if ( han == INVALID_HANDLE_VALUE )
        return -1;

    FindClose(han);
    return 0;
}
*/

/**************************************************************************************/

DWORD FindPattPath(char *path)
{

    char    *end;
    DWORD   dwRet = 0;
    DWORD   dwClientType = 0;

    // Get the client type
    dwClientType = GetVal(hMainKey,"ClientType",0);

    // Are we a client running on Windows NT?
    if ( IsWinNT() && dwClientType == CLIENT_TYPE_CONNECTED || dwClientType == CLIENT_TYPE_STANDALONE )
    {
        // Yep. Set the path to the Windows NT common app data directory
        dwRet = GetAppDataDirectory( NAV_COMMON_APP_DATA , path ) ;
    }
    else
    {
        // Use the install/home dir in all other cases
        StrCopy(path,HomeDir);
    }

    end = &path[NumBytes(path)];
    strcat(path,"\\");
    strcat(path,GetPatternSearch());

    if ( maccess(path) )
    {
        dwRet = P_NO_PATH;
    }

    *end = 0;
    return dwRet;
}

#endif // 0




/******************************************************************************/
DWORD AddNoScanDir(NOSCANDIR **list,char *StorageName,DWORD ID,char *Path,BOOL children)
{

    NOSCANDIR *cur;

    cur = malloc(sizeof(NOSCANDIR));
    if ( cur == NULL )
        return ERROR_MEMORY;

    StrCopy(cur->StorageName,StorageName);
    cur->ID = ID;
    cur->Path = malloc(NumBytes(Path)+1);

    if ( cur->Path == NULL )
    {
        free(cur);
        return ERROR_MEMORY;
    }

    StrCopy(cur->Path,Path);
    cur->Children = children;

    cur->Next = *list;
    *list = cur;

    return ERROR_SUCCESS;
}


/********************************************************************************/
// Function will return TRUE if the given path(Current dir) is a sub path of source(Dir to Exclude).
BOOL isSubPath(char *path,char *source,BOOL children)
{
    int len = NumBytes(source);

    if ( len )
    {
        if ( children )
        {
            if ( !strnicmp(path,source,len) )
                if ( path[len] == '/' || path[len] == '\\' || path[len] == 0 )
                    return TRUE;
        }
        else
        {
            if ( !stricmp(path,source) )
                return TRUE;
        }
    }
    else
    {
        // If the source has no length then it must be excluding the whole drive
        return TRUE;
    }


    return FALSE;
}

/******************************************************************************/

BOOL isNoScanDir(NOSCANDIR *cur,PSTORAGEINFO info,DWORD ID,char *path)
{

//  char path[IMAX_PATH];
//  char *q;

    while ( cur )
    {
        if ( !StrComp(info->Name,cur->StorageName) && ID == cur->ID )
        {
            if ( isSubPath(path,cur->Path,cur->Children) )
                return cur->Children?TRUE|0x80000000:TRUE;
        }
        cur = cur->Next;
    }

    return FALSE;
}


/******************************************************************************/

DWORD PreReadNoScanDirs(//HKEY hmkey,
                        NOSCANDIR **cur)
{

    char line[IMAX_PATH];
    PSTORAGEITEM Item;
    DWORD ID;
    DWORD index=0;
    char *str;
    //HKEY hkey;
    BOOL first = TRUE;

    if ( *cur )
    { // free old stuff
        NOSCANDIR *y,*x = *cur;
        while ( x )
        {
            y = x->Next;
            free(x->Path);
            free(x);
            x = y;
        }
        *cur = NULL;
    }

    //if ( hmkey == NULL )
    //    return ERROR_SUCCESS;

    str = line;
    //GetStr(hmkey,"MoveDir",str,sizeof(str),"");
    if ( *str )
    {
        Item = GetStorageAndIDFromPath(&str,&ID);
        if ( Item )
        {
            AddNoScanDir(cur,Item->Name,ID,str,1);
        }
    }

    str = line;
    //GetStr(hmkey,"TmpDir",str,sizeof(str),"");
    if ( *str )
    {
        Item = GetStorageAndIDFromPath(&str,&ID);
        if ( Item )
        {
            AddNoScanDir(cur,Item->Name,ID,str,1);
        }
    }

    again:
    //if ( GetVal(hmkey,"HaveExceptionDirs",0) )
    {
        //if ( RegOpenKey(hmkey,"NoScanDir",&hkey) == ERROR_SUCCESS )
        {
            DWORD cb = IMAX_PATH;
            DWORD cb2 = sizeof(DWORD);
            DWORD children = 0;
            str = line;
            //while ( RegEnumValue(hkey,index++,str,&cb,0,NULL,(BYTE*)&children,&cb2) == ERROR_SUCCESS )
            {
                Item = GetStorageAndIDFromPath(&str,&ID);
                if ( Item )
                {
                    AddNoScanDir(cur,Item->Name,ID,str,children);
                }
                cb = IMAX_PATH;
                cb2 = sizeof(DWORD);
                str = line;
            }
            //RegCloseKey(hkey);
        }
        /** ksr ???
        else if ( !first )
        {
            //hmkey = GetCommonKey();
            first = FALSE;
            index = 0;
            goto again;
        }
        */
    }

    return ERROR_SUCCESS;
}


///////////////////////////////////////////////////////////////////////////////
//
// Function name: Within
//
// Description  : This function compares two numbers (which represent time in
//                minutes) and checks if the second number is at least within
//                2 min of the first number.
//
// Parameters:    [in]  - DWORD minSch - The scheduled time in minutes.
//                [in]  - DWORD minNow - The current time in minutes.
//  
// Return Values: Returns TRUE if it is within, FALSE if it isn't.
//
///////////////////////////////////////////////////////////////////////////////
// 2/5/2001 - JCHEN: Comments added 
///////////////////////////////////////////////////////////////////////////////
BOOL Within(DWORD minSch,DWORD minNow)
{

    return(minSch <= minNow && minSch+1 >=  minNow); // do event within 2 min of start time.
}



///////////////////////////////////////////////////////////////////////////////
//
// Function name: IsItTime
//
// Description  : This function will compare a time obtained from a registry
//                setting and the actual current time, and indicate whether
//                the times match.
//
// Parameters:    [in]  - HKEY hkey: the handle to the registry key that
//                        contains a 'Schedule' key.
//  
// Return Values: Returns TRUE if times match, FALSE if they do not.
//
///////////////////////////////////////////////////////////////////////////////
// 2/5/2001 - JCHEN: Comments added 
///////////////////////////////////////////////////////////////////////////////
BOOL IsItTime()//HKEY hkey)
{

    BOOL    ret=FALSE;
    DWORD   curTime = time(NULL); //curTime stores the time as a total sum of minutes in the day.
    struct  tm *ptm = localtime((time_t *)&curTime); // ptm stores the time in a structure in its parts
    DWORD   type = 0;
    DWORD   dwMinOfDay;
    DWORD   dwDayOfWeek;
    DWORD   dwDayOfMonth;

	// If the Scheduled Even isn't enables, just exit out.
    //if ( GetVal(hkey,"Schedule\\Enabled",1) == 0 )
    //    return FALSE;

	// If the scheduled event has a value called 'YES' and it is equal to '1', run the event.
    /*
    if ( GetVal(hkey,"Schedule\\YES",0) == 1 )
    {
		// Reset the 'YES' value to 0.
        PutVal(hkey,"Schedule\\YES",0);
        return TRUE;
    }
    */
    
    // Get scheduled values or randomized values as appropriate
    GetTimeValues(//hkey,
                  &dwMinOfDay,
                  &dwDayOfWeek,
                  &dwDayOfMonth);

	// Within will actually do the time comparisons, checking if the reg key time and the actual time match.
    if ( Within(dwMinOfDay,ptm->tm_min + ptm->tm_hour*60) )
    {
		// Find out the frequency of the Scheduled Event.
        //type = GetVal(hkey,"Schedule\\Type",0);
        switch ( type )
        {
			// If it is daily, run it, no questions asked.
			// If it is weekly, check to see if the day of the week matches.
			// If it is monthly, check to see if we are on the correct day of the month. 
            case S_NONE: default: break;
            case S_DAILY: ret = TRUE; break;
            case S_WEEKLY: if ( (int)dwDayOfWeek == ptm->tm_wday ) ret = 1;break;
            case S_MONTHLY: if ( (int)dwDayOfMonth == ptm->tm_mday ) ret = 1;break;
        }
    }
    else // We do not have matching times, but we need to check if MissedEvents is turned on and should be dealt with.
        if ( TRUE == MissedEvent(//hkey,
                                 curTime,&dwMinOfDay,&dwDayOfWeek,&dwDayOfMonth) )
        return TRUE;

    if ( ret ) // Scan should occur, but make one last check...
    {
		// We don't want the scan to occur twice in a row, which could happen if we get through this code
		// twice in a minute.  So make sure we are not within 5 minutes of the LastStart time before running scan.
		// Otherwise, run the scan, and record the LastStart time in the registry.
        if ( curTime //- GetVal(hkey,"Schedule\\LastStart",0) 
                < 5*60 )
            ret = FALSE;
        //else
            //PutVal(hkey,"Schedule\\LastStart",curTime);
    }

    return ret;
}



///////////////////////////////////////////////////////////////////////////////
//
// Function name: GetTimeValues
//
// Description  : This function will grab and store the time values for a
//                scheduled event from the registry.
//
// Parameters:    [in]  - HKEY hkey: the handle to the registry key that
//                        contains a 'Schedule' key.
//                [out] - DWORD* pdwMinOfDay:   Will store the minute of the
//                        day read from Registry.
//                [out] - DWORD* pdwDayOfWeek:  Will store the day of the week
//                        read from Registry.
//                [out] - DWORD* pdwDayOfMonth: Will store the day of the month
//                        read from Registry.
//  
// Return Values: None.
//
///////////////////////////////////////////////////////////////////////////////
// 2/5/2001 - JCHEN: Function Description added 
///////////////////////////////////////////////////////////////////////////////
void GetTimeValues( //HKEY hkey,
                    DWORD* pdwMinOfDay,
                    DWORD* pdwDayOfWeek,
                    DWORD* pdwDayOfMonth )
{
    // Initialize these to the scheduled values
    //*pdwMinOfDay = GetVal(hkey, "Schedule\\MinOfDay", 0xffffffff);
    //*pdwDayOfWeek = GetVal(hkey,"Schedule\\DayOfWeek",0);
    //*pdwDayOfMonth = GetVal(hkey,"Schedule\\DayOfMonth",0);

    // Determine if randomization is enabled
    /*
    if ( TRUE == GetVal(hkey, "Schedule\\RandomizeDayEnabled", FALSE) ||
         TRUE == GetVal(hkey, "Schedule\\RandomizeWeekEnabled", FALSE) ||
         TRUE == GetVal(hkey, "Schedule\\RandomizeMonthEnabled", FALSE) )
    {
        // It is, so see if we need to generate and store the random number
        //if(TRUE == GetVal(hkey, "Schedule\\RandomizationGenerate", FALSE))
        DWORD genFlags=0;

        genFlags = GetVal(hkey, "Schedule\\RandomizationGenerate", FALSE);

        if ( genFlags ) // We do need to generate them.
        {
            GenerateRandomValues(genFlags,
                                 GetVal(hkey,"Schedule\\Type",0),
                                 GetVal(hkey, "Schedule\\RandomizeDayRange", 60),
                                 GetVal(hkey, "Schedule\\RandomizeWeekStart", 1),
                                 GetVal(hkey, "Schedule\\RandomizeWeekEnd", 5),
                                 GetVal(hkey, "Schedule\\RandomizeMonthRange", 10),
                                 pdwMinOfDay,
                                 pdwDayOfWeek,
                                 pdwDayOfMonth);

            // and store them
            PutVal(hkey, "Schedule\\RandomizedMinOfDay", *pdwMinOfDay);
            PutVal(hkey, "Schedule\\RandomizedDayOfWeek", *pdwDayOfWeek);
            PutVal(hkey, "Schedule\\RandomizedDayOfMonth", *pdwDayOfMonth);
            // and clear flag
            PutVal(hkey, "Schedule\\RandomizationGenerate", 0);
        }
        else
        {
            // numbers already generated so just get them
            *pdwMinOfDay = GetVal(hkey, "Schedule\\RandomizedMinOfDay", 0xffffffff);
            *pdwDayOfWeek = GetVal(hkey,"Schedule\\RandomizedDayOfWeek",0);
            *pdwDayOfMonth = GetVal(hkey,"Schedule\\RandomizedDayOfMonth",0);
        }
    }
    */
    
    return;
}

/**************************************************************/
void GenerateRandomValues( DWORD dwGenerateFlags,
                           DWORD dwType,
                           DWORD dwRangeDaily,
                           DWORD dwRangeWeekStart,
                           DWORD dwRangeWeekEnd,
                           DWORD dwRangeMonthly,
                           DWORD* pdwMinOfDay,
                           DWORD* pdwDayOfWeek,
                           DWORD* pdwDayOfMonth )
{
    UINT    iRand;
    BOOL    bAdd;

    // Enforce valid (and useful) input
    if ( (dwRangeDaily <= 1) || (dwRangeDaily > 720) )
        return;

    if ( (dwRangeWeekStart > 6) ||
         (dwRangeWeekEnd > 6) )
        return;

    if ( (dwRangeMonthly <= 0) || (dwRangeMonthly > 28) )
        return;

    // Seed the random-number generator with current time so that
    // the numbers will be different every time we run.
    srand( (unsigned)time( NULL ) );

    // First determine whether we will add to or subtract from the time
    bAdd = rand() % 2;

    // get number between 0 and the range
    iRand = rand() % dwRangeDaily;

    if ( dwGenerateFlags & RANDOM_GENERATE_FLAG_WEEKLY )
    {
        // Generate random day of week
        UINT iTemp=0;
        BOOL bDone=FALSE;

        while ( !bDone )
        {
            // Get a random day of the week using the upper bound --
            // If our start day is greater than our end day, its inclusive of Sat(6),
            // so use %7 to get a number between 0 and 6.
            iTemp = rand() % ( (dwRangeWeekStart > dwRangeWeekEnd) ? 7 : (dwRangeWeekEnd + 1) );

            // ... Until we get one in our range
            if ( dwRangeWeekStart < dwRangeWeekEnd )
            {
                if ( ( dwRangeWeekStart <= iTemp ) &&
                     ( iTemp <= dwRangeWeekEnd ) )
                    bDone = TRUE;

            }
            else
            {
                if ( ( ( dwRangeWeekStart <= iTemp ) && (iTemp <= 6 ) ) ||
                     ( (iTemp <= dwRangeWeekEnd ) ) )
                    bDone = TRUE;
            }
        }

        *pdwDayOfWeek = iTemp;

    }

    if ( dwGenerateFlags & RANDOM_GENERATE_FLAG_MONTHLY )
    {
        // Generate random day of month
        UINT iRandMonth;

        // Generate a random number between 0 and the range.
        iRandMonth = rand() % (dwRangeMonthly + 1);

        if ( bAdd )
        {
            *pdwDayOfMonth += iRandMonth;

            if ( *pdwDayOfMonth > 28 )
                *pdwDayOfMonth -= 28; // Wrap to next month
        }
        else
        {
            if ( *pdwDayOfMonth <= iRandMonth )
                *pdwDayOfMonth = (*pdwDayOfMonth + 28) - iRandMonth; // Wrap to previous month
            else
                *pdwDayOfMonth -= iRandMonth;
        }
    }

    if ( dwGenerateFlags & RANDOM_GENERATE_FLAG_DAILY )
    {
        if ( bAdd )
        {
            if ( iRand + *pdwMinOfDay >= 1440 )
            {
                *pdwMinOfDay = *pdwMinOfDay + iRand - 1440;

                // We're wrapping to the next day, so we need to increment
                // the day if type is weekly or monthly
                switch ( dwType )
                {
                    case S_WEEKLY:
                        *pdwDayOfWeek = (*pdwDayOfWeek + 1) % 7; // Saturday (6) wraps to Sunday (0)
                        break;
                    case S_MONTHLY:
                        *pdwDayOfMonth = (*pdwDayOfMonth % 28) + 1; // 28 wraps to 1
                        break;
                }
            }
            else
            {
                *pdwMinOfDay = *pdwMinOfDay + iRand;
            }
        }
        else
        {
            if ( iRand > *pdwMinOfDay )
            {
                *pdwMinOfDay = (1440 + *pdwMinOfDay) - iRand;

                // We're going to wrap to the previous day, so we need to decrement
                // the day
                switch ( dwType )
                {
                    case S_WEEKLY:
                        *pdwDayOfWeek = (*pdwDayOfWeek + 6) % 7; // Sunday (0) wraps to Saturday (6)
                        break;
                    case S_MONTHLY:
                        *pdwDayOfMonth = ((*pdwDayOfMonth + 26) % 28) + 1; // 1 wraps to 28
                        break;
                }
            }
            else
            {
                *pdwMinOfDay = *pdwMinOfDay - iRand;
            }
        }
    }

    return;
}


/******************************************************************************/
DWORD BlockToProgress(PSCAN_STATUS block,PROGRESSBLOCK *pb)
{
//#ifdef NLM    // gdf 07/19/00 //EA 07/20/2000 start fix for STS 340035
  	char szLongPath[IMAX_PATH] = "\0";  // gdf 07/19/00
  	int nRet;
  	char* szPos;
  	int bCompressedFile = 0;
  	char szCompressedFile[IMAX_PATH];
//#endif  // gdf 07/19/00 //EA 07/20/2000 end fix for STS 340035
  
	
    memset(pb,0,sizeof(PROGRESSBLOCK));

    pb->Size = sizeof(PROGRESSBLOCK);
    pb->ScanID = block->ScanID;
    pb->Status = block->Status;
    pb->StartTime = block->StartTime;
    pb->Dirs = block->Dirs;
    pb->Files = block->Files;
    pb->Scanned = block->Scanned;
    pb->Infected = block->Infected;
    pb->Viruses = block->Viruses;
    pb->NotOpen = block->NotOpen;
   //pb->logger = block->logger;
    pb->GroupID = block->GroupID;

//#ifdef NLM   // gdf 07/19/00 //EA 07/20/2000 start fix for STS 340035
   
  	memset(szLongPath, 0, IMAX_PATH);  // gdf 07/19/00
  
  	nRet = ConvertToLongName(szLongPath, block->CurrentFile, IMAX_PATH, 0);
  	if(nRet == TRUE) //gdf 07/19/00
  	{
  		strcpy(pb->CurrentFile, szLongPath); // gdf 07/19/00
  		dprintf("The current file is %s block->CurrentFile szLongPath is %s nRet = %d with true\r\n", block->CurrentFile,szLongPath, nRet);
  	}
  	else  // gdf 07/19/00
  	{
  		//check if we failed because it had a bracket may be we are a compressed file
  		//check here if file has a ( by reverse parsing if it has check if it is compressed if it is convert to long file
  		//name without the brackets and then attach the ( part
  		szPos = strrchr(block->CurrentFile, '(');
  		if(szPos != NULL)
  		{
  			//there is a possibility that the file is compressed try again by getting compressed file
  			//i.e by parsing the bracket out of the currentfile 
  			memset(szLongPath, 0, IMAX_PATH); 
  			memset(szCompressedFile, 0 , IMAX_PATH);
  			strncpy(szCompressedFile, block->CurrentFile, strlen(block->CurrentFile) - strlen(szPos) + 1);
  			dprintf("For compress file check szCompressedFile is %s the brack is in pos is %s\r\n",szCompressedFile,szPos);
  			//lets see if we can get longfilename without the bracket
  			nRet = ConvertToLongName(szLongPath, szCompressedFile, IMAX_PATH, 0);
  			if(nRet == TRUE)
  			{
  				strcat(szLongPath,szPos);
  				strcpy(pb->CurrentFile, szLongPath);
  				dprintf("The current file(the compressed version) is %s block->CurrentFile szLongPath is %s nRet = %d with true\r\n", block->CurrentFile,szLongPath, nRet);
  			}
  			else
  			{
  				//we cant do anything so we will pass the short file name
  				strcpy(pb->CurrentFile,block->CurrentFile); // gdf 07/19/00
  				dprintf("The current file is %s block->CurrentFile szLongPath is %s nRet = %d with false\r\n", block->CurrentFile,szLongPath, nRet);
  			}
  		}
  	}
/*  
#else  // gdf 07/19/00 //EA 07/20/2000 end of fix for STS 340035
  	strcpy(pb->CurrentFile,block->CurrentFile); // gdf 07/19/00
#endif // gdf 07/19/00
*/  
  
//	strcpy(pb->CurrentFile,block->CurrentFile); // gdf 07/19/00
    return ERROR_SUCCESS;
}
/*********************************************************************************/
//#endif // SERVER || CLISCAN


DWORD NotifyProgress(PSCAN_STATUS block)
{

    PROGRESSBLOCK pb;
    DWORD cc;

    if ( block->cbProgress )
    {
        BlockToProgress(block,&pb);
        cc = block->cbProgress(block,&pb);
        if ( cc == ERROR_STOP_SCAN )
        {
            if ( ScanRunning(block->Status) && block->Status != S_STOPPING )
                StopScan(block->han,TRUE);
        }
    }
    return ERROR_SUCCESS;
}
//#endif // SERVER || CLISCAN

/**
// write a string value to the registry, unless the string is empty, in which case
// I delete the value key

VOID PutNonNullStrValue( HKEY hKey, char *szValueName, char *szValue )
{
    if (szValue[0])
    {
        ClientCheckIn.dwClientPuttingString += 1;
        PutStr(hKey,szValueName,szValue);
    }
    else
    {
        ClientCheckIn.dwClientDeleteNullStrValue += 1;
        RegDeleteValue(hKey,szValueName);
    }
}

// write a DWORD value to the registry, unless the value is zero, in which case
// I delete the value key

VOID PutNonZeroValue( HKEY hKey, char *szValueName, DWORD dwValue )
{
    if (dwValue)
    {
        ClientCheckIn.dwClientPuttingValue += 1;
        PutVal(hKey,szValueName,dwValue);
    }
    else
    {
        ClientCheckIn.dwClientDeleteZeroValue += 1;
        RegDeleteValue(hKey,szValueName);
    }
}

// write a VTIME struct to the registry, unless the year is zero, in which case
// I delete the value key

VOID PutNonZeroVTime( HKEY hKey, char *szValueName, VTIME *lpvTime )
{
    if (lpvTime->year)
    {
        ClientCheckIn.dwClientPuttingVTime += 1;
        PutData(hKey,szValueName,lpvTime,sizeof(*lpvTime));
    }
    else
    {
        ClientCheckIn.dwClientDeleteZeroVTime += 1;
        RegDeleteValue(hKey,szValueName);
    }
}
**/

/**************************************************************************************/
//#ifdef SERVER
/**
DWORD RemoveClient(char *name)
{

    HKEY hkey;

    if ( RegOpenKey(hMainKey,"Clients",&hkey) == ERROR_SUCCESS )
    {
        RegDelKeys(hkey,name);
        RegCloseKey(hkey);
        dprintf("Remove Client %s\n",name);
        ReStartPongEngine(FALSE);
    }

    return ERROR_SUCCESS;
}
**/

/***********************************************************************************/
/**
DWORD DoVECopy(char *source,char *dest,char *file,BOOL old,char *name)
{


    char line[IMAX_PATH];   // Remote HomeDir\xfer\tempname
    char line2[IMAX_PATH];  // Remote HomeDir\filename
    char lfile[IMAX_PATH];  // Local  HomeDir\filename
    char lfile2[IMAX_PATH]; // Local  HomeDir\xfer\filename
    char str[13];
    DWORD cc;
    BOOL bResume = FALSE;

    WSprintf(line,"%s\\xfer",HomeDir);
    _VerifyPath(line);

    WSprintf(str,"%08X.xfr",time(NULL));
    WSprintf(line,"$\\xfer\\%s",str);
    WSprintf(line2,"$\\%s",file);
    WSprintf(lfile,"%s\\%s",HomeDir,file);
    WSprintf(lfile2,"%s\\xfer\\%s",HomeDir,file);

// Resumable File Copy added. jallee 1/31/2000

// For older clients, ( version is determined via pong data ) we copy virus def
// files directly into the HomeDir.

// Newer versions of the client can be instructed to move all files from the HomeDir\xfer
// directory into the HomeDir. We copy a temp file into the xfer directory, if
// successful, we rename the file in place. The caller of (the caller of) this function
// is responsible for notifying the client to update virus defs with a call like this :
// PutRemoteVal(name,"ProductControl","NewPatternFile",1);

// Finally, ResumableFileCopy is a server change which <should> be compatible with new and
// old clients, however, since the cost of testing on older clients far outweighs the benefit,
// it will not be allowed on old clients.

// ResumableFileCopy copies a temp file to the HomeDir/Xfer_tmp directory.
// If successful, the temp file is moved to the HomeDir. This is done by the server directly.
// Since we now copy only a single file, not a set of files, it is not necessary to stage
// a whole set of files and have the client copy them all at once.

// ResumableFileCopy leaves the partially copied temp file on the drive on loss of connection.
// Information about the transfer is stored in the registry of the destination machine. If
// possible, the file transfer will be resumed if ResumableFileCopy is called with the same
// arguments.

// Note: This call represents how most clients get their defs from their server in the Virus
// Definition Transport model. Server pushes defs to the client in response to client sending
// pong data in the a call to 'CheckInWithMommy'.

// Resumable File Copy added. jallee 1/31/2000


#if defined(SERVER)
    if ( NULL == source && NULL != dest && old == FALSE )
    {
        cc=0;
        //bResume = (BOOL) GetVal(hMainKey,"UseResumableCopy",0);
        if ( bResume )
        {
            cc = ResumableFileCopy(source,lfile,dest,line2, COPY_NEW_FILES|COPY_SAVE_DATE);
        }
        else
            cc = MasterFileCopy(source,source?line2:lfile,dest,dest?(old?line2:line):lfile2,COPY_NEW_FILES|COPY_SAVE_DATE);
    }
    else
    {
        cc = MasterFileCopy(source,source?line2:lfile,dest,dest?(old?line2:line):lfile2,COPY_NEW_FILES|COPY_SAVE_DATE);
    }
#else
    cc = MasterFileCopy(source,source?line2:lfile,dest,dest?(old?line2:line):lfile2,COPY_NEW_FILES|COPY_SAVE_DATE);
#endif


    if ( cc && cc != COM_ERROR_UNSUPPORTED_FUNCTION )
    {
        EVENTBLOCK log;
        char str[20];
        BOOL bLogFailure = TRUE;
        //DWORD x = GetVal(hMainKey,"UsingPattern",0);
        DWORD x = 1; // ???

        // Attempt to determine if this is an attempt to copy definitions to a client.
        // If it is, then only log failure if the clients good flag is set.
        // This is to prevent filling the logs with failed definition update entries in the event
        // that a client goes down. This is necessary since we have moved to a 'push' system of def
        // distribution. jallee 26Sep2000
        /**
        if ( dest && name )
        {
            char  szClientKeyValue[140];         // enough room for 40-char value
            
            // Get the client's good flag. 
            strcpy( szClientKeyValue, "Clients\\" );
            strcat( szClientKeyValue, name );
            strcat( szClientKeyValue, "\\good" );
            bLogFailure = GetVal(hMainKey, szClientKeyValue, 1 );
        }
        /// ksr
        
        if ( bLogFailure && name )
        {
            char  szDisplayName[NAME_SIZE + 1] = {0};         // 48 + 1
            char *pszGuidStart = _tcsstr( name, "_::_" );

            if (pszGuidStart)
            {
                int nNameLen = pszGuidStart - name;
                nNameLen = min( sizeof(szDisplayName)-1, nNameLen );
                memcpy( szDisplayName, name, nNameLen );
            }
            else
                _tcsncpy ( szDisplayName, name, sizeof(szDisplayName)-1 ); 

            VDBVersionString(x, VeInfo->szVendorName, str, sizeof(str), 0);
            wsprintf(line,LS(IDS_PATT_UPDATE_FAILURE),szDisplayName,str,cc);

            memset(&log,0,sizeof(log));
            log.Description = line;
            log.logger = LOGGER_VPDOWN;
            //log.hKey[0] = 0;
            log.Category = GL_CAT_PATTERN;
            log.Event = GL_EVENT_PATTERN_UPDATE;
            GlobalLog(&log);
        }


    }
    else
    {
        if ( !old && !bResume )
        {
            if ( dest )
            {
                SendCOM_ACT_ON_FILE(dest,line2,"",2);  // delete org

                cc = SendCOM_ACT_ON_FILE(dest,line,line2,1);  // rename the file
            }
            else
            {
                unlink(lfile);
                cc = rename(lfile2,lfile);
            }
        }
    }

    return cc;
}
*/


/***********************************************************************************/
/*
DWORD CopyVEStuff(char *source,char *dest,char *pattname,BOOL old,char *cname)
{

    char *file;
    //HKEY hkey;
    char name[32];
    DWORD namesize=sizeof(name);
    DWORD cc=MINUS_ONE;
    DWORD index=0;

    file = StrRChar(pattname,'\\');
    if ( file )
        cc = DoVECopy(source,dest,file+1,old,cname); // we are making the assumetion that the pattern is in the home dir

    if ( cc==ERROR_SUCCESS )
            //&& RegOpenKey(hMainKey,"PatternManager\\EngineFiles",&hkey) == ERROR_SUCCESS )
    {
        while ( cc==ERROR_SUCCESS )
                //&&RegEnumValue(hkey,index++,name,&namesize,0,NULL,NULL,NULL) == ERROR_SUCCESS )
        {
            cc = DoVECopy(source,dest,name,old,cname);
            namesize=sizeof(name);
        }
        //RegCloseKey(hkey);
    }

    return cc;
}
*/

/***********************************************************************************/

// this structure is optimized to save space - if I have a large number
// of clients I may have a lot of these hanging around - any extra processing
// time incurred is insignificant - some effort was made to ensure that the
// alignments are optimal as well based on the usage
/*
typedef struct _CLIENT_UPDATE
{
    struct _CLIENT_UPDATE *next;   // when this is multi-threaded I need doubly-linked
    struct _CLIENT_UPDATE *prev;

    CBA_Addr address;

    // the following are right out of the Pong packet and are used to decide
    // whether the machine needs updating or not

    DWORD   pattVer;
    DWORD   Flags;              // isPrimary=1 | isShairing = 2
    DWORD   ProductVersion;
    BYTE    GuidData[16];       // this is accessed as DWORD's

    VTIME   GRCTime;

    // used to prevent updating the item I am working on if it arrives
    // while I am working on it

    BYTE    bItemInWork;        // treated as a BOOL

    char    ComputerName[1];    // variable size, nominal limit is 48

} CLIENT_UPDATE;

// empty head cell links to itself

CLIENT_UPDATE ClientUpdateListHead = {&ClientUpdateListHead, &ClientUpdateListHead};
*/


// ksr - do we need threadpool.h???

//NET_SUBNET NetSubnet[MAX_UPDATE_CLIENT_FILE_THREADS] = { 0 };


// test and claim a network

// caller must hold LOCK
/*
int SetNetInWork( CBA_Addr *lpCBA_Addr, int nThreadNumber, unsigned long ulIpSubnetMask )
{
    int     i;
    int     nMaxWorkerThreads = GetMaxUpdateClientFileThreads( );

    unsigned char ucProtocol = lpCBA_Addr->ucProtocol;
    unsigned long ulNet;
    int     nRet;

    if ( ucProtocol == CBA_PROTOCOL_IPX )
        ulNet = lpCBA_Addr->dstAddr.netAddr.ipx.ipxNet;
    else
        ulNet = lpCBA_Addr->dstAddr.netAddr.ipAddr & ulIpSubnetMask;

    nRet = NET_IS_YOURS;

    for ( i = 0; i<nMaxWorkerThreads; i++ )
    {
        if ( NetSubnet[i].bInWork && 
             NetSubnet[i].ulNetOrSubnet == ulNet && 
             NetSubnet[i].ucProtocol == ucProtocol )
        {
            nRet = NET_ALREADY_IN_USE;
            break;
        }
    }

    // isn't in use - finish making it mine

    if ( nRet != NET_ALREADY_IN_USE )
    {
        NetSubnet[nThreadNumber].ulNetOrSubnet = ulNet;
        NetSubnet[nThreadNumber].ucProtocol = ucProtocol;
        NetSubnet[nThreadNumber].bInWork = TRUE;
    }

    return nRet;
}
*/

// tell that I am done with the network I was working on - returns TRUE if I 
// was actually working on one.
/*
BOOL SetNetDone( int nThreadNumber )
{
    BOOL    bRet;

    LOCK( );

    bRet = NetSubnet[nThreadNumber].bInWork;

    NetSubnet[nThreadNumber].bInWork = FALSE;

    UNLOCK( );

    return bRet;
}
*/

// checks to see if a client address matches the subnet I am currently doing
/*
BOOL IsThisMyNet( CLIENT_UPDATE *cur, NET_SUBNET *pNetSubnet, unsigned long ulIpSubnetMask )
{
    BOOL bRet = FALSE;

    unsigned char ucProtocol = cur->address.ucProtocol;
    unsigned long ulNet;

    if ( ucProtocol == CBA_PROTOCOL_IPX )
    {
        ulNet = cur->address.dstAddr.netAddr.ipx.ipxNet;
    }
    else
    {
        ulNet = cur->address.dstAddr.netAddr.ipAddr & ulIpSubnetMask;
    }

    if ( ucProtocol == pNetSubnet->ucProtocol && ulNet == pNetSubnet->ulNetOrSubnet )
    {
        bRet = TRUE;
    }

    return bRet;
}
*/

// locate the next client for me to work on - returns NULL if there isn't one suitable
// returns a pointer to the item, marked in work, if found
/**
CLIENT_UPDATE *FindItemToWorkOn( PTHREAD_POOL lpThreadPoolEntry )
{
    CLIENT_UPDATE      *cur;

    LOCK();

    if ( ! UpdateClientsByNetOrSubnet( ) )
    {
        // no break out by subnet - get the first non-busy item off the list

        for ( cur = ClientUpdateListHead.next; cur != &ClientUpdateListHead; cur = cur->next )
        {
            if ( ! cur->bItemInWork )
            {
                // Leave on list, but flag in work - this avoids duplicate work if it
                // arrives again while I am working on it. This will happen now and then,
                // more frequently if clients check in fairly rapidly but are slow to update.

                dprintf( "next non-subnet selected item\n" );

                cur->bItemInWork = TRUE;
                break;
            }
        }
    }
    else
    {
        int nIpSubnetMask ;//= GetVal( hMainKey, "IpSubnetMask", 0xffffff00 );

        // if I have a subnet already, then find the next entry that is on that network

        if ( NetSubnet[lpThreadPoolEntry->nThreadNumber].bInWork )
        {
            for ( cur = ClientUpdateListHead.next; cur != &ClientUpdateListHead; cur = cur->next )
            {
                if ( ! cur->bItemInWork && IsThisMyNet( cur, &NetSubnet[lpThreadPoolEntry->nThreadNumber], nIpSubnetMask ) )
                {
                    dprintf( "next item for subnet %d\n", NetSubnet[lpThreadPoolEntry->nThreadNumber].ulNetOrSubnet );

                    cur->bItemInWork = TRUE;        // Leave on list, but flag in work
                    break;
                }
            }
        }
        else
        {
            // I don't have a network - find one that no one is working on

            for ( cur = ClientUpdateListHead.next; cur != &ClientUpdateListHead; cur = cur->next )
            {
                if ( ! cur->bItemInWork && SetNetInWork( &cur->address, lpThreadPoolEntry->nThreadNumber, nIpSubnetMask ) == NET_IS_YOURS )
                {
                    dprintf( "starting work on subnet %d\n", NetSubnet[lpThreadPoolEntry->nThreadNumber].ulNetOrSubnet );

                    cur->bItemInWork = TRUE;        // Leave on list, but flag in work
                    break;
                }
            }
        }
    }

    UNLOCK();

    // if I came up with nothing, then return nothing

    if ( cur == &ClientUpdateListHead ) 
    {
        cur = NULL;
    }

    return cur;
}
*/

// this is the main thread that processes the client list and pushes definitions
// and grc.dat files out if the client is out of date
/*
void UpdateClientFiles( PTHREAD_POOL lpThreadPoolEntry )
{

    CLIENT_UPDATE      *cur;

    DWORD   dwClientsProcessed = 0;
    BOOL    bClientsModified = FALSE;

    time_t  tClientsProcessedStartTime = time(NULL);

    // These are used to cache the registry key values that I use.
    // Caching these lets me empty the list very quickly when there
    // is no work to do

    DWORD dwUpdateClientsVal = 0;
    DWORD dwUsingPatternVal = 0;
    VTIME tGRCTime = {0};

    ThreadPoolThreadStarting( lpThreadPoolEntry );

    while ( SystemRunning && ! ThreadPoolThreadShouldExit( lpThreadPoolEntry ) )
    {
        cur = FindItemToWorkOn( lpThreadPoolEntry );

        // if I came up with anything, then go work on it

        if ( cur )
        {
            CBA_Addr *address = &cur->address;
            char line[IMAX_PATH];
            char szClientKey[100];    // this is enough room for Clients/Name::GUID/
            DWORD *g;

            BOOL bUpdateCachedKeys = FALSE;

            ClientCheckIn.dwClientsDequeued += 1;

            if ( dwClientsProcessed == 0 )
            {
                // this is the first client for this pass - update my cached keys

                //dwUpdateClientsVal = GetVal(hPattManKey,"UpdateClients",1);
                //dwUsingPatternVal = GetVal(hMainKey,"UsingPattern",0);

                //GetData(hMainKey,"ClientConfig\\GRCUpdateTime",&tGRCTime,sizeof(tGRCTime),NULL,NULL);

                tClientsProcessedStartTime = time(NULL);
            }

            dwClientsProcessed += 1;    // count them for statistics

            g = (DWORD *)cur->GuidData;
            WSprintf(line,"%s_::_%08X%08X%08X%08X",cur->ComputerName,g[0],g[1],g[2],g[3]);
            dprintf("CLIENT_UPDATEQ - processing %s\n", line);

            // dwUpdateClientsVal is cached, the szReg_Val_MakeActivePattern flag is not.
            if ( dwUpdateClientsVal && (cur->Flags&PF_WANT_PATTERN_UPDATES)
                    // && !GetVal ( hProductControlKey, szReg_Val_MakeActivePattern, 0 ))    
            {
                if ( cur->pattVer < dwUsingPatternVal )                          // dwUsingPatternVal is cached
                {
                    // his definitions are old - send new ones

                    char  szClientKeyValue[140];         // enough room for 40-char value
                    DWORD dwRet;

                    DWORD dwCopyBegin, dwCopyEnd;

                    strcpy( szClientKey, "Clients\\" );   // build the client key to post results
                    strcat( szClientKey, line );
                    strcat( szClientKey, "\\" );

                    dprintf("CLIENT_UPDATEQ - updating definitions for %s at %s\n", line, HomeDir);

                    bClientsModified = TRUE;

                    dwCopyBegin = GetFineLinearTime( );
                    
                    // Send the full client name, not just the display name.
                    dwRet = CopyVEStuff(NULL,(char *)address,PatternFileUsed,(cur->ProductVersion>>16) < 150,line);
                    if ( dwRet == ERROR_SUCCESS )
                    {
                        dwCopyEnd = GetFineLinearTime( );

                        // post the elapsed time in seconds

                        strcpy( szClientKeyValue, szClientKey );
                        strcat( szClientKeyValue, "DefUpdateElapsedTime" );
                        //PutVal(hMainKey, szClientKeyValue, ElapsedFineLinearTime(dwCopyBegin, dwCopyEnd) );

                        strcpy( szClientKeyValue, szClientKey );
                        strcat( szClientKeyValue, "DefUpdateCompleteTime" );
                        //PutVal(hMainKey, szClientKeyValue, time(NULL));

                        // set the good flag.
                        strcpy( szClientKeyValue, szClientKey );
                        strcat( szClientKeyValue, "good" );
                        //PutVal(hMainKey, szClientKeyValue, 1 );

                        // worked - tell the client that there are new definitions

                        PutRemoteVal((char *)address,"ProductControl","NewPatternFile",1);

                        dprintf("CLIENT_UPDATEQ - updating definitions for %s succeeded - %d elapsed\n", line, dwCopyEnd - dwCopyBegin );
                    }
                    else
                    {
                        // report the failure

                        dprintf("CLIENT_UPDATEQ - updating definitions for %s failed - reason %x\n", line, dwRet );

                        // reset the good flag on failure.
                        // we use the state of the good flag to try to log 
                        // failure only once per client check in interval.
                        strcpy( szClientKeyValue, szClientKey );
                        strcat( szClientKeyValue, "good" );
                        //PutVal(hMainKey, szClientKeyValue, 0 );

                        strcpy( szClientKeyValue, szClientKey );
                        strcat( szClientKeyValue, "DefUpdateFailedReason" );
                        //PutVal(hMainKey, szClientKeyValue, dwRet);

                        strcpy( szClientKeyValue, szClientKey );
                        strcat( szClientKeyValue, "DefUpdateFailedTime" );
                        //PutVal(hMainKey, szClientKeyValue, time(NULL));

                        
                    }

                    bUpdateCachedKeys = TRUE;   // since I've been away a while copying a file

                }
            }

            if ( VTcomp(tGRCTime,cur->GRCTime) > 0 )           // vt is cached
            {
                // his GRC.dat file is out of date - send a new one

                char  szClientKeyValue[140];         // enough room for 40-char value
                DWORD dwRet;

                strcpy( szClientKey, "Clients\\" );   // build the client key to post results
                strcat( szClientKey, line );
                strcat( szClientKey, "\\" );

                dprintf("CLIENT_UPDATEQ - updating grc.dat for %s at %s\n", line, HomeDir);

                bClientsModified = TRUE;

                // build the file name and force it down his throat

                wsprintf(line,"%s\\GRC.DAT",HomeDir);
                dwRet = FileCopyToRemoteServer((char*)address,line,"$\\GRC.DAT");
                if ( dwRet == ERROR_SUCCESS )
                {
                    // worked - tell the client

                    // set the good flag.
                    strcpy( szClientKeyValue, szClientKey );
                    strcat( szClientKeyValue, "good" );
                    //PutVal(hMainKey, szClientKeyValue, 1 );

                    PutRemoteVal((char *)address,"ProductControl","ProcessGRCNow",1);
                }
                else
                {
                    // report the failure

                    dprintf("CLIENT_UPDATEQ - updating GRC.DAT for %s failed - reason %x\n", line, dwRet );

                    strcpy( szClientKeyValue, szClientKey );
                    strcat( szClientKeyValue, "GRCUpdateFailedReason" );
                    //PutVal(hMainKey, szClientKeyValue, dwRet);

                    strcpy( szClientKeyValue, szClientKey );
                    strcat( szClientKeyValue, "GRCUpdateFailedTime" );
                    //PutVal(hMainKey, szClientKeyValue, time(NULL));
                }

                bUpdateCachedKeys = TRUE;   // since I've been away a while copying a file

            }

            dprintf("CLIENT_UPDATEQ - processing %s complete\n", line);

            // done with the entry, unlink it and free it

            LOCK( );

            cur->prev->next = cur->next;
            cur->next->prev = cur->prev;

            // I don't clear the bItemInWork flag since I am unlinking it
            // and it can't be seen any more anyway!

            UNLOCK( );

            free(cur);

#ifdef NLM
            if ( dwClientsProcessed % 100 == 98 ) // brief pause every 100 clients
            {
                NTxSleep(5);   // this is only needed so I don't hog the NetWare server - this averages 9 ms
            }
#endif
            if ( bUpdateCachedKeys )
            {
                // I've been away for a while - update my cached keys

                //dwUpdateClientsVal = GetVal(hPattManKey,"UpdateClients",1);
                //dwUsingPatternVal = GetVal(hMainKey,"UsingPattern",0);

                //GetData(hMainKey,"ClientConfig\\GRCUpdateTime",&tGRCTime,sizeof(VTIME),NULL,NULL);
            }
        }
        else
        {
            // I went through the client list and didn't find anything for me- 
            // either there was nothing to do, or I just finished the last
            // machine on a subnet.

            BOOL bGetNewSubnet = FALSE;

            // release any subnet I was doing - if I was actually working on one
            // then circle around and pick up the next free subnet to work on.
            // otherwise, just go to sleep and wait on more work. This lets me
            // distinguish the case where I woke up and there was nothing to do

            if ( UpdateClientsByNetOrSubnet( ) )
            {
                bGetNewSubnet = SetNetDone( lpThreadPoolEntry->nThreadNumber );

                if (dwClientsProcessed > 0)
                {
                    dprintf( "subnet complete? %d %d\n", bGetNewSubnet, NetSubnet[lpThreadPoolEntry->nThreadNumber].ulNetOrSubnet );
                }
            }

            // if there may be more work, don't count this done - done
            // means really idle - no more entries to do

            if ( bGetNewSubnet )
            {
                // just fall through and run back around to the top to start the
                // new subnet
            }
            else
            {
                // post the processing time for this run of the thread

                if ( dwClientsProcessed > 0 )
                {
                    ClientCheckIn.dwClientsProcessedInLastPass = dwClientsProcessed;
                    ClientCheckIn.dwTimeToProcessLastClientPass = time(NULL) - tClientsProcessedStartTime;
                    
                    // I am done. If the list is empty, and I actually updated something, then I was the 
                    // last thread doing work, and can post the end of the push. If not, someone else 
                    // is still working and they will post it when they get done. I must update them
                    // because otherwise they are probably empty checkins that aren't pushes.

                    // this may be off slightly if a previously unseen client checks in, but that isn't
                    // important, since I would have pushed to them anyway.

                    if (bClientsModified && ClientUpdateListHead.next == &ClientUpdateListHead)
                    {
                        // it is empty - I must have been the last thread

                        //PutVal(hMainKey,"ClientPushUpdatesCompletedAt", time(NULL) );
                    }
                    else
                    {
                        // otherwise there is stuff on the queue, but it is being worked on
                    }
                }

                ClientCheckIn.dwClientQueueCheckedAndEmpty += 1;

                NTxSleep(1000); // nothing to do, check again in a while

                dwClientsProcessed = 0;             // reset the client loop tracking
                bClientsModified = FALSE;

                tClientsProcessedStartTime = time(NULL);
            }
        }
    }

    // I am leaving - free the subnet I was doing - I may not have actually finished it

    SetNetDone( lpThreadPoolEntry->nThreadNumber );

    // the main thread is leaving, so I clean up the list

    if (lpThreadPoolEntry->nThreadNumber == 0)
    {

        // empty the list, if any
    
        LOCK( );
    
        {
            CLIENT_UPDATE *Entry = ClientUpdateListHead.next;
    
            while ( Entry != &ClientUpdateListHead )
            {
                CLIENT_UPDATE *NextEntry = Entry->next;
    
                // get rid of the stuff that isn't working right now
                // the others will get freed when the thread that is 
                // working on them exits
    
                if (! Entry->bItemInWork)
                {
                    Entry->prev->next = Entry->next;
                    Entry->next->prev = Entry->prev;
    
                    free( Entry );
                }
    
                Entry = NextEntry;
            }
        }
    
        UNLOCK( );
    }

    ThreadPoolThreadEnding( lpThreadPoolEntry );

}

**/

// take the client data and post to the background queue for updating definitions and
// settings via GRC.dat rollout - returns if the machine is already on the queue
/*
BOOL QueueClientForUpdate(
                         char *Name,
                         BOOL bUpdateDuplicate,
                         CBA_Addr *address,
                         DWORD pattVer, DWORD Flags, DWORD ProductVersion,
                         BYTE *GuidData, char *ComputerName, VTIME *GRCTime )
{
    CLIENT_UPDATE *pClientUpdate = NULL;
    BOOL bMatched = FALSE;

    LOCK();

    pClientUpdate = ClientUpdateListHead.next;
    bMatched = FALSE;

    // Walk the list to see if we've already got an entry for this client

    while ( pClientUpdate != &ClientUpdateListHead && !bMatched )
    {
        if ( 0 == memcmp(pClientUpdate->GuidData, GuidData, 16) &&
             ! (strcmp(pClientUpdate->ComputerName, ComputerName)) )
        {
            // the PONG queue processor requests that newly arrived duplicates
            // override existing entries - if I post the entry because I am pushing
            // defs then I don't want to do that, because the entry that is there
            // is a Pong packet that is presumably newer than what I may have - so I
            // let it rule and call with bUpdateDuplicate FALSE.

            // On the other hand, I am usually the mechanism for updating stuff, so
            // it is unlikely that things have actually changed, but this does
            // allow for 3rd parties updating things

            bMatched = TRUE;

            if ( bUpdateDuplicate )
            {
                // this computer has already been seen, just update the pong
                // data on the queue to the newer stuff. I don't update the
                // computer name and Guid since I just checked and they are
                // the same

                pClientUpdate->pattVer        = pattVer;
                pClientUpdate->Flags          = Flags;
                pClientUpdate->ProductVersion = ProductVersion;

                memcpy( &pClientUpdate->GRCTime, GRCTime, sizeof( pClientUpdate->GRCTime ) );

                pClientUpdate->address = *address;   // this copies the struct inline

                ClientCheckIn.dwDuplicateClients += 1;

                dprintf("Duplicate client %s - updating queue information\n",Name);
            }
            else
            {
                // it is a duplicate, but I am not supposed to update it, presumably because
                // it is the client push guy and his values may be older than the values that
                // are here - so I just do nothing - bMatched is already set so I don't queue
                // another copy

                dprintf("Duplicate client %s - NOT updating queue information\n",Name);

            }

            break;  // no need to look further
        }
        pClientUpdate = pClientUpdate->next;
    }

    if ( !bMatched )
    {
        // Now add it to the queue - note that it is variable size

        int nComputerNameLen = strlen( ComputerName );  // the struct has a byte for end of string
        pClientUpdate = malloc(sizeof(CLIENT_UPDATE) + nComputerNameLen);

        dprintf("Adding client %s to queue\n",Name);
        if ( pClientUpdate )
        {
            // note the list is locked above - we used to lock here

            CLIENT_UPDATE *LinkAfter;

            pClientUpdate->pattVer        = pattVer;
            pClientUpdate->Flags          = Flags;
            pClientUpdate->ProductVersion = ProductVersion;
            pClientUpdate->bItemInWork    = FALSE;

            memcpy( pClientUpdate->GuidData, GuidData, sizeof(pClientUpdate->GuidData) );
            strcpy( pClientUpdate->ComputerName, ComputerName );
            memcpy( &pClientUpdate->GRCTime, GRCTime, sizeof( pClientUpdate->GRCTime ) );

            pClientUpdate->address = *address;     // this copies the struct inline

            // link to the end of the list

            LinkAfter = ClientUpdateListHead.prev;

            pClientUpdate->next = LinkAfter->next;
            pClientUpdate->next->prev = pClientUpdate;

            LinkAfter->next = pClientUpdate;
            pClientUpdate->prev = LinkAfter;

            ClientCheckIn.dwClientsQueued += 1;
        }
        else
        {
            dprintf("CLIENT_UPDATEQ malloc failed for %s\n",Name);
            ClientCheckIn.dwFailedClientMallocs += 1;
        }
    }

    UNLOCK();

    return bMatched;
}
*/



//#endif // SERVER






#if 0



//
// standard check used to see whether I should attempt to contact a client machine
// or whether he is likely offline

BOOL IsClientOverdue( time_t tLastCheckInTime, time_t tCheckTime, DWORD dwCheckConfigMinutes )
{
    // allow him 2 minutes or 10% if he checks in more often than every 20 minutes

    DWORD dwCheckConfigSeconds = dwCheckConfigMinutes * 60;
    DWORD dwCheckInGrace = min( 2 * 60, (dwCheckConfigSeconds * 110) / 100);

    return tCheckTime > tLastCheckInTime + dwCheckConfigSeconds + dwCheckInGrace;
}


/********************************************************************************/
DWORD UpdateClientListEntry(CBA_Addr *address,PONGDATA *pong)
{

    //HKEY hkey;
    //HKEY hckey;
    PONGDATA Pong;
    char Name[IMAX_PATH];
    DWORD *g;

    // this ensures that if I get an old, short Pong from someone, then
    // all the new fields that aren't there are zero. Otherwise I just
    // use the live stuff.

    if ( pong->MySize < sizeof(PONGDATA) )
    {
        memset(&Pong,0,sizeof(PONGDATA));
        memcpy(&Pong,pong,pong->MySize);
        pong = &Pong;
    }

    g = (DWORD *)pong->GuidData;
    WSprintf(Name,"%s_::_%08X%08X%08X%08X",pong->ComputerName,g[0],g[1],g[2],g[3]);

    //if ( RegOpenKey(hMainKey,"Clients",&hkey) == ERROR_SUCCESS )
    {

        //  KJS   Removing duplicate CBA address checking here, and moving it out to the
        // 5/3/00 main timer loop.  This was causing a tremendous slowdown when
        //        the size of the client list grew.

        dprintf("adding %s to Client list\n",Name);
        //if ( RegCreateKey(hkey,Name,&hckey) == ERROR_SUCCESS )
        {
            // I used to call ClearKey to delete all the values all the time. This was bad in 3 ways.
            // 99.9% of the time we just write the keys back again so this is just frothing the registry
            // and wasting time. It gives anybody enumerating clients a hard time since they are
            // coming and going. It gives the console a hard time because the clients and values aren't 
            // always there when he goes to build the list.

            // note - the way the code used to work would cause subtle inconsistencies when
            // another thread was trying to use the values and the client checked in and
            // temporarily nuked some of them - like the address, for example

            // This code has the same end effect as the old code. If some value isn't going to be written 
            // then I delete it, following the same rules as the original code.
            
            /**
            //PutVal(hckey,"good",1);
            //PutVal(hckey,"LastCheckinTime",time(NULL));
            //PutVal(hckey,"Flags",pong->Flags);

            PutNonNullStrValue(hckey,"LicenseNumber",pong->License);
            PutNonNullStrValue(hckey,"UserName",pong->Mom);

            PutNonZeroValue(hckey,"PatternVersion",pong->pattVer);
            PutNonZeroValue(hckey,"PatternFileDate",pong->PatternFileDate);

            PutVal(hckey,"PatternFileRevision",pong->dwPatternRevision);
            PutVal(hckey,"PatternFileSequence",pong->dwPatternSequence);

            PutNonZeroValue(hckey,"ProductVersion",pong->ProductVersion);
            PutNonZeroValue(hckey,"ServiceRelease",pong->ServiceRelease);
            PutNonZeroValue(hckey,"InstalledProducts",pong->InstalledProducts);
            PutNonZeroValue(hckey,"ScanEngineVersion",pong->EngineVersion);

            PutNonNullStrValue(hckey,"ScanEngineVendor",pong->ScanEngineVendor);

            PutNonZeroVTime(hckey,"TimeOfLastVirus",&pong->TimeOfLastVirus);
            PutNonZeroVTime(hckey,"TimeOfLastScan",&pong->TimeOfLastScan);

            // this didn't used to be saved, but I need it to push out grc.dat file changes
            // it also very handy for troubleshooting

            PutNonZeroVTime(hckey,"GRCUpdateTime",&pong->GRCTime);
            **/
            
            // and last do the complex data types

            if ( *(((DWORD *)(pong->GuidData))+3) )
            {
                ClientCheckIn.dwClientPuttingGUID += 1;
                //PutData(hckey,"GUID",pong->GuidData,16);
            }
            else
            {
                ClientCheckIn.dwClientDeleteNullGUID += 1;
                //RegDeleteValue(hckey,"GUID");
            }

            if ( address )
            {
                ClientCheckIn.dwClientPuttingAddress += 1;
                //PutVal(hckey,"TransportVersion",pong->TransportVersion);
                WriteAnAddress(//hckey,
                                address);
            }
            else
            {
                ClientCheckIn.dwClientDeleteNullAddress += 1;

                //RegDeleteValue(hckey,"TransportVersion");
                //NukeAnAddress(hckey);
            }

            // the registry client entry is complete - now post the
            // client for update checks

            if ( address && SystemRunning )
            {
                QueueClientForUpdate( Name,
                                      TRUE,         // update duplicates seen
                                      address,
                                      pong->pattVer, pong->Flags, pong->ProductVersion,
                                      pong->GuidData, pong->ComputerName, &pong->GRCTime );
            }

            //RegCloseKey(hckey);
        }

        //RegCloseKey(hkey);
        ReStartPongEngine(FALSE);
    }

    return 0;
}


/********************************************************************************/
/**
DWORD DeleteChildListEntry(char *computer)
{

    HKEY hkey;

    if ( RegOpenKey(hMainKey,"Children",&hkey) == ERROR_SUCCESS )
    {
        dprintf("removing %s from child list\n",computer);
        RegDeleteValue(hkey,computer);
        RegCloseKey(hkey);
    }
    return 0;
}

**/

/********************************************************************************/
/*
DWORD AddToConsoleList(char *name,CBA_Addr *address)
{

    //HKEY hkey;
    char line[IMAX_PATH];

    wsprintf(line,"Consoles\\%s",name);

    //if ( RegCreateKey(hMainKey,line,&hkey) == ERROR_SUCCESS )
    {
        dprintf("adding %s to Console list\n",name);
        WriteAnAddress(//hkey,
                        address);
        //RegCloseKey(hkey);
    }
    return 0;

}
*/
/********************************************************************************/
/**
DWORD RemoveFromConsoleList(char *name)
{

    HKEY hkey;

    if ( RegOpenKey(hMainKey,"Consoles",&hkey) == ERROR_SUCCESS )
    {
        RegDeleteKey(hkey,name);
        dprintf("removing %s from console list\n",name);
        RegCloseKey(hkey);
    }
    return 0;

}
**/
/*************************************************************************************/
DWORD MakeTransportableServerStatus(T_SERVERSTATUS *stat)
{

    char UserName[NAME_SIZE],DomainName[NAME_SIZE];

    GetNames((PSID)&pStatBlock->LastUser,UserName,DomainName);
    StrCopy(stat->LastUserName,UserName);

    memcpy(stat->ActiveScans,gServerStatus.ActiveScans,min(sizeof(stat->ActiveScans),sizeof(gServerStatus.ActiveScans)));
    stat->MRS = gServerStatus.MRS;

    stat->RealTimeStatus.Size                   = pStatBlock->Size;
    stat->RealTimeStatus.TotalScaned            = pStatBlock->TotalScaned;
    stat->RealTimeStatus.TimeStarted            = pStatBlock->TimeStarted;
    stat->RealTimeStatus.VirusesFound           = pStatBlock->VirusesFound;
    stat->RealTimeStatus.LastVirusFoundTime     = pStatBlock->LastVirusFoundTime;
    stat->RealTimeStatus.DriverErr              = pStatBlock->DriverErr;
    stat->RealTimeStatus.Exceptions             = pStatBlock->Exceptions;
    stat->RealTimeStatus.Status                 = pStatBlock->Status;
    stat->RealTimeStatus.LastVirusFoundAction   = pStatBlock->LastVirusFoundAction;

    StrCopy(stat->RealTimeStatus.LastVirusFoundName     ,pStatBlock->LastVirusFoundName);
    StrCopy(stat->RealTimeStatus.LastVirusFoundUserName ,pStatBlock->LastVirusFoundUserName);
    StrCopy(stat->RealTimeStatus.LastVirusFoundFile     ,pStatBlock->LastVirusFoundFile);
    StrCopy(stat->RealTimeStatus.LastScaned             ,pStatBlock->LastScaned);
    return ERROR_SUCCESS;
}
/***********************************************************************************************/
/**
DWORD UpdateChildListEntry(char *computer)
{

    HKEY hkey;

    if ( RegOpenKey(hMainKey,"Children",&hkey) == ERROR_SUCCESS )
    {
        dprintf("adding %s to Child list\n",computer);
        PutVal(hkey,computer,1);
        RegCloseKey(hkey);
    }
    return 0;
}
**/



/******************************************************************/
//#if defined (SERVER) || defined (TRANSMAN) || defined (NLMCGI) || defined (START)

long RemoteEnumKey(char *computer,char *root, HKEY hParentRegKey)
{
    DWORD   dwCount,dwIndex = 0,dwType,dwDataSize,dwRet;
    char    *pszValue,*pNext,*nRoot;
    BYTE    *pSendBuffer,*pCurrentData,*pData;
    HKEY    hkey;
    int i,j;

    pszValue = malloc(IMAX_PATH);
    pData = malloc (IMAX_PATH);
    pSendBuffer = malloc(MAX_PACKET_DATA);
    nRoot = malloc(IMAX_PATH);

    dwCount = 0;
    do
    {
        dwRet = SendCOM_LIST_KEY_BLOCK(computer,root, pSendBuffer, MAX_PACKET_DATA, &dwIndex,&dwCount);
        if ( dwCount && dwRet == 0 )
        {
            pNext = (char *)pSendBuffer;
            for ( i = 0; i < (int)dwCount; i++ )
            {
                if ( *pNext == '\0' )
                    break;

                if ( !*root )//(root == "")
                    strcpy(nRoot,pNext);
                else
                {
                    strcpy(nRoot,root);
                    strcat(nRoot,"\\");
                    strcat(nRoot,pNext);
                }

                if ( RegCreateKey(hParentRegKey,pNext,&hkey) == ERROR_SUCCESS )
                {
                    RemoteEnumKey(computer, nRoot, hkey);
                    RegCloseKey(hkey);
                }

                pNext += strlen(pNext) + 1;
            }
        }
        else
        {
            dprintf("SendCOM_LIST_KEY_BLOCK failed with error %x\n", dwRet);
        }
    } while ( dwIndex != 0 );

    if ( !*root )//(root == "")
        hkey = hMainKey;
    else if ( RegCreateKey(hMainKey, root, &hkey) != ERROR_SUCCESS )
    {
        dprintf("Unable to create key [%s].", root);
    }

    dwCount = 0;
    do
    {
        dwRet = SendCOM_LIST_VALUE_BLOCK(computer,root, pSendBuffer, MAX_PACKET_DATA, &dwIndex,&dwCount);
        if ( dwCount && dwRet == 0 )
        {
            pCurrentData = pSendBuffer;
            for ( j = 0; j < (int)dwCount; j++ )
            {
                dwDataSize = IMAX_PATH;
                pCurrentData = GetValueFromEnumBlock(pCurrentData, pszValue, &dwType, pData, &dwDataSize);

                if ( RegSetValueEx(hkey, pszValue, 0, dwType, pData, dwDataSize) != ERROR_SUCCESS )
                {
                    dprintf("\nFailed to set registry value %s\\%s = %s...", root, pszValue,pData);
                }
            }
        }
        else
        {
            dprintf("SendCOM_LIST_VALUE_BLOCK failed with error %x\n", dwRet);
        }
    } while ( dwIndex != 0 );

    free(pszValue);
    free(pData);
    free(pSendBuffer);
    free(nRoot);

    return dwRet;
}
/*************************************************************************************************/
DWORD CopyRemoteReg(char *computer,char *LocalRoot,char *RemoteRoot)
{

    HKEY    hServerKey;
    long  lRet = 0;

    if ( RegCreateKey(hMainKey, LocalRoot, &hServerKey) == ERROR_SUCCESS )
        lRet = RemoteEnumKey(computer, RemoteRoot, hServerKey);

    return lRet;
}
/***********************************************************************************************/
BYTE *GetValueFromEnumBlockWithIndex(BYTE *block,int element,char *name,DWORD *type,DWORD *size)
{

    int j;
    BYTE *out=0;
    char c;
    int i;
    DWORD oSize=0;

    for ( j=0;j<=element;j++ )
    {
        i = *(WORD *)block;
        block += sizeof(WORD);
        c = *block;
        if ( j == element )
        {
            if ( type )
                *type = c=='D'?REG_DWORD:c=='S'?REG_SZ:c=='M'?REG_MULTI_SZ:REG_BINARY;
            if ( name )
                memcpy(name,block+1,i-1);
        }
        block += i;
        oSize = *(WORD *)block;
        block += sizeof(WORD);
        out = block;
        block += oSize;
    }

    *size=min(*size,oSize);

    return out;
}


//#endif // defined (SERVER) || defined (TRANSMAN) || defined (NLMCGI) || defined (START)
/***********************************************************************************************/

//#if defined (SERVER) || defined (TRANSMAN) || defined (NLMCGI)

BYTE *GetNameFromList(BYTE *List,int element)
{

    int i;
    BYTE *ret = NULL;

    for ( i=0;i<=element;i++ )
    {
        ret = List;
        List += NumBytes((char *)List) + 1;
    }

    return ret;
}
/***********************************************************************************************/
/********************************************************************************/
/*
BYTE *GetInfectionFromBlock(BYTE *block,PINFNODE inf) {

    if (inf == NULL)
        return NULL;

    inf->VirusID         = *(DWORD *)block;   block += sizeof(DWORD);
    inf->VirusType       = *(DWORD *)block;   block += sizeof(DWORD);
    inf->CleanInfo       = *(DWORD *)block;   block += sizeof(DWORD);
    inf->WantedAction[0] = *(DWORD *)block;   block += sizeof(DWORD);
    inf->WantedAction[1] = *(DWORD *)block;   block += sizeof(DWORD);
    inf->Action          = *(DWORD *)block;   block += sizeof(DWORD);
    StrCopy(inf->Name,block);                 block += NumBytes(block) + 1;
    StrCopy(inf->VirusName,block);            block += NumBytes(block) + 1;
    return block;
}
*/
/********************************************************************************/
/***************************************************************************************/
BOOL rExists(char *name,char *file)
{

//  char File[32];
    HANDLE han=0;
    BYTE buf[IMAX_PATH];
    WORD num;
    DWORD cc;
//  char *q=buf;

    cc = SendCOM_DIR_BLOCK(name,file,&han,buf,sizeof(buf),&num,T_FILES|T_OLDSTYLE);
    if ( cc )
        return cc;

    if ( han != 0 )
        SendCOM_DIR_BLOCK(name,"",&han,(BYTE *)"",0,&num,0);

    return num;
}
/**********************************************************************************************/
DWORD FileCopyToRemoteServer(char *CName,char *lpath,char *rpath)
{

    return MasterFileCopy(NULL,lpath,CName,rpath,COPY_TODAYS_DATE|COPY_ALWAYS);
}
/***************************************************************************************/
DWORD FileCopyFromRemoteServer(char *CName,char *rpath,char *lpath)
{

    return MasterFileCopy(CName,rpath,NULL,lpath,COPY_TODAYS_DATE|COPY_ALWAYS);
}
/***************************************************************************************/
DWORD xFileCopyFromRemoteServer(char *CName,char *rpath,char *lpath)
{

    DWORD han;
    DWORD ret;
    int lhan;
    BYTE buf[MAX_PACKET_DATA];
    int size;
    DWORD len,l;
    DWORD loc=0;

    lhan = open(lpath,O_WRONLY|O_BINARY|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    if ( lhan == -1 )
        return errno;


    ret = SendCOM_OPEN_FILE(CName,rpath,"r",&han,(DWORD*)&size);
    if ( !ret )
    {

        while ( size > 0 )
        {
            len = l = min(size,sizeof(buf));
//          if (SendCOM_READ_FILE(CName,han,DEFAULT,&len,buf) != 0)
            if ( SendCOM_READ_FILE(CName,han,loc,&len,buf) != 0 )
                break;
            write(lhan,buf,len);
            if ( len != l )
                break;
            size -= len;
            loc += len;
        }

        SendCOM_CLOSE_FILE(CName,han);
    }

    close(lhan);

    return ret;
}
/***************************************************************************************/
DWORD xFileCopyToRemoteServer(char *CName,char *lpath,char *rpath)
{


    DWORD han;
    DWORD ret;
    int lhan;
    BYTE buf[MAX_PACKET_DATA];
    int size;
    DWORD len,l;
    DWORD loc=0;

    lhan = open(lpath,O_RDONLY|O_BINARY,0);
    if ( lhan == -1 )
        return errno;

    ret = SendCOM_OPEN_FILE(CName,rpath,"wct",&han,(DWORD*)&size);

    size = lseek(lhan,0,SEEK_END);
    lseek(lhan,0,SEEK_SET);

    if ( !ret )
    {
        while ( size > 0 )
        {
            len = l = min(size,sizeof(buf));
            len = read(lhan,buf,len);
//          if (SendCOM_WRITE_FILE(CName,han,DEFAULT,&len,buf) != 0)
            if ( SendCOM_WRITE_FILE(CName,han,loc,&len,buf) != 0 )
                break;
            if ( len != l )
                break;
            size -= len;
            loc += len;
        }

        SendCOM_CLOSE_FILE(CName,han);
    }

    close(lhan);

    return ret;

}
/********************************************************************************/
DWORD GetProductVersion(char *name)
{

    PONGDATA pd;

    if ( SendCOM_GET_PONG_DATA(name,&pd) != ERROR_SUCCESS )
        return 0;

    return pd.ProductVersion;
}
/********************************************************************************/
DWORD ClearAddressCacheEntry(char *name)
{

    HKEY hkey;

    if ( RegOpenKey(hMainKey,"AddressCache",&hkey) == ERROR_SUCCESS )
    {
        RegDeleteKey(hkey,name);
        RegCloseKey(hkey);
    }

    return 0;
}
/********************************************************************************/
/*
DWORD GetAddress(char *name,CBA_Addr *address)
{

    HKEY hkey,hckey;
    DWORD good;
    DWORD ret = 0xffffffff;

    if ( RegOpenKey(hMainKey,"AddressCache",&hkey) == ERROR_SUCCESS )
    {
        if ( RegCreateKey(hkey,name,&hckey) == ERROR_SUCCESS )
        {
            if ( GetVal(hckey,"TransportVersion",TRANSPORT_VERSION) == TRANSPORT_VERSION )
            {
                good = GetVal(hckey,"good",0);
                ReadAnAddress(hckey,address);
                if ( good )
                {
                    PutVal(hckey,"LastGoodTime",time(NULL));
                    ret = 0;
                }
                else
                {
                    ret = FindComputer(hckey,name,address);
                    if ( ret == 0 )
                        ReadAnAddress(hckey,address);
                }
            }
            else
                ret = COM_ERROR_BAD_TRANSPORT_VERSION;
            RegCloseKey(hckey);
        }
        RegCloseKey(hkey);
    }

    return ret;

}
*/

//#endif // server transman


/********************************************************************************/
//#if defined (SERVER) || defined (TRANSMAN) || defined (NLMCGI) || defined(START)
/************************************************************************************/
/********************************************************************************/


/**
DWORD InvalidateAddressCacheEntry(char *name)
{

    HKEY hkey,hckey;

    if ( RegOpenKey(hMainKey,"AddressCache",&hkey) == ERROR_SUCCESS )
    {
        if ( RegOpenKey(hkey,name,&hckey) == ERROR_SUCCESS )
        {
            PutVal(hckey,"good",0);
            RegCloseKey(hckey);
        }
        RegCloseKey(hkey);
    }
    return 0;
}

DWORD VerifyAnAddress(char *name)
{

    PONGDATA pd;

    if ( SendCOM_GET_PONG_DATA(name,&pd) == 0 )
    {
        UpdateAddressCacheEntry(NULL,&pd);
        return 0;
    }

    return ERROR_COMPUTER_NOT_FOUND;
}

**/

/********************************************************************************/

/*
DWORD WriteAnAddress(HKEY hkey,CBA_Addr *address)
{

    char str[64];

    wsprintf(str,"Address_%u",address->ucProtocol);
    PutData(hkey,str,address,sizeof(CBA_Addr));
    PutStr(hkey,"Protocol",str);

    return 0;
}

/********************************************************************************
DWORD NukeAnAddress(HKEY hkey) 
{
    ClientCheckIn.dwAddressesNuked += 1;

    RegDeleteValue(hkey,"Address_0");
    RegDeleteValue(hkey,"Address_1");
    RegDeleteValue(hkey,"Protocol");

    return 0;
}
*/

/*************************************************************************************/
DWORD ReadAnAddress(HKEY hkey,CBA_Addr *address)
{

    char str[64];
    DWORD df=TRUE;

    //GetStr(hkey,"Protocol",str,sizeof(str),
//#ifdef NLM
           "Address_1"
/*
#else // !NLM
           "Address_0"
#endif // !NLM
*/
          );

    //GetData(hkey,str,address,sizeof(CBA_Addr),NULL,(BOOL*)&df);

    return df?ERROR_NO_ADDRESSES:ERROR_SUCCESS;
}
/*************************************************************************************/
/*
DWORD UpdateAddressCacheEntry(CBA_Addr *address,PONGDATA *pong)
{

    HKEY hkey,hckey;
    PONGDATA Pong;

    if ( pong->MySize < sizeof(PONGDATA) )
    {
        memset(&Pong,0,sizeof(PONGDATA));
        memcpy(&Pong,pong,pong->MySize);
        pong = &Pong;
    }

    if ( RegOpenKey(hMainKey,"AddressCache",&hkey) == ERROR_SUCCESS )
    {
        if ( RegCreateKey(hkey,pong->ComputerName,&hckey) == ERROR_SUCCESS )
        {

            // KSACKIN - Removing the code which clears the address cache entry before writing a new one.
            // 7/24/00   We are now going to intelligently write new values based on whether they were
            //           in the pong packet or not.  This is how the client entries now do this.

//            if ( address )
//                ClearKey(hckey);

            PutNonNullStrValue(hckey,"LicenseNumber",pong->License);
            PutNonNullStrValue(hckey,"Parent",pong->Mom);

            PutNonZeroValue(hckey,"PatternVersion",pong->pattVer);
            PutNonZeroValue(hckey,"PatternFileDate",pong->PatternFileDate);

            PutVal(hckey,"PatternFileRevision",pong->dwPatternRevision);
            PutVal(hckey,"PatternFileSequence",pong->dwPatternSequence);

            PutVal(hckey,"NumberOfClients",pong->NumberOfClients);

            PutNonZeroValue(hckey,"ScanEngineVersion",pong->EngineVersion);
            PutNonZeroValue(hckey,"ProductVersion",pong->ProductVersion);
            PutNonZeroValue(hckey,"ServiceRelease",pong->ServiceRelease);
            PutNonZeroVTime(hckey,"TimeOfLastVirus",&pong->TimeOfLastVirus);
            PutNonZeroVTime(hckey,"TimeOfLastScan",&pong->TimeOfLastScan);
            PutNonZeroValue(hckey,"InstalledProducts",pong->InstalledProducts);

            PutNonNullStrValue(hckey,"ScanEngineVendor",pong->ScanEngineVendor);
            PutNonNullStrValue(hckey,"Domain",pong->DomainName);
            PutNonNullStrValue(hckey,"ConsolePassword",pong->ConsolePassword);

            PutVal(hckey,"good",1);

            PutVal(hckey,"Flags",pong->Flags);
            PutVal(hckey,"LastUpdateTime",time(NULL));

            // and last do the complex data types

            if ( *(((DWORD *)(pong->GuidData))+3) )
                PutData(hckey,"GUID",pong->GuidData,16);
            else
                RegDeleteValue(hckey,"GUID");


            if ( address )
            {
                PutVal(hckey,"TransportVersion",pong->TransportVersion);
                WriteAnAddress(hckey,address);
            }
//            else
//            {
//                RegDeleteValue(hckey,"TransportVersion");
//                NukeAnAddress(hckey);
//            }

            RegCloseKey(hckey);
        }
        RegCloseKey(hkey);
    }

    return 0;
}

*/

//#endif //defined (SERVER) || defined (TRANSMAN) || defined (NLMCGI) || defined(START)
/******************************************************************************************************/


//#ifdef SERVER

// This sets the login options from the server registry into a file called vp_login.ini
// in the login directory which is read by the login programs

/*
DWORD ProcessLogin(void)
{

    HKEY hkey;
    char str[IMAX_PATH];
    char FileServerName[NAME_SIZE];
    FILE *file;
    char str1[IMAX_PATH];
    char filename[IMAX_PATH];

	// ksr
//    NTSGetComputerName(FileServerName,NULL);
    GetFileServerName( 0, FileServerName );

    if ( RegOpenKey(hMainKey,"LoginOptions",&hkey) != ERROR_SUCCESS )
        return ERROR_NO_KEY;


    dprintf("Processing Login stuff\n");

/**
#ifdef WIN32
    WSprintf(filename,NT_LOGIN_DIRECTORY"\\vpscan16.bat",HomeDir);
    file = fopen(filename,"wt");
#endif // WIN32
** /

//#ifdef NLM
    WSprintf(filename,NW_LOGIN_DIRECTORY"\\vpscan16.bat");
    file = fopen(filename,"wt");
    if ( !file )
    {
        MakeWriteable(NW_LOGIN_DIRECTORY"\\vpscan16.bat",0xfffffffc);
        file = fopen(NW_LOGIN_DIRECTORY"\\vpscan16.bat","wt");
    }
//#endif // NLM
    if ( file )
    { // 16 bit scanner
        GetStr(hkey,"ScannerName16",str,sizeof(str),"VSCAND.EXE");
        GetStr(hkey,"ScannerOptions16",str1,sizeof(str1),"/CM /S=0 /V /C /SE");
        fprintf(file,"%%1\\%s %s\n",str,str1);
        fclose(file);
    }

/**
#ifdef WIN32
    WSprintf(filename,NT_LOGIN_DIRECTORY"\\vp_login.ini",HomeDir);
    file = fopen(filename,"wt");
#endif // WIN32
** /

//#ifdef NLM
    file = fopen(NW_LOGIN_DIRECTORY"\\vp_login.ini","wt");
    if ( !file )
    {
        MakeWriteable(NW_LOGIN_DIRECTORY"\\vp_login.ini",0xfffffffc);
        file = fopen(NW_LOGIN_DIRECTORY"\\vp_login.ini","wt");
    }
//#endif // NLM
    if ( file )
    {
// Store the name of the scannner for the various platforms
        fprintf(file,"[32BitScanner]\n");

        GetStr(hkey,"ScannerName32",str,sizeof(str),"VSCAND.EXE");
        fprintf(file,"Name=%s\n",str);

        GetStr(hkey,"ScannerOptions32",str,sizeof(str),"/CM /S=0 /V /C /SE");
        fprintf(file,"Options=%s\n",str);

        fprintf(file,"\n[16BitScanner]\n");

        GetStr(hkey,"ScannerName16",str,sizeof(str),"VSCAND.EXE");
        fprintf(file,"Name=%s\n",str);

        GetStr(hkey,"ScannerOptions16",str,sizeof(str),"/CM /S=0 /V /C /SE");
        fprintf(file,"Options=%s\n",str);

// What is the name of the install program?
        fprintf(file,"\n[Installer]\n");

        GetStr(hkey,"InstallProgram32",str,sizeof(str),"");
        fprintf(file,"Win32=%s\n",str);

//        GetStr(hkey,"InstallProgramNT",str,sizeof(str),"");
//        fprintf(file,"WinNT=%s\n",str);

//        GetStr(hkey,"InstallProgram95",str,sizeof(str),"");
//        fprintf(file,"Win95=%s\n",str);

// Set Login Scan Options
        fprintf(file,"\n[ScanOptions]\n");

        if ( GetVal(hkey,"DoScanOnWinNT",0) )
            fprintf(file,"WinNT=FORCE\n");
        else
            fprintf(file,"WinNT=NONE\n");

        if ( GetVal(hkey,"DoScanOnWin95",0) )
            fprintf(file,"Win95=FORCE\n");
        else
            fprintf(file,"Win95=NONE\n");

        if ( GetVal(hkey,"DoScanOn16Bit",0) )
            fprintf(file,"16Bit=FORCE\n");
        else
            fprintf(file,"16Bit=NONE\n");

// Set Login Install Options
        fprintf(file,"\n[InstallOptions]\n");

        GetStr(hkey,"DoInstallOnWinNT",str,sizeof(str),"NONE");
        fprintf(file,"WinNT=%s\n",str);

        GetStr(hkey,"DoInstallOnWin95",str,sizeof(str),"NONE");
        fprintf(file,"Win95=%s\n",str);

        GetStr(hkey,"DoInstallOn16Bit",str,sizeof(str),"NONE");
        fprintf(file,"16Bit=%s\n",str);

//Client Number is used to force a client to update on login.  If the locally stored
//number on a client is different than this number, then it will do the update.
        fprintf(file,"\n[ClientNumber]\n");
        fprintf(file,"WinNT=%d\n",GetVal(hkey,"WinNTClientVersion",1));
        fprintf(file,"Win95=%d\n",GetVal(hkey,"Win95ClientVersion",1));
        fprintf(file,"16Bit=%d\n",GetVal(hkey,"16BitClientVersion",1));

        fprintf(file,"BuildNumber=%08X\n",(MAINPRODUCTVERSION*100+SUBPRODUCTVERSION)|(BUILDNUMBER<<16));

        fclose(file);
    }

    RegCloseKey(hkey);

    return 0;
}
*/

/****************************************************************************************************/
/*
DWORD MakeAddressFile(char *ComputerName,CBA_Addr *ipxaddress,CBA_Addr *ipaddress)
{

    char line[IMAX_PATH];
    HKEY hkey;

    if ( GetVal(hMainKey,"ManageClients",1) == 0 )
        return ERROR_CLIENTS_NOT_INSALLED;

    PutStr(hMainKey,"ClientConfig\\Parent",ComputerName);
    dprintf("putting parent name in client config [%s]\n",ComputerName);

    wsprintf(line,"ClientConfig\\AddressCache\\%s",ComputerName);
    if ( RegCreateKey(hMainKey,line,&hkey) == ERROR_SUCCESS )
    {
        int p = GetVal(hMainKey,"PreferedProtocol",1);
        if ( p == 1 && ipaddress )
        {
            WriteAnAddress(hkey,ipaddress);
        }
        if ( ipxaddress )
        {
            WriteAnAddress(hkey,ipxaddress);
        }
        if ( p == 0 && ipaddress )
        {
            WriteAnAddress(hkey,ipaddress);
        }

        PutVal(hkey,"good",1);

        RegCloseKey(hkey);
        PutVal(hProductControlKey,"ProcessGRCNow",1);
        return ERROR_SUCCESS;
    }
    return ERROR_REG_FAIL;
}
*/
/************************************************************************************************/
/*
void SendFileToAllClients(char *filename)
{

    static char inUse=0;
    HKEY hclkey;
    HKEY hckey;
    int index=0;
    char name[IMAX_PATH];
    char *q;
    char line[64];

    dprintf("SendFileToAllClients::Entered function, filename (%s)\n", filename);
    if ( inUse )
    {
        free(filename);
        return;
    }

    inUse = 1;

    if ( RegOpenKey(hMainKey,"Clients",&hclkey) == ERROR_SUCCESS )
    {
        while ( SystemRunning&&RegEnumKey(hclkey,index++,name,sizeof(name)) == ERROR_SUCCESS )
        {
            if ( RegOpenKey(hclkey,name,&hckey) == ERROR_SUCCESS )
            {
                CBA_Addr address;
                if ( ReadAnAddress(hckey,&address) == ERROR_SUCCESS )
                {
                    q = StrRChar(filename,'\\');
                    if ( q )
                    {
                        wsprintf(line,"$%s",q);
                        dprintf("SendFileToAllClients::FileCopyToRemoteServer filename (%s) line (%s)\n", filename, line);

                        FileCopyToRemoteServer((char *)&address,filename,line);

                        PutRemoteVal((char *)&address,"ProductControl","ProcessGRCNow",1);
                    }
                }
                RegCloseKey(hckey);
            }
        }
        RegCloseKey(hclkey);
    }

    free(filename);
    inUse = 0;

    return;
}
*/


/************************************************************************************************/
void SendFileToAllChildren(char *filename)
{

    static char inUse=0;
    HKEY hclkey;
    HKEY hckey;
    HKEY hackey;
    int index=0;
    char name[IMAX_PATH];
    char *q;
    char line[64];

    dprintf("SendFileToAllChildren::Entered function, filename (%s)\n", filename);
    if ( inUse )
    {
        free(filename);
        return;
    }

    if ( RegOpenKey(hMainKey,"AddressCache",&hackey) != ERROR_SUCCESS )
        return;

    inUse = 1;

    if ( RegOpenKey(hMainKey,"Children",&hclkey) == ERROR_SUCCESS )
    {
        while ( SystemRunning&&RegEnumKey(hclkey,index++,name,sizeof(name)) == ERROR_SUCCESS )
        {
            if ( RegOpenKey(hackey,name,&hckey) == ERROR_SUCCESS )
            {
                q = StrRChar(filename,'\\');
                if ( q )
                {
                    wsprintf(line,"$%s",q);
                    dprintf("SendFileToAllClients::FileCopyToRemoteServer filename (%s) line (%s)\n", filename, line);
                    FileCopyToRemoteServer((char *)name,filename,line);
                }
                RegCloseKey(hckey);
            }
        }
    }
    RegCloseKey(hclkey);

    free(filename);
    inUse = 0;
    RegCloseKey(hackey);

    return;
}
/************************************************************************************************/
/*
void CheckAllClients(void )
{

    HKEY hclkey;
    HKEY hckey;
    int index=0,del;
    char name[IMAX_PATH];
    DWORD   dwClientTimeout;

    // Get the Client Removal timeout.  This value will indicate how long
    // a server should track a client before it removes it from it's list
    // of clients.  Timeout here is in hours.
    dwClientTimeout = GetVal( hMainKey, "ClientExpirationTimeout", 72 );

    if ( RegOpenKey(hMainKey,"Clients",&hclkey) == ERROR_SUCCESS )
    {
        while ( SystemRunning&&RegEnumKey(hclkey,index++,name,sizeof(name)) == ERROR_SUCCESS )
        {
            del = 0;
            if ( RegOpenKey(hclkey,name,&hckey) == ERROR_SUCCESS )
            {
                if ( time(NULL) - GetVal(hckey,"LastCheckinTime",0) > (60L*60L* dwClientTimeout ) )
                {
                    del = 1;
                }
                RegCloseKey(hckey);
                if ( del )
                {
                    RemoveClient(name);
                    index--;
                }
            }
            ThreadSwitch();
        }
        RegCloseKey(hclkey);
    }
    return;
}
*/
/**********************************************************************************************/
/*
#ifndef NLM
BOOL IsItemInList(char *list,char *item)
{

    while ( *list )
    {
        if ( !stricmp(list,item) )
            return TRUE;
        list += strlen(list) + 1;
    }

    return FALSE;
}
#endif // NLM
*/

/**********************************************************************************************/

/*
DWORD CheckUserName(char *name)
{

    if ( stricmp(name,CurrentUserName) )
    {
        ReStartPongEngine(TRUE);
        strcpy(CurrentUserName,name);
        GetSid((PSID)&MainSid);
        dprintf("Got new username %s\n",CurrentUserName);
        NotifyStoragesOfNewUser(CurrentUserName);
        return ERROR_SUCCESS;
    }

    return ERROR_SAME_USER;
}
*/

/*****************************************************************************************************/
char *ModifyLicenseDescription(char *Lic)
{

    char str[32] = "";
    char str2[32];
    char num[16];
    int i; // ??? ksr    = GetLicenseType(Lic);
/**
#ifdef WIN32
    HKEY hkey;
#endif // WIN32
**/

    DWORD cc;

    switch ( i )
    {
        case LIC_60_CLIENT_TDK:
        case LIC_60_TDK:
/**
#ifdef WIN32
            RegCreateKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\VersionControl",&hkey);
            if ( hkey == 0 )
            {
                RegCloseKey(hkey);
                return Lic;
            }

            GetStr(hkey, "ivp60R", str2,sizeof(str2),"");
            RegCloseKey(hkey);

            if ( !StrComp(str2,"000nt4-82bn-07nv") )
            {
                strcpy(str,"(T0)");
                break;
            }
#endif // WIN32
**/

//#ifdef NLM
            {
                FILE *file = fopen(NW_SYSTEM_DIR"\\NOVIVP50.DAT","rt");
                if ( file )
                {
                    fgets(str2,sizeof(str2),file);
                    fclose(file);
                    str2[16]=0;
                }
                else
                {
                    return Lic;
                }
            }
//#endif // NLM
            // ??? ksr   cc = GetLicenseType(str2);

            memcpy(&num[0],&str2[0] ,3);
            memcpy(&num[3],&str2[12],2);
            memcpy(&num[5],&str2[7] ,2);

            if ( cc != LIC_TIMEOUT )
                return Lic;

            cc =  (time(NULL)/(60L*60L*24L)) - atoi(num);
            cc = cc>DAYS?0:DAYS-cc;
            wsprintf(str,"(T%u)",cc);
            break;

        case LIC_60_REAL:       strcpy(str,"(R1)"); break;
        case LIC_60_BETA:    strcpy(str,"(B)"); break;
        case LIC_60_GOLD:    strcpy(str,"(G)"); break;
        case LIC_60_20PACK:  strcpy(str,"(R20)");   break;
        case LIC_60_CLIENT_OEM:   strcpy(str,"(O20)");  break;
        case LIC_60_CLIENT_GOLD:  strcpy(str,"(G)");    break;
        case LIC_60_CLIENT:       strcpy(str,"(C)");    break;
    }

    strcat(Lic,str);
    return Lic;
}
/*****************************************************************************************************/
PONGDATA *GetPongData(PONGDATA *pong)
{

    HKEY hkey;
    char key[IMAX_PATH];
    DWORD index=0;
    VTIME vt;

    memset(pong,0,sizeof(PONGDATA));

	// ksr
//    NTSGetComputerName(pong->ComputerName,NULL);
    GetFileServerName( 0, pong->ComputerName );
    pong->pattVer = GetVal(hMainKey,"UsingPattern",0);
    GetData(hMainKey,"PatternFileDate",&vt,sizeof(vt),NULL,NULL);
    pong->PatternFileDate = DaysOfVTime(&vt);
    // Get NAV daily rev number and IBM sequence number
    pong->dwPatternRevision = GetVal(hMainKey,"PatternFileRevision",0);
    pong->dwPatternSequence = GetVal(hMainKey,"PatternFileSequence",0);

//#if defined NLM
    pong->Flags |= PF_PLATFORM_NLM;

    switch ( NWversion )
    {
        case 3: pong->Flags |= PF_NETWARE_3; break;
        case 4: pong->Flags |= PF_NETWARE_4; break;
        case 5: pong->Flags |= PF_NETWARE_5; break;
    }
    /*
#elif defined WINNT
    pong->Flags |= PF_PLATFORM_WINNT;
#elif defined WIN95
    pong->Flags |= PF_PLATFORM_WIN95;
#endif // WIN95
*/
    if ( GetVal(hMainKey,"ManageClients",0) )
        pong->Flags |= PF_SUPPORT_CLIENTS;
    if ( AmsActive )
        pong->Flags |= PF_USING_AMS;

    if ( GetVal(hProductControlKey,"ManageThisComputer",0) == 0 )
    {
        strcpy(pong->DomainName,"CLIENT_SET");
        strcpy(pong->Mom,CurrentUserName);
        if ( GetVal(hPattManKey,"UpdateClients",1) )
            pong->Flags |= PF_WANT_PATTERN_UPDATES;
    }
    else
    {
        GetStr(hMainKey,"DomainName",pong->DomainName,sizeof(pong->DomainName),"DEFDOMAIN");
        GetStr(hMainKey,"Parent",pong->Mom,sizeof(pong->Mom),"");
        if ( RegOpenKey(hMainKey,"DomainData",&hkey) == ERROR_SUCCESS )
        {
            pong->Flags |= PF_PRIMARY;
            if ( GetVal(hPattManKey,"UpdateChildren",0) )
                pong->Flags |= PF_SHARE;
            RegCloseKey(hkey);
        }
    }
    GetStr(hMainKey,"LicenseNumber",pong->License,sizeof(pong->License),"");
    GetStr(hMainKey,"ConsolePassword",pong->ConsolePassword,sizeof(pong->ConsolePassword),"");
    GetStr(hMainKey,"ScanEngineVendor",pong->ScanEngineVendor,sizeof(pong->ScanEngineVendor),"IBM");

    ModifyLicenseDescription(pong->License);
    pong->ProductVersion = (MAINPRODUCTVERSION*100+SUBPRODUCTVERSION)|(BUILDNUMBER<<16);
    pong->ServiceRelease = GetVal(hMainKey,"ServiceRelease",0);

    GetData(hMainKey,"TimeOfLastVirus",&pong->TimeOfLastVirus,sizeof(VTIME),NULL,NULL);
    pong->InstalledProducts = GetVal(hMainKey,"InstalledProducts",1);
    pong->TransportVersion = TRANSPORT_VERSION;
    GetData(hMainKey,"TimeOfLastSCan",&pong->TimeOfLastScan,sizeof(VTIME),NULL,NULL);
    GetData(hMainKey,"GRCUpdateTime",&pong->GRCTime,sizeof(VTIME),NULL,NULL);
    pong->MySize = sizeof(PONGDATA);
    memset(pong->GuidData,0,16);
    GetData(hMainKey,"GUID",pong->GuidData,16,NULL,NULL);

    if ( RegOpenKey(hMainKey,"Clients",&hkey) == ERROR_SUCCESS )
    {
        while ( RegEnumKey(hkey,index++,key,sizeof(key)) == ERROR_SUCCESS );
        index--;
        RegCloseKey(hkey);
    }

    pong->NumberOfClients = index;
    pong->EngineVersion = GetVal(hMainKey,"ScanEngineVersion",0);
    pong->ComPatNum = COM_PAT_NUM;

    return pong;
}
/***************************************************************************************/

/*
void ReStarter(void)
{
//  REF(nothing);
    return; // this really does not work, and it is not even used.

  NTxSleep(100);
#ifdef NLM
    ThreadsInUse--; // don't count this thread
#endif // NLM
    DeInitPscan();
#ifdef NLM
    ThreadsInUse++; // don't count this thread
#endif // NLM
    NTxSleep(2000);
    InitPscan();

}
*/

/************************************************************************************/

/*
DWORD BeginRestart(void)
{

    return MyBeginThread((THREAD)ReStarter,NULL,"RTV Restarter");
}
*/
//#endif // SERVER




/************************************************************************************/
//#ifndef WIN95
/*
DWORD InitClientMemory(void) {

    LoginArray = malloc(sizeof(PCLIENT_ARRAY)*MaxClients);
    if (LoginArray != NULL) {
        memset(LoginArray,0,sizeof(PCLIENT_ARRAY)*MaxClients);
        return ERROR_SUCCESS;
        }

    return ERROR_MEMORY;
}
*/
/************************************************************************************/
/*
DWORD DeinitClientMemory(void) {

    DWORD i;

    if (LoginArray) {
        for (i=0;i<MaxClients;i++) {
            if (LoginArray[i]) {
                free(LoginArray[i]);
                LoginArray[i] = NULL;
                }
            }
        free(LoginArray);
        }

    LoginArray = NULL;
    return 0;
}
*/
//#endif // !WIN95
/******************************************************************/




DWORD ReportChange(int items
							//,CBA_Addr *address
							)
{

    //EVENTBLOCK log;
    char line[IMAX_PATH];
    mSID sid;

    //set(&log,0,sizeof(EVENTBLOCK));

    MakeFalseSid((PSID)&sid,"User",MakeCBAAddrString(address));

    WSprintf(line,LS(IDS_CONFIG_CHANGED),items);
    /*
    log.Description = line;
    log.Time = 0;
    log.pSid = (PSID)&sid;
    log.Event = GL_EVENT_CONFIG_CHANGE;
    log.Category = GL_CAT_SECURITY;
    log.logger = LOGGER_Console;
    log.hKey[0] = NULL;
    return GlobalLog(&log);
    */
    return (DWORD)1; //ksr ???
}
/*****************************************************************************/
DWORD CheckChange(CBA_Addr *address)
{

    static CBA_Addr LastAddress;
    static int items=0;
    static DWORD LastChange;

    if ( address )
    {
        if ( items == 0 )
        { // first time
            start:
            LastAddress = *address;
            items = 1;
            LastChange = time(NULL);
            return 0;
        }
        else
        {
            if ( memcmp(&LastAddress,address,sizeof(CBA_Addr)) )
            {  // flush old
                ReportChange(items,&LastAddress);
                goto start;
            }
            items++;
        }
    }
    else
    {
        // Fix 'random logging of configuration changes'.
        // Change the minimum interval between writes logged as a single change
        // from 30 minutes to thirty seconds. jallee 4/20/2000
        if ( items && time(NULL) - LastChange > 30 )
        {
            ReportChange(items,&LastAddress);
            items = 0;
        }
    }

    return ERROR_SUCCESS;
}
/**********************************************************************************/
DWORD AddIDToServerStatus(DWORD han)
{

    DWORD x;
    PSCAN_STATUS block;

    LOCK();
    x = (gServerStatus.MRS+1)%MAX_VIEWABLE_SCANS;
    gServerStatus.MRS = x;
    if ( GetScanStatus(gServerStatus.ActiveScans[x].Handle,&block) == ERROR_SUCCESS )
        block->inuse--;
    gServerStatus.ActiveScans[x].Handle = han;
    if ( GetScanStatus(han,&block) == ERROR_SUCCESS )
        block->inuse++;
    UNLOCK();
    return x;
}
/**********************************************************************************/

//DWORD RemoveIDFromServerStatus(DWORD han)
//{




/**********************************************************************************/
//DWORD UpdateIDInServerStatus(DWORD han,DWORD Status)
//




// the following funcions are in ALL modules
/********************************************************************************************************/

/********************************************************************************/
//#if defined(START) || defined(SERVER) || defined(TRANSMAN) || defined (NLMCGI)

/********************************************************************************/
BYTE *GetValueFromBlock(BYTE *block,int element,WORD *size)
{

    BYTE *ret=NULL;
    int i;
    WORD len;


    for ( i=0;i<=element;i++ )
    {
        len = *(WORD*)block;
        block += sizeof(WORD);
        ret = block;
        block += len;
        if ( size )
            *size = len;
    }

    return ret;

}
/***************************************************************************************/
BYTE *GetValueFromEnumBlock(BYTE *block,char *name,DWORD *type,BYTE *data,DWORD *size)
{

    char c;
    int i;
    DWORD oSize;

    i = *(WORD *)block;
    block += sizeof(WORD);
    c = *block;
    *type = c=='D'?REG_DWORD:c=='S'?REG_SZ:c=='M'?REG_MULTI_SZ:REG_BINARY;
    memcpy(name,block+1,i-1);
    block += i;
    oSize = *(WORD *)block;
    block += sizeof(WORD);
    memcpy(data,block,*size=min(*size,oSize));
    block += oSize;

    return block;
}
/********************************************************************************/
DWORD AddValueToBlock(BYTE *block,char *value,DWORD type,WORD size,BYTE *data,DWORD *used)
{

    int t;

    *used = 0;

//  set block and used to end of data to append value/data
    while ( *block )
    {
        //  name, is LPSTR
        *used += NumBytes((char*)block)+1;
        block += NumBytes((char*)block)+1;

        //  type, is DWORD
        *used += sizeof(DWORD);
        block += sizeof(DWORD);

        //  size of data, is WORD
        t = *(WORD *)block;
        *used += sizeof(WORD);
        block += sizeof(WORD);

        //  data, is t bytes
        *used += t;
        block += t;
    }

    // 128 bytes reserved for root path name in packet
    if ( 128 + *used + size + NumBytes(value) + 1 + sizeof(DWORD) + sizeof(WORD) + 2 > MAX_PACKET_DATA )
        return ERROR_NO_MORE_ROOM;

//  append value/data
//  name, is LPSTR
    StrCopy((char*)block,value);
    *used += NumBytes((char*)value)+1;
    block += NumBytes((char*)value)+1;

//  type, is DWORD
    *(DWORD *)block = type;
    block += sizeof(DWORD);
    *used += sizeof(DWORD);

//  size of data, is WORD
    *(WORD *)block = size;
    block += sizeof(WORD);
    *used += sizeof(WORD);

//  data, is size bytes
    memcpy(block,data,size);
    block += size;
    *used += size;

    *block = 0;

    return ERROR_SUCCESS;
}
/********************************************************************************/
DWORD PutRemoteVal(char *CName,char *root,char *value,DWORD val)
{

    BYTE buf[128];
    DWORD used;

    memset(buf,0,sizeof(buf));
    AddValueToBlock(buf,value,(DWORD)REG_DWORD,(WORD)sizeof(DWORD),(BYTE*)&val,&used);
    return SendCOM_SET_VALUES(CName,root,1,buf,used);
}
/********************************************************************************/
DWORD GetRemoteVal(char *CName,char *root,char *value,DWORD def)
{

    BYTE buf[128];
    DWORD count =1;
    DWORD cc;

    memset(buf,0,sizeof(buf));
    lstncat((char *)buf,value,128);

    cc = SendCOM_GET_VALUES(CName,(char *)root,(char *)buf,0,&count);

    if ( cc == ERROR_SUCCESS )
    {
        DWORD Size;
        BYTE *d = GetValueFromBlock(buf,0,(WORD *)&Size);
        if ( Size == sizeof(DWORD) )
            cc = *(DWORD *)d;
        else
            cc = def;
    }
    else
        cc = def;

    return cc;
}
/***************************************************************************************/
DWORD MasterFileCopy(char *FromComputer,char *FromPath,char *ToComputer,char *ToPath,DWORD Flags)
{

    #define CHUNK_SIZE (MAX_PACKET_DATA-32)

    DWORD ret=0;
    DWORD fHan;
    DWORD tHan;
    BYTE buf[MAX_PACKET_DATA];
    int size;
    DWORD len=0,tlen;
    DWORD tmp;
    DWORD loc=0;
    VTIME Time,fTime,tTime;
    char LocalToPath[IMAX_PATH];
    char LocalFromPath[IMAX_PATH];
    int i;
    HKEY hkey;
    BOOL bcopy = FALSE;
    char str[128];
    DWORD retry = GetVal(hMainKey,"FileCopyRetryCount",10);
    DWORD ChunkArray[300];
    DWORD totalNumberOfPacketsToSend=0, sizeOfLastPacket=0;
    DWORD packet=0;
    int sentcount=0;
    static RetryBlockCount=0;
    char options[32];

    AdjustPath(FromPath,LocalFromPath);
    AdjustPath(ToPath,LocalToPath);

    if ( ToComputer )
    {
        if ( ((CBA_Addr *)ToComputer)->addrSize != sizeof(CBA_Addr) )
        {
            WSprintf(str,"AddressCache\\%s",ToComputer);
            if ( RegOpenKey(hMainKey,str,&hkey) == ERROR_SUCCESS )
            {
                DWORD cc = GetVal(hkey,"SupportsBurstCopy",4321);
                if ( cc == 1 )
                {
                    bcopy = TRUE;
                }
                else if ( cc == 4321 )
                {
                    cc = SendCOM_BCLOSE_FILE(ToComputer,1234,NULL,NULL);
                    if ( cc == 1234 )
                    {
                        PutVal(hkey,"SupportsBurstCopy",1);
                        bcopy = TRUE;
                    }
                    else
                        PutVal(hkey,"SupportsBurstCopy",0);
                }
                RegCloseKey(hkey);
            }
        }
    }
    // Force 'burst' mode to OFF.  We already modified DoCOM_BCLOSE_FILE to return 'FALSE'
    // when asked if 'burst' mode is supported.  However, when we do an update, this function
    // gets called on the machine initiating the update.  If the machine to be updated is older,
    // its DoCOM_BCLOSE_FILE will return 'TRUE', so we need to make sure we turn 'burst' mode OFF.
    bcopy = FALSE;

    if ( Flags&(COPY_NEW_FILES|COPY_NEW_AND_CURRENT_FILES) )
    {
        if ( FromComputer==NULL )
        {
            ret = GetFileDate(LocalFromPath,&fTime);
        }
        else
        {
            ret = SendGET_FILE_DATE(FromComputer,FromPath,&fTime);
        }

        if ( ret == ERROR_SUCCESS )
        {
            if ( ToComputer==NULL )
            {
                ret = GetFileDate(LocalToPath,&tTime);
            }
            else
                ret = SendGET_FILE_DATE(ToComputer,ToPath,&tTime);

            if ( ret == ERROR_SUCCESS )
            {
                i = VTcomp(fTime,tTime);
                if ( i < 0 )
                    return ERROR_COPY_OUT_OF_DATE;

                if ( !(Flags&COPY_NEW_AND_CURRENT_FILES) )
                    if ( i == 0 )
                        return ERROR_COPY_OUT_OF_DATE;
            }
        }
    }

    if ( FromComputer == NULL )
    {
        fHan = open(LocalFromPath,O_RDONLY|O_BINARY,0);
        if ( fHan == 0xffffffff )
            return errno;

        size = lseek(fHan,0,SEEK_END);
        lseek(fHan,0,SEEK_SET);
    }
    else
    {
        ret = SendCOM_OPEN_FILE(FromComputer,FromPath,"r",&fHan,(DWORD*)&size);
        if ( ret != ERROR_SUCCESS )
            return ret;
    }

    if ( ToComputer == NULL )
    {
        VerifyPath(LocalToPath);
        tHan = open(LocalToPath,O_WRONLY|O_BINARY|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
        if ( tHan == 0xffffffff )
        {
            ret = errno;
            goto done1;
        }
    }
    else
    {
        StrCopy(options,"wct");
        if ( Flags&COPY_READONLY )
            StrCat(options,"z");
        if ( bcopy )
        {
            ClearBits(ChunkArray, 32*sizeof(ChunkArray));
            ret = SendCOM_BOPEN_FILE(ToComputer,ToPath,options,&tHan,size,CHUNK_SIZE);
        }
        else
            ret = SendCOM_OPEN_FILE(ToComputer,ToPath,options,&tHan,(DWORD*)&tmp);
        if ( ret != ERROR_SUCCESS )
            goto done1;
    }

    if ( bcopy )
    {
        totalNumberOfPacketsToSend = (size+CHUNK_SIZE-1)/CHUNK_SIZE;
        sizeOfLastPacket = size%CHUNK_SIZE;
        if ( sizeOfLastPacket == 0 )
            sizeOfLastPacket = CHUNK_SIZE;
    }

    domore:
    if ( bcopy )
    {
        packet=0;
        size = 1;
        sentcount=0;
    }

    while ( size > 0 )
    {
        if ( bcopy )
        {
            for ( ; packet < totalNumberOfPacketsToSend; packet++ )
            {
                if ( !TestBit(ChunkArray, packet) )
                {
                    len = (packet == totalNumberOfPacketsToSend-1) ? sizeOfLastPacket : CHUNK_SIZE;
                    loc = packet*CHUNK_SIZE;
                    break;
                }
            }

            if ( packet >= totalNumberOfPacketsToSend )
                break;
        }
        else
            len = min(size,sizeof(buf));
        tlen = len;
        if ( FromComputer == NULL )
        {
            lseek(fHan,loc,SEEK_SET);
            len = read(fHan,buf,len);
        }
        else
        {
            for ( i=0,ret=1;ret!=ERROR_SUCCESS&&i<(int)retry;i++ )
            {
                len = tlen;
                ret = SendCOM_READ_FILE(FromComputer,fHan,loc,&len,buf);
                if ( ret != ERROR_SUCCESS ) NTxSleep(55); // some kind of error occured, so lets let things settel down and try again;
            }
            if ( ret != ERROR_SUCCESS )
                goto done2;

        }

        if ( tlen != len )
        {
            ret = ERROR_READ_FAIL;
            goto done2;
        }
        if ( ToComputer == NULL )
        {
            lseek(fHan,loc,SEEK_SET);
            tlen = write(tHan,buf,len);
        }
        else
        {
            for ( i=0,ret=1;ret!=ERROR_SUCCESS&&i<(int)retry;i++ )
            {
                len = tlen;
                if ( bcopy )
                {
                    ret = SendCOM_BWRITE_FILE(ToComputer,tHan,loc,len,buf,packet);
                    if ( (++sentcount%8) == 0 )
                        NTxSleep(20);
                }
                else
                    ret = SendCOM_WRITE_FILE(ToComputer,tHan,loc,&len,buf);
                if ( ret != ERROR_SUCCESS ) NTxSleep(5000); // some kind of error occured, so lets let things settel down and try again;
            }
            if ( ret != ERROR_SUCCESS )
                goto done2;
        }

        if ( tlen != len )
        {
            ret =  ERROR_WRITE_FAIL; // some knid of disk error occured on the remote computer
            goto done2;
        }
        if ( !bcopy )
        {
            size -= len;
            loc += len;
        }
        else
            packet++;
    }

    if ( !bcopy )
    {
        if ( size == 0 )
            ret = ERROR_SUCCESS;
        else
            ret = ERROR_SIZE_FAIL;
    }

    done2:
    if ( ToComputer == NULL )
        close(tHan);
    else
    {
        if ( bcopy )
        {
            DWORD r;
            Time.year = 0;
            if ( Flags&COPY_SAVE_DATE )
            {
                if ( FromComputer==NULL )
                    GetFileDate(LocalFromPath,&Time);
                else
                    SendGET_FILE_DATE(FromComputer,FromPath,&Time);
            }

            r = SendCOM_BCLOSE_FILE(ToComputer,tHan,ChunkArray,&Time);
            if ( r == COM_ERROR_DATA_NEEDED )
            {
                RetryBlockCount++;
                goto domore;
            }
            if ( r == COM_ERROR_BAD_WRITE )
            {
                ret = r;
                goto done1;
            }
        }
        else
            SendCOM_CLOSE_FILE(ToComputer,tHan);
    }

    if ( ret != ERROR_SUCCESS )
    {
        if ( ToComputer == NULL )
            unlink(LocalToPath);
        else
            SendCOM_ACT_ON_FILE(ToComputer,ToPath,"",2);
    }

    done1:
    if ( FromComputer == NULL )
        close(fHan);
    else
        SendCOM_CLOSE_FILE(FromComputer,fHan);

    if ( !bcopy && ret == ERROR_SUCCESS && (Flags&COPY_SAVE_DATE) )
    {
        if ( FromComputer==NULL )
            ret = GetFileDate(LocalFromPath,&Time);
        else
            ret = SendGET_FILE_DATE(FromComputer,FromPath,&Time);

        if ( ret == ERROR_SUCCESS )
        {
            if ( ToComputer==NULL )
                SetFileDate(LocalToPath,&Time);
            else
            {
                ret = SendSET_FILE_DATE(ToComputer,ToPath,&Time);
            }
        }
    }

    return ret;
}



//#endif  // SERVER || ....



/********************************************************************************************************/
/*
static char casBuff[256];

char *MakeCBAAddrString(CBA_Addr *address)
{

    BYTE *ip;

    if ( address->ucProtocol == CBA_PROTOCOL_IP )
    {
        ip = (BYTE *)&address->dstAddr.netAddr.ipAddr;
        WSprintf(casBuff,"(IP)-%u.%u.%u.%u",ip[0],ip[1],ip[2],ip[3]);
    }
    else if ( address->ucProtocol == CBA_PROTOCOL_IPX )
    {
        ip = (BYTE *)&address->dstAddr.netAddr.ipx.ipxNet;
        WSprintf(casBuff,"(IPX)-%02X%02X%02X%02X:%02X%02X%02X%02X%02X%02X",
                 ip[0],ip[1],ip[2],ip[3],
                 address->dstAddr.netAddr.ipx.ipxNode[0],
                 address->dstAddr.netAddr.ipx.ipxNode[1],
                 address->dstAddr.netAddr.ipx.ipxNode[2],
                 address->dstAddr.netAddr.ipx.ipxNode[3],
                 address->dstAddr.netAddr.ipx.ipxNode[4],
                 address->dstAddr.netAddr.ipx.ipxNode[5]);
    }
    else
    {
        StrCopy(casBuff,"UNKNOWN Address Type");
    }


    return casBuff;

}
*/
/********************************************************************************/
DWORD ClearKey(HKEY hkey)
{

    char name[IMAX_PATH];
    DWORD size;
	LONG  lRet = ERROR_SUCCESS;
    size = sizeof(name);


    while ( RegEnumValue(hkey,0,name,&size,0,NULL,NULL,NULL) == ERROR_SUCCESS )
    {
		lRet = RegDeleteValue(hkey,name);

		// The absence of the following Check will result in an infinite loop
		// for cases when RegDeleteValue() fails (e.g. lack appropriate privileges).
        if(ERROR_SUCCESS != lRet)
		{
			dprintf("ClearKey: Failed to delete registry value %s due to error: %08x, breaking ...\n", name, lRet);
			break;
		}
        size = sizeof(name);
    }

    return lRet;
}
/**********************************************************************************/
DWORD RegCopyValues(HKEY source,HKEY dest)
{

    DWORD index=0;
    char name[IMAX_PATH];
    DWORD namesize = sizeof(name);
    BYTE data[IMAX_PATH];
    DWORD datasize = sizeof(data);
    DWORD type;

    while ( RegEnumValue(source,index++,name,&namesize,NULL,&type,data,&datasize) == ERROR_SUCCESS )
    {
        RegSetValueEx(dest,name,0,type,data,datasize);
        namesize = sizeof(name);
        datasize = sizeof(data);
    }

    return ERROR_SUCCESS;
}
/**********************************************************************************/
DWORD RegCopyKeys(HKEY source,HKEY dest)
{

    DWORD index = 0;
    char key[IMAX_PATH];
    HKEY hskey,hdkey;

    while ( RegEnumKey(source,index++,key,sizeof(key)) == ERROR_SUCCESS )
    {
        if ( RegCreateKey(dest,key,&hdkey) == ERROR_SUCCESS )
        {
            if ( RegOpenKey(source,key,&hskey) == ERROR_SUCCESS )
            {
                RegCopyKeys(hskey,hdkey);
                RegCloseKey(hskey);
            }
            RegCloseKey(hdkey);
        }
    }

    return RegCopyValues(source,dest);
}
/**********************************************************************************/
DWORD RegDelKeys(HKEY hBase,char *Key)
{

    char name[IMAX_PATH];
    HKEY hkey;

    if ( Key == NULL )
    {
        while ( RegEnumKey(hBase,0,name,sizeof(name)) == ERROR_SUCCESS )
        {
            RegDelKeys(hBase,name);
        }
        ClearKey(hBase);
    }
    else
    {
        if ( RegOpenKey(hBase,Key,&hkey) == ERROR_SUCCESS )
        {
            while ( RegEnumKey(hkey,0,name,sizeof(name)) == ERROR_SUCCESS )
            {
                RegDelKeys(hkey,name);
            }
            RegCloseKey(hkey);
        }

        RegDeleteKey(hBase,Key);
    }

    return 0;
}



#endif  // 0



/**********************************************************************************/

DWORD UpdateIDInServerStatus(DWORD han,DWORD Status)
{

    int i;

    LOCK();
    for ( i=0;i<MAX_VIEWABLE_SCANS;i++ )
        if ( gServerStatus.ActiveScans[i].Handle == han )
        {
            gServerStatus.ActiveScans[i].Status = Status;
            UNLOCK();
            return 1;
        }
    UNLOCK();
    return 0;
}

/**********************************************************************************/


DWORD RemoveIDFromServerStatus(DWORD han)
{

    int i;
    PSCAN_STATUS block;

    LOCK();
    for ( i=0;i<MAX_VIEWABLE_SCANS;i++ )
        if ( gServerStatus.ActiveScans[i].Handle == han )
        {
            if ( GetScanStatus(han,&block) == ERROR_SUCCESS )
                block->inuse--;
            gServerStatus.ActiveScans[i].Handle = 0;
            UNLOCK();
            return 1;
        }
    UNLOCK();
    return 0;
}


// the following funcions are in ALL modules
/********************************************************************************************************/


/*
BOOL DeleteKeyTree(HKEY hkeyMain, char *szKey)
{
    BOOL        bBad = FALSE,
                bVal=FALSE;
    HKEY        hkeySelf;
    int     iSubKey = 0;
    char        szSubKey[256];
    DWORD       dwSize = sizeof(szSubKey);


    if (RegOpenKey(hkeyMain,szKey,&hkeySelf) != ERROR_SUCCESS)
        return TRUE;

    while (RegEnumKey(hkeySelf,iSubKey,szSubKey,dwSize) == ERROR_SUCCESS)
    {
        bVal |= DeleteKeyTree(hkeySelf, szSubKey);
        dwSize = sizeof(szSubKey);
//      iSubKey++;
    }


    RegCloseKey(hkeySelf);

    bVal |= RegDeleteKey(hkeyMain, szKey) == ERROR_SUCCESS;

    if (!bVal)
        bBad = TRUE;

    return !bBad;
}
*/
/********************************************************************************/
/*
#if defined(CONSOLE) || defined (CLISCAN)
VOID dprintf(char *format,...) {

    va_list marker;
    char line[1024];

    va_start(marker, format);
    vSprintf(line,format,marker);
#ifdef _CONSOLE
    printf(line);
#else // !_CLIENT
    if (debug&DEBUGOUTPUT)
        OutputDebugString(line);
#endif // !_CLIENT
    va_end(marker);
}
#endif // CONSOLE || CLISCAN
*/
/************************************************************************/
int Append(char *buf,char *item)
{

    char *q =buf;
    int total=0,size;
    char found=0;

    while ( *q )
    {
        if ( !stricmp(q,item) )
            found = 1;
        size = strlen(q)+1;
        total += size;
        q += size;
    }

    if ( !found )
    {
        strcpy(q,item);
        size = strlen(q)+1;
        total += size;
        q += size;
        *q = 0;
    }

    return total + 1;
}
/*************************************************************************/
int Remove(char *buf,char *item,int len)
{

    char *q =buf;
    int total=0,size;

    while ( *q )
    {
        size = strlen(q)+1;
        len -= size;
        if ( !stricmp(q,item) )
        {
            memmove(q,q+size,len);
        }
        else
        {
            total += size;
            q += size;
        }
    }

    return total + 1;
}
/*****************************************************************************************/
/*
char *_strncpy(char *d,char *s,int n)
{
    char *org=d;
    n--;
    while ( n&&*s )
    {
        *d++=*s++;
        n--;
    }
    *d=0;
    return org;
}       //MLR Fixed
*/
/***************************************************************************************/
char *lstncat(char *list,char *add,int n)
{

    while ( *list )
    {
        list += strlen(list) + 1;
    }
    _strncpy(list,add,n);
    list[strlen(list)+1] = 0;
    return list;
}
/***************************************************************************************/
int lstlen(char *list)
{

    int len=0;

    do
    {
        len += NumBytes(list) + 1;
        list += NumBytes(list) + 1;
    } while ( *list );

    return len;
}
/******************************************************************************/


#if 0





DWORD _PutData(HKEY hkey,char *sval,void *val,int len,DWORD Type)
{

    char *q,*lastQuote,*firstQuote=NULL;
    char str[IMAX_PATH] = "";
    char t[IMAX_PATH];

    //MWS CODE CHANGE...07/12/2000
    // Variables to support change below.
    BYTE readBuffer[IMAX_PATH];
    DWORD readBufferLength = IMAX_PATH;
    DWORD readBufferType;
    LONG returnCode;
    //END MWS CHANGE...07/12/2000

    if ( !hkey )
        return MINUS_ONE;
/*
#if defined(WIN95) && defined(SERVER)
    if ( hkey == hProductControlKey )
    {
        HANDLE ev = OpenEvent(EVENT_ALL_ACCESS,FALSE,"Win95RegEvent");
        SetEvent(ev);
        CloseHandle(ev);
    }
#endif // WIN95 || SERVER
*/
    strncpy(t,sval,IMAX_PATH-1);    t[IMAX_PATH - 1] = 0;
    lastQuote = StrRChar(t,'\"');
    if ( lastQuote )
    {
        *lastQuote = 0;
        firstQuote = StrRChar(t,'\"');
        if ( firstQuote )
        {
            *firstQuote = 0;
            strcpy(str,firstQuote+1);
        }
        *lastQuote = '\"';
    }

    q = StrRChar(t,'\\');
    if ( firstQuote )
        *firstQuote = '\"';
    if ( q )
    {
        HKEY hckey;
        DWORD ret;
        *q = 0;
        if ( RegOpenKey(hkey,t,&hckey) != ERROR_SUCCESS )
        {
            *q = '\\';
            return MINUS_ONE;
        }
        ret = RegSetValueEx(hckey,str[0]?str:q+1,0,Type,(LPVOID)val,len);
        *q = '\\';
        RegCloseKey(hckey);
        return ret;
    }

    //MWS CODE CHANGE...07/12/2000
    //  While at Volvo, they were complaining about ScanDisk restarting
    //  constantly while Auto-Protect is running on their Win9x systems.  After
    //  some digging I tracked this down to some intermittent file writes on
    //  the system caused by intermittent writing of registry keys.  This
    //  activity was generated by RTVSCN95.EXE  While there are other places
    //  where registry keys are written, this by far seems to be the most
    //  common code path.  So...
    //
    //  What I've done here is add some code that checks to see if the write
    //  about to take place is actually going to change the data already
    //  existing in the registry key.  If not, I skip the write.  To do this,
    //  I read the existing data (should use _GetData, but am unsure of the
    //  parameters) and compare it to what we are about to write.  If they are
    //  the same, I just return ERROR_SUCCESS.
    //
    //  Incident #399727, Defect #??????
    if ( len <= IMAX_PATH ) {
        returnCode = RegQueryValueEx( hkey, str[0]?str:t, NULL, &readBufferType, readBuffer, &readBufferLength );
        if ( returnCode == ERROR_SUCCESS   &&
             readBufferType == Type        &&
             len == (int)readBufferLength  &&
             memcmp( readBuffer, val, len ) == 0 ) {
            return ERROR_SUCCESS;
            }
        }
    //END MWS CHANGE...07/12/2000

    return RegSetValueEx(hkey, str[0]?str:t, 0, Type,(LPVOID)val, len);
}
/******************************************************************************/
DWORD PutStr(HKEY hkey,char *sval,char *val)
{

    return _PutData(hkey,sval,(LPVOID)val,NumBytes(val)+1,REG_SZ);
}
/*******************************************************************************/
DWORD PutData(HKEY hkey,char *sval,void *val,int len)
{

    return _PutData(hkey,sval,(LPVOID)val,len,REG_BINARY);
}
/******************************************************************************/
DWORD PutVal(HKEY hkey,char *sval,DWORD val)
{

    return _PutData(hkey,sval,(LPVOID)&val,sizeof(DWORD),REG_DWORD);
}
/******************************************************************************/
HKEY GetCommonKey(void)
{

    static HKEY hkey;

    if ( !hkey )
        RegOpenKey(hMainKey,"Common", &hkey);

    return hkey;
}
/******************************************************************************/
DWORD GetVal(HKEY hkey,char *sval,DWORD def)
{

    DWORD val = 0;

    GetData(hkey,sval,&val,sizeof(DWORD),&def,NULL);

    return val;
}
/******************************************************************************/
char *GetStr(HKEY hkey,char *sval,char *in,int len,char *def)
{

    GetData(hkey,sval,in,len,def,NULL);
    return in;
}
/******************************************************************************/
DWORD _GetVal(HKEY *hkey,char *sval,DWORD def)
{

    DWORD val = 0;
    BOOL du = 1;

    while ( *hkey && du )
    {
        GetData(*hkey,sval,&val,sizeof(DWORD),&def,&du);
        hkey++;
    }

    if ( du )
        GetData(0,sval,&val,sizeof(DWORD),&def,NULL);

    return val;
}
/******************************************************************************/
char *_GetStr(HKEY *hkey,char *sval,char *in,int len,char *def)
{

    BOOL du = 1;

    while ( *hkey && du )
    {
        GetData(*hkey,sval,in,len,def,&du);
        hkey++;
    }

    if ( du )
        GetData(0,sval,in,len,def,NULL);

    return in;
}
/******************************************************************************/
void *_GetData(HKEY hkey,char *sval,void *in,int len,void *def,BOOL *DefUsed,DWORD *type,DWORD *outSize)
{

    DWORD dwType=0;
    DWORD cbData=0;
    DWORD cc = 0xffffffff;
    char t[IMAX_PATH];
    char *q;

    strncpy(t,sval,IMAX_PATH-1);    t[IMAX_PATH - 1] = 0;
    q = StrRChar(t,'\\');
    if ( q )
    {
        HKEY hckey;
        *q = 0;
        if ( RegOpenKey(hkey,t,&hckey) != ERROR_SUCCESS )
        {
            hkey = GetCommonKey();
            if ( RegOpenKey(hkey,t,&hckey) != ERROR_SUCCESS )
            {
                *q = '\\';
                goto usedef;
            }
        }
        _GetData(hckey,q+1,in,len,def,DefUsed,type,outSize);
        *q = '\\';
        RegCloseKey(hckey);
        return in;
    }

    if ( hkey )
    {
//      *in = 0;
        cbData = len;
        cc = RegQueryValueEx(hkey, t, 0, &dwType,(LPVOID)in, &cbData);
    }

    if ( cc == ERROR_SUCCESS )
    {
        if ( DefUsed )
            *DefUsed = FALSE;
    }
    else
    {
        if ( DefUsed && *DefUsed )
            goto usedef;

        hkey = GetCommonKey();
        if ( hkey )
        {
//          *in = 0;
            cbData = len;
            cc = RegQueryValueEx(hkey, t, 0, &dwType,(LPVOID)in, &cbData);
            if ( cc != ERROR_SUCCESS )
            {
                usedef:     if ( def )
                {
                    __try
                    {
                        memcpy(in,def,len);
                    }
                    __except(1)
                    {
                        // sometimes in WIN32 the len of the def buffer is too short to read from to fill the dest buffer, just trap the exception and go on
                        // this most likly will not happen on netware until novell starts using virtual memory alot more thay they are now.
                    }
                }
                if ( DefUsed )
                    *DefUsed = TRUE;
                dwType = 0xffffffff;
                cbData = len;
            }
            else if ( DefUsed )
                *DefUsed = TRUE;
        }
        else
        {
            goto usedef;
        }
    }

    if ( type )
        *type = dwType;
    if ( outSize )
        *outSize = cbData;

    return in;
}
/*****************************************************************************************************/
void *GetData(HKEY hkey,char *sval,void *in,int len,void *def,BOOL *DefUsed)
{
    return _GetData(hkey,sval,in,len,def,DefUsed,NULL,NULL);
}

#endif  // 0



/*****************************************************************************************************/
// if t1>t2  return +
// if t1<t2  return -
// if t1==t2 return =
int VTcomp(VTIME t1,VTIME t2)
{

    int x;

    if ( (x = t1.year-t2.year)==0 )
        if ( (x = t1.month-t2.month)==0 )
            if ( (x = t1.day-t2.day)==0 )
                if ( (x = t1.hour-t2.hour)==0 )
                    if ( (x = t1.min-t2.min)==0 )
                        if ( (x = t1.sec-t2.sec)==0 || abs(t1.sec-t2.sec) < 10 )
                            return 0;
    return x;
}
/*******************************************************************************************/
DWORD CvtStrToBuf(BYTE *buf,char *str)
{

    char slen[5];
    DWORD c=0;

    while ( str[0] && str[1] )
    {
        memcpy(slen,str,2);
        str += 2;
        slen[2] = 0;
        *buf++ = (BYTE)strtol(slen,NULL,16);
        c++;
    }

    return c;
}
/*****************************************************************************************************/
DWORD VTime2TimeT(VTIME cur)
{

    struct tm tm;
    DWORD t;

    tm.tm_year  =  cur.year + 70;
    tm.tm_mon   =  cur.month;
    tm.tm_mday  =  cur.day;
    tm.tm_hour  =  cur.hour;
    tm.tm_min   =  cur.min;
    tm.tm_sec   =  cur.sec;
    // Let the C-Runtime determine if this is daylight savings time or not
    // by passing -1 into the tm_isdst field (CDR) (SCR37830 & SCR37802)
    tm.tm_isdst = -1;

    t = mktime(&tm);
    if ( t == 0xffffffff )
        t = 0;

    return t;
}
/*****************************************************************************************************/
VTIME VTstr(char *str)
{

    VTIME cur = {0,0,0,0,0,0,0};
    int i = strlen(str);

    if ( i > sizeof(VTIME)*2 || i%2 != 0 )
        return cur;

    CvtStrToBuf((BYTE*)&cur,str);
    return cur;
}
/*****************************************************************************************************/
VTIME vtime(DWORD t)
{

    DWORD val = time(NULL);
    struct tm *tm;
    VTIME cur;

    memset(&cur,0,sizeof(VTIME));

    tm = localtime((const time_t*)(t?&t:&val));

    if ( tm )
    {
        cur.year  = (BYTE)(tm->tm_year-70);
        cur.sec   = (BYTE)tm->tm_sec;
        cur.min   = (BYTE)tm->tm_min;
        cur.hour  = (BYTE)tm->tm_hour;
        cur.day   = (BYTE)tm->tm_mday;
        cur.month = (BYTE)tm->tm_mon;
    }

    return cur;
}
/*****************************************************************************************************/
char *vctime(VTIME cur)
{

    struct tm tm;
    char *str;
    char *q;

    memset(&tm,0,sizeof(tm));

    tm.tm_year = cur.year + 70;
    tm.tm_mon = cur.month;
    tm.tm_hour = cur.hour;
    tm.tm_min = cur.min;
    tm.tm_sec = cur.sec;
    tm.tm_mday =cur.day;

    __try
    {
        str = asctime(&tm);
    }
//#ifndef NLM
    __except(1)
    {
        str = "BAD TIME";
    }
//#endif // NLM

    do
    {
        q = strrchr(str,'\n');
        if ( q )
            *q = 0;
    } while ( q );

    str += 4;

    return str;
}
/*****************************************************************************************************/
/*****************************************************************************************************/
/*****************************************************************************************************/
/*char *GetTimeString(DWORD t) {


    char *str;
    char *q;
//  struct tm *tm = localtime(&t);

    __try {
        str = ctime((time_t *)&t);
        }
    __except(1) {
        str = "BAD TIME";
        }

    do {
        q = strrchr(str,'\n');
        if (q)
            *q = 0;
        } while (q);

    str += 4;

    return str;

}
*/
/*******************************************************************/
DWORD SetDownLoadStatus(DWORD val)
{

    // MMENDON 05-04-2000:  Fixing the spelling of the PatternManager
    //                      registry key
    //return PutVal(hMainKey,"PatternManagrer\\DownLoadStatus",val);
    //return PutVal(hMainKey,"PatternManager\\DownLoadStatus",val);
    // MMENDON 05-04-2000:  End change
}
/*************************************************************************************************************/
DWORD DaysOfVTime(VTIME *vt)
{

    DWORD t = VTime2TimeT(*vt);
    return t / (60*60*24);
}
/*************************************************************************************************************/
DWORD GetVTIMEOfFile(char *name,VTIME *t)
{

    struct stat filestat;
    int han;

    han = open(name,O_RDONLY|O_BINARY);
    if ( han < 0 )
        return ERROR_OPEN_FAIL;

    if ( (fstat(han,&filestat)!=ERROR_SUCCESS) )
    {
        close (han);
        return ERROR_OPEN_FAIL;
    }
    close (han);
    *t = vtime(filestat.st_mtime);
    return ERROR_SUCCESS;
}
/**********************************************************************************************/

/*
void NTsSemaTimedWait(HANDLE *pSema,unsigned long waitTime)
{
//#ifdef NLM
    if ( *pSema != 0 )
        TimedWaitOnLocalSemaphore(*pSema,waitTime); 
/*
#else
    if ( *pSema != 0 )
    {
        WaitForSingleObject(*pSema,waitTime);
    }
#endif

}
*/


/*******************************************************************************************/

// ksr
// #if defined(SERVER) || defined (START)  || defined (NLMCGI)
/**/
char *GetErrorText(DWORD err)
{

    switch ( err )
    {
        case P_NO_PATH: return LS(IDS_P_NO_PATH);
        case P_NO_OPEN_DEVICE: return LS(IDS_P_NO_OPEN_DEVICE);
        case P_SEC_ALLOC_FAIL: return LS(IDS_P_SEC_ALLOC_FAIL);
        case P_INIT_DES_FAIL: return LS(IDS_P_INIT_DES_FAIL);
        case P_SET_DES_FAIL: return LS(IDS_P_SET_DES_FAIL);
        case P_ASYNC_SCAN_MUTEX_FAIL: return LS(IDS_P_ASYNC_SCAN_MUTEX_FAIL);
        case P_PSCAN_START_ERROR: return LS(IDS_P_PSCAN_START_ERROR);
        case P_HOOK_BAD: return LS(IDS_P_HOOK_BAD);
        case P_BAD_KERNAL_CODE: return LS(IDS_P_BAD_KERNAL_CODE);
        case P_NO_DEVICE_HANDLE: return LS(IDS_P_NO_DEVICE_HANDLE);
        case P_VEINIT_FAIL: return LS(IDS_P_VEINIT_FAIL);
        case P_CANNOT_FIND_PATT: return LS(IDS_P_CANNOT_FIND_PATT);
        case P_INVALID_PATT: return LS(IDS_P_INVALID_PATT);
        case P_NO_VIRUS_ENGINE: return LS(IDS_P_NO_VIRUS_ENGINE);
        case P_INVALID_VIRUS_ENGINE: return LS(IDS_P_INVALID_VIRUS_ENGINE);
        case P_ALREADY_RUNNING: return LS(IDS_P_ALREADY_RUNNING);
//        case P_NTS_START_FAIL: return LS(IDS_P_NTS_START_FAIL);
        case P_VERSION_MISMATCH: return LS(IDS_P_VERSION_MISMATCH);
        case ERROR_NO_KEY: return LS(IDS_DATABASE_NOT_INITED);
        case ERROR_MEMORY:
//#ifdef NLM
        case ERROR_NO_MEMORY:
//#endif // NLM
            return LS(IDS_ERROR_MEMORY);
        case P_PSCAN_INSTALL_ERROR: return LS(IDS_P_PSCAN_INSTALL_ERROR);
        case ERROR_SCAN_IN_PROGRESS: return LS(IDS_ERROR_SCAN_IN_PROGRESS);
        case ERROR_BAD_PARAM: return LS(IDS_ERROR_BAD_PARAM);
//#ifdef NLM
        case ERROR_BAD_DATABASE: return LS(IDS_E_BAD_DATA);
        case ERROR_BAD_KEY:
        case ERROR_NO_PATH: return LS(IDS_ERROR_IN_DATABASE);
//#endif // NLM
    }

    return "";
}

/**/

//#endif // SERVER || start

/*******************************************************************************************/

char *_ctime(const time_t *t)
{

    static char out[64];
    char str[32];
    struct tm *tm;
    char sDate[16] = "/";
    char sShortDate[32] = "M/d/yy";
    char s1159[32] = "AM";
    char s2359[32] = "PM";
    char sTimeFormat[64] = "h/m t";
    char sTime[16] = ":";
    DWORD size;
    char *q;

    //HKEY hkey;

    *out = 0;

//#ifdef NLM
    if ( MessageFileLanguageID == 9 )
    {
        strcpy(sDate,"/");
        strcpy(sShortDate,"m/d/y");
        strcpy(s1159,"\x8c\xdf\x91\x4f");
        strcpy(s2359,"\x8c\xdf\x8c\xe3");
        strcpy(sTimeFormat,"h/m");
    }
//#endif

/**
#ifdef  WIN32
    if ( RegOpenKey(HKEY_CURRENT_USER,"Control Panel\\International",&hkey) == ERROR_SUCCESS )
    {
#else
    //if ( RegOpenKey(HKEY_LOCAL_MACHINE,"Time",&hkey) == ERROR_SUCCESS )
    {
#endif
        size = sizeof(sDate);
        RegQueryValueEx(hkey,"sDate",0,NULL,(unsigned char *)sDate,&size);
        size = sizeof(sShortDate);
        RegQueryValueEx(hkey,"sShortDate",0,NULL,(unsigned char *)sShortDate,&size);
        size = sizeof(s1159);
        RegQueryValueEx(hkey,"s1159",0,NULL,(unsigned char *)s1159,&size);
        size = sizeof(s2359);
        RegQueryValueEx(hkey,"s2359",0,NULL,(unsigned char *)s2359,&size);
        size = sizeof(sTime);
        RegQueryValueEx(hkey,"sTime",0,NULL,(unsigned char *)sTime,&size);
        size = sizeof(sTimeFormat);
        RegQueryValueEx(hkey,"sTimeFormat",0,NULL,(unsigned char *)sTimeFormat,&size);
        RegCloseKey(hkey);
    }
*/
    tm = localtime(t);
    while ( (q=strchr(sShortDate,'\\')) != 0 )
    {
        *q = '/';
    }

    q = strtok(sShortDate,"/");
    while ( q )
    {
        switch ( toupper(*q) )
        {
            case 'M': wsprintf(str,"%02u",tm->tm_mon+1); break;
            case 'D': wsprintf(str,"%02u",tm->tm_mday); break;
            case 'Y': wsprintf(str,"%02u",tm->tm_year+1900); break;      
        }
        if ( *out )
            strcat(out,sDate);
        strcat(out,str);
        q = strtok(NULL,"/");
    }


    if ( sTimeFormat[strlen(sTimeFormat)-1] != 't' )
    {
        wsprintf(str," %u:%02u  ",tm->tm_hour,tm->tm_min);
    }
    else
    {
        if ( tm->tm_hour == 0 )
        {
            wsprintf(str," 12:%02u %s ",tm->tm_min,s1159);
        }
        else if ( tm->tm_hour == 12 )
        {
            wsprintf(str," 12:%02u %s ",tm->tm_min,s2359);
        }
        else if ( tm->tm_hour > 12 )
        {
            wsprintf(str," %u:%02u %s  ",tm->tm_hour-12,tm->tm_min,s2359);
        }
        else
            wsprintf(str," %u:%02u %s  ",tm->tm_hour,tm->tm_min,s1159);
    }

    strcat(out,str);


    return out;
}

/*
char *_ctime(DWORD *t) {

    static char out[32];
    struct tm *tm;

    tm = localtime(t);
    wsprintf(out,"%02u/%02u/%04u  %u:%02u",tm->tm_mon+1,tm->tm_mday,tm->tm_year+1900,tm->tm_hour,tm->tm_min);

    return out;
}
*/


/************************************************************************************/
char *StrRep(char *line,char *find,char *rep)
{

    char *q = line;
    int dif = strlen(rep) - strlen(find);
    int sFind = strlen(find);
    int sRep = strlen(rep);
    char *w;

    do
    {
        w = strstr(q,find);
        if ( w )
        {
            if ( dif )
                memmove(w+sFind+dif,w+sFind,strlen(w));
            memcpy(w,rep,sRep);
            q = w+sRep;
        }
    } while ( w );

    return line;
}
/************************************************************************************/
DWORD _VerifyPath(char *path)
{

    DWORD ret;
    char *q;

//  dprintf ("_VerifyPath (%s)\n",path);
    if ( !access(path,0) )
        return 0;

    q = StrRChar(path,'\\');
    if ( !q )
        return 1;

    *q = 0;
    ret = _VerifyPath(path);
    *q = '\\';
    if ( ret == 0 )
        ret = mkdir(path);

    return ret;
}
/************************************************************************************/

DWORD VerifyPath(char *path)
{

    char Path[IMAX_PATH];
    char *q;

    strcpy(Path,path);
    q = StrRChar(Path,'\\');
    if ( !q )
        return 1;

    *q = 0;
    return _VerifyPath(Path);
}


/************************************************************************************/

//////////////////////////////////////////////////////////////////
//
// Function: MissedEvent
//
// Description: This function determines whether or not a
// scheduled repeating event has been missed, and should be run.
//
// Params: HKEY          [IN]: Handle to a schedule reg key
//         time_t        [IN]: Current time
//         pdwMinOfDay   [IN]: Minute of day
//         pdwDayOfWeek  [IN]: Day of Week
//         pdwDayOfMonth [IN]: Day of Month
//
// Returns: TRUE:  If the event should be run now.
//          FALSE: Otherwise.
// 
//////////////////////////////////////////////////////////////////
// 12/14/99 MHOTTA :: Function Created
//////////////////////////////////////////////////////////////////

#define mtos(x) ((x) * 60L) // Convert x minutes to seconds
#define dtos(x) ((x) * 24L * 3600L) // Convert x days to seconds

BOOL MissedEvent( //HKEY hkey, 
                    time_t tNow, DWORD* pdwMinOfDay, DWORD* pdwDayOfWeek, DWORD* pdwDayOfMonth )
{
    int nType;
    int nAllowSkipEvent;
    int nSkipped=0;
    time_t tLastStart;
    time_t tCSR=0;  /* Current scheduled run time */
    time_t tNewLastStart=0;
    time_t tWindow=0;
    time_t tCreated=0;
    BOOL bRet=FALSE;
    BOOL bFirstRun=FALSE;

    // Check to see if Missed Events is enabled
    //if ( GetVal( hkey, "Schedule\\MissedEventEnabled", 0 ) == 0 )
    {
        //dprintf( "MissedEvents: Disabled\n" );
        return FALSE;
    }

    // Initialize some variables
//    tLastStart = (time_t) GetVal( hkey, "Schedule\\LastStart", 0 );
//    nType = (int) GetVal( hkey, "Schedule\\Type", 0 );
//    nAllowSkipEvent = (int) GetVal( hMainKey, "AllowSkipEvent", 3 );

    //
    // Don't allow the current time to be before the last start time
    //
    if ( tNow < tLastStart )
    {
        dprintf( "MissedEvents: Invalid time.\n" );
        return FALSE;
    }

    //
    // If there is no last start time, do some checking
    //
    if ( 0 == tLastStart )
    {
        //
        // Check to see if there's a create time -
        // this could be a first run.  If not,
        // return FALSE
        //
//        if ( ( tCreated = (time_t) GetVal( hkey, "Schedule\\Created", 0 ) ) == 0 )
        {
            dprintf( "MissedEvents: No last start and create time. tCreated=%ld\n" );
            return FALSE;
        }

        bFirstRun = TRUE;
        //
        // This is a first run, so determine the first run time
        //
        tCSR = CalculateFirstRunTime( (int) *pdwMinOfDay,
                                      (int) *pdwDayOfWeek,
                                      (int) *pdwDayOfMonth,
                                      tCreated,
                                      nType );
        if ( !tCSR )
        {
            dprintf( "MissedEvents: Could not get valid first start time. tCSR=%ld\n", tCSR );
            return FALSE;
        }
    }

    //
    // Now do the calculations depending on the type of schedule
    //

    switch ( nType )
    {
        case S_DAILY:
            if ( !bFirstRun )
            {
                //
                // Calculate current scheduled run time
                //
                tCSR = tLastStart + dtos(1) + mtos(2);
                //
                // Calculate how many events were skipped
                //
                nSkipped = ( tNow - tLastStart ) / dtos(1);
                //
                // Calculate new start time to stamp in the registry
                //
                tNewLastStart = tLastStart + dtos(nSkipped);
            }
            else
            {
                //
                // Calculate the number of skipped events from the
                // scheduled time
                //
                nSkipped = ( tNow - tCSR ) / dtos(1);
                //
                // Count the case when we're just past the scheduled run time
                //
                if ( tNow > tCSR )
                    nSkipped++;

                tNewLastStart = tCSR + dtos(nSkipped-1);
            }
            //
            // Calculate the skip window, if any
            //
//            tWindow = GetVal( hkey, "Schedule\\TimeWindowDaily", 0 ) * 3600L;
            break;
        case S_WEEKLY:
            //
            // Do calculations as above for weekly events
            //
            if ( !bFirstRun )
            {
                tCSR = tLastStart + dtos(7) + mtos(2);
                nSkipped = ( tNow - tLastStart ) / dtos(7);
                tNewLastStart = tLastStart + ( nSkipped * dtos(7) );
            }
            else
            {
                nSkipped = ( tNow - tCSR ) / dtos(7);

                if ( tNow > tCSR )
                    nSkipped++;

                tNewLastStart = tCSR + ( ( nSkipped - 1 ) * dtos(7) );
            }
//            tWindow = GetVal( hkey, "Schedule\\TimeWindowWeekly", 0 ) * dtos(1);
            break;
        case S_MONTHLY:
            if ( !bFirstRun )
            {
                tCSR = tLastStart + dtos(GetMonthDays(tLastStart)) + mtos(2);
                //
                // To get the skipped count, calculate the # of days in each skipped
                // month
                //
                if ( ( tNow - tLastStart ) > dtos(GetMonthDays(tLastStart)) )
                {
                    //
                    // More than a month - 
                    // get the number of days for each month missed
                    //
                    int mdays = 0;
                    time_t tTmp = tLastStart;

                    while ( tNow > tTmp )
                    {
                        //
                        // Get the # of days in the next month
                        //
                        mdays = GetMonthDays( tTmp );
                        tTmp += dtos(mdays);

                        //
                        // Increment the skipped count
                        //
                        nSkipped++;

                        //
                        // Add the number of full month days to the new last start value
                        //
                        if ( tNow > tTmp )
                            tNewLastStart += dtos(mdays);
                    }

                    //
                    // Don't count the first month as skipped
                    //
                    nSkipped--;
                }

                tNewLastStart += tLastStart;
            }
            else // First Run
            {
                if ( ( tNow - tCSR ) > dtos(GetMonthDays(tCSR)) )
                {
                    int mdays = 0;
                    time_t tTmp = tCSR;

                    while ( tNow > tTmp )
                    {
                        mdays = GetMonthDays( tTmp );
                        tTmp += dtos(mdays);
                        nSkipped++;

                        if ( tNow > tTmp )
                            tNewLastStart += dtos(mdays);
                    }

                    nSkipped--;
                }
                //
                // Are we past the first run time in the current month?
                //
                if ( tNow > tCSR )
                    nSkipped++;

                tNewLastStart += tCSR;
            }

//            tWindow = GetVal( hkey, "Schedule\\TimeWindowMonthly", 0 ) * dtos(1);
            break;
        default:
            break;
    }

    if ( tNow > tCSR )
    {
        //
        // *Missed Event*
        //

        //
        // Is it inside our window?
        //
        if ( tNow < ( tCSR + tWindow ) )
        {
            bRet = TRUE;
        }
        else
        {
            //
            // Not inside our window, should we force a run?
            //
            if ( nAllowSkipEvent && nSkipped > nAllowSkipEvent )
                bRet = TRUE;
            //else
//                PutVal( hkey, "Schedule\\SkipEvent", (DWORD)nSkipped );
        }
    }

    if ( TRUE == bRet )
    {
//        PutVal( hkey, "Schedule\\LastStart", tNewLastStart );
//        PutVal( hkey, "Schedule\\SkipEvent", 0 );
    }

    return bRet;
} /*MissedEvent()*/







#if 0

DWORD AdjustPath(//char *key,
                    char *path)
{

    DWORD   dwClientType = 0;
    DWORD   dwError;

    // Get the client type
    //dwClientType = GetVal(hMainKey,"ClientType",0);

    //if ( *key == '$' )  // VP Home dir
    {
		if ( IsWinNT() && dwClientType == CLIENT_TYPE_CONNECTED || dwClientType == CLIENT_TYPE_STANDALONE )
		{
            // Are we a client running on WinNT?
            // Set the path to the common app data directory
            dwError = GetAppDataDirectory( NAV_COMMON_APP_DATA , path ) ;
        }
		else if ( IsWinNT() && dwClientType == CLIENT_TYPE_SERVER )
		{
    		//  Check for the commonly used data directories
			if ( strstr( strupr(key), _T("LOGS")) ||
				 strstr( strupr(key), _T("QUARANTINE")) ||
				 strstr( strupr(key), _T("XFER")) )
			{
				// Set the path to the common app data directory
				dwError = GetAppDataDirectory( NAV_COMMON_APP_DATA , path ) ;
			}
			else
            {
                // All other server directories are here
                StrCopy(path,HomeDir);
            }
        }
        else
        {
            // Use the install/home dir in all other cases
            StrCopy(path,HomeDir);
        }
        key++;
    }
    else if ( *key == '#' ) // System
    {
//#ifdef NLM
        strcpy(path,NW_SYSTEM_DIR);
//#endif

/**
#ifdef WIN32
        GetSystemDirectory(key,IMAX_PATH);
#endif
**/

        key++;
    }
    else
        path[0] = 0;

    StrCat(path,key);

    return 0;
}


//#ifdef SERVER
/***************************************************************************************/
/***************************************************************************************/
int _FileMatch(char *word,char *pattern)
{

    int rv;
    char *pp, *sp;

    /* test special case for generic eof, if 1st char doesn't match, eof */
    if ( *word != *pattern && *pattern != '*' && *pattern != '?' )
        return -1;
    pp = pattern;
    sp = word;
    while ( *pp && *sp )
    {
        if ( *pp == '*' )
        {
            pp++;
            while ( *sp )
            {
                while ( *pp && *sp != *pp )
                {
                    if ( !*sp )
                        return(int) (sp - word);
                    /* no match at end of word */
                    sp++;
                }
                if ( *pp == 0 )
                    return 0;   /* * followed by null matches anything */

                /*  call self to see if rest of word matches after 1st char found matching*/
                rv = _FileMatch(sp, pp);
                if ( rv == 0 )
                    return 0;
                sp++;
            }
            return(int) (sp - word);
        }
        else if ( *pp == '?' || *pp == *sp )
        {        /* we matched */
            if ( *pp == '?' && *sp == '.' )
            {
                while ( *pp == '?' )
                    pp++;
                if ( *pp != '.' )
                    return -1;
            }
            pp++;
            sp++;
        }
        else
        {         /* we didn't match */
            return(int) (sp - word);
        }
    }
    if ( *pp == *sp || (*sp == 0 && *pp == '*' && pp[1] == 0) )
        return(0);
    else return(int) (sp - word);
}
/*****************************************************************************/
int FileMatch(char *word,char *pattern)
{

    char wordDOT[IMAX_PATH];
    strcpy(wordDOT,word);
    if ( strchr(word,'.') == NULL )
        strcat(wordDOT,".");

    strupr(wordDOT);

    if ( wordDOT[strlen(wordDOT)-1] == '\n' )
        wordDOT[strlen(wordDOT)-1] = 0;

    return(_FileMatch(wordDOT,pattern));
}
/***************************************************************************************/
BOOL MyCompareString(char *String,char *Search,DWORD len,BOOL caseSense)
{

    DWORD
    i;

    if ( caseSense )
    {
        for ( i=0 ; Search[i] && i<len ; i++ )
        {
            if ( !String[i] || (Search[i] !='?' && (caseSense?String[i]:toupper(String[i]))!=(caseSense?Search[i]:toupper(Search[i]))) ) // ? are wildcard characters
                return FALSE;
        }
    }
    else
        return !FileMatch(String,Search);

    return TRUE;
}
/***************************************************************************************/
//DWORD CheckOldVersions(char *path);
//#ifdef NLM
    #define LOGIN_DIR "login"
    /*
#else
    #define LOGIN_DIR "logon"
#endif
*/

void UpdateLoginPatternFile(void)
{
/*
This function replaces references to the old pattern file in wkstacfg.ini and copies 
the new pattern file to the local login directory (%VPHOME%\Login)

If this is running on NetWare we also copy the new pattern file into the system 
directory (NW_LOGIN_DIRECTORY)
*/
    char
    *p,
    *pf,
    *pfs,
    oldpfs[64],
    line[1024],
    BackupFile[MAX_PATH],
    TempFile[MAX_PATH],
    LoginFile[MAX_PATH];
    FILE
    *new,
    *ini;
    BOOL ReplacementMade=FALSE;
    DWORD ver;

    dprintf ("UpdateLoginPatternFile\n");

    pf=strrchr (PatternFileUsed,'\\');
    if ( !pf ) return;
    pf++;

    ver = VDBVersion(pf);
    dprintf ("\tExamining wkstacfg.ini\n");

    Sprintf (LoginFile,"%s\\" LOGIN_DIR "\\wkstacfg.ini",HomeDir);
    Sprintf (TempFile,"%s\\" LOGIN_DIR "\\wkstacfg.new",HomeDir);

    ini=fopen (LoginFile,"rt");
    if ( ini )
    {
        dprintf ("wkstacfg.ini file opened\n");

        new=fopen (TempFile,"wt");
        if ( new )
        {
            dprintf ("wkstacfg tempfile opened\n");

            pfs=GetPatternSearch();
            dprintf ("PatternSearch: (%s)\n",pfs);

            //GetStr (hMainKey,"OldPatternSearch",oldpfs,64,"lpt$vpn.???"); // we know what the Newport pattern file name was so use as default
            dprintf ("OldPatternSearch: (%s)\n",oldpfs);

            strupr(pfs);
            strupr(oldpfs);

// read through the wkstacfg.ini file to replace any references to the previous pattern file.
            while ( fgets(line,1024,ini) )
            {

                if ( feof(ini) ) break;

                p=strchr(line,'=');
                if ( p )
                {
                    p++;
// if the current pattern file is already there ignore it
// if we find the old pattern file search or the current pattern file search on the line replace it
                    if ( strnicmp (p,pf,strlen (pf)) && (MyCompareString(p,pfs,strlen(pfs),FALSE) || MyCompareString(p,oldpfs,strlen(oldpfs),FALSE)) )
                    {
                        dprintf ("\tOld Pattern File: %s\tNew Pattern File: %s\n",p,pf);
                        strcpy (p,pf);
                        strcat (line,"\n\0");
                        //PutStr (hMainKey,"OldPatternSearch",pfs);
                        ReplacementMade=TRUE;
                    }
                }
                fputs (line,new);
            }
            dprintf ("Done with ini file: replacement%s made\n",ReplacementMade?"":" NOT");
            fclose (new);
        }
        else
        {
            dprintf ("\tUnable to open file: %s\n",TempFile);
        }
        fclose (ini);

        dprintf ("\tCopying pattern file into local login directory\n");
        Sprintf (LoginFile,"%s\\" LOGIN_DIR ,HomeDir);
// get rid of unecessary pattern files in VPHOME\login directory
        CheckOldVersions (LoginFile,ver); 

// copy the current pattern file into the vphome\login directory
        strcat (LoginFile,"\\");
        strcat (LoginFile,pf);
        if ( MasterFileCopy(NULL, PatternFileUsed, NULL, LoginFile, COPY_ALWAYS|COPY_SAVE_DATE)==0 )
        {
            dprintf ("pattern file copied into local login directory\n");

//#ifdef NLM 
            dprintf ("\tCopying pattern file into NetWare system login directory\n");
            Sprintf (LoginFile,LOGIN_DIR "\\%s",pf);
            if ( CopyNewFile (LoginFile,TRUE)==0 )
            {
                char SystemLoginDir[MAX_PATH];
                //GetStr (hMainKey,"LoginDir",SystemLoginDir,sizeof (SystemLoginDir),NW_LOGIN_DIRECTORY);
// get rid of unecessary pattern files in netware system login directory
                CheckOldVersions (SystemLoginDir,ver);
//#endif

                if ( ReplacementMade )
                {// no need to update wkstacfg.ini if we didn't replace anything
                    dprintf ("\tCopying wkstacfg.ini into local login directory\n");
                    Sprintf (LoginFile,"%s\\" LOGIN_DIR "\\wkstacfg.ini",HomeDir);
                    Sprintf (BackupFile,"%s\\" LOGIN_DIR "\\wkstacfg.bak",HomeDir);
                    Sprintf (TempFile,"%s\\" LOGIN_DIR "\\wkstacfg.new",HomeDir);

                    if ( unlink(BackupFile)!=0 )
                    {
                        dprintf ("\tunlink (%s) failed\n",BackupFile);
                    }
                    if ( rename(LoginFile,BackupFile)!=0 )
                    {
                        dprintf ("\trename(%s,%s) failed\n",LoginFile,BackupFile);
                    }
                    if ( rename(TempFile,LoginFile)!=0 )
                    {
                        dprintf ("\trename(%s,%s) failed\n",TempFile,LoginFile);
                    }
                }

//#ifdef NLM 
                if ( ReplacementMade )
                { // no need to copy if we didn't replace anything
                    dprintf ("\tCopying wkstacfg.ini into NetWare system login directory\n");
                    Sprintf (LoginFile, LOGIN_DIR "\\wkstacfg.ini");
                    if ( CopyNewFile (LoginFile,TRUE)!=0 )
                    {
                        dprintf ("\tCopyNewFile (%s) returned non-zero\n",LoginFile);
                    }
                }
            }
            else
            {
                dprintf ("\tCopyNewFile (%s) returned non-zero\n",LoginFile);
            }
//#endif // def NLM

        }
        else
        {
            dprintf ("\tMasterFileCopy (%s,%s) returned non-zero\n",PatternFileUsed,LoginFile);
        }
    }
    else
    {
        dprintf ("\tUnable to open file: %s\n",LoginFile);
    }
}

#endif  // 0



/*******************************************************************************************/

DWORD CopyNewFile (char *file,BOOL force)
{
    char
    dest[MAX_PATH],
    src[MAX_PATH],
    //SystemLoginDir[MAX_PATH],
    *f;
    int
    ret;
//      newer=0;

    if ( !file ) 
    	return 1;

    while ( isspace(file[strlen(file)-1]) )
        file[strlen(file)-1]=0;

    Sprintf (src,"%s\\%s",HomeDir,file);

    f=strchr (file,'\\');
    if ( !f ) return 1;
    *f=0;
    f++;

    //memset (SystemLoginDir,0,sizeof (SystemLoginDir));
    
/**
#ifdef NLM
    //GetStr (hMainKey,"LoginDir",SystemLoginDir,sizeof (SystemLoginDir),"");
#else // ifdef WIN32
    Sprintf (SystemLoginDir,NT_LOGIN_DIRECTORY,HomeDir);
#endif
**/
    //if ( strlen (SystemLoginDir)==0 ) return 1;

    //if ( !strnicmp(file,"login",5) )
    //    Sprintf (dest,"%s\\%s",SystemLoginDir,f);
//#ifdef NLM
    //else 
    if ( !strnicmp(file,"system",6) )
        Sprintf (dest,NW_SYSTEM_DIR"\\%s",f);
//#endif
    else
        return 1;
    dprintf ("Copying %s to %s\n",src,dest);
//#ifdef NLM
    MakeWriteable (dest,0xfffffffc);
//#endif
    ret=MasterFileCopy(NULL,src,NULL,dest, COPY_SAVE_DATE|(force?COPY_ALWAYS:COPY_NEW_AND_CURRENT_FILES));

/*  if (!force)
        newer=CheckNewerFileTime(dest,src);

    if (force || newer<=0)
        ret=MyCopyFile(src,dest);*/

    if ( ret )
        dprintf ("Error %x copying file: \"%s\" to \"%s\"\n",ret,src,dest);

    return ret?1:0;
}


/*****************************************************************************/


#if 0



//#if defined(SERVER) || defined(CLISCAN) || defined(TRANSMAN) || defined(CLIPROXY)  || defined (NLMCGI)
/***********************************************************************/
char *GetLogStr(char *LogLine,DWORD index,char *Item)
{

    //just call the length limited version with unlimited lenghth
    return GetLogStrEx( LogLine, index, Item, 0xffffffff ); 

}

/***********************************************************************/
char *GetLogStrEx(char *LogLine,DWORD index,char *Item, unsigned int nItemLen)
{


    char *start;
    DWORD pos=0;
    char *end,*next=LogLine;
    unsigned int     nCurrLen, nMaxLen;

    Item[0] = 0;

    // loop for each delimited item

    while ( next )
    {
        start = next;
        if ( *start == '\"' )
        {
            start++;
            end = StrChar(start,'\"');
            if ( end==NULL )
                return "";
            next = StrChar(end,',');
        }
        else
        {
            end = StrChar(start,',');
            next = end;
        }

        // is this the item I want?

        if ( pos++ == index )
        {
            char c=0;

            // does it begin with "
            if ( end )
            {
                c = *end;
                *end = 0;   // nuke closing quote
            }

            nCurrLen = strlen( start ) + 1;

            // handle the length limits
            if ( nCurrLen <= nItemLen )
            {
                StrCopy(Item,start);        // plenty of room
            }
            else
            {
                // this should be moved to the message file in the next release
                char szContinues[] = "+";

                // copy the string, leaving enough room for szContinues + <EOS>
                nMaxLen = nItemLen-strlen(szContinues)-1;

                // a comment for the curious - the local RTVSCAN version of strncpy actually
                // puts a trailing 0 even when the string is too short for the buffer 
                // - this makes the string too short by one, so I test for this, and then redo it.
                // I have enough room to copy a little bit more. This behavior
                // here is friendly, but non-standard. I check for it just in case somebody
                // ever puts it back, because I am relying on the lenghth coming out right.

                StrNCopy(Item, start, nMaxLen);
                // note arithmetic is multi-byte OK here because I am looking for 0
                if ( Item[nMaxLen-1] == 0 )
                {
                    // strncpy made the string too short - redo it
                    StrNCopy(Item, start, nMaxLen+1);
                }
                Item[nMaxLen] = 0;  // terminate the string gracefully

                // this should just fill it up
                StrCat(Item, szContinues);  
            }

            if ( end )
                // restore closing quote - the buffer wasn't mine
                *end = c;
            break;
        }
        if ( next )
            next++;
    }
    return Item;
}
/***********************************************************************/
DWORD GetLogVal(char *LogLine,DWORD index)
{

    char str[32];

    return atoi(GetLogStrEx(LogLine,index,str,sizeof(str)));
}
/***********************************************************************/
DWORD CreateEventFromLogLine(PEVENTBLOCK *out,char *Line)
{

    char user[NAME_SIZE];
    char computer[NAME_SIZE];
    char virus[MAX_VIRUS_NAME]={""};
    char description[IMAX_PATH];
    char buf[32];
    char eventdata[128];
    char parentserver[NAME_SIZE] = {0};
    char szGUID[NAME_SIZE] = {0};

//rchinta
/**
#ifdef WIN32
    DWORD   dwDepthOfFileToGet = 0;
    BOOL    bIsCompressed = FALSE;
    DWORD   dwStillInfected = 0;
    DWORD   SizeP;                      // Size of DECOMPFILEINFO
    DWORD   dwCleanType=0;
    DWORD   dwDeleteType=0;
#endif
**/

//#ifdef NLM //EA 05/15/2000
    DWORD   dwCleanType=0;//EA 05/15/2000
    //DWORD   dwDeleteType=0;//EA 05/15/2000 commenting it out since dwDelete is not implemented in NAVAPI when it gets
    //implemented we need to uncomment this 
//#endif//EA 05/15/2000

    PEVENTBLOCK cur;
    DWORD SizeD,SizeV,SizeE,SizeS,SizeG,Size;
    BOOL f = GetLogVal(Line,LI_CAT) == GL_CAT_INFECTION;

    if ( f )
    {
        GetLogStrEx(Line,LI_VIRUS,virus,sizeof(virus));
        GetLogStrEx(Line,LI_FILE,description,sizeof(description));
        GetLogStrEx(Line,LI_GUID,szGUID,sizeof(szGUID));

/**
#ifdef WIN32
        bIsCompressed       = GetLogVal(Line,LI_COMPRESSED);
        dwDepthOfFileToGet  = GetLogVal(Line,LI_DEPTH);
        dwStillInfected     = GetLogVal(Line,LI_STILL_INFECTED);
        dwCleanType         = GetLogVal(Line,LI_CLEANINFO);
        dwDeleteType        = GetLogVal(Line,LI_DELETEINFO);
#endif // WIN32
**/

//#ifdef NLM//EA 05/15/2000
        dwCleanType         = GetLogVal(Line,LI_CLEANINFO);//EA 05/15/2000
        //dwDeleteType        = GetLogVal(Line,LI_DELETEINFO);//EA 05/15/2000 commenting it out since dwDelete is not implemented in NAVAPI when it gets
        //implemented we need to uncomment this
//#endif//EA 05/15/2000
    }
    else
        GetLogStrEx(Line,LI_DESCRIPTION,description,sizeof(description));

    GetLogStrEx(Line,LI_COMPUTER,computer,sizeof(computer));
    GetLogStrEx(Line,LI_USER,user,sizeof(user));
    GetLogStrEx(Line,LI_EVENT_DATA,eventdata,sizeof(eventdata));
    GetLogStrEx(Line,LI_TIME,buf,sizeof(buf));
    GetLogStrEx(Line,LI_PARENT,parentserver,sizeof(parentserver));

    SizeD = NumBytes(description)+1;
    SizeV = NumBytes(virus)+1;
    SizeE = NumBytes(eventdata)+1;
    SizeS = NumBytes(parentserver)+1;
    SizeG = NumBytes(szGUID)+1;

//rchinta
/**
#ifdef WIN32

    //TODO: Investigate if File Name info needs to be retrieved.  If so, read from the
    // log line and also include the appropriate lengths in SizeP
    SizeP = sizeof(DECOMPFILEINFO);

    cur = malloc(Size = (sizeof(EVENTBLOCK) + sizeof(mSID) + SizeD + SizeV + SizeE + SizeP + SizeS + SizeG));

#else // !WIN32
**/
    cur = malloc(Size = (sizeof(EVENTBLOCK) + sizeof(mSID) + SizeD + SizeV + SizeE + SizeS + SizeG));
//#endif // WIN32


    if ( cur )
    {
        memset(cur,0,sizeof(EVENTBLOCK));

        cur->pSid               = (PSID)(cur+1);
        cur->Description        = (char*)(cur+1)+sizeof(mSID);
        cur->VirusName          = (char*)(cur+1)+sizeof(mSID)+SizeD;
        cur->EventData          = (BYTE*)(cur+1)+sizeof(mSID)+SizeD+SizeV;
        cur->lpParent           = (char*)(cur+1)+sizeof(mSID)+SizeD+SizeV+SizeE;
        cur->lpGUID             = (char*)(cur+1)+sizeof(mSID)+SizeD+SizeV+SizeE+SizeS;
        cur->Event              = GetLogVal(Line,LI_EVENT);
        cur->Category           = GetLogVal(Line,LI_CAT);
        cur->logger             = GetLogVal(Line,LI_LOGGER);
        cur->WantedAction[0]    = GetLogVal(Line,LI_ACTION1);
        cur->WantedAction[1]    = GetLogVal(Line,LI_ACTION2);
        cur->RealAction         = GetLogVal(Line,LI_ACTION0);
        cur->VirusType          = GetLogVal(Line,LI_VIRUSTYPE);
        cur->Flags              = GetLogVal(Line,LI_FLAGS);
        cur->ScanID             = GetLogVal(Line,LI_SCANID);
        cur->GroupID            = GetLogVal(Line,LI_GROUPID);
        cur->so                 = NULL;
        cur->Log                = NULL;
        cur->Handle             = NULL;
        cur->Time               = VTime2TimeT(VTstr(buf));
        cur->VBinID             = GetLogVal(Line,LI_VBIN_ID);
        cur->VirusID            = GetLogVal(Line,LI_VIRUS_ID);
        cur->QFStatus           = GetLogVal(Line,LI_QUARFWD_STATUS);
        cur->Access             = GetLogVal(Line,LI_ACCESS);
        cur->SNDStatus          = GetLogVal(Line,LI_SND_STATUS);
        cur->dwBackupID         = GetLogVal(Line,LI_BACKUP_ID);

        GetLogStrEx(Line,LI_NEW_EXT,cur->NewExt,sizeof(cur->NewExt));

        MakeFalseSid(cur->pSid,user,computer);

        memcpy(cur->VirusName ,virus,SizeV);
        memcpy(cur->Description,description,SizeD);
        memcpy(cur->EventData,eventdata,SizeE);
        memcpy(cur->lpParent,parentserver,SizeS);
        memcpy(cur->lpGUID,szGUID,SizeG);

//rchinta
/**
#ifdef WIN32

        // TODO:  Investigate if the log line at this point has the File Name
        // information.  sizeof(DECOMPFILEINFO) may have to be changed to
        // include the file names and read the file names from the Log Line
        // and copy to cur->pdfi
        cur->pdfi = malloc(sizeof(DECOMPFILEINFO));
        if ( cur->pdfi )
        {
            memset(cur->pdfi, 0, sizeof(DECOMPFILEINFO));

            cur->pdfi->bIsCompressed        = bIsCompressed;
            cur->pdfi->dwDepthOfFileToGet   = dwDepthOfFileToGet;
        }

        cur->dwStillInfected    = dwStillInfected;

        // Get the def set info
        if ( GetLogStrEx(Line,LI_DEFINFO,buf,sizeof(buf)) )
        {
            WORD    wYear = 0;
            WORD    wMonth = 0;
            WORD    wDay = 0;
            DWORD   dwVersion = 0;

            sscanf( buf,
                    "%04u%02u%02u.%03u", 
                    &wYear, 
                    &wMonth,
                    &wDay,
                    &dwVersion );

            cur->DefVersionInfo.wYear = wYear;
            cur->DefVersionInfo.wMonth = wMonth;
            cur->DefVersionInfo.wDay = wDay;
            cur->DefVersionInfo.dwVersion = dwVersion;

            cur->DefVersionInfo.dwSequence = GetLogVal(Line,LI_DEFSEQNUMBER);
        }

        cur->dwDeleteType = dwDeleteType;
        cur->CleanType = dwCleanType;
#endif
**/

//#ifdef NLM //EA 05/15/2000

        // Get the def set info
        if ( GetLogStrEx(Line,LI_DEFINFO,buf,sizeof(buf)) )//EA 05/15/2000
        {

            unsigned int year,mon,day,version;
            sscanf( buf,
                    "%04u%02u%02u.%03u", 
                    &year, 
                    &mon,
                    &day,
                    &version
                  );
            cur->DefVersionInfo.wYear = year;
            cur->DefVersionInfo.wMonth = mon;
            cur->DefVersionInfo.wDay = day;
            cur->DefVersionInfo.dwVersion = version;
            cur->DefVersionInfo.dwSequence = GetLogVal(Line,LI_DEFSEQNUMBER);//EA 05/15/2000
        }//EA 05/15/2000

//        cur->dwDeleteType = dwDeleteType;//EA 05/15/2000 commenting it out since dwDelete is not implemented in NAVAPI when it gets
        //implemented we need to uncomment this
        cur->CleanType = dwCleanType;//EA 05/15/2000
//#endif//EA 05/15/2000

        cur->Normalizer = (DWORD)cur;
        *out = cur;
        cur->Size = Size;
        return ERROR_SUCCESS;
    }

    return ERROR_MEMORY;
}
/***********************************************************************/

void FixupFilename(char *str, char *Filename)
{

    // If there are any commas in Filename, encase the entire name in quotes - 
    // this works on all platforms and is what the LogLine handling code 
    // expects - it strips leading/trailing quotes when it reads strings 
    // from the log lines

    // the reason for doing this is that an embedded comma breaks the 
    // comma-delimited format of the log lines

    if ( StrChar(Filename, ',') )
    {
        // if it already has quotes, then don't quote again - note that 
        // the file shouldn't ever be quoted at this point - this is just 
        // for safety

        if ( StrChar(Filename, '\"') )
            WSprintf(str, "%s", Filename);
        else
            WSprintf(str, "\"%s\"", Filename);
    }
    else
    {
        WSprintf(str, "%s", Filename);
    }

}

/***********************************************************************/
char *GenerateLogLine(char *Line,PEVENTBLOCK eb)
{

    char *q;
    char TimeS[13];
    VTIME vt;
    char UserName[NAME_SIZE];
    char ComputerName[NAME_SIZE];
    int i;
    char *cur;
    char *data;
    char str[MAX_LOG_LINE_SIZE];
    BOOL f = eb->Category == GL_CAT_INFECTION;
    BYTE *eventdata;
    char szDefinfo[MAX_DATE_STRING_SIZE] = {0};

/**
#ifdef WIN32

    // place holder for the scan statistics of a container
    char            szCompFileStatus[NAME_SIZE] = "\0";
    HKEY            hKey = NULL;
    UUID*           pUuid = NULL;
    OLECHAR         wCLSIDStr[UUID_SIZE] = {0};
    TCHAR           szCLSID[UUID_SIZE] = {0};
#endif
**/
    vt = vtime(eb->Time);
    q = (char *)&vt;
    wsprintf(TimeS,"%02X%02X%02X%02X%02X%02X",q[0],q[1],q[2],q[3],q[4],q[5]);

    GetNames(eb->pSid,UserName,ComputerName);

    cur = Line;

    if ( eb->EventData == NULL )
        eventdata = (PBYTE)"";
    else
        eventdata = eb->EventData;
/**
#ifdef WIN32

    // For the top-level container save the statistics of the scan
    // (i.e. total number of infected files in a container).
//    if (f)
//        eb->dwStillInfected = eb->pdfi->dwInfected - eb->pdfi->dwCleaned - eb->pdfi->dwDeleted;

    if ( f && eb->pdfi->bIsCompressed && 
         (eb->pdfi->dwDepthOfFileToGet == 0) )
    {
        if ( eb->dwStillInfected )
        {
            wsprintf(szCompFileStatus, LS(IDS_REMAINING_INFECTIONS), eb->dwStillInfected);
        }
        else
        {
            wsprintf(szCompFileStatus, "%s", LS(IDS_NO_INFECTIONS) );
        }
    }

    // Get the date and version of the defs in use.
    if ( eb->DefVersionInfo.wYear )
    {
        wsprintf(szDefinfo,
                 "%04d%02d%02d.%03d", 
                 eb->DefVersionInfo.wYear, 
                 eb->DefVersionInfo.wMonth,
                 eb->DefVersionInfo.wDay,
                 eb->DefVersionInfo.dwVersion );
    }

    //
    // Get the guid. 
    //
    if ( f )
    {
        if ( eb->lpGUID )
            _tcscpy(szCLSID, eb->lpGUID);
        else
        {

            if ( ERROR_SUCCESS == RegOpenKeyEx( HKEY_LOCAL_MACHINE,
                                                szReg_Key_Main,
                                                0,
                                                KEY_READ,
                                                &hKey) )
            {
                DWORD   dwRegKeyType = REG_BINARY;
                GUID    PlatformGUID;
                DWORD   dwPlatformGUIDSize = sizeof(GUID);

                if ( ERROR_SUCCESS == RegQueryValueEx( hKey,
                                                       szReg_Val_Guid,
                                                       NULL,
                                                       &dwRegKeyType,
                                                       (BYTE*)&PlatformGUID,
                                                       &dwPlatformGUIDSize) )
                {
                    pUuid = &PlatformGUID;

                    if ( SUCCEEDED(StringFromGUID2( (REFGUID)pUuid, (LPOLESTR)wCLSIDStr, UUID_SIZE)) )
                    {
#ifdef UNICODE
                        lstrcpy( szCLSID, wCLSIDStr );
#else
                        WideCharToMultiByte( CP_OEMCP,
                                             0,
                                             wCLSIDStr,
                                             -1,
                                             szCLSID,
                                             UUID_SIZE,
                                             NULL,
                                             NULL);
#endif // Unicode
                    }
                }

                RegCloseKey( hKey );
            }

        }
    }

#endif // Win32
**/

//#ifdef NLM//EA 05/15/2000
    // Get the date and version of the defs in use.
    if ( eb->DefVersionInfo.wYear )//EA 05/15/2000
    {
        wsprintf(szDefinfo,
                 "%04d%02d%02d.%03d", 
                 eb->DefVersionInfo.wYear, 
                 eb->DefVersionInfo.wMonth,
                 eb->DefVersionInfo.wDay,
                 eb->DefVersionInfo.dwVersion );//EA 05/15/2000
    }

//#endif//EA 05/15/2000
    for ( i=0;i<=LI_TOTAL_FIELDS;i++ )
    {
        data = str;*str = 0;
        switch ( i )
        {
            case LI_TIME:          data = TimeS;                                   break;
            case LI_EVENT:          WSprintf(str,"%u",eb->Event);                   break;
            case LI_CAT:            WSprintf(str,"%u",eb->Category);                break;
            case LI_LOGGER:        WSprintf(str,"%u",eb->logger);                  break;
            case LI_COMPUTER:      data = ComputerName;                            break;
            case LI_USER:          data = UserName;                                break;
            case LI_EVENT_DATA:    data = (char *)eventdata;                       break;
            case LI_GROUPID:       WSprintf(str,"%u",eb->GroupID);                 break;
            case LI_SCANID:        WSprintf(str,"%u",eb->ScanID);                  break;
            case LI_VIRUS:         if ( f && eb->VirusName ) data = eb->VirusName;break;
                //case LI_FILE:          if(f) data = eb->Description;                   break;
                // Changed to convert the filename in case there is a comma present
                // in the filename or path of the infected file...
            case LI_FILE:          if ( f ) FixupFilename(str, eb->Description);break;

            case LI_ACTION1:       if ( f ) WSprintf(str,"%u",eb->WantedAction[0]);break;
            case LI_ACTION2:       if ( f ) WSprintf(str,"%u",eb->WantedAction[1]);break;
            case LI_ACTION0:       if ( f ) WSprintf(str,"%u",eb->RealAction);break;
            case LI_VIRUSTYPE:     if ( f ) WSprintf(str,"%u",eb->VirusType);break;
            case LI_FLAGS:         WSprintf(str,"%u",eb->Flags);                   break;
            case LI_NEW_EXT:       if ( f ) data = eb->NewExt;break;
/**
#ifdef WIN32
            case LI_DESCRIPTION:   WSprintf(str,"\"%s\"",f?szCompFileStatus:eb->Description);    break;
#else
**
            case LI_DESCRIPTION:   WSprintf(str,"\"%s\"",f?"":eb->Description);    break;
//#endif
            case LI_VBIN_ID:       if ( f ) WSprintf(str,"%u",eb->VBinID);break;
            case LI_VIRUS_ID:      if ( f ) WSprintf(str,"%u",eb->VirusID);break;
            case LI_QUARFWD_STATUS:if ( f ) WSprintf(str,"%u",eb->QFStatus);break;
            case LI_ACCESS:        WSprintf(str,"%u",eb->Access);                  break;
            case LI_SND_STATUS:    if ( f ) WSprintf(str,"%u",eb->SNDStatus);break;
            case LI_BACKUP_ID:     if ( f ) WSprintf(str,"%u",eb->dwBackupID);break;
            case LI_PARENT:        if ( eb->lpParent ) WSprintf(str,"%s",eb->lpParent);break;
//rchinta
/**
#ifdef WIN32
            case LI_COMPRESSED:    if ( f ) WSprintf(str,"%u",eb->pdfi->bIsCompressed);break;
            case LI_DEPTH:         if ( f ) WSprintf(str,"%u",eb->pdfi->dwDepthOfFileToGet);break;
            case LI_STILL_INFECTED: if ( f ) WSprintf(str,"%u",eb->dwStillInfected);break;
            case LI_DEFINFO:       if ( f ) WSprintf(str,"%s",szDefinfo);break;
            case LI_DEFSEQNUMBER:  if ( f ) WSprintf(str,"%u",eb->DefVersionInfo.dwSequence);break;
            case LI_CLEANINFO:     if ( f ) WSprintf(str,"%u",eb->CleanType);break;
            case LI_DELETEINFO:    if ( f ) WSprintf(str,"%u",eb->dwDeleteType);break;
            case LI_GUID:          if ( _tcslen(szCLSID) ) WSprintf(str,"%s",szCLSID);break;
#endif
**/

//#ifdef NLM //EA 05/15/2000
            case LI_DEFINFO:       if ( f ) WSprintf(str,"%s",szDefinfo);break;
            case LI_DEFSEQNUMBER:  if ( f ) WSprintf(str,"%u",eb->DefVersionInfo.dwSequence);break;
            case LI_CLEANINFO:     if ( f ) WSprintf(str,"%u",eb->CleanType);break;
                //  case LI_DELETEINFO:    if(f) WSprintf(str,"%u",eb->dwDeleteType); break;//EA 05/15/2000 commenting it out since dwDelete is not implemented in NAVAPI when it gets
                //implemented we need to uncomment this
//#endif//EA 05/15/2000
        }
        StrCopy(cur,data);
        cur += NumBytes(cur);
        StrCopy(cur,",");
        cur += NumBytes(cur);
    }

    cur--;
    *cur = 0;

    return Line;
}
/*******************************************************************************/
DWORD NormalizeEventBlock(PEVENTBLOCK eb)
{

    if ( eb->Normalizer == 0 )
        return ERROR_CAN_NOT_NORMALIZE;

    return ERROR_SUCCESS;
/*
#if 0


    // 
    // TCashin: this is a test. See if we see any side affects of removing
    //          this function. Since eb->Normalizer is only ever set to eb
    //          nothing really happens.
    //

    eb->so = NULL;

    eb->Description = eb->Description - (char *)(eb->Normalizer) + (char *)eb;
    eb->VirusName   = eb->VirusName   - (char *)(eb->Normalizer) + (char *)eb;
    if ( eb->EventData )
        eb->EventData   = eb->EventData   - (BYTE *)(eb->Normalizer) + (BYTE *)eb;
    eb->pSid        = (PSID)((char *)((char *)eb->pSid - (char *)(eb->Normalizer) + (char *)eb));

    return ERROR_SUCCESS;

#endif */

}
/*******************************************************************************/



#endif 0




DWORD CreateCopyOfEvent(PEVENTBLOCK in,PEVENTBLOCK *out)
{

    //HKEY hkeys[2] = {0,0};
    PEVENTBLOCK cur;
    DWORD SizeD,SizeE,SizeV,SizeS,SizeG;
    DWORD Size;
//rchinta
/**
#ifdef WIN32
    DWORD SizeP = 0;
    DWORD SizeExtractTempFile = 0;
    DWORD SizeFileToGet = 0;
    DWORD SizeNestingPath = 0;
    DWORD SizeOrigArchive = 0;
#endif
**/
    if ( in->EventData == NULL )
        SizeE = 0;
    else
        SizeE = NumBytes((char *)in->EventData)+1;


    if ( in->Description )
    {
        SizeD = NumBytes(in->Description)+1;
    }
    else
        SizeD = 0;

    if ( in->VirusName )
    {
        SizeV = NumBytes(in->VirusName)+1;
    }
    else
        SizeV = 0;

    if ( in->lpParent )
    {
        SizeS = NumBytes(in->lpParent)+1;
    }
    else
        SizeS = 0;

    if ( in->lpGUID )
    {
        SizeG = NumBytes(in->lpGUID)+1;
    }
    else
        SizeG = 0;

//rchinta
/**
#ifdef WIN32
    SizeP = 0;

    if ( in->pdfi != NULL )
    {
        if ( in->pdfi->lpszExtractTempFile )
            SizeExtractTempFile = lstrlen(in->pdfi->lpszExtractTempFile);

        if ( in->pdfi->lpszFileToGet )
            SizeFileToGet = lstrlen(in->pdfi->lpszFileToGet);

        if ( in->pdfi->lpszNestingPath )
            SizeNestingPath = lstrlen(in->pdfi->lpszNestingPath);

        if ( in->pdfi->lpszOrigArchiveFileName )
            SizeOrigArchive = lstrlen(in->pdfi->lpszOrigArchiveFileName);

        SizeP = sizeof(DECOMPFILEINFO) + 4 +  // countring the terminating NULL's for the four strings
                SizeExtractTempFile +
                SizeFileToGet +
                SizeNestingPath +
                SizeOrigArchive;

    }

    cur = malloc(Size = (sizeof(EVENTBLOCK) + sizeof(mSID) + SizeD + SizeE + SizeV + SizeP + SizeS + SizeG));
#else   // !WIN32
**/
    cur = malloc(Size = (sizeof(EVENTBLOCK) + sizeof(mSID) + SizeD + SizeE + SizeV + SizeS + SizeG));
//#endif  // WIN32

    if ( cur )
    {
    /**
        if ( in->hKey[0] )
            DUPKEY(in->hKey[0],&hkeys[0]);
        if ( in->hKey[1] )
            DUPKEY(in->hKey[1],&hkeys[1]);
   /**/
        memcpy(cur,in,sizeof(EVENTBLOCK));

        cur->pSid        = (PSID)(cur+1);

        if ( SizeD )
            cur->Description = (char*)(cur+1)+sizeof(mSID);

        if ( SizeV )
            cur->VirusName   = (char*)(cur+1)+sizeof(mSID)+SizeD;

        if ( SizeE )
            cur->EventData   = (BYTE*)(cur+1)+sizeof(mSID)+SizeD+SizeV;

        if ( SizeS )
            cur->lpParent    = (char*)(cur+1)+sizeof(mSID)+SizeD+SizeV+SizeE;

        if ( SizeG )
            cur->lpGUID    = (char*)(cur+1)+sizeof(mSID)+SizeD+SizeV+SizeE+SizeS;

        cur->so = NULL;
        cur->Special = 0;

        //cur->hKey[0] = hkeys[0];
        //cur->hKey[1] = hkeys[1];

        if ( in->pSid )
            memcpy(cur->pSid,in->pSid,sizeof(mSID));
        else
        {
//#ifdef SERVER
            GetSid(cur->pSid);
/**
#else
            dprintf("Non-Server can not create Sid!!!\n");
            StrCopy((char *)cur->pSid,"\xff\xff\xff\xffUser\x01Computer");
#endif
**/
        }

        MakeSidFalse(cur->pSid);

        memcpy(cur->VirusName ,in->VirusName,SizeV);
        memcpy(cur->Description,in->Description,SizeD);

        if ( SizeE )
            memcpy(cur->EventData,in->EventData,SizeE);

        if ( SizeS )
            memcpy(cur->lpParent,in->lpParent,SizeS);

        if ( SizeG )
            memcpy(cur->lpGUID,in->lpGUID,SizeG);

//rchinta
/**
#ifdef WIN32
        cur->pdfi = NULL;

        if ( SizeP )
        {
            cur->pdfi = malloc( SizeP );

            if ( cur->pdfi )
            {
                memset(cur->pdfi, 0, SizeP);
                memcpy(cur->pdfi, in->pdfi, SizeP);
            }
        }

        cur->CleanType = in->CleanType;
        cur->dwDeleteType = in->dwDeleteType;
#endif
**/
//#ifdef NLM //EA 05/15/2000
        cur->CleanType = in->CleanType;//EA 05/15/2000
        //cur->dwDeleteType = in->dwDeleteType; //EA 05/15/2000 need to uncomment once NAVAPI implements delete info for NLM's
//#endif//EA 05/15/2000

        //cur->Log = NULL;
        cur->Handle = NULL;
        cur->Normalizer = (DWORD)cur;
        cur->Size = Size;

        *out = cur;
        return ERROR_SUCCESS;
    }

    return ERROR_MEMORY;
}


/******************************************************************************/

DWORD DestroyCopyOfEvent(PEVENTBLOCK cur)
{
    if ( cur->Special )
    {
        free ( (void *) (cur->Special) );
        cur->Special = 0;
    }
    
//rchinta
/**
#ifdef WIN32
    NAVFree(cur->pdfi);
#endif
**/    
    /*
    if ( cur->hKey[0] )
        RegCloseKey(cur->hKey[0]);

    if ( cur->hKey[1] )
        RegCloseKey(cur->hKey[1]);
    */
    
    NAVFree(cur);
    return ERROR_SUCCESS;
}



#if 0




/*******************************************************************************/
void insertfront(char* szShortPath,char* cp)
{
    char szTemp[IMAX_PATH];
    StrCopy(szTemp,szShortPath);
    StrCopy(szShortPath,cp);
    StrCat(szShortPath,szTemp);
}
/**********************************************************************************************************/
void ShortPath(char* szPath,char* szShortPath,const int maxlen)
{

    int         len=0;
    int         bTruncated=0;
    char* cp,*start;
    int use;
    char temp[IMAX_PATH];

    if ( (int)NumBytes(szPath) <= maxlen )
    {
        StrCopy(szShortPath,szPath);
        return;
    }

    szShortPath[0]=0;
    StrCopy(temp,szPath);

    start = StrChar(temp+3,'\\');
    if ( start )
    {
        use = start-temp;
        for ( ;; )
        {
            cp = StrRChar(start,'\\');
            if ( cp==NULL )
                break;
            len += NumBytes(cp);
            if ( len+use+5>maxlen )
            {
                bTruncated=1;
                break;
            }
            insertfront(szShortPath,cp);
            *cp=0;
        }

        if ( bTruncated )
        {
            *start = 0;
            insertfront(szShortPath,"\\...");
        }

        insertfront(szShortPath,temp);
    }

}
//#endif



///////#if 0 



/**********************************************************************************************************/
#ifdef TRANSMAN
DWORD SpecialChildCheck(char *name)
{

    if ( !stricmp(name,"ADDRESSCACHE") || !stricmp(name,"DOAMINDATA") || !stricmp(name,"CLIENTCONFIG") ||
         !stricmp(name,"CURRENTMAPS") || !stricmp(name,"CONSOLE") || !stricmp(name,"COMCACHE") ||
         !stricmp(name,"SRVCON") || !stricmp(name,"SRVCONNEW") || !stricmp(name,"STORAGELIST") ||
         !stricmp(name,"CHILDREN") || !stricmp(name,"CLIENTS") || !stricmp(name,"CONSOLES") )
        return ERROR_ITEM_NOT_NEEDED;

    return ERROR_SUCCESS;
}
/**********************************************************************************************************/

DWORD SpecialFullBurstRegPut(char *CName,char *Root,HKEY hkey,DWORD Flags)
{

    DWORD index=0;
    char *name;
    BYTE *data;
    BYTE *packet;
    DWORD namesize=MAX_REMOTE_REG_VAL_SIZE;
    DWORD datasize=MAX_REMOTE_REG_VAL_SIZE;
    DWORD type;
    DWORD used=0;
    DWORD cc=ERROR_SUCCESS;
    DWORD count;
    HKEY hckey;

    name = malloc(MAX_REMOTE_REG_VAL_SIZE);
    data = malloc (MAX_REMOTE_REG_VAL_SIZE);
    packet = malloc(MAX_PACKET_DATA);

    if ( name == NULL || data == NULL || packet == NULL )
        return ERROR_MEMORY;

    if ( Flags&GC_INCLUDE_CHILDREN )
    {
        while ( cc==ERROR_SUCCESS&&RegEnumKey(hkey,index++,name,MAX_REMOTE_REG_VAL_SIZE) == ERROR_SUCCESS )
        {
            if ( (Flags&GC_EXCLUDE_SPECIAL_CHILDREN) && SpecialChildCheck(name) )
                continue;
            if ( RegOpenKey(hkey,name,&hckey) == ERROR_SUCCESS )
            {
                if ( Root[0] == 0 )
                    WSprintf((char *)data,"%s",name);
                else
                    WSprintf((char *)data,"%s\\%s",Root,name);
                cc = SpecialFullBurstRegPut(CName,(char *)data,hckey,Flags);
                RegCloseKey(hckey);
            }
        }
    }


    if ( GetVal(hkey,"DELETE_ALL_VALUES-D",0) )
    {
        SendCOM_DEL_KEY(CName,Root);
        //RegDeleteValue(hkey,"DELETE_ALL_VALUES-D");
    }

    memset(packet,0,MAX_PACKET_DATA);
    count = 0;
    index=0;
    while ( cc==ERROR_SUCCESS&&RegEnumValue(hkey,index++,name,&namesize,0,&type,data,&datasize) == ERROR_SUCCESS )
    {
        if ( strcmp(name,"DELETE_ALL_VALUES-D") )
        {
            if ( AddValueToBlock(packet,name,(DWORD)type,(WORD)datasize,data,&used) != ERROR_SUCCESS )
            {
                cc = SendCOM_SET_VALUES(CName,Root,count,packet,used);
                memset(packet,0,MAX_PACKET_DATA);
                count = 0;
                AddValueToBlock(packet,name,(DWORD)type,(WORD)datasize,data,&used);
            }

            count++;
        }
        namesize=MAX_REMOTE_REG_VAL_SIZE;
        datasize=MAX_REMOTE_REG_VAL_SIZE;
    }

    if ( cc == ERROR_SUCCESS && count )
        cc = SendCOM_SET_VALUES(CName,Root,count,packet,used);

    free(name);
    free(data);
    free(packet);

    return cc;
}
/********************************************************************************************************/
DWORD SpecialRegSetValue(HKEY hkey,char *name,DWORD type,BYTE *data,DWORD size)
{

    char Data[IMAX_PATH];
    DWORD Type;
    DWORD Size = sizeof(Data);

    if ( RegQueryValueEx(hkey,name,NULL,&Type,(PBYTE)Data,&Size) == ERROR_SUCCESS )
    {
        if ( Size != size || Type != type || memcmp(Data,data,size) )
        {
            WSprintf(Data,"%s-V",name);
            PutVal(hkey,Data,1);
            RegDeleteValue(hkey,name);
            return ERROR_SUCCESS;
        }
    }

    return(DWORD)RegSetValueEx(hkey,name,0,type,data,size);
}
/********************************************************************************************************/
DWORD SpecialFullBurstRegGet(char *CName,char *Root,HKEY hkey,DWORD Flags)
{

    DWORD   count;
    DWORD index = 0;
    DWORD type;
    DWORD datasize;
    DWORD cc;
    char    *value;
    BYTE    *packet;
    BYTE    *pCurrentData;
    BYTE    *data;
    char  *next;
    HKEY    hckey;
    DWORD i;

    value = malloc (MAX_REMOTE_REG_VAL_SIZE);
    data = malloc (MAX_REMOTE_REG_VAL_SIZE);
    packet = malloc(MAX_PACKET_DATA);

    if ( value == NULL || data == NULL || packet == NULL )
        return ERROR_MEMORY;


    if ( Flags&GC_INCLUDE_CHILDREN )
    {
        do
        {
            cc = SendCOM_LIST_KEY_BLOCK(CName,Root, packet, MAX_PACKET_DATA, &index,&count);
            if ( count && cc == ERROR_SUCCESS )
            {
                for ( i = 0; i < count; i++ )
                {
                    next = (char *)GetNameFromList(packet,i);
                    if ( (Flags&GC_EXCLUDE_SPECIAL_CHILDREN) && SpecialChildCheck(next) )
                        continue;

                    if ( !*Root )//(Root == "")
                        strcpy(value,next);
                    else
                        WSprintf(value,"%s\\%s",Root,next);

                    if ( RegCreateKey(hkey,next,&hckey) == ERROR_SUCCESS )
                    {
                        SpecialFullBurstRegGet(CName, value, hckey,Flags);
                        RegCloseKey(hckey);
                    }
                }
            }
        } while ( cc == ERROR_SUCCESS &&index != 0 );
    }


    index = 0;
    do
    {
        cc = SendCOM_LIST_VALUE_BLOCK(CName,Root, packet, MAX_PACKET_DATA, &index,&count);
        if ( count && cc == ERROR_SUCCESS )
        {
            pCurrentData = packet;
            for ( i = 0; i < count; i++ )
            {
                datasize = MAX_REMOTE_REG_VAL_SIZE;
                pCurrentData = GetValueFromEnumBlock(pCurrentData, value, &type, data, &datasize);
                SpecialRegSetValue(hkey,value,type,data,datasize);
            }
        }
    } while ( index != 0 && cc == ERROR_SUCCESS );

    if ( cc == ERROR_FILE_NOT_FOUND )
        cc = ERROR_SUCCESS;

    free(value);
    free(data);
    free(packet);

    return cc;

}
/********************************************************************************************************/
DWORD SpecialRegCopy(HKEY in,HKEY out,DWORD Flags)
{

// copy all values in in to out that are not in out
    DWORD index=0;
    char *name;
    BYTE *data;
    DWORD namesize=MAX_REMOTE_REG_VAL_SIZE;
    DWORD datasize=MAX_REMOTE_REG_VAL_SIZE;
    DWORD type;
    HKEY hckey;
    HKEY hokey;

    name = malloc (MAX_REMOTE_REG_VAL_SIZE);
    data = malloc (MAX_REMOTE_REG_VAL_SIZE);

    if ( name == NULL || data == NULL )
        return ERROR_MEMORY;

    if ( Flags&GC_INCLUDE_CHILDREN )
    {
        while ( RegEnumKey(in,index++,name,MAX_REMOTE_REG_VAL_SIZE) == ERROR_SUCCESS )
        {
            if ( (Flags&GC_EXCLUDE_SPECIAL_CHILDREN) && SpecialChildCheck(name) )
                continue;
            if ( RegOpenKey(in,name,&hckey) == ERROR_SUCCESS )
            {
                if ( RegCreateKey(out,name,&hokey) == ERROR_SUCCESS )
                {
                    SpecialRegCopy(hckey,hokey,Flags);
                    RegCloseKey(hokey);
                }
                RegCloseKey(hckey);
            }
        }
    }

    index=0;
    while ( RegEnumValue(in,index++,name,&namesize,0,&type,data,&datasize) == ERROR_SUCCESS )
    {
        if ( RegQueryValueEx(out,name,NULL,NULL,NULL,NULL) != ERROR_SUCCESS )
        {
            RegSetValueEx(out,name,0,type,data,datasize);
        }
        namesize=MAX_REMOTE_REG_VAL_SIZE;
        datasize=MAX_REMOTE_REG_VAL_SIZE;
    }

    free(name);
    free(data);

    return ERROR_SUCCESS;
}
/********************************************************************************************************/
DWORD SpecialRegBurstCopy(char *CName,char *From,char *To)
{

    HKEY hkey;
    DWORD cc;

    if ( (cc=RegCreateKey(hMainKey,"TmpCopy",&hkey)) == ERROR_SUCCESS )
    {
        cc = SpecialFullBurstRegGet(CName,From,hkey,GC_INCLUDE_CHILDREN);
        if ( cc == ERROR_SUCCESS )
        {
            cc = SpecialFullBurstRegPut(CName,To,hkey,GC_INCLUDE_CHILDREN);
        }

        RegCloseKey(hkey);
        RegDelKeys(hMainKey,"TmpCopy");
    }

    return cc;
}


#endif // 0


/**
#ifdef WIN32  //mmendon
#include <assert.h>
//////////////////////////////////////////////////////////////////
//
// bool FileTimeTotime_t(const LPFILETIME lpFileTime, time_t *lptime_t)
//
//  Convert a FILETIME to a time_t
//
//  lpFileTime - pointer to a valid FILETIME struct
//  lptime_t - pointer to a time_t which will be updated with the 
//             equivalent FILETIME time.  If error, 0 is returned.
//
//  RETURN VALUE:   true  = success
//                  false = error 
//
//  mmendon  8/24/99
//////////////////////////////////////////////////////////////////
BOOL FileTimeTotime_t(const LPFILETIME lpFileTime, time_t *lptime_t)
{

    SYSTEMTIME SysTime;
    struct tm tmTime;


    assert(lpFileTime);
    assert(lptime_t);
    if ( !lpFileTime || !lptime_t )
        return(FALSE);

    //  Fill the SYSTEMTIME struct from the FILETIME struct
    if ( !FileTimeToSystemTime(lpFileTime, &SysTime) )
    {
        *lptime_t = 0;
        return(FALSE);
    }

    // convert from SYSTEMTIME to tm struct
    tmTime.tm_sec = SysTime.wSecond;     /* seconds after the minute - [0,59] /
    tmTime.tm_min = SysTime.wMinute;     /* minutes after the hour - [0,59] /
    tmTime.tm_hour = SysTime.wHour;      /* hours since midnight - [0,23]/
    tmTime.tm_mday = SysTime.wDay;       /* day of the month - [1,31] /
    tmTime.tm_mon = SysTime.wMonth - 1;      /* months since January - [0,11], SYSTEMTIME - [1,12] /
    tmTime.tm_year = SysTime.wYear - 1900;      /* years since 1900 /
    tmTime.tm_wday = SysTime.wDayOfWeek; /* days since Sunday - [0,6] /
    tmTime.tm_yday = SysTime.wDay;       /* days since January 1 - [0,365] /
    tmTime.tm_isdst = 0;                 /* daylight savings time flag, set to standard time /

    // convert to time_t
    *lptime_t = mktime(&tmTime);

    // check for valid return value
    // -1 means conversion could not be done
    if ( *lptime_t == -1 )
    {
        *lptime_t = 0;
        return(FALSE);
    }

    return(TRUE);

}

#endif //win32 mmendon
**/

//////////////////////////////////////////////////////////////////
//
// Function: GetMonthDays
//
// Description: Returns the number of days in the month for the
// input time, time_t.
//
// Params: time_t [IN]: Desired time
//
// Returns: Number of days in the month.
//////////////////////////////////////////////////////////////////
// 12/14/99 MHOTTA :: Function Created
//////////////////////////////////////////////////////////////////

int GetMonthDays( time_t t )
{
    int ndays=0;
    struct tm *tp = localtime(&t);

    switch ( tp->tm_mon )
    {
        case 0:
        case 2:
        case 4:
        case 6: 
        case 7:
        case 9:
        case 11: 
            ndays = 31;
            break;
        case 1: 
            ndays = (isleapyear(tp->tm_year) ? 29 : 28);
            break;
        case 3:
        case 5:
        case 8:
        case 10: 
            ndays = 30; 
            break;
        default: 
            break;
    }

    return ndays;
}

//////////////////////////////////////////////////////////////////
//
// Function: isleapyear
//
// Description: Determines whether or not the year is a leap year.
//
// Params: int [IN]: Year
//
// Returns: TRUE:  If the year is a leap year.
//          FALSE: Otherwise
//////////////////////////////////////////////////////////////////
// 12/14/99 MHOTTA :: Function Created
//////////////////////////////////////////////////////////////////

BOOL isleapyear( int year )
{
    return( year % 4 == 0 ? TRUE : FALSE );
}

//////////////////////////////////////////////////////////////////
//
// Function; CalculateFirstRunTime
//
// Description: Do the necessary calculations to get a first run
// time from a newly created repeating event.
//
// Params: int nMinOfDay   [IN]: Minute of the current day.
//         int nDayOfMonth [IN]: Day of month.
//         int nDayOfWeek  [IN]: Day of week.
//         time_t created  [IN]: Time event was created.
//         int nType       [IN]: Type of schedule.
//
// Returns: The time in time_t format of the first scheduled
// run time.
//////////////////////////////////////////////////////////////////
// 01/07/99 MHOTTA :: Function Created
//////////////////////////////////////////////////////////////////

time_t CalculateFirstRunTime( int nMinOfDay, 
                                int nDayOfWeek, 
                                int nDayOfMonth, 
                                time_t created, 
                                int nType )
{
    struct tm *tp;
    struct tm *tpCreated;
    DWORD dwCreate;
    DWORD dwScheduled;
    time_t tFirstRun=0;

    tp = localtime(&created);
    tpCreated = (struct tm *)malloc( sizeof(struct tm) );

    if ( !tpCreated )
        return 0;

    memcpy( tpCreated, tp, sizeof(struct tm) );

    // Update the time structure with the first run information
    tp->tm_min = nMinOfDay % 60;
    tp->tm_hour = nMinOfDay / 60;

    switch ( nType )
    {
        case S_DAILY:
            // For daily events, increment the date if we're already past the
            // scheduled time for that day.  Overflow is accounted for by mktime(). 
            // Ex: if the date is incremented to 32 for a particular month,
            // then the value is normalized in the return value.
            dwCreate = mtos(tpCreated->tm_min + tpCreated->tm_hour * 60) + tpCreated->tm_sec;
            dwScheduled = mtos(nMinOfDay);

            if ( dwCreate > dwScheduled )
                // Wraps to next day so add one day
                tp->tm_mday += 1;

            break;
        case S_WEEKLY:
            // For weekly events, add the number of remaining days depending on whether 
            // we're before or after the next scheduled event.
            dwCreate = dtos(tpCreated->tm_wday) + mtos(tpCreated->tm_min + tpCreated->tm_hour * 60) + tpCreated->tm_sec;
            dwScheduled = dtos(nDayOfWeek) + mtos(nMinOfDay);

            if ( dwCreate > dwScheduled )
                tp->tm_mday += ( 7 - ( tpCreated->tm_wday - nDayOfWeek ) );
            else
                tp->tm_mday += ( nDayOfWeek - tpCreated->tm_wday );
            break;
        case S_MONTHLY:
            // For monthly events, increment the month if we're past the scheduled
            // event.  Again, overflow is accounted for by mktime() and the values
            // are normalized in the return value.
            dwCreate = dtos(tpCreated->tm_mday) + mtos(tpCreated->tm_min + tpCreated->tm_hour * 60) + tpCreated->tm_sec;
            dwScheduled = dtos(nDayOfMonth) + mtos(nMinOfDay);

            if ( dwCreate > dwScheduled )
            {
                tp->tm_mday = nDayOfMonth;
                tp->tm_mon += 1;
            }
            else
                tp->tm_mday = nDayOfMonth;

            break;
        default:
            break;
    }

    tFirstRun = mktime(tp);

    if ( (time_t) -1 == tFirstRun )
    {
        // mktime() failed
        dprintf( "MissedEvents: mktime() failed in CalculateFirstRunTime().\n" );
        return 0;
    }

    if ( tpCreated )
        free( tpCreated );

    return( tFirstRun );
} /*CalculateFirstRunTime()*/


//////////////////////////////////////////////////////////////////
//
// Function:    GetAppDataDirectory
//
// Description: Get NAV's data directory. For Windows 9x, it 
//	            will be found in the HOMEDIR reg key. For 
//              Windows 2000 and NT we call SHGetFolderPath().
//
// Params:      [in]     - DWORD  dwFlags - See pscan.h
//              [in/out] - LPTSTR lpDataDir
//
// Returns:     Standard error codes.
// 
//////////////////////////////////////////////////////////////////
// 03/03/2000   TCASHIN Function Created
//////////////////////////////////////////////////////////////////
DWORD GetAppDataDirectory(DWORD dwFlags, LPTSTR lpDataDir)
{
    DWORD   dwError = ERROR_SUCCESS;

/**
#if defined WIN32

#if defined(SERVER) || defined(CLISCAN) || defined(CLIPROXY)

    auto PFNSHGetFoldPathA pfnSHGetFolderPathA = NULL;

    auto TCHAR          szAppData[MAX_PATH] = {0};
    auto TCHAR          szSystemDir[MAX_PATH] = {0};
    auto TCHAR          szSHFolderDLL[MAX_PATH] ={0};
    auto HINSTANCE      hFolderDLL = NULL;
    auto HRESULT        hr = S_OK;
    auto int            len = 0;
    auto DWORD          dwClientType = 0;


    // A little error checking...
    if ( (dwFlags != NAV_COMMON_APP_DATA  &&
          dwFlags != NAV_USER_APP_DATA)   ||
         lpDataDir == NULL )
    {
        return ERROR_INVALID_PARAMETER;
    }

    // Get the client type
    dwClientType = GetClientType();

    // If we're a client running on a Win2K system then continue
    if ( IsWinNT() )
    {
        // Get the system directory
        if ( GetSystemDirectory(szSystemDir, sizeof(szSystemDir)) )
        {
            // Append the DLL name
            wsprintf ( szSHFolderDLL, _T("%s\\shfolder.dll"), szSystemDir );

            // Load it.
            hFolderDLL = LoadLibrary( szSHFolderDLL );

            if ( hFolderDLL )
            {
                // Get the function
                pfnSHGetFolderPathA = (PFNSHGetFoldPathA)GetProcAddress( hFolderDLL, _T("SHGetFolderPathA") );

                if ( pfnSHGetFolderPathA )
                {
                    // Call it.
                    if ( dwFlags == NAV_COMMON_APP_DATA )
                    {
                        // Per machine, all users, non-roaming, set up at install
                        hr = pfnSHGetFolderPathA( NULL, CSIDL_COMMON_APPDATA, NULL, 0, szAppData);
                    }
                    else
                    {
						if ( IsWindows2000() )
						{
							// Win2K only. Per machine, specific user, non-roaming, create it here
							hr = pfnSHGetFolderPathA( NULL, CSIDL_LOCAL_APPDATA | CSIDL_FLAG_CREATE, NULL, 0, szAppData);
						}
						else
						{
							// NT4 only.
							hr = pfnSHGetFolderPathA( NULL, CSIDL_APPDATA, NULL, 0, szAppData);
						}
                    }

                    if ( SUCCEEDED(hr) )
                    {
						// Did we get a path for the "Default User"
						if ( _tcsstr(szAppData, _T("Default User")) )
						{
	                        // Yes, but we don't write there. Go create the one we need
                            CreateUserDataPath( szAppData );
						}
  
                        // Make the string for the NAV data directory
                        len = wsprintf(lpDataDir, "%s\\%s\\%s",szAppData, 
                                       SYMANTEC_COMMON_DATA_DIR, 
                                       SHARED_VERSION_DATA_DIRECTORY );
                    }
                    else
                    {
						dprintf("GetAppDataDirectory: SHGetFolderPath() failed. ( %08X )\n", hr);

                        dwError = ERROR_NO_PATH1;
                    }
                }

                FreeLibrary( hFolderDLL );
            }
            else
                dwError = GetLastError();
        }
        else
            dwError = GetLastError();
    }
    else
    {
        // Not Windows NT. Use HOMEDIR
        WSprintf( lpDataDir, "%s", HomeDir );
    }

#endif  // defined(SERVER) || defined(CLISCAN)

#else // WIN32

    WSprintf( lpDataDir, "%s", HomeDir );

#endif

**/

    return dwError;
}

///////////////////////////////////////////////////////////////////////////////
//
// Function name: IsWindows2000
//
// Description  : Checks to see if the operating system is Windows 2000 or later.
//
// Return Values: TRUE is the OS is Win2K
//
///////////////////////////////////////////////////////////////////////////////
// 3/5/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
/**
BOOL IsWindows2000()
{

#ifdef WIN32
    OSVERSIONINFO   osInfo;
    BOOL            bRet = FALSE;

    osInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO); 

    if ( GetVersionEx (&osInfo) )
    {
        if ( osInfo.dwMajorVersion >= 5 )
        {
            bRet = TRUE;
        }
    }

    return bRet;
#else

    return FALSE;

#endif
}
**/


///////////////////////////////////////////////////////////////////////////////
//
// Function name: DirectoryExists
//
// Description  : See if the specified directory exists
//
//                ALWAYS RETURNS FALSE FOR NON-WIN32 PLATFORMS!!!!!!
//
// Parameters   : LPTSTR lpDir - the directory to find
//
// Return Values: TRUE if the dirctory exists
//
///////////////////////////////////////////////////////////////////////////////
// 3/12/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
BOOL DirectoryExists(LPTSTR lpDir)
{
/**
#if defined (WIN32) && !defined (NLM)
    BOOL            bDirExists = FALSE;
    HANDLE          hDir = NULL;
    WIN32_FIND_DATA finddata = {0};


    hDir = FindFirstFile( lpDir, &finddata );

    if ( hDir && hDir != INVALID_HANDLE_VALUE )
    {
        bDirExists = TRUE;
        FindClose( hDir );
    }

    return bDirExists;
#else
**/
    return FALSE;

//#endif
}


///////////////////////////////////////////////////////////////////////////////
//
// Function name: CreateDataDirs
//
// Description  : 
//
// Return Values: 
//
///////////////////////////////////////////////////////////////////////////////
// 3/5/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
DWORD CreateDataDirs()
{
    DWORD   dwError = ERROR_SUCCESS;
/**
#if defined WIN32 && !defined COPYSRV

    auto PFNSHGetFoldPathA pfnSHGetFolderPathA = NULL;

    auto TCHAR          szAppData[MAX_PATH] = {0};
    auto TCHAR          szSystemDir[MAX_PATH] = {0};
    auto TCHAR          szTemp1[IMAX_PATH] = {0};
    auto TCHAR          szTemp2[IMAX_PATH] = {0};
    auto TCHAR          szSHFolderDLL[MAX_PATH] ={0};
    auto HINSTANCE      hFolderDLL = NULL;
    auto HRESULT        hr ;
    auto DWORD          dwClientType = 0;



    dwClientType = GetClientType();

    // If we're running on a WinNT system then continue
    if ( IsWinNT() )
    {
        // Get the system directory
        if ( GetSystemDirectory(szSystemDir, sizeof(szSystemDir)) )
        {
            // Append the DLL name
            wsprintf ( szSHFolderDLL, _T("%s\\shfolder.dll"), szSystemDir );

            // Load it.
            hFolderDLL = LoadLibrary( szSHFolderDLL );

            if ( hFolderDLL )
            {
                // Get the function
                pfnSHGetFolderPathA = (PFNSHGetFoldPathA)GetProcAddress( hFolderDLL, _T("SHGetFolderPathA") );

                if ( pfnSHGetFolderPathA )
                {
                    // Call it. Per machine, all users, non-roaming, set up at install
                    hr = pfnSHGetFolderPathA( NULL, CSIDL_COMMON_APPDATA, NULL, 0, szAppData);

                    if ( SUCCEEDED(hr) )
                    {
                        dwError = ERROR_SUCCESS;
                    }
                    else
                    {
                        dwError = ERROR_NO_PATH1;
                    }
                }
                FreeLibrary( hFolderDLL );
            }
            else
                dwError = GetLastError();
        }
        else
            dwError = GetLastError();
    }

    //
    // If we go the common app data dir ok, then create the
    // directories we need.
    //
    if ( dwError == ERROR_SUCCESS )
    {
        _tcscpy( szTemp1, szAppData );

        // Create "Symantec"
        wsprintf( szTemp2,"%s\\%s", szTemp1, SYMANTEC_COMPANY_NAME );
        if ( !CreateDirectory(szTemp2, NULL) )
        {
            dwError = GetLastError();

            if ( dwError != ERROR_ALREADY_EXISTS )
                goto All_Done;
        }

        _tcscpy(szTemp1, szTemp2);

        // Create "Norton AntiVirus Corporate Edition"
        wsprintf( szTemp2,"%s\\%s", szTemp1, NAVCORP_DIRECTORY_NAME );
        if ( !CreateDirectory(szTemp2, NULL) )
        {
            dwError = GetLastError();

            if ( dwError != ERROR_ALREADY_EXISTS )
                goto All_Done;
        }

        _tcscpy(szTemp1, szTemp2);

        // Create the version number directory
        wsprintf( szTemp2,"%s\\%s", szTemp1, SHARED_VERSION_DATA_DIRECTORY );
        if ( !CreateDirectory(szTemp2, NULL) )
        {
            dwError = GetLastError();

            if ( dwError != ERROR_ALREADY_EXISTS )
                goto All_Done;
        }

        // Now save this dir as szAppData
        _tcscpy( szAppData, szTemp2 );

        // Set the attributes on szAppData
        if(SetDirectoryAccessAttributes(szAppData) != ERROR_SUCCESS)
			{
			// what do we want to do about this error?
			// we should probably continue creating the other dirs...
	        dprintf("SetDirectoryAccessAttributes() failed!");
			}

        // Create the Logs directory
        wsprintf( szTemp2,"%s\\%s", szAppData, _T("Logs") );
        if ( !CreateDirectory(szTemp2, NULL) )
        {
            dwError = GetLastError();
            goto All_Done;
        }

        // Create the Quarantine directory
        wsprintf( szTemp2,"%s\\%s", szAppData, _T("Quarantine") );
        if ( CreateDirectory(szTemp2, NULL) )
        {
            dwError = ERROR_SUCCESS;
        }
        else
        {
            dwError = GetLastError();
        }

    }

    All_Done:

#endif
**/

    return dwError;
}

/**
#if defined(WIN32) && (defined(SERVER) || defined(CLISCAN) || defined(CLIPROXY))
///////////////////////////////////////////////////////////////////////////////
//
// Function name: CreateUserDataPath
//
// Description  : If the path returned by SHGetFolderPath(CSIDL_LOCAL_APPDATA)
//                fails to get the directory for the current user, then we build
//                the path here.
//                
//                The buffer must contain the string returned by SHGetFolderPath.
//
// Return Values: 
//
///////////////////////////////////////////////////////////////////////////////
// 3/5/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
BOOL CreateUserDataPath(LPTSTR lpUserDataDir)
{
    TCHAR       szTemp[MAX_PATH] = {0};
    TCHAR       szSubDir[MAX_PATH] = {0};
    LPTSTR      lpTemp1 = NULL;
    LPTSTR      lpTemp2 = NULL;
    BOOL        bRet = S_FALSE;

    // Do we have a valid buffer?
    if ( !lpUserDataDir )
    {
        return bRet;
    }

    // Does the string contain "Default User?
    lpTemp1 = _tcsstr( lpUserDataDir, _T("Default User") );

    if ( !lpTemp1 )
    {
        return bRet;
    }

    // See if we have the name of the current user
    if ( !_tcslen(CurrentUserName) )
    {
        return bRet;
    }

    // Copy the string to our buffer
    _tcscpy( szTemp, lpUserDataDir);

    // Point to "Default User" in the temp buffer
    lpTemp1 = _tcsstr( szTemp, _T("Default User") );

    // Find the rest of the string
    lpTemp2 = _tcschr( lpTemp1, '\\' );

    // Save off the rest of the string for later
    _tcscpy( szSubDir, lpTemp2 );

    // Terminate the string right there
    *lpTemp1 = '\0';

    // Append the name of the current user
    _tcscat( szTemp, CurrentUserName );

    // Copy the rest of the callers buffer to 
    // our temp buffer.
    _tcscat( szTemp, szSubDir );

    // Does the directory exist?
    if ( DirectoryExists(szTemp) )
    {
        // Yep. Copy it to the callers buffer.
        _tcscpy( lpUserDataDir, szTemp );

        bRet = S_OK;
    }

    return bRet;
}
#endif // #if defined(WIN32) && defined(SERVER)
**/

//////////////////////////////////////////////////////////////////////////
//
// Function: SetDirectoryAccessAttributes
//
// Set the security attributes for the Everyone group to full access
//
//////////////////////////////////////////////////////////////////////////
DWORD SetDirectoryAccessAttributes(LPTSTR lpszDirectory)
{
    DWORD               dwError = ERROR_SUCCESS;
/**
#ifdef WIN32

    BOOL                bRet;
    BOOL                bIsNTFS = FALSE;
    SECURITY_DESCRIPTOR absSecurityDesc;
    PSID                pEveryoneGrpSID = NULL;
    PACL                pNewACL = NULL;
    DWORD               newACLSize;
	LPVOID				pACE;
    // mmendon  10-25-2000:  Fix for German/French NT AP start problem
    SID_IDENTIFIER_AUTHORITY IdentifierAuthority = SECURITY_WORLD_SID_AUTHORITY;  //Everyone group
    // mmendon  10-25-2000:  End fix for German/French NT AP start problem


    // See if this is an NTFS volume
    VolumeIsNTFS( lpszDirectory, &bIsNTFS );

    if ( !bIsNTFS )
    {
        // This isn't NTFS. Skip everything and say we completed ok.
        goto All_Done;
    }

    // mmendon  10-25-2000:  Fix for German/French NT AP start problem
    //                       Getting the SID for the everyone group using #defines
    //                       and the API to allocate memory and init the SID.
    bRet = AllocateAndInitializeSid(&IdentifierAuthority, (BYTE)1,SECURITY_WORLD_RID,0,0,0,0,0,0,0, &pEveryoneGrpSID);

    // Errors?
    if ( !bRet )
    {
        dwError = GetLastError();
        pEveryoneGrpSID = NULL;
        goto All_Done;
    }
    // mmendon  10-25-2000:  End fix for German/French NT AP start problem

    // Initialize the absolute security descriptor
    bRet = InitializeSecurityDescriptor( &absSecurityDesc, SECURITY_DESCRIPTOR_REVISION );

    if ( !bRet )
    {
        dwError = GetLastError();
        goto All_Done;
    }

    // compute size of new DACL
	if(IsValidSid(pEveryoneGrpSID))
		// tmm: why 6 extra bytes?  I don't know... it works...
	    newACLSize = sizeof(ACCESS_ALLOWED_ACE) + GetLengthSid(pEveryoneGrpSID) + 6;
	else
	    {
	    dwError = ERROR_INVALID_SID;
		goto All_Done;
		}

    // allocate memory
    pNewACL = (PACL) GlobalAlloc( GPTR, newACLSize );

    if ( !pNewACL )
    {
        dwError = ERROR_NOT_ENOUGH_MEMORY;
        goto All_Done;
    }

    // initialize the new DACL
    bRet = InitializeAcl( pNewACL, newACLSize, ACL_REVISION );
    if ( !bRet )
    {
        dwError = GetLastError();
        goto All_Done;
    }

    //  replace the DACL
    // Add an entry for the Everyone group
    bRet = AddAccessAllowedAce( pNewACL, ACL_REVISION, FILE_ALL_ACCESS, pEveryoneGrpSID );
    if ( !bRet )
    {
        dwError = GetLastError();
        goto All_Done;
    }

	// get the first (and only) ACE in the list
	if (GetAce(pNewACL, 0, &pACE))
		{
		// and set the ACE so that child folders/objects will inherit this ACE
		((ACCESS_ALLOWED_ACE*)pACE)->Header.AceFlags = CONTAINER_INHERIT_ACE|OBJECT_INHERIT_ACE;
		}
	else
	    {
	    dwError = ERROR_INVALID_ACL;
		goto All_Done;
		}

    // set the new DACL in the absolute SD
    bRet = SetSecurityDescriptorDacl( &absSecurityDesc, TRUE, pNewACL, FALSE );

    if ( !bRet )
    {
        dwError = GetLastError();
        goto All_Done;
    }

    // Did we build the new security descriptor correctly?
    bRet = IsValidSecurityDescriptor( &absSecurityDesc );

    if ( !bRet )
    {
        dwError = GetLastError();
        goto All_Done;
    }

    // Finally set the new DACL for the directory
    SetFileSecurity(lpszDirectory, DACL_SECURITY_INFORMATION, &absSecurityDesc);

All_Done:

    // Free the new ACL buffer
    if ( pNewACL )
    {
        GlobalFree( pNewACL );
    }

    // Free the Everyone group SID buffer
    if ( pEveryoneGrpSID )
    {
        // mmendon  10-25-2000:  Fix for German/French NT AP start problem
        FreeSid( pEveryoneGrpSID );
        // mmendon  10-25-2000:  End fix for German/French NT AP start problem
    }

#endif
**/
    return dwError;
}

/**
#ifdef WIN32
///////////////////////////////////////////////////////////////////////////////
//
// Function name: VolumeIsNTFS
//
// Description  : See if the volume in the given path is an NTFS volume
//
// Parameters   : [in]  - LPTSTR lpPath - directory or file
//                [out] - LPBOOL lpbIsNTFS - buffer to receive TRUE if volume
//                        is NTFS
//
// Return Values: Standard error codes.
//
///////////////////////////////////////////////////////////////////////////////
// 3/19/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
DWORD VolumeIsNTFS(LPTSTR lpPath, LPBOOL lpbIsNTFS)
{
    DWORD   dwError;
    LPTSTR  lpRoot = NULL;
    TCHAR   szRootDir[MAX_PATH] = {0};
    TCHAR   szVolumeName[MAX_PATH] = {0};
    DWORD   dwVolumeSerialNumber = 0;
    DWORD   dwMaxComponentLength = 0;
    DWORD   dwFileSystemFlags = 0;
    TCHAR   szFileSystemName[MAX_PATH] = {0};


    // Copy the path/file name to our temp buffer
    _tcscpy( szRootDir, lpPath );

    // Get the drive letter from the string
    lpRoot = _tcschr( szRootDir, '\\' );

    // Do we have a drive letter delimiter?
    if ( lpRoot )
    {
        // Yep. Terminate the string
        lpRoot = CharNext( lpRoot );
        *lpRoot = '\0';

        // Get the Volume info for this drive letter
        if ( GetVolumeInformation( szRootDir,                  // root directory
                                   szVolumeName,               // volume name buffer
                                   sizeof(szVolumeName),       // length of name buffer
                                   &dwVolumeSerialNumber,      // volume serial number
                                   &dwMaxComponentLength,      // maximum file name length
                                   &dwFileSystemFlags,         // file system options
                                   szFileSystemName,           // file system name buffer
                                   sizeof(szFileSystemName)) ) // length of file system name buffer
        {
            // See if the volume info says we're NTFS
            if ( _tcsstr(szFileSystemName, _T("NTFS")) )
                *lpbIsNTFS = TRUE;
            else
                *lpbIsNTFS = FALSE;

            dwError = ERROR_SUCCESS;
        }
        else
        {
            dwError = GetLastError();
        }
    }
    else
    {
        dwError = GetLastError();
    }

    return dwError;
}
#endif


#ifdef WIN32
///////////////////////////////////////////////////////////////////////////////
//
// Function name: GetClientType()
//
// Description  : Gets the data from the ClientType reg key. We may not always 
//                be able to use the normal GetVal() method.
//
// Return Values: 0 is we couldn't read the key otherwise the normal data
//
///////////////////////////////////////////////////////////////////////////////
// 3/19/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
DWORD GetClientType()
{
    DWORD           dwClientType = 0;
    DWORD           dwSize = sizeof(DWORD);
    LRESULT         lRet = 0;
//    HKEY            hKey = NULL;

    lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, szReg_Key_Main, 0, KEY_READ, &hKey );

    if ( ERROR_SUCCESS == lRet )
    {
        lRet = RegQueryValueEx(hKey, szReg_Val_Client_Type, NULL, 
                               NULL, (LPBYTE)&dwClientType, &dwSize);

        RegCloseKey( hKey );
    }
    else
    {
        dprintf("RegOpenKeyEx() failed: %d", lRet);
    }

    return dwClientType;
}
#endif


#ifdef WIN32
///////////////////////////////////////////////////////////////////////////////
//
// Function name: CheckDataDirs
//
// Description  : See if our Windows NT data directories are built. If not
//                then create them, move the appropriate files, and delete
//                then obsolete directories.
//
// Return Values: None
//
///////////////////////////////////////////////////////////////////////////////
// 3/19/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
void CheckDataDirs()
{
    DWORD   dwError = ERROR_SUCCESS;
    DWORD   dwClientType = 0;
    DWORD   dwLogFilesMoved = 0;
    DWORD   dwQuarFilesMoved = 0;
    TCHAR   szPath[IMAX_PATH] = {0};


    dprintf("Processing CheckDataDirs()\n");

    // Get the client type
    dwClientType = GetClientType();

    dprintf("CheckDataDirs: Client type is %d\n", dwClientType);

    // Are we running on WinNT?
    if ( IsWinNT() )
    {
        dprintf("Getting Common NAV app directory\n");

        // Yep. Get the path to the Windows 2000 common app data directory
        dwError = GetAppDataDirectory( NAV_COMMON_APP_DATA , szPath ) ;

        dprintf("Common NAV app directory: %s\n", szPath);

        // Smoke test: does our directory exist?
        if ( !DirectoryExists(szPath) )
        {
            dprintf("Common NAV app directory doesn't exist\n");

            // Nope. Create them
            dwError = CreateDataDirs();
        }

        // We're good so far
        if ( dwError == ERROR_SUCCESS )
        {
            auto TCHAR szTemp[IMAX_PATH] = {0};
            auto TCHAR szHome[IMAX_PATH] = {0};

            dprintf("CheckDataDirs: Moving NAV files\n");

            GetHomeDir( szHome, sizeof(szHome) );

            GetAppDataDirectory( NAV_COMMON_APP_DATA , szTemp );

            dprintf("New common app dir is: %s\n", szTemp);

            // Move files from the old Logs directory to the new directory
            MoveNAVFiles(szTemp, szHome, "Logs", &dwLogFilesMoved );

            // Move files from the old Quarantine directory to the new one
            MoveNAVFiles(szTemp, szHome, "Quarantine", &dwQuarFilesMoved );

            // Should we  nuke old directories?
            if ( dwQuarFilesMoved || dwLogFilesMoved )
            {
                // Remove old directories
                RemoveObsoleteDirs();
            }
        }

    }

    dprintf("CheckDataDirs: all done");

    return;
}


///////////////////////////////////////////////////////////////////////////////
//
// Function name: MoveNAVFiles
//
// Description  : Moves files from a subdir under the installation directory to
//                another location. For example, log files can be moved from:
//
//                C:\Program Files\NAVNT\Logs to 
//                C:\Documents and Settings\All Users\Symantec\...\7.5\Logs
//
// Parameters:    [in] - LPTSTR lpDestDir - destination directory
//                [in] - LPTSTR lpSrcDir  - source directory
//                [in] - LPTSTR lpCommonSubDir - common sub directory
//                [out] - LPDWORD lpNumberMoved - Number of files moved
//
// Return Values: Standard error codes
//
///////////////////////////////////////////////////////////////////////////////
// 3/19/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
DWORD MoveNAVFiles(LPTSTR lpDestDir, LPTSTR lpSrcDir, LPTSTR lpCommonSubDir, LPDWORD lpNumberMoved )
{
    DWORD           dwError = ERROR_SUCCESS;
    DWORD           dwClientType = 0;
    HANDLE          hFind = NULL;
    WIN32_FIND_DATA finddata = {0};
    TCHAR           szSourceFile[IMAX_PATH] = {0};
    TCHAR           szDestinationFile[IMAX_PATH] = {0};
    DWORD           dwNumberMoved = 0;


    // Get the client type
    dwClientType = GetClientType();

    // Are we running on Windows NT?
    if ( IsWinNT() )
    {
        // Set up the first source file
        wsprintf( szSourceFile,"%s\\%s\\*.*", lpSrcDir, lpCommonSubDir );

        dprintf("MoveNAVFiles: searching for %s\n", szSourceFile);

        // See if there are any files to copy
        hFind = FindFirstFile( szSourceFile, &finddata );

        while ( hFind && hFind != INVALID_HANDLE_VALUE )
        {
            // Found something
            if ( !(finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) )
            {
                // Set up the source file name
                wsprintf( szSourceFile,"%s\\%s\\%s", lpSrcDir, 
                          lpCommonSubDir, 
                          finddata.cFileName );

                // Set up the destination file name
                wsprintf( szDestinationFile,"%s\\%s\\%s", lpDestDir, 
                          lpCommonSubDir, 
                          finddata.cFileName);

                dprintf("MoveNAVFiles: Copying %s to %s\n", szSourceFile, szDestinationFile);

                // Copy the file
                if ( CopyFile( szSourceFile, szDestinationFile, FALSE ) )
                {
                    // Ok! Now delete it 
                    DeleteFile( szSourceFile );

                    dwNumberMoved++;
                }
            }

            FindNextFile( hFind, &finddata );

            // Any more files?
            if ( GetLastError() == ERROR_NO_MORE_FILES )
                break;
        }

        FindClose( hFind );
    }

    *lpNumberMoved = dwNumberMoved;

    return dwError;
}

#ifdef WIN32
///////////////////////////////////////////////////////////////////////////////
//
// Function name: RemoveObsoleteDirs
//
// Description  : Look through the home directory for any subdirs. Delete 
//                any that we find because they are now longer used.
//
// Return Values: Always returns ERROR_SUCCESS
//
///////////////////////////////////////////////////////////////////////////////
// 3/19/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
DWORD RemoveObsoleteDirs()
{
    DWORD           dwError = ERROR_SUCCESS;
    DWORD           dwClientType = 0;
    HANDLE          hFind = NULL;
    WIN32_FIND_DATA finddata = {0};
    TCHAR           szDir[IMAX_PATH] = {0};
    TCHAR           szHome[IMAX_PATH] = {0};


    // Get the home directory
    GetHomeDir( szHome, sizeof(szHome) );

    // Get the client type
    dwClientType = GetClientType();

    // Are we running on WinNT?
    if ( IsWinNT() && dwClientType == CLIENT_TYPE_CONNECTED || dwClientType == CLIENT_TYPE_STANDALONE )
    {
        // Set up the first source file
        wsprintf( szDir,"%s\\*.*", szHome );

        // See if there are any files to copy
        hFind = FindFirstFile( szDir, &finddata );

        while ( hFind && hFind != INVALID_HANDLE_VALUE )
        {
            // Found something. A directory??
            if ( finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
            {
                // Skip "." and ".."
                if ( (_tcscmp(finddata.cFileName, _T("..")) != 0) ||
                     (_tcscmp(finddata.cFileName, _T(".")) != 0 ) )
                {
                    // Set up the string
                    wsprintf( szDir,"%s\\%s", szHome, finddata.cFileName );

                    // Remove it
                    RemoveDirectory( szDir );
                }

            }

            FindNextFile( hFind, &finddata );

            // Any more files?
            if ( GetLastError() == ERROR_NO_MORE_FILES )
                break;
        }

        FindClose( hFind );
    }

    return dwError;
}
#endif


///////////////////////////////////////////////////////////////////////////////
//
// Function name: GetHomeDir
//
// Description  : Get the data for the HomeDir reg key. The normal getval()
//                method may npt always be available.
//
// Parameters:    [out] - LPTSTR lpHomeDir - buffer to receive the value 
//                               of the key
//                [in]  - DWORD dwHomeSize - size of the above buffer
//  
// Return Values: Standard error codes.
//
///////////////////////////////////////////////////////////////////////////////
// 3/19/2000 -   TCASHIN: Function created / header added 
///////////////////////////////////////////////////////////////////////////////
LRESULT GetHomeDir(LPTSTR lpHomeDir, DWORD dwHomeSize)
{
    DWORD           dwSize = dwHomeSize;
    LRESULT         lRet = ERROR_SUCCESS;
    HKEY            hKey = NULL;

    lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, szReg_Key_Main, 0, KEY_READ, &hKey );

    if ( ERROR_SUCCESS == lRet )
    {
        lRet = RegQueryValueEx(hKey, szReg_Val_HomeDir, NULL, 
                               NULL, (LPBYTE)lpHomeDir, &dwSize);

        RegCloseKey( hKey );
    }

    return lRet;
}
#endif // WIN32
**/



// implementation of GetFineLinearTime, which returns fine grain time for the platforms
// Win32 and NLM - fine grain means millisecond resolution or better, platform permitting

// this calculates delta elapsed time - this allows for wraparound, and works regardless
// of the scale, as long as the begin and time are on the same scale!

DWORD ElapsedFineLinearTime( DWORD dwStartTime, DWORD dwEndTime )
{
    DWORD dwElapsed;

    if (dwEndTime >= dwStartTime)
    {
        dwElapsed = dwEndTime - dwStartTime;
    }
    else
    {
        dwElapsed = 0xffffffff - dwStartTime;   // time from start up to the end
        dwElapsed += dwEndTime + 1;             // time from zero up to now
    }

    return dwElapsed;
}


/**
#ifdef WIN32

static __int64 tTimeMultiplier[] = { 1000, 1000, 10000};   // precision multipliers

static int nFineLinearTimeMode = MILLISECONDS;

void SetFineLinearTimeMode( int nMode )
{
    nFineLinearTimeMode = nMode;
}

// returns a linear time with a base time of when the routine was first called
// with resolution of nFineLinearTimeMode - the possiblities are either milliseconds
// or 1/10 milliseconds

DWORD GetFineLinearTime( VOID )
{

    static  __int64 tFirstLight = 0;
    static  __int64 tTicksPerSec;

    static  BOOL    bHiResTimerOK = TRUE;

    __int64 tCurrTime = 0;

    __int64 tSeconds;
    __int64 tFracSeconds;

    __int64 tResolutionMultiplier = tTimeMultiplier[nFineLinearTimeMode];

    if ( tFirstLight == 0 )       // first run through?
    {
        if ( QueryPerformanceFrequency( (LARGE_INTEGER *) &tTicksPerSec ) )
        {
            QueryPerformanceCounter( (LARGE_INTEGER *) &tFirstLight );
        }
        else
        {
            bHiResTimerOK = FALSE;
            tFirstLight = (__int64) GetTickCount( );
        }
    }

    if ( bHiResTimerOK )
    {
        __int64 tCurrCounter;

        QueryPerformanceCounter( (LARGE_INTEGER *) &tCurrCounter );
        tCurrCounter -= tFirstLight;

        tSeconds = tCurrCounter / tTicksPerSec;
        tFracSeconds = (tCurrCounter % tTicksPerSec) * tResolutionMultiplier;

        tCurrTime = tSeconds * tResolutionMultiplier + tFracSeconds / tTicksPerSec;
    }
    else
    {
        tCurrTime =  (__int64) GetTickCount( ) - tFirstLight;
    }

    return((DWORD) tCurrTime);
}

// end Win32 code

#else
*/



#endif 0




// NLM code, none of the above follows

//#ifdef NLM

typedef DWORD (* FGETHIGHRESOLUTIONTIMER) (void);
typedef DWORD (* FGETCURRENTTICKS) (void);

#define HIRES_TICKS_PER_SECOND_3X4X 9216

DWORD TicksToMilliseconds( DWORD dwTicks )
{
    return((dwTicks * 5492) / 100); 
}


static nFineLinearTimeMode = MILLISECONDS;
static DWORD dwTimeMultiplier[] = { 1000, 1000, 10000};   // precision multipliers

void SetFineLinearTimeMode( int nMode )
{
    nFineLinearTimeMode = nMode;
}

// returns a linear time with a base time of when the routine was first called
// with resolution of nFineLinearTimeMode - the possiblities are either milliseconds
// or 1/10 milliseconds

DWORD GetFineLinearTime( VOID )
{

    static  DWORD   dwFirstLight = 0;
    static  DWORD   dwTicksPerSec = 0;

    static  FGETHIGHRESOLUTIONTIMER fGetHighResolutionTimer = NULL;
    static  FGETCURRENTTICKS        fGetCurrentTicks = NULL;

    DWORD   dwOsStartTime = 0;

    DWORD   dwSeconds;
    DWORD   dwFracSeconds;

    DWORD   dwResolutionMultiplier = dwTimeMultiplier[nFineLinearTimeMode];

    if ( nFineLinearTimeMode != TICKS )
    {
        if ( dwFirstLight == 0 )  // first run through?
        {
            FILE_SERV_INFO  ServerInfo;

            GetServerInformation( sizeof( ServerInfo ), &ServerInfo );

            fGetHighResolutionTimer = ImportSymbol(GetNLMHandle(), "GetHighResolutionTimer");
            fGetCurrentTicks = ImportSymbol(GetNLMHandle(), "GetCurrentTicks");

            if ( fGetHighResolutionTimer )
                dwFirstLight = fGetHighResolutionTimer( );
            else if ( fGetCurrentTicks )
                dwFirstLight = fGetCurrentTicks( );
            else
                dwFirstLight = time( NULL );

            // they changed the undocumented API in 4.x - it used to be driven by the high
            // resolution timer, now they use the Pentium RDTSC instruction - when they
            // changed they changed the output resolution to 1/10000 s

            if ( ServerInfo.netwareVersion >= 4 )
            {
                dwTicksPerSec = 10000;
            }
            else
            {
                dwTicksPerSec = HIRES_TICKS_PER_SECOND_3X4X;
            }
        }

        if ( fGetHighResolutionTimer )
        {
            dwOsStartTime = fGetHighResolutionTimer( ) - dwFirstLight;

            dwSeconds = dwOsStartTime / dwTicksPerSec;
            dwFracSeconds = (dwOsStartTime % dwTicksPerSec) * dwResolutionMultiplier;

            dwOsStartTime = dwSeconds * dwResolutionMultiplier + dwFracSeconds / dwTicksPerSec;
        }
        else if ( fGetCurrentTicks )
        {
            dwOsStartTime =  TicksToMilliseconds( fGetCurrentTicks( ) - dwFirstLight );
        }
        else
        {
            dwOsStartTime = (time( NULL ) - dwFirstLight) * dwResolutionMultiplier;
        }       
    }
    else
    { // assume TICKS
        if ( dwFirstLight == 0 )
        {
            fGetCurrentTicks = ImportSymbol(GetNLMHandle(), "GetCurrentTicks");

            if ( fGetCurrentTicks )
                dwFirstLight = fGetCurrentTicks( );
            else
                dwFirstLight = 1;
        }

        if ( fGetCurrentTicks )
        {
            dwOsStartTime =  TicksToMilliseconds( fGetCurrentTicks( ) - dwFirstLight );
        }
        else
        {
            dwOsStartTime = (time( NULL ) - dwFirstLight) * dwResolutionMultiplier;
        }       
    }

    return(dwOsStartTime);
}

//#else

// not Win32, not NLM platformas
/*
static nFineLinearTimeMode = MILLISECONDS;
static DWORD dwTimeMultiplier[] = { 1000, 1000, 10000};   // precision multipliers

void SetFineLinearTimeMode( int nMode )
{
    nFineLinearTimeMode = nMode;
}


// returns a linear time with a base time of when the routine was first called
// with resolution of nFineLinearTimeMode - the possiblities are either milliseconds
// or 1/10 milliseconds

DWORD GetFineLinearTime( VOID )
{

    static  DWORD   dwFirstLight = 0;

    DWORD   dwOsStartTime   =   0;

    DWORD   dwResolutionMultiplier = dwTimeMultiplier[nFineLinearTimeMode];

    // for generic platforms I settle for 1-second resolution

    if ( dwFirstLight == 0 )      // first run through?
    {
        dwFirstLight = time( NULL );
    }

    dwOsStartTime =  time( NULL ) - dwFirstLight;

    dwOsStartTime *= dwResolutionMultiplier;

    return(dwOsStartTime);
}

//#endif  // #ifdef NLM

//#endif // #ifdef WIN32
/**/



/********************************************************************************************************/
/********************************************************************************************************/
/********************************************************************************************************/
/********************************************************************************************************/


