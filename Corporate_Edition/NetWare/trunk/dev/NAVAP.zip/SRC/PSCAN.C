//------------------------------------------------------------------------------
//
//      PScan.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------


#include "pscan.h"
//#include "pushmult.h"
//#include "finetime.h"

//#include "ThreadPool.h" // ksr


DWORD CheckXferDir(void);

char HomeDir[IMAX_PATH];

extern DWORD UpdateRunning;
extern DWORD DownloadRunning;
SERVERSTATUS gServerStatus;
//CLIENT_ARRAY **ClientArray;
STAT_BLOCK StatBlock;
PSTAT_BLOCK pStatBlock=NULL;
BOOL InitCritDone=FALSE;
char CurrentUserName[NAME_SIZE] = {0};
char ClientDir[IMAX_PATH];
char gszMoveDir[IMAX_PATH];

/**
#ifdef WIN32
HANDLE hAsyncScanMutex = NULL;
HANDLE hWatchForLogonsThreadSignal = NULL;
#endif
**/

/**
HKEY hClientKey=0;
HKEY hForwardKey=0;
HKEY hSystemKey=0;
HKEY hMainKey=0;
HKEY hCommonKey = 0;
HKEY hProductControlKey=0;
HKEY hPattManKey=0;
**/

HANDLE hAccessToken = 0;

extern DWORD currHeuristicLevel;
//DWORD NewPatternFile;
mSID MainSid;
char SystemRunning=0;


//#ifdef NLM
char EventThreadRunning=0;     // this is used to coordinate successfull shutdown of 
                               // the event handling system
//#endif


DWORD ThreadsInUse=0;


//#ifdef NLM
void RegDebug (void/*BOOL set*/);
//#endif


// these structures let me manage the pool of client update threads
// and rollout by net/subnet

/* ksr
THREAD_POOL UpdateClientFileThreadPool[MAX_UPDATE_CLIENT_FILE_THREADS] = {0};
int         nMaxUpdateClientFileThreads = 0;
BOOL        bUpdateClientsByNetOrSubnet = FALSE;
*/

/****************************************************************************************/
/****************************************************************************************/



#if 0  // ksr - Pattern Function


DWORD AmIMyOwnParent(void)
{

    char ComputerName[IMAX_PATH];
    char parent[IMAX_PATH];

    //HKEY hkey;

    //GetStr(hMainKey,"Parent",parent,sizeof(parent),"");
    // ksr
//    NTSGetComputerName(ComputerName,NULL);
    GetFileServerName( 0, ComputerName );

    if ( !stricmp(parent,ComputerName) )
    {    // I am my own parent
        dprintf("I am My Parent\n");
        //PutStr(hMainKey,"Parent","");   // so clear out the value
    }

	/**
    if ( RegOpenKey(hMainKey,"Children",&hkey) == ERROR_SUCCESS )
    {
        if ( GetVal(hkey,ComputerName,1234) != 1234 )
        {
            dprintf("I am My Child\n");
            RegDeleteValue(hkey,ComputerName);
        }
        RegCloseKey(hkey);
    }
	**/
    return 0;
}


//===============================================================

void UpdateFromReg(void)
{
    TIME_STAMP("UpdateFromReg");

    if ( NewPatternFile || GetVal(hProductControlKey,"NewPatternFile",0) )
    {
        CheckXferDir();
        CheckPattern(FALSE);
        NewPatternFile = 0;
        PutVal(hProductControlKey, "NewPatternFile",NewPatternFile);
    }

    if ( VeInfo->wSize != sizeof(VEINFO10) )
    {
        if ( GetVal(hMainKey,"HeuristicLevel",2) != currHeuristicLevel )
            CheckPattern(TRUE);
    }

    ThreadSwitch();

    if ( GetVal(hProductControlKey,"StartManualScanNow",0) )
    {
        StartServerScan(NULL,NULL);
        PutVal(hProductControlKey,"StartManualScanNow",0);
    }

    ThreadSwitch();

//#ifdef NLM
    RegDebug(/*FALSE*/);

    if ( GetVal(hProductControlKey,"UpdateServerFiles",0) )
    {
        UpdateServerFiles();
        PutVal(hProductControlKey,"UpdateServerFiles",0);
    }

    ThreadSwitch();
//#endif


    // Added 4-14-2000 jallee
    // Server Synchronization via GRCSrv.dat below
    /**
    if ( GetVal(hProductControlKey,"ProcessGRCSrvNow",0) )
    {
        HKEY hkey;
        if ( RegOpenKey(hMainKey,"DomainData",&hkey) == ERROR_SUCCESS )
        {
            // This is a primary server.
            // Write a GRCSrv.dat.
            ProcessGRCSrv(0);
            RegCloseKey ( hkey );
        }
        else
        {
            // This is a secondary server.
            // Read a GRCSrv.dat if available.
            if ( ERROR_SUCCESS == CheckGRCSrv() )
                // Check in with the Primary if we read new server settings.
                CheckInWithMommy();
        }
        PutVal(hProductControlKey,"ProcessGRCSrvNow",0);
    }
    **/

    ThreadSwitch();
    // Server Synchronization via GRCSrv.data above.

    if ( GetVal(hProductControlKey,"ProcessGRCNow",0) )
    {
        if ( GetVal(hMainKey,"Type",REG_DEFAULT_Type) != TYPE_IS_SERVER )
            CheckGRC();
        else
            ProcessGRC();
        PutVal(hProductControlKey,"ProcessGRCNow",0);
    }

    ThreadSwitch();


/**
#ifdef WIN32
    if ( GetVal(hProductControlKey,"EnumThreads",0) )
    {
        EnumAllThreads();
        PutVal(hProductControlKey,"EnumThreads",0);
    }
#endif
**/

    if ( GetVal(hProductControlKey,"ProcessLoginNow",0) )
    {
        ProcessLogin();
        PutVal(hProductControlKey,"ProcessLoginNow",0);
    }

    ThreadSwitch();

    if ( GetVal(hProductControlKey,"StartDownLoadNow",0) )
    {
        if ( !DownloadRunning )
            MyBeginThread((THREAD)StartADownload, NULL,"RTV Download");
        PutVal(hProductControlKey,"StartDownLoadNow",0);
    }
} 



/*************************************************************************************/
/**
typedef struct
{
    //HKEY hkey;
    char name[32];
    void (*fun)(void);
} REGWATCH;
typedef void (*VOIDFP)(void);
void WhenRegChange(REGWATCH *rw)
{

    DWORD cc;

    TIME_STAMP("WhenRegChange");

    while ( rw->hkey && SystemRunning )
    {
        cc = RegNotifyChangeKeyValue(rw->hkey,TRUE,REG_NOTIFY_CHANGE_LAST_SET,NULL,FALSE);
        if ( rw->hkey && SystemRunning )
        {
            __try 
            {
                if ( cc == ERROR_SUCCESS )
                    dprintf("%s change noted, re-reading.\n",rw->name);
                rw->fun();
            }
#ifndef NLM
            __except(1) 
            {
                MyBeginThread((THREAD)WhenRegChange,rw,"RTV Reg");
                return ;
            }
#endif
        }
    }

    free(rw);
}

**/

//============================================================================
/**
#if defined(WIN32) &&defined(SERVER)
void WatchForLogons(void *nothing);
#endif
**/


///////////////////////////////////////////////////////////////////////////////
//
// Function name: CheckScanForSchedule
//
// Description  : This function checks the data of a scan in the registry and
//                makes sure it is indeed a scheduled scan.  Then, it checks
//                if it is time to run the scan, and if it is, runs the scan.
//
// Parameters:    [in]  - HKEY hlkey: the handle to the registry key of a scan.
//                [in]  - char *name: the complete path of the registry key
//                        hlkey is pointing to.
//  
// Return Values: Returns ERROR_SUCCESS everytime.
//
///////////////////////////////////////////////////////////////////////////////
// 2/5/2001 - JCHEN: Comments added 
///////////////////////////////////////////////////////////////////////////////


DWORD CheckScanForSchedule(//HKEY hlkey,
							char *name)
{

    //HKEY hskey;
    //HKEY hkey;
    char str[128];

    strupr(name);

	// Take name passed in and attach '\Schedule' to it, so we can check that registry key.
    WSprintf(str,"%s\\Schedule",name);

	/**
	// Try to retrieve the handle the the registry key from 'str'.  We just want to see if it exists.
    if ( RegOpenKey(hlkey,str,&hskey) == ERROR_SUCCESS )
    {
		// Okay, 'Schedule' exists, so let's just grab the handle to the registry key in 'name'
		// since that is what we need to pass into the 'IsItTime' function.
        if ( RegOpenKey(hlkey,name,&hkey) == ERROR_SUCCESS )
        {
			// Check to see if it is actually time to run the scheduled scan.
            if ( IsItTime(hkey) )
            {
				// It is time to run a Scheduled Scan!  So indicate in the Logger reg key that
				// a Scheduled Scan is the event that logged the information.
                PutVal(hkey,"Logger",LOGGER_Scheduled);
                dprintf("Starting Scheduled Scan %s \n",str);

				// Actually start the Scan.
                StartServerScan(hkey,NULL);
            }
            else
				// Releasing the handle we got from 'name'.
                RegCloseKey(hkey);
        }
		// Releasing the handle we got from 'str'.
        RegCloseKey(hskey);
    }
    **/

    return ERROR_SUCCESS;
}


// ------------------------- Begin Duplicate Client Check Code --------------------------


// Forward declaration.
struct tagDupClientCheckStruct;

typedef struct tagDupClientCheckStruct
{
    LPTSTR      szClientName;
    //CBA_Addr    cbaAddress;
    DWORD       dwLastCheckinTime;

    struct tagDupClientCheckStruct *next;
}  DUPCLIENTCHECK, *LPDUPCLIENTCHECK;


/****************************************************************************************/

LPDUPCLIENTCHECK ReadClientsIntoList( void )
{
    LPDUPCLIENTCHECK    topClient = NULL;
    LPDUPCLIENTCHECK    lpNewDupClientCheckStruct = NULL;
    //HKEY                hkey = NULL;
    //HKEY                hckey = NULL;
    //char                szSubKey[IMAX_PATH];
    DWORD               index;

	/**
    if ( RegOpenKey(hMainKey,"Clients",&hkey) == ERROR_SUCCESS )
    {
        index=0;

        while ( RegEnumKey(hkey,index++,szSubKey,sizeof(szSubKey)) == ERROR_SUCCESS )
        {
            if ( RegOpenKey(hkey,szSubKey,&hckey) == ERROR_SUCCESS )
            {
                // Create a new node.
                lpNewDupClientCheckStruct = (LPDUPCLIENTCHECK) malloc( sizeof(DUPCLIENTCHECK) );
                memset( lpNewDupClientCheckStruct, 0, sizeof( DUPCLIENTCHECK ) );

                // Link this new node to the head of our client list.
                lpNewDupClientCheckStruct->next = topClient;
                topClient = lpNewDupClientCheckStruct;

                // Fill in the client name.
                lpNewDupClientCheckStruct->szClientName = (LPTSTR) malloc( (strlen( szSubKey ) + 1) * sizeof(TCHAR) );
                strcpy( lpNewDupClientCheckStruct->szClientName, szSubKey );

                // Read the last checkin time of this client into memory.
                lpNewDupClientCheckStruct->dwLastCheckinTime = GetVal( hckey, "LastCheckinTime", 0 );

                // Read this client's CBA Address into memory.
                ReadAnAddress(hckey, &(lpNewDupClientCheckStruct->cbaAddress) );

                // Close this client's registry key.
                RegCloseKey(hckey);
            }
        }

        // Close the main Clients registry key.
        RegCloseKey(hkey);
    }
    **/

    return topClient;
}

/****************************************************************************************/

int CompareClientCheckPointers( const void *arg1, const void *arg2 )
{
    LPDUPCLIENTCHECK lpClient1 = *((LPDUPCLIENTCHECK *)arg1);
    LPDUPCLIENTCHECK lpClient2 = *((LPDUPCLIENTCHECK *)arg2);

    int nComparison = 0;
    //int nSizeOfCompare = sizeof( CBA_Addr );

    // Compare the addresses.
    //nComparison = memcmp( &(lpClient1->cbaAddress), &(lpClient2->cbaAddress), nSizeOfCompare );

    return nComparison;
}


/****************************************************************************************/

LPDUPCLIENTCHECK SortClientList( LPDUPCLIENTCHECK topClient )
{
    LPDUPCLIENTCHECK *lpClientPointerArray;
    LPDUPCLIENTCHECK  lpClientIterator = topClient;
    int               nActualClientCount = 0;
    int               nLoop = 0;

    // Check for the NULL case.
    if ( NULL == topClient )
        return NULL;

    // Get a count of the number of elements.
    while ( lpClientIterator )
    {
        nActualClientCount++;
        lpClientIterator = lpClientIterator->next;
    }


    // Allocate an array of Pointers to Pointers to ClientCheck structures.
    lpClientPointerArray = (LPDUPCLIENTCHECK *) malloc( sizeof( LPDUPCLIENTCHECK ) * (nActualClientCount + 1) );

    if ( NULL == lpClientPointerArray )
    {
        // Memory allocation error.
        return NULL;
    }

    // Zero the memory for our new list.
    memset( lpClientPointerArray, 0, sizeof(LPDUPCLIENTCHECK *) * (nActualClientCount + 1) );


    // Reset our client iterator.
    lpClientIterator = topClient;

    for ( nLoop=0; nLoop < nActualClientCount && lpClientIterator; nLoop++ )
    {
        // Set this position in our Pointer array to this element of our linked list.
        lpClientPointerArray[nLoop] = lpClientIterator;

        lpClientIterator = lpClientIterator->next;
    }


    // Quick sort the pointers to structures in our pointer array.
    qsort( lpClientPointerArray, nActualClientCount, sizeof( LPDUPCLIENTCHECK ), CompareClientCheckPointers );


    // Re-link the list based on our sorted pointer array.
    for ( nLoop=0; nLoop < nActualClientCount; nLoop++ )
    {
        // link each item's next to the next item in the list.
        lpClientPointerArray[nLoop]->next = lpClientPointerArray[nLoop+1];
    }

    // Make sure the last item's next is NULL;
    lpClientPointerArray[nActualClientCount - 1]->next = NULL;

    // Reset the top client to the pointer in the head location of our pointer list.
    topClient = lpClientPointerArray[0];

    // Delete our client pointer array.
    free( lpClientPointerArray );

    // Return the position of the new head element in our sorted list.
    return topClient;
}

/****************************************************************************************/
// Node and List cleanup code.


void DeleteClientNode( LPDUPCLIENTCHECK lpItemToDelete )
{
    // Delete our string that contains the client name.
    free( lpItemToDelete->szClientName );

    // Delete this record itself.
    free( lpItemToDelete );
}


void DeleteClientList( LPDUPCLIENTCHECK topClient )
{
    LPDUPCLIENTCHECK lpItemToDelete = NULL;

    while ( topClient )
    {
        // Set a temp pointer to this item, and increment our top position.
        lpItemToDelete = topClient;
        topClient = topClient->next;

        DeleteClientNode( lpItemToDelete );
    }
}


/****************************************************************************************/

LPDUPCLIENTCHECK WalkAndDiscardDuplicateClients( LPDUPCLIENTCHECK topClient )
{

    LPDUPCLIENTCHECK lpClientIterator = topClient;
    LPDUPCLIENTCHECK lpPreviousClient = NULL;
    LPDUPCLIENTCHECK lpItemToDelete = NULL;

    // Handle NULL case.
    if ( NULL == topClient )
        return NULL;

    while ( lpClientIterator != NULL )
    {
        // Loop while we have a duplicate address between the current item, and the current item's next.
        while ( ( lpClientIterator->next )  )
                // &&
                //( !memcmp( &(lpClientIterator->cbaAddress), 
                //  &(lpClientIterator->next->cbaAddress), sizeof( CBA_Addr )) ) )
        {
            // Case 1:  Second is newer.  Remove the first.
            if ( lpClientIterator->dwLastCheckinTime < lpClientIterator->next->dwLastCheckinTime )
            {
                if ( lpPreviousClient )
                {
                    // Unlink the first item.
                    lpPreviousClient->next = lpClientIterator->next;

                    // Remove this client from the registry.
                    RemoveClient( lpClientIterator->szClientName );

                    DeleteClientNode( lpClientIterator );

                    lpClientIterator = lpPreviousClient->next;
                }
                else
                {
                    // This handles the top client case.  We are going to increment our top node so
                    // that we return back the correct top.
                    lpClientIterator = lpClientIterator->next;

                    // Remove the top item from the registry.
                    RemoveClient( topClient->szClientName );

                    // Delete the old first node.
                    DeleteClientNode( topClient );

                    // Set the topClient variable to the new top of the list.
                    topClient = lpClientIterator;
                }
            }
            // Case 2:  First is newer.  Remove the second from the linked list, and try again.
            else
            {
                // Save the node we wish to remove.
                lpItemToDelete = lpClientIterator->next;

                // Unlink it from our linked list.
                lpClientIterator->next = lpClientIterator->next->next;

                // Remove this client from the registry.
                RemoveClient( lpItemToDelete->szClientName );

                // Delete this node, and free it's memory.
                DeleteClientNode( lpItemToDelete );

            }
        }

        // Save the last iteration position.
        lpPreviousClient = lpClientIterator;

        // Increment our iterator.
        lpClientIterator = lpClientIterator->next;
    }

    // Return back the potentially new top client node.
    return topClient;
}

/****************************************************************************************/
// Thread function that will get called periodically to discard all duplicate clients
// in the registry based on their CBA Address.
/*
void DiscardDuplicateClients( void *nothing )
{
    LPDUPCLIENTCHECK    topClient = NULL;
    DWORD *             lpdwDuplicateCheckRunning = (DWORD *)nothing;

    REF(nothing);

    // Make sure we don't re-enter ourself.
    *lpdwDuplicateCheckRunning = TRUE;

    // Leaving this check in.  May remove later if it is unnecessary.
    /**kamy
    if ( GetVal( hMainKey, "DiscardDuplicateClients", 1 ) )
    {
        topClient = ReadClientsIntoList();
        topClient = SortClientList( topClient );
        topClient = WalkAndDiscardDuplicateClients( topClient );

        DeleteClientList( topClient );
    }
    ** /

    //Set this back to FALSE, lets other threads know that no other thread is executing this function.
    *lpdwDuplicateCheckRunning = FALSE;
}

*/

// ------------------------- End Duplicate Client Check Code ---------------------------

void PushUpdateToClients( LPDWORD lpdwPushUpdateToClientsRunning )
{
 	//HKEY                hkey = NULL;
 	//HKEY                hckey = NULL;
	//char                szSubKey[IMAX_PATH];
	DWORD               index;

    // these are used to cache the registry key values that I use

    DWORD dwUpdateClientsVal;
    DWORD dwUsingPatternVal;
    DWORD dwCheckConfigMinutes;
    DWORD dwIgnoreLateClients;
    DWORD dwHonorClientGoodFlag;

    VTIME MyGRCUpdateTime;

    DWORD dwFineStartTime = GetFineLinearTime( );

    BOOL  bNoOnePushedYet = TRUE;
    int   nClientsPushed = 0;

    *lpdwPushUpdateToClientsRunning = TRUE;

    // get the registry values to check the clients
	/**
    dwUpdateClientsVal = GetVal( hPattManKey,"UpdateClients", 1 );
    dwUsingPatternVal = GetVal( hMainKey,"UsingPattern", 0 );

    // this is normally off - the plan here is that clients are checking in seldom
    // so that late check-in isn't a reliable indicator, or more accurately
    // that having checked in a while ago doesn't mean much since the machine might be
    // off anyway

    dwIgnoreLateClients = GetVal( hMainKey, "IgnoreLateClients", REG_DEFAULT_IgnoreLateClients );

    // this indicates that the 'good' flag is an indicator of suitability
    // for rollout - the default is on.

    dwHonorClientGoodFlag = GetVal( hMainKey, "HonorClientGoodFlag", REG_DEFAULT_HonorClientGoodFlag );

    GetData( hMainKey, "ClientConfig\\GRCUpdateTime", &MyGRCUpdateTime, sizeof(VTIME), NULL, NULL);
    
    dwCheckConfigMinutes = 
        GetVal( hMainKey, "ClientConfig\\PatternManager\\CheckConfigMinutes", DEFAULT_CHECK_CONFIG_MINUTES );

    // now run through the clients and see who's looking out of date

    if (RegOpenKey(hMainKey,"Clients",&hkey) == ERROR_SUCCESS) 
    {
        index=0;

		while (SystemRunning && RegEnumKey(hkey,index++,szSubKey,sizeof(szSubKey)) == ERROR_SUCCESS) 
        {
			if (RegOpenKey(hkey,szSubKey,&hckey) == ERROR_SUCCESS) 
            {
                BOOL bDoThisClient = TRUE;

                if (dwIgnoreLateClients)
                {
                    // is he late? if so I probably can't talk to him, so skip him

                    time_t tCheckTime = time(NULL);
                    time_t tPreviousCheckInTime = GetVal(hckey,"LastCheckinTime", 0);

                    if ( IsClientOverdue( tPreviousCheckInTime, tCheckTime, dwCheckConfigMinutes ) )
                    {
                        bDoThisClient = FALSE;
                    }
                }

                if (bDoThisClient && dwHonorClientGoodFlag)
                {
                    if ( GetVal( hckey, "good", 0 ) == 0)
                    {
                        bDoThisClient = FALSE;
                    }
                }

                if (bDoThisClient)
                {
                    BOOL    bUpdateNeeded = FALSE;

                    DWORD   Flags;
                    VTIME   GRCTime;
                    DWORD   pattVer = GetVal( hckey, "PatternVersion", 0);

                    // am I updating people, and will he accept it?

                    Flags = GetVal( hckey, "Flags", 0);              // isPrimary=1 | isShairing = 2

                    if (dwUpdateClientsVal && (Flags&PF_WANT_PATTERN_UPDATES) )
                    {
                        // are the definitions older than what I have?

                        if (pattVer < dwUsingPatternVal)
                        {
                            // here comes new good stuff

                            bUpdateNeeded = TRUE;
                        }
                    }

                    // now check the GRC.dat file time stamp

                    GetData(hckey,"GRCUpdateTime",&GRCTime,sizeof(VTIME),NULL,NULL);
                    if (VTcomp(MyGRCUpdateTime, GRCTime) > 0)
                    {
                        // here comes new good stuff

                        bUpdateNeeded = TRUE;
                    }

                    // time to work on this guy?

                    if (bUpdateNeeded)
                    {
                        CBA_Addr address;
                        DWORD   ProductVersion;
                        BYTE    GuidData[16];
                        TCHAR   ComputerName[48];
                        
                        TCHAR   *szGuidStart;

                        BOOL    bAlreadyQueued;

                        DWORD   Count;
                        int     cc;
                        BOOL    bVerified = FALSE;
                        BYTE    VerifiedGuidData[16] = {"GUID\0\0"};

                        // get the rest of the stuff from the registry

                        ReadAnAddress( hckey, &address );
                        ProductVersion = GetVal( hckey, "ProductVersion", 0 );
                        GetData(hckey,"GUID",GuidData,16,NULL,NULL);

                        // recover the computer name - it isn't in the key!

                        memset( ComputerName, 0, sizeof(ComputerName) );
                        szGuidStart = _tcsstr( szSubKey, "_::_" );
                        if (szGuidStart)
                        {
                            int nNameLen = szGuidStart - szSubKey;
                            nNameLen = min( sizeof(ComputerName)-1, nNameLen );

                            memcpy( ComputerName, szSubKey, nNameLen );
                        }

                        // and off to the reeducation camp

                        // First check we need to see if the client we are about to queue up
                        // still lives at the address we have cached. Check the GUID, if it does not
                        // match, the client entry is bad. The client is probably configured to get its IP
                        // address from a DHCP server and the client has lost its lease. Some other client
                        // now has that lease. If the client can't be contacted, don't bother queueing it,
                        
                        Count = 1; // ask for 1 value.
                        cc = SendCOM_GET_VALUES((char *)&address, "",(char *)VerifiedGuidData,0,&Count);

                        if (cc == ERROR_SUCCESS) 
                        {
                            DWORD Size = 0;
                            BYTE *pData;

                            pData = GetValueFromBlock(VerifiedGuidData,0,(WORD *)&Size);
                    
                            if (Size >= (WORD)sizeof(GuidData))
                            {
                                if ( 0 == memcmp (pData, GuidData, sizeof(GuidData) ))
                                {
                                    // Guids match, this client is verified.
                                    bVerified = TRUE;
                                }
                                else
                                    // Guids don't match. Remove this client.
                                    // We have to wait for the client to check in with it's new
                                    // address before we can do anything. We delete the entry to 
                                    // prevent this client from getting hijacked. 
                                    // Duplicate checking removes clients w/ the same address, but
                                    // this doesn't work for clients of another server. If we send a grc.dat
                                    // we'll probably be stealing this client from another server.

                                    dprintf("ClientPushUpdateToClients - GUID mismatch. Removing %s\n", ComputerName);
                                    RemoveClient (  szSubKey );

                            }
                            else
                                dprintf("ClientPushUpdateToClients - queueing failed, client returned invalid GUID\n");
                        }
                        else
                        {
                            dprintf("ClientPushUpdateToClients  - queueing failed unable to contact client for GUID\n");
                        }

                        if ( bVerified )
                        {   
                            // Only queue clients after we have asked for their GUID directly and
                            // confirmed their identity.

                            bAlreadyQueued = QueueClientForUpdate( 
                                szSubKey,
                                FALSE,          // don't override any Pong's that may have showed up
                                &address,
                                pattVer, Flags, ProductVersion,
                                GuidData, ComputerName, &GRCTime );

                            if (! bAlreadyQueued)
                            {
                                // see if this is the first one for this pass, and mark the push
                                // starting in the registry
    
                                if (bNoOnePushedYet)
                                {
                                    bNoOnePushedYet = FALSE;
    
                                    PutVal( hMainKey, "ClientPushStartedAt", time(NULL) );
                                }
    
                                nClientsPushed += 1;
                            }
                        }
                    }
                }

                // Close this client's registry key.
				RegCloseKey(hckey);
			}
		}

        // Close the main Clients registry key.
        RegCloseKey(hkey);
    }

    if (nClientsPushed > 0)
    {
        PutVal( hMainKey, "ClientPushedCount", nClientsPushed );
        PutVal( hMainKey, "ClientPushCompletedAt", time(NULL) );
        PutVal( hMainKey, "ClientPushElapsedTime", ElapsedFineLinearTime( dwFineStartTime, GetFineLinearTime( ) ) );
    }
    else
    {
        PutVal( hMainKey, "ClientPushNoneElapsedTime", ElapsedFineLinearTime( dwFineStartTime, GetFineLinearTime( ) ) );
    }
	**/
	
    *lpdwPushUpdateToClientsRunning = FALSE;

    return ;
}


static DWORD    dwPushUpdateRate = 5;   // inital value in minutes for how often I check 
                                        // for push to clients - this gets updated from 
                                        // "ClientPushUpdateRate" registry key

void StartPushToClients( )
{
    // this is static because pointers to it are handed to another thread
    // if this thread exits this will evaporate before the child threads are yanked
    // away.
    
    static DWORD    dwPushUpdateToClientsRunning = 0;

    // make sure that push is enabled

    if ( dwPushUpdateRate != 0 && dwPushUpdateToClientsRunning == 0 )
        {
            MyBeginThread( PushUpdateToClients, &dwPushUpdateToClientsRunning, "PushUpdateToClients" );
        }
}

#endif	// 0



///////////////////////////////////////////////////////////////////////////////
//
// Function name: MainTimer
//
// Description  : This is the main Thread of the rtvscan service.  The main
//                events rtvscan checks for while running will be found here.
//
// Parameters:    None.
//  
// Return Values: None.
//
///////////////////////////////////////////////////////////////////////////////
// 2/5/2001 - JCHEN: Comments added 
///////////////////////////////////////////////////////////////////////////////

void MainTimer(void *nothing)
{
    DWORD   loopCount=0;
    char    name[128];
    //HKEY    hlkey;
    char    RootName[IMAX_PATH];
    // these are static because pointers to them are handed to another thread
    // if this thread exits they may evaporate before the child threads are yanked
    // away.
    static DWORD    dwDuplicateCheckRunning = 0;
    BOOL    bManagingClients = FALSE;               
    DWORD   dwPushUpdateTargetRemainder = 1;
    int i;
    DWORD index;

    REF(nothing);

    NTxSleep(5000);

    // Get the client type - Servers manage clients - this is a pretty permanent flag, so I don't
    // reread it all the time - I wanted to read ClientType, but that isn't defined on NetWare

//    bManagingClients = ( GetVal(hMainKey,"Type",REG_DEFAULT_Type) == TYPE_IS_SERVER );


	// **********************
   // BEGIN MAIN THREAD LOOP
	// **********************
	while( SystemRunning )
   {
    		ThreadSwitch();    		
/**
        // this is static because pointers to it are handed to another thread
        // if this thread exits it will evaporate before the child threads are yanked
        // away.
        
        static DWORD    dwDuplicateCheckRunning = 0;

        // move quite a bit of processing under this flag so that we don't do it unnecessarily

		// Every 5 Loops:
		// Check to see if Definition Roll back has failed.  If so, recall "MakeActivePattern".
		// ************************************************************************************
        if ( (loopCount%5) == 0 )    
            MyBeginThread((THREAD)RetryMakeActivePattern, NULL,"RTV Pattern Check");

		// The following only need to be done if we are an AV Server.
        if (bManagingClients)
        {
			// Every 3 (+2) Loops:
            // this check updates the client push update rate from the registry, whether I am currently pushing or not
            // this is done every n minutes - ensuring that I can reasonably quickly change the value
            // reqardless of the previous setting
			// ************************************************************************************
            if ( (loopCount % 3) == 2 )
            {
                DWORD dwRequestedPushUpdateRate;
    
                // update the rate and check if enabled - the default rate is - look below
                
                // 25sep2000 - jmillard - change the default rate - 3 is too often anyway - now I wait 2 minutes
                // past the time required to scavenge any files left in use because of communication 
                // errors - this will be currently 17 minutes

                dwRequestedPushUpdateRate = GetVal( hMainKey, "ClientPushUpdateRate", (FILE_HAN_TIMEOUT/60) + 2 );
    
                // adjust the expected remainder so that if the delay has changed, I actually
                // wake up at the end of the new period (starting from now), not a minute from now 
                // if I changed the rate from 3 minutes to 4 minutes.
    
                if (dwPushUpdateRate != dwRequestedPushUpdateRate)
                {
                    // note that when the rate changes I will always start a round of push if it
                    // is not already running
    
                    if (dwRequestedPushUpdateRate != 0)
                    {
                        dwPushUpdateTargetRemainder = loopCount % dwRequestedPushUpdateRate;                
                    }

                    dwPushUpdateRate = dwRequestedPushUpdateRate;    // use this rate from now on
                }
            }
    
            // this actually does the push, assuming that I am pushing anything
            // do this every "ClientPushUpdateRate" minutes, 0 == don't push
    
            if ( dwPushUpdateRate != 0 && (loopCount % dwPushUpdateRate) == dwPushUpdateTargetRemainder )
            {
                StartPushToClients( );
            }
     


			// Every 3 (+2) Loops:
            // Adjust the number of UpdateClientFile threads in case the reg key has changed
			// ************************************************************************************
            if (( (loopCount % 3) == 2) )
            {
                CreateUpdateClientThreadPool( );
            }

			// Every 60 Loops:
            // Check to see if we have bogus duplicate clients every 60 loops (~60 minutes).
			// ************************************************************************************
            if ( ( (loopCount%60) == 0) && ( !dwDuplicateCheckRunning ) )
                MyBeginThread(DiscardDuplicateClients,&dwDuplicateCheckRunning,"DuplicateClientCheck");
        } // end if (bManagingClients)

		// Every 5 Loops.
        // Check to see if the secondary servers need their defs updated.
		// ************************************************************************************
        if ( (loopCount%5) == 0 )
            if ( (GetVal(hPattManKey,"UpdateChildren",0)||GetVal(hPattManKey,"UpdateClients",0)) && !UpdateRunning )
                MyBeginThread((THREAD)UpdateChildren, NULL,"RTV Update");

		// Every Loop:
        // Check to see if its time to kickoff the scheduled definition update.
		// ************************************************************************************
        if ( !DownloadRunning && IsItTime(hPattManKey) )
            MyBeginThread((THREAD)StartADownload, NULL,"RTV Download");

        // MMENDON 04-04-2000:  STS defect 332288: A check for the .vdb file in the NAV directory
        //                      be independent of the schedule set for the CheckInWithMommy()
        //                      packet.  This allows defs put on the client by other means to
        //                      be processed in a timely manner.
        { 
            int foo = GetVal(hPattManKey,szReg_Val_CheckConfigMinutes, DEFAULT_CHECK_CONFIG_MINUTES );

            foo = foo ? foo : 1; // foo can't be zero or we'll gpf
            if ( (loopCount%(foo)) == 0 )
            {
                if ( GetVal(hMainKey,"Type",REG_DEFAULT_Type) != TYPE_IS_SERVER )
                {
                    TIME_STAMP("CheckInWithMommy");
                    CheckInWithMommy();
                }
            }
        }
		
		// Every 3 Loops:
        // check for new pattern file
		// ************************************************************************************
        if ( (loopCount%3) == 0 )
        {// check for new pattern file every foo loopCounts
            TIME_STAMP("CheckPattern");
            CheckPattern(FALSE);
        }
        // MMENDON 04-04-2000:  End fix STS defect 332288

		// Every Loop:
		// Check to see if there are any locally created Scheduled Scans (scans created by the local
		// client GUI) that need to be run.
		// ************************************************************************************
		
        if ( GetVal(hMainKey,"RunUserScans",0) )
        {
            TIME_STAMP("RunUserScans");
            WSprintf(RootName,VpRegBase[HKEY_VP_USER_SCANS&0xff].Key,"");

			// At the time of writing this comment, we are looking under the following Registry Path:
			// '\\HKEY_CURRENT_USER\Software\Intel\Landesk\VirusProtect6\CurrentVersion\CustomTasks'
			// Open the handle to that path.
            if ( RegOpenKey(VpRegBase[HKEY_VP_USER_SCANS&0xff].hBase,RootName,&hlkey) == ERROR_SUCCESS )
            {
                index=0;

				// Iterate through all the registry keys found in the path listed above.
                while ( RegEnumKey(hlkey,index++,name,sizeof(name)) == ERROR_SUCCESS )
                {
					// Check to see if the Scan has a "Schedule" registry key under it.
                    CheckScanForSchedule(hlkey,name);
                }
                RegCloseKey(hlkey);
            }
        }

		// Every Loop:
		// Check to see if there are any remotely created Scheduled Scans (scans created by an
		// Administrator from the SSC Console) that need to be run.
		// ************************************************************************************
        WSprintf(RootName,VpRegBase[HKEY_VP_ADMIN_SCANS&0xff].Key,"");

		// At the time of writing this comment, we are looking under the following Registry Path:
		// '\\HKEY_LOCAL_MACHINE\Software\Intel\Landesk\VirusProtect6\CurrentVersion\LocalScans'
		// Open the handle to that path.
		if ( RegOpenKey(VpRegBase[HKEY_VP_ADMIN_SCANS&0xff].hBase,RootName,&hlkey) == ERROR_SUCCESS )
        {
//      if (RegOpenKey(hMainKey,"LocalScans",&hlkey) == ERROR_SUCCESS) {
            index=0;

			// Iterate through all the registry keys found in the path listed above.
			while ( RegEnumKey(hlkey,index++,name,sizeof(name)) == ERROR_SUCCESS )
            {
				// Check to see if the Scan has a "Schedule" registry key under it.
                CheckScanForSchedule(hlkey,name);
            }
            RegCloseKey(hlkey);
        }

        // Every 360 Loops:
		// Clean up log files every 6 hours.
		// ************************************************************************************
        if ( (loopCount%(60*6)) == 0 )
        {
            TIME_STAMP("CleanUpLogFiles");
            CleanUpLogFiles();
        }

        // Every 60 Loops:
		// Moving client check outside of the log file check.  We are going to attempt to check clients for
        // deletion on a 1 hour granularity.
		// ************************************************************************************
        if ( (loopCount%(60)) == 0 )
        {
            TIME_STAMP("CheckAllClients");
            CheckAllClients();
        }
		
		// Every 5 Loops:
		// ************************************************************************************
        if ( (loopCount%5) == 0 )
        {
            TIME_STAMP("CheckScans");
            CheckScans();
#ifdef NLM
            RegSaveDatabase();
#endif
            AmIMyOwnParent();
        }

        // Every Loop:
		// Check for and log any Configuration Changes.
		// ************************************************************************************
		// 4/20/2000 Moved CheckChange out of the above 
        // group. Now check every minute instead of every 5.
        TIME_STAMP("CheckChange");
        CheckChange(NULL);

        // Every 10 Loops:
		// Check to see is a new GRC.dat file needs to be processed.
		// ************************************************************************************
		// 25sep2000 - jmillard - don't check this so often - this was changed to reduce the frequency
        // of checking for defs when we are backrev'ing - with a large number of clients this pounds
        // the server and slows things down. there doesn't seem to be a downside to this other than if
        // someone copies a grc.dat file to the machine we won't pick it up quite so fast - if it shows
        // up through normal channels CheckGRCNow is set and CheckGRC gets called immediately from 
        // another place. This used to be done every time through, once a minute.

        if ( (loopCount % 10) == 0 )    
        {
            if ( GetVal(hMainKey,"Type",REG_DEFAULT_Type) != TYPE_IS_SERVER )
            {
                TIME_STAMP("CheckGRC");
                CheckGRC();
            }
        }

#ifndef WIN95
//      GetLoginInfo();
#endif

        // Every Loop
		// Only on non-Netware AV Servers, check to see if any of the LiveUpdate Settings have been changed.
		// If so, register those changes. Then, check to see if there is a LiveUpdate that needs to be run.
		// If so, run it.
		// ************************************************************************************
		// Check to see if we need to upate this machines LiveUpdate settings.
#ifdef SERVER
#ifndef NLM  //ML
        CheckLiveUpdate();
        CheckLuAdminForSchedule();
#endif //.. ifndef NLM
#endif

		// Every Loop:
		// Make sure all the pongs are in sync.
		// ************************************************************************************
        ReStartPongEngine(FALSE);  // redundent but there are cases where we can get out of sync.
       
		// Start a new loop, to delay time before the next main cycle runs.  Cycle 120 times,
		// or until the Service is shut down.
		// ************************************************************************************
		for ( i=0;i<60*2&&SystemRunning;i++ )
        {
//GetCPUUtilization();
            NTxSleep(500);

            if ( i%10 == 0 )
            {
                CheckVirusAlerts();
            }

            if ( i%30 == 0 )
            {
                if ( GetVal(hMainKey,"Type",REG_DEFAULT_Type) == TYPE_IS_SERVER )
                    CheckClientDir();
            }
        }
        loopCount++;
        if ( loopCount == 3 )
            PutVal(hMainKey,"Status",0);
**/
    }	// while
}


/***********************************************************************************************************/

//#ifdef REAL_SERVICE	// ???

////void ServiceUpdate(void);

void LookAlive(void *var)
{
    int i;
    DWORD *Var = (DWORD *)var;
    *Var = 1;

    ThreadsInUse--;

    for ( i=0; i<4*60*2&&*Var==1; i++ )
    {
        ////ServiceUpdate();
        
	     // ksr
	     //Sleep(250);
	     NTxSleep(250);
    }

    ThreadsInUse++;

    if ( *Var == 1 )
    {
        dprintf("Service Hung\n");
    }
}

//#endif


//#ifdef NLM

DWORD GetBranchTarget( LPBYTE lpBranch )
{
    DWORD dwTarget = 0xffffffff;

    // verify branch

    if ( *lpBranch == 0xe9 || *lpBranch == 0xe8 )
    {
        DWORD dwOffset = * (LPDWORD) lpBranch + 1;

        // make absolute address - it is relative to the end of the branch.

        dwTarget = dwOffset + ((DWORD)lpBranch) + 1 + 4;
    }

    return dwTarget;
}


void *ImportSymbolReturnTrueAddress( int NLMHandle, char *szSymbol )
{
    LPBYTE lpRequestedAddr = ImportSymbol( NLMHandle, szSymbol );

    if ( lpRequestedAddr )
    {
        // see if it looks like it is marshalled

        if ( *lpRequestedAddr == 0x68 && *(lpRequestedAddr + 5) == 0xe9 )
        {
            DWORD dwRealRequestedAddr = * (LPDWORD) (lpRequestedAddr + 1);

            lpRequestedAddr = (LPBYTE) dwRealRequestedAddr;
        }
        else
        {
            // doesn't seem to be marshalled
        }
    }

    return lpRequestedAddr;
}



static BYTE MsgSemaWaitCodeSequence1[ ] = {
    0x55, 0x89, 0xe5, 0x53, 0x8b, 0x5d, 0x08, 0x8b, 0x13,
    0x85, 0xd2, 0x74, 0x18, 0x6a, 0xff, 0x52, 0xe8};

static BYTE MsgSemaWaitCodeSequence2[ ] = {
    0x83, 0xc4, 0x08, 0x85, 0xc0, 0x74, 0x09, 0x53, 0xe8};

static BYTE MsgSemaWaitCodeSequence2Patched[ ] = {
    0x83, 0xc4, 0x08, 0x85, 0xc0, 0x74, 0x09, 0xe9, 0xe3, 0xff, 0xff, 0xff};

static BYTE MsgSemaWaitCodeSequence3[ ] = {
    0x83, 0xc4, 0x04, 0x8b, 0x03, 0x5b, 0x5d, 0xc3};

#define OFFSET_TO_TIMEOUT   0x0e

int FindAndVerifyMsgSemaWait ( LPBYTE *lplpMsgSemaWaitCode )
{
    int nRet = ERROR_SUCCESS;

    LPBYTE lpMsgSysFindIDCode = NULL;
    LPBYTE lpMsgSemaWaitCode = NULL;

    lpMsgSysFindIDCode = ImportSymbolReturnTrueAddress(GetNLMHandle(), "MsgSysFindID");
    if ( lpMsgSysFindIDCode )
    {
        BOOL bSeq1, bSeq2, bSeq2Patched, bSeq3;

        // found msgsys.nlm - life is good

        lpMsgSemaWaitCode = lpMsgSysFindIDCode - 0x2030;    // a bit ad hoc, I admit, but I am
                                                            // more careful further down
        bSeq1 = memcmp( lpMsgSemaWaitCode, 
                        MsgSemaWaitCodeSequence1, sizeof( MsgSemaWaitCodeSequence1 )) == 0;
        bSeq2 = memcmp( lpMsgSemaWaitCode + sizeof( MsgSemaWaitCodeSequence1 )+4, 
                        MsgSemaWaitCodeSequence2, sizeof( MsgSemaWaitCodeSequence2 )) == 0;
        bSeq2Patched = 
        memcmp( lpMsgSemaWaitCode + sizeof( MsgSemaWaitCodeSequence1 )+4, 
                MsgSemaWaitCodeSequence2Patched, sizeof( MsgSemaWaitCodeSequence2Patched )) == 0;
        bSeq3 = memcmp( lpMsgSemaWaitCode + sizeof( MsgSemaWaitCodeSequence1 )+4 + sizeof( MsgSemaWaitCodeSequence2 )+4, 
                        MsgSemaWaitCodeSequence3, sizeof( MsgSemaWaitCodeSequence3 )) == 0;

        // verify the code looks exactly like I expect

        if ( bSeq1 && bSeq2 && bSeq3 )
        {
            // everything is cool!
        }
        else if ( bSeq1 && bSeq2Patched && bSeq3 )
        {
            nRet = MSGSYS_PATCHED;
        }
        else
        {
            nRet = MSGSYS_WRONG;        // code is not exactly right
        }


        UnimportSymbol(GetNLMHandle(), "MsgSysFindID");

    }
    else
    {
        nRet = MSGSYS_NOT_FOUND;           // msgsys.nlm is not running
    }

    // never give them anything to work with on error

    if ( nRet != ERROR_SUCCESS )
    {
        lpMsgSemaWaitCode = NULL;
    }

    *lplpMsgSemaWaitCode = lpMsgSemaWaitCode;

    return nRet;
}



// #define TEST_NEVER_HAPPENS  1

// this is from the Maple code base - this is the Handle they pass to MsgSemaWait

typedef struct nwhandle 
{
    struct nwhandle *pNext;
    LONG handleType;
    LONG handleValue;
    LONG handleRef;
    LONG handleStack;
    long threadGroupID;
    BYTE handleName[1];
};

typedef struct nwhandle *P_NWHANDLE;


// stack offsets to interesting parameters

typedef struct tagTimedSemaphore 
{
    struct  tagTimedSemaphore *pNext;   // +0
    struct  tagTimedSemaphore *pPrev;   // +4
    DWORD   dwExpireTime;               // +8
    DWORD   hSemaphore;                 // +c
    DWORD   hThread;                    // +10
    DWORD   dwTrailingTimeout;          // +14 // only in service pack 8 code
};

typedef struct tagTimedSemaphore *P_TIMEDSEMAPHORE;


#define EBP_HSEMA               (+13*4)     // + 13 dwords
#define EBP_REQUESTED_TIMEOUT   (+6 *4)     // + 6 dwords
#define EBP_TIMED_SEMAPHORE_6   (-8 *4)     // -8 dwords
#define EBP_TIMED_SEMAPHORE_8   (-9 *4)     // -9 dwords

DWORD dwBreakFlag = 0;


//#endif      // #ifdef NLM


// this code patches/unpatches a bug in INTEL's msgsys.nlm


int FixMsgSysNLM( void )
{
    int nRet = ERROR_SUCCESS;

//#ifdef NLM

    LPBYTE  lpMsgSemaWaitCode;
    LPBYTE  lpPatchPoint;

    static BOOL bMsgSysPatched = FALSE;

    // offset to branch I want to patch

    int     nPatchOffset1 = sizeof( MsgSemaWaitCodeSequence1 ) + 4 + sizeof( MsgSemaWaitCodeSequence2 ) - 2;


    if ( ! bMsgSysPatched )
    {

        nRet = FindAndVerifyMsgSemaWait( &lpMsgSemaWaitCode );
        if ( nRet == ERROR_SUCCESS )
        {
            DWORD dwPatchData;

            bMsgSysPatched = TRUE;  // I do this early to it doesn't get in the middle of the patch

            lpPatchPoint = (lpMsgSemaWaitCode + nPatchOffset1);
            dwPatchData = (DWORD) -29;

            // note - this is not strictly speaking, multi-thread safe, but Intel's code doesn't work on
            // a multi-processor NW 4.x - this is slight risky on NW 5.x - need to get multiprocessor
            // blocking code, if there is such a thing - really should get Intel to fix this.

            // note that the risk is really VERY small - this code is only executed if an infinite
            // timeout occurs, which almost never happens anyway. If I am the one who
            // loaded msgsys.nlm, it happened in the last 45 seconds, so there is no
            // risk. If LanDesk loaded it a while ago, then there is a very small risk
            // that they might have an infinite timeout expire. Or if RTVSCAN has been loaded and 
            // unloaded.

            // to ensure that it this does break it breaks in a visible, least
            // dangerous way, I put an illegal instruction where the risk is,
            // then overwrite it with good stuff - the trailing fc makes the branch
            // jump to the illegal instruction after patch 2 before patch 3, and 
            // it gets executed directly betweene 0 and 2.

            // this also ensures the mildest form of soft abend during loading

            * (LPDWORD) (lpPatchPoint + 1) = 0xfffffffc; // makes the next branch visibly bad

            * lpPatchPoint = 0xe9;

            * (LPDWORD) (lpPatchPoint + 1) = dwPatchData; // makes the branch right

            * (lpPatchPoint + 5) = 0x90;        // nop to finish clean up - no risk here

        }
        else if ( nRet == MSGSYS_PATCHED )
        {
            nRet = ERROR_SUCCESS;
        }
        else
        {
            // something wrong, either msgsys.nlm not running, or the patch isn't right
            // the caller must decide what to do.
        }
    }

//#endif

    return nRet;

}


//============================================================================

void DeInitPscan(void)
{
    int i;
    //HKEY hkey = hProductControlKey;
    //EVENTBLOCK log;
    char line[64];
    long SmStatus=0;
    int count;

//#ifdef REAL_SERVICE
	// tmm07-24-00: made Var static since we are passing in its
	// address to a new thread.  There were times when I was debugging
	// (on a fast machine) when DeInitPscan would finish before LookAlive
	// so the pointer to Var became invalid.
    static DWORD Var = 0;
    
    // ksr  - chk following ???
    
    MyBeginThread(LookAlive,(void *)&Var,"LookAlive");
    
    #define END end: Var = 0;
/*
#else
    #define END end:
#endif
*/

    TIME_STAMP("DeInitPscan");

    if ( !SystemRunning )
        goto end;

    //PutVal(hMainKey,"Status",4);
    //PutVal(hMainKey,szReg_Val_ServiceRunning, KEYVAL_NOTRUNNING);

    dprintf("Stopping Scans\n");
    StopAllScans();

/*
#ifdef WIN32
    StopVBinMonitor();

    // Tell the WatchForLogons thread to quit
    if ( hWatchForLogonsThreadSignal )
    {
        SetEvent( hWatchForLogonsThreadSignal );
    }
#else
#ifdef NLM //EA - 08/09 for Quar Fwd
    StopVBinMonitor(); //EA - 08/09
#endif  //EA - 08/09    
#endif
*/
//    memset(&log,0,sizeof(log));
    WSprintf(line,LS(IDS_SYSTEM_SHUTDOWN));
    /*
    log.Description = line;
    log.logger = LOGGER_System;
    //log.hKey[0] = 0;
    log.Category = GL_CAT_SUMMARY;
    log.Event = GL_EVENT_SHUTDOWN;
    GlobalLog(&log);*/
    NTxSleep(250);

    SystemRunning=0;
    dprintf("Closing Pscan.");

    NTxSleep(250); // give things a chance to settle down
    
/**
    dprintf("Checking pattern manager\n");
    for ( i=0;(UpdateRunning||DownloadRunning)&&i<30;i++ )
    {
#ifdef NLM
        _printf(LS(IDS_WAITING_PATT_MAN));
#else
        dprintf("Waiting For Pattern Manger to stop\n");
#endif
        NTxSleep(1000);
    }
**/

//#ifdef WIN32
    //dprintf("Stop LPC\n");
    //StopLPC();
//#endif

    //dprintf("Stop Packet Processing\n");
    //StopProcessing();

/*
    if ( AmsActive )
    {
        dprintf("Deataching from AMS\n");
        UninstallAMS();
    }
*/

/*
#ifdef WINNT
    EndEventLog();
#endif
*/

    //dprintf("Shutting down Pattern Manager\n");
    //ShutDownPattern();

    NTxSleep(250);

    //dprintf("Starting Stutdown of StorageManager\n");
    MyBeginThread((void (*)(void *))StorageManagerStop,&SmStatus,"Storage Manager Stop");


//#ifdef NLM
	//The following block was added by EA and BNM to clean up the virus alert queue
	//when we shutdown before emptying the whole list. This will prevent memory leak
	//which causes the error message "rtvscan has ## unreleased resources" on NetWare
	//servers. This was causing PAL memory certification test to fail at Novell.
	
	// ksr ???  FreeAllVirusAlerts();
	
//#endif

    //hProductControlKey = 0;

	/**
    if ( hkey )
        RegCloseKey(hkey);

    hkey = hPattManKey;
    hPattManKey = 0;
    if ( hkey )
        RegCloseKey(hkey);
	**/
	
    NTxSleep(128);


    dprintf("Checking Shutdown of StorageManager -");
    for ( i=0;i<20*30&&SmStatus==1;i++ )
    {
        NTxSleep(55);
        dprintf("-");
    }
    dprintf("\n");


/**

    dprintf("Stopping NTS\n");
    StopNTS();
#ifdef NLM
	//Fix for STS 340597 - unloading qsfwd nlm 
	if( FindNLMHandle( _T("QsFwd.NLM") ) != NULL )
		_FreeLibrary( _T( "QsFwd.NLM" ) ); 
#endif

**/

    NTxSleep(128);

    dprintf("Checking Threads, Current Thread List \n");
    
    
/**
#ifdef WIN32
    EnumAllThreads();
#endif
**/

//#ifdef NLM
    count=2*60*5;
/*#else
    count=debug?2*60*2:2*30;
#endif
*/
    for ( i=0;ThreadsInUse&&i<count;i++ )
    {
        if ( (i%30) == 0 )
        {
//#ifdef NLM
            _printf(LS(IDS_WAITING_THREADS));
//#endif
/**
#ifdef WIN32
            if ( debug&&ThreadsInUse )
            {
                dprintf("Waiting for %u Threads\nAll threads running ---\n",ThreadsInUse);
                EnumAllThreads();
            }
#endif
**/
        }
        NTxSleep(500);
        dprintf("+");
    }
    dprintf("\n");

//#ifdef NLM

    // safety check at close of business to let the EventThread leave
    // if I don't let him leave on his own terms, the server will die
    // because he is probably stuck on a semaphore. Therefore I will wait
    // forever, if necessary. Note that he has been cleaned up so that he
    // should exit in a fairly timely way, assuming that the underlying
    // communication system is functioning.

    if ( EventThreadRunning )
    {
        int nEverySoManySeconds = 0;
        int nInterval = 120;             // seconds, that is
        
        while ( EventThreadRunning )
        {
            NTxSleep(1000);

            nEverySoManySeconds += 1;
            // starts at 1 so they get the first message right away
            if ( nEverySoManySeconds % nInterval == 1 )
                _printf("RTVSCAN: waiting for RTV Do Events thread to leave" );
        }

    }

    if ( ThreadsInUse )
        _printf(LS(IDS_KILL_THREADS));
    dprintf("Threads In Use: %d\n",ThreadsInUse);
    if ( ThreadsInUse )
        _printf("We have [%d] unreleased Threads!\n",ThreadsInUse);

    Breakpoint(TrackThreads && ThreadsInUse);    // REMOVE THIS BEFORE SHIPPING!!!
 
    
 #ifdef ThreadCheck
    ThreadReport(FALSE);
 #endif // ThreadCheck
 
//#endif
    dprintf("%u threads left running\n",ThreadsInUse);

    //dprintf("Freeing Scan Memory\n");
    //FreeAllScans();

    //dprintf("Closing Keys\n");
/**
    if ( hClientKey )
        RegCloseKey(hClientKey);

    if ( hForwardKey )
        RegCloseKey(hForwardKey);

    if ( hSystemKey )
        RegCloseKey(hSystemKey);

//  Close the handle to the Common key if it was opened.
    hCommonKey = GetCommonKey();
    if(hCommonKey)
        RegCloseKey(hCommonKey);
 **/
 
/**
#ifdef WIN32
    if ( hFileMap )
    {
        UnmapViewOfFile(pStatBlock);
        CloseHandle(hFileMap);
    }

    if ( hAsyncScanMutex )
    {
        CloseHandle(hAsyncScanMutex);
        hAsyncScanMutex = NULL;
    }

    if ( hWatchForLogonsThreadSignal )
    {
        CloseHandle(hWatchForLogonsThreadSignal);
        hWatchForLogonsThreadSignal = NULL;
    }
#endif
**/

    dprintf("Done with Deinit\n");

    //PutVal(hMainKey,"Status",5);

    //if ( hMainKey )
    //    RegCloseKey(hMainKey);

    InitCritDone = FALSE;
//#ifdef NLM
    _printf("Shutdown Complete\n");
//#endif

    if ( debug&DEBUGPRINT )
    {
        dprintf("Debug Delay 6 sec.");
        NTxSleep(6000);
    }

    END
    return;
}

//============================================================================

DWORD InitCrit(void)
{
    DWORD cc;

    if ( !InitCritDone )
    {
    	/**
        cc = RegOpenKey(HKEY_LOCAL_MACHINE, REGHEADER, &hMainKey);
        if ( cc != ERROR_SUCCESS )
            return ERROR_NO_KEY;

        RegOpenKey(hMainKey, "PatternManager", &hPattManKey);
        RegOpenKey(hMainKey, "ProductControl", &hProductControlKey);
        RegOpenKey(hMainKey, "ClientScan", &hClientKey);
        RegOpenKey(hMainKey, "ForwardScan", &hForwardKey);
        RegOpenKey(hMainKey, "SystemScan", &hSystemKey);

        PutVal(hMainKey,"Type",!GetVal(hProductControlKey,"ManageThisComputer",0));
		**/
/*		
#ifdef WINNT
        InitEventLog();
#endif
*/
        InitCritDone = TRUE;
    }

    return ERROR_SUCCESS;
}

 
 
// create or update a pool of threads

// this gets the appropriate number of threads running, regardless
// of how many are currently running, too many or too few

// the RegKey for the count is assumed to be in hMainKey ("CurrentVersion")
/**
void CreateThreadPool( char *szBaseThreadName, THREAD fThreadProc, 
                       char *RegKeyForThreadCount, int nMinThreadCount, int nDefaultThreadCount, int nMaxThreadCount, 
                       THREAD_POOL ThreadPool[], int *lpnMaxPoolThreads )
{
    int  i;

	int nThreadCount = 0;//ksr = GetVal( hMainKey, RegKeyForThreadCount, nDefaultThreadCount );

    // clamp down hard on the number

    if (nThreadCount > nMaxThreadCount)
        {
        nThreadCount = nMaxThreadCount;
        }

    if (nThreadCount < nMinThreadCount)
        {
        nThreadCount = nMinThreadCount;
        }

    // set the current thread limit - any running threads check this, and
    // if their number is over the limit, they gracefully exit at
    // the next convenient breaking point

    *lpnMaxPoolThreads = nThreadCount;   // it is zero-based

    // I run through even if this number hasn't changed, just in case
    // some threads have left - I will start them up again to get up to
    // a full pool

    for( i=0; i<nThreadCount; i++)
        {

        // start any non-running threads that I think should be running.

        if (! ThreadPool[i].bRunning)
            {

            ThreadPool[i].lpnMaxThreadNumber = lpnMaxPoolThreads;
            ThreadPool[i].nThreadNumber = i;
    
            // build the thread name

            strcpy( ThreadPool[i].szThreadName, szBaseThreadName );

            // all threads but the first have a postfix number
            if (i > 0)
                {
                char szThreadNumber[10];

                ltoa( i, szThreadNumber, 10 );

                strcat( ThreadPool[i].szThreadName, "_" );
                strcat( ThreadPool[i].szThreadName, szThreadNumber );
                }

            dprintf( "starting update pool thread %s\n", ThreadPool[i].szThreadName );

            ThreadPool[i].bExited  = FALSE;
            ThreadPool[i].bRunning = FALSE;

            ThreadPool[i].hThread = MyBeginThread( fThreadProc, &ThreadPool[i], ThreadPool[i].szThreadName);

            // wait for him to start up

            while( ! ThreadPool[i].bRunning && ! ThreadPool[i].bExited && ThreadPool[i].hThread != MINUS_ONE )
                {
                NTxSleep(100); // let him get running
                }

            }
        }
}
 
 // routine start up stuff
 
 void ThreadPoolThreadStarting( THREAD_POOL *ThreadPoolEntry )
 {
 #ifdef WIN32
     
     // this is the only way to identify the thread on NT, and
     // I save the name myself since NT doesn't. Now I have the
     // two things I need to see what is happening with NT threads
 
     ThreadPoolEntry->dwThreadId = GetCurrentThreadId( );
 
 #endif
     
     dprintf( "starting update pool thread %s\n", ThreadPoolEntry->szThreadName );
 
     ThreadPoolEntry->tStartTime = time(NULL);
     ThreadPoolEntry->bRunning = TRUE;
 }
 
 // routine shut down stuff
 
 void ThreadPoolThreadEnding( THREAD_POOL *ThreadPoolEntry )
 {
     dprintf( "ending update pool thread %s\n", ThreadPoolEntry->szThreadName );
     ThreadPoolEntry->tStopTime = time(NULL);
 
     ThreadPoolEntry->bExited  = TRUE;
     ThreadPoolEntry->bRunning = FALSE;
 }
 
 // check to see if I should leave because I am over the thread limit
 
 BOOL ThreadPoolThreadShouldExit( THREAD_POOL *ThreadPoolEntry )
 {
     BOOL bExit = TRUE;
 
     if (ThreadPoolEntry->nThreadNumber < *(ThreadPoolEntry->lpnMaxThreadNumber) )
         bExit = FALSE;
 
     return bExit;
 }
 
 
 void CreateUpdateClientThreadPool( )
 {
     // This should only be called on servers, but double check.
     
     ///
     if ( GetVal(hMainKey,"Type",REG_DEFAULT_Type) == TYPE_IS_SERVER )
     {
     
     // refresh this from registry - it controls the use of subnets for rollout
 
     bUpdateClientsByNetOrSubnet = GetVal( hMainKey, "UpdateClientsByNetOrSubnet", 0 );

     // and update the pool - doesn't do much if the reg key hasn't changed
 
     CreateThreadPool( "RTV Client update", (THREAD)UpdateClientFiles, 
                       "ClientUpdateThreadPool", 
                       MIN_UPDATE_CLIENT_FILE_THREADS, 
                       DEFAULT_UPDATE_CLIENT_FILE_THREADS, 
                       MAX_UPDATE_CLIENT_FILE_THREADS, 
                       UpdateClientFileThreadPool, &nMaxUpdateClientFileThreads );
     }
     ////
              
 }
 
 
BOOL UpdateClientsByNetOrSubnet( )
{
    return bUpdateClientsByNetOrSubnet;
}

int GetMaxUpdateClientFileThreads( )
{
    return nMaxUpdateClientFileThreads;
}

**/

//============================================================================
//============================================================================

DWORD InitPscan(void)
{
/**
#ifdef WIN32
#ifdef REAL_SERVICE
    PSECURITY_DESCRIPTOR    pSD;
    SECURITY_ATTRIBUTES     sa;
	// tmm07-24-00: made Var static since we are passing in its
	// address to a new thread.  There were times when I was debugging
	// (on a fast machine) when DeInitPscan would finish before LookAlive
	// so the pointer to Var became invalid.
    static DWORD Var=0;
#endif
    GUID guid;
    BOOL df;
    BYTE arrybytMac[6];
    BYTE arrybytRegMac[6];
    BOOL bNIC; 
#endif
**/
    DWORD cc = ERROR_SUCCESS;
    DWORD index;
    char name[128];
    //EVENTBLOCK log;
    char line[IMAX_PATH+64];
    int tg;
    //HKEY hkey;
    //REGWATCH *rw;
    int bIgnore3 = FALSE;
            
    extern BOOL StorageManagerActive;
    DWORD Var = 0;
    

    TIME_STAMP("InitPscan");

/**
#ifdef WIN32
    InitException();
    SetErrorMode(SEM_FAILCRITICALERRORS);

    if ( IsWinNT() )
    {
        CheckDataDirs();
    }
#endif
**/

//ksr ???
//#ifdef REAL_SERVICE

    MyBeginThread( LookAlive, (void *)&Var," LookAlive" );
    // ksr
    //Sleep(250);
    NTxSleep(250);
//#endif

#define RETURN(x) {cc = x; goto end;}

    cc = InitCrit();
    if ( cc != ERROR_SUCCESS )
        return cc;


    // Fix to STS #342082.  Setting the GUID value in the registry as soon as
    // hMainKey is available. This  will ensure that the GUID will never be "zero" 
    // whenever the threads send pong data to the parent server (in case of a 
    // managed client).  Previously this was done at later point in this 
    // function which some times resulted in sending zero pong data.
    
/**
#ifdef WIN32
    ZeroMemory( arrybytMac, sizeof(arrybytMac) );
    ZeroMemory( arrybytRegMac, sizeof(arrybytRegMac) );
    // get a copy of the systems localMAC address, and cache it.
    bNIC = GetLocalMACAddress( arrybytMac, sizeof(arrybytMac) );
    GetData(hMainKey,"GUID",&guid,sizeof(GUID),NULL,&df);
    if ( df )
    {
        CreateGuid(&guid);
        PutData(hMainKey,"GUID",&guid,sizeof(GUID));
        PutData(hMainKey, "LocalMAC", arrybytMac, sizeof(arrybytMac) );
    }
    else
    {
        GetData(hMainKey, "LocalMAC", arrybytRegMac, sizeof(arrybytMac), NULL, &df );
        if ( df )
        {
            CreateGuid(&guid);
            PutData(hMainKey,"GUID",&guid,sizeof(GUID));
            PutData(hMainKey, "LocalMAC", arrybytMac, sizeof(arrybytMac) );
        }
        else if ( bNIC && !MacAddressCmp(arrybytMac, arrybytRegMac) )
        {
            // case where there is a GUID and LocalMAC entry, but LocalMac entry
            // does not match against what we found for the network adaptor locally
            // it's redundant, but not during run time, only in appearance
            // in the case of a system without a NIC (laptop with dock) then we
            // skip this the comparison this time
            CreateGuid(&guid);
            PutData(hMainKey,"GUID",&guid,sizeof(GUID));
            PutData(hMainKey, "LocalMAC", arrybytMac, sizeof(arrybytMac) );

        }

    }
#endif
**/

    //tg=GetVal(hMainKey,"Status",0);
    
    // MMENDON - STS defect 332940 - extending change to win32.  We no longer want the messagebox displayed.
//#if defined (NLM) //|| defined (WIN32)  //EA - 09/16

    //EA - 09\16\1999 forcing tg i.e. value of Status under the MainRegKey to be 0 so that it does not show the Debug Error
    //EA - 09\16\1999 basically to solve Defect 148147
    tg = 0; //EA - 09/16
//#endif //EA - 09/16

    dprintf("Last Status %u\n",tg);
    if ( tg != 5 && tg != 0 )
    {
        // check new key to ignore status 3 errors
        //bIgnore3=GetVal(hMainKey,"IgnoreStatus3",0);
        if ( tg != 3 || !bIgnore3 )
            if ( AskIfAbort() )
                return 1;
    }

    //PutVal(hMainKey,"Status",1);

    if ( SystemRunning )
        RETURN(P_ALREADY_RUNNING);

    dprintf("Starting PSCAN\n");

/**
#ifdef NLM


    // patch MsgSys.nlm

    cc = FixMsgSysNLM( );
    if ( cc && cc != MSGSYS_NOT_FOUND )
    {
        cc = ERROR_SUCCESS;     // ignore the error that MSGSYS.NLM isn't exactly like what I expected - that
                                // means that it is likely the newer version that has been fixed.
    }
    else if ( cc == MSGSYS_NOT_FOUND )
    {
        cc = ERROR_SUCCESS;     // ignore the error that MSGSYS.NLM isn't running.
    }

#endif

    //GetStr(hMainKey, "Home Directory",HomeDir, sizeof(HomeDir),".");
**/

    SystemRunning = 1;

    /*cc=*/

	//InitNTS();
	
	
//#ifdef WIN32
    //StartLPC();
//#endif


//  if (cc)         // if we can't initialize the network we will still start
//      RETURN(cc); // but if we want to change that we can just uncomment these two lines


//#ifndef WIN95

//  cc = InitClientMemory();
//  if (cc)
//      RETURN(cc);
//#endif
    //dprintf("Initialize Scan Engine\n");
    //cc = InitlizeScanEngine();
    //if ( cc )
    //    RETURN(cc);

/**
#ifdef WIN32
    hAsyncScanMutex = CreateMutex(NULL, FALSE, NULL);
    if ( hAsyncScanMutex == NULL )
    {
        RETURN(P_ASYNC_SCAN_MUTEX_FAIL);
    }

#ifdef REAL_SERVICE
    pSD = (PSECURITY_DESCRIPTOR) LocalAlloc(LPTR,SECURITY_DESCRIPTOR_MIN_LENGTH);

    if ( pSD == NULL )
        RETURN(P_SEC_ALLOC_FAIL);

    if ( !InitializeSecurityDescriptor(pSD, SECURITY_DESCRIPTOR_REVISION) )
    {
        LocalFree((HLOCAL)pSD);
        RETURN(P_INIT_DES_FAIL);
    }

    // add a NULL disc. ACL to the security descriptor.
    //
    if ( !SetSecurityDescriptorDacl(pSD, TRUE, (PACL) NULL, FALSE) )
    {
        LocalFree((HLOCAL)pSD);
        RETURN(P_SET_DES_FAIL);
    }

    sa.nLength = sizeof(sa);
    sa.lpSecurityDescriptor = pSD;
    sa.bInheritHandle = TRUE;       // why not...
    #define PSA &sa
#else
    #define PSA NULL
#endif

    pStatBlock = NULL;
    hFileMap = CreateFileMapping((HANDLE)0xffffffff,PSA,PAGE_READWRITE,0,sizeof(STAT_BLOCK),"PscanStatBlock");
    if ( hFileMap )
        pStatBlock = MapViewOfFile(hFileMap,FILE_MAP_WRITE,0,0,0);
    if ( !pStatBlock )
        pStatBlock=&StatBlock;
#endif
**/


//#ifdef NLM
    pStatBlock=&StatBlock;
//#endif

    memset(&StatBlock,0,sizeof(STAT_BLOCK));
    
    //MMENDON 07-19-2000 STS Defect 340445:  The time and action will be set
    //                                       when AP is started on WIN32

//#ifndef WIN32
    pStatBlock->LastVirusFoundAction = 0;
    pStatBlock->TimeStarted = vtime(0);
//#endif


    //MMENDON 07-19-2000 STS Defect 340445:  End change

    pStatBlock->Size = sizeof(STAT_BLOCK);

    dprintf("Update Drive Tables\n");

    GetSid((PSID)&MainSid);

	/**
#ifdef WIN32

    {   HKEY hkey;
        DWORD size;
        if ( RegOpenKey(hMainKey,"CurrentMaps",&hkey) == ERROR_SUCCESS )
        {
            size = sizeof(name);
            while ( RegEnumValue(hkey,0,name,&size,0,NULL,NULL,NULL) == ERROR_SUCCESS )
            {
                RegDeleteValue(hkey,name);
                size = sizeof(name);
                ThreadSwitchWithDelay();
            }
            RegCloseKey(hkey);
        }
    }

#endif
    **/

	/**
    WSprintf(line,"%s\\ALERT",HomeDir);
    GetStr(hProductControlKey, "ClientDir", ClientDir, sizeof(ClientDir),line);
    StrUpper(ClientDir);

#ifdef WIN32
    PutVal(hMainKey,"MyProcessID",GetCurrentProcessId());
#endif

    if ( RegOpenKey(hMainKey,"LocalScans",&hkey) == ERROR_SUCCESS )
    {
        index = 0;
        while ( RegEnumKey(hkey,index++,name,sizeof(name)) == ERROR_SUCCESS )
        {
            strcat(name,"\\Status");
            if ( GetVal(hkey,name,S_NEVER_RUN) != S_NEVER_RUN )
                PutVal(hkey,name,S_NEVER_RUN);
            ThreadSwitchWithDelay();
        }
        RegCloseKey(hkey);
    }
    **/

    // CvtCBA2GRC((time(NULL)/60)^MASTER_SEED);	// ???

    if ( cc == ERROR_SUCCESS )
    {
        dprintf("Starting Sub Processors\n");
        MyBeginThread((THREAD)StorageManagerStart,(void *)TRUE,"RTV Storage Start");

    /**
        CreateUpdateClientThreadPool( );        // handle pushing to clients


        StrCopy ( CurrentUserName, LS(IDS_USER_NOT_LOGGED_IN));

#ifdef WIN32

        hWatchForLogonsThreadSignal = CreateEvent(NULL, TRUE, FALSE, NULL);

        MyBeginThread(WatchForLogons,NULL,"WatchForLogons");
        MyBeginThread(RecieveVirusAlertIPC,NULL,"RTV IPC");
        MyBeginThread(MesBoxHan,NULL,"RTV MessageBox");
        MyBeginThread((THREAD)ClientScanner,NULL,"RTV Client Scanner");
#endif
        MyBeginThread((THREAD)ClientSendStart,NULL,"RTV Client Reporter");
        MyBeginThread((THREAD)SystemProcess,NULL,"RTV Server M");
	**/        
        
        /**
        rw = malloc(sizeof(REGWATCH));
        if ( rw )
        {
            rw->hkey = hProductControlKey;
            StrCopy(rw->name,"Product Control");
            rw->fun = (VOIDFP)UpdateFromReg;
            MyBeginThread((THREAD)WhenRegChange,rw,"RTV Reg");	
        }
        **/
/**
#ifdef WIN32
        StartVBinMonitor();
#else
//#ifdef NLM //EA - 08/09 for Quar Fwd
//        StartVBinMonitor(); //EA - 08/09
//#endif  //EA - 08/09        
#endif
**/

/**
#if defined(WIN32) && defined(SERVICE)

        if ( ScanMemory )
        {
            VEMEMINFO mi;
            STORAGEOBJECT rso,*so=&rso;
            SNODE node;
            DWORD cc;
            SCAN_STATUS rblock;
            PSCAN_STATUS block = &rblock;
            USEVE

            int smallwait;
            memset ( &rblock, 0, sizeof(rblock) );
            dprintf ("Scanning Memory\n");

            memset(so,0,sizeof(STORAGEOBJECT));
            memset(&node,0,sizeof(SNODE));

            so->Flags = FA_WALKSCAN | FA_SCANNING_MEMORY;
            so->block = block;

            so->Node = &node;
            for ( smallwait = 0; !StorageManagerActive && smallwait < 100; smallwait++ )
                Sleep ( 100 );
            if ( StorageManagerActive && FileStorageItem && FileStorageItem->Info )
            {
                so->Info = FileStorageItem->Info;

                cc = so->Info->Functions->CreateSNode(2048,NULL,so->Node);
                if ( cc == ERROR_SUCCESS )
                {
                    StrCopy(block->CurrentFile,so->Node->Description);
                    memset(&mi,0,sizeof(VEMEMINFO));
                    mi.wSize = sizeof(VEMEMINFO);
                    mi.appContext = (VECONTEXT)so;
                    mi.dwScanType = (block->ScanType&(~MYSCANFLAGS))&(VESLOWSCAN|VEFASTSCAN);
                    mi.cbMemoryStatus = NULL;
                    mi.dwBreakSize = 1024;

                    CALLVE;
                    cc = VEScanMemory(VEhan,&mi);
                    RETVE;

                    so->Node->Functions->ReleaseSNode(so->Node);
                }
                dprintf("mem ret = %08X\n",cc);

            }
        }

#endif
**/
            
            
        // MyBeginThread((void (*)(void *))StartNTS,NULL,"RTV TransStart");
        NTxSleep(128);
        //CheckClientDir();
        
Breakpoint( 1 );

        MyBeginThread(MainTimer,NULL,"RTV Timer");

        if ( cc )
        {
//#ifdef NLM
            _printf("LOW MEMORY, some functions are disabled\n");
//#endif
            cc = ERROR_SUCCESS;
        }

//#ifndef WIN95
//        if ( GetVal(hProductControlKey,"LoadAMS",1) )
//            MyBeginThread(StartAMS,NULL,"RTV AMS Start");
//#endif
    }

    if ( cc != ERROR_SUCCESS )
        DeInitPscan();

    //PutVal(hMainKey,"Status",2);
    end:
    
//#ifdef REAL_SERVICE
    Var = 0;
    // ksr
    //Sleep(300);
    NTxSleep(300);
//#endif

    NTxSleep(1000);

   // memset(&log,0,sizeof(log));
    if ( cc == ERROR_SUCCESS )
        WSprintf(line,LS(IDS_SYSTEM_START_STAT_GOOD));
    else
        WSprintf(line,LS(IDS_SYSTEM_START_STAT_FAIL),GetErrorText(cc),cc);
    /*
    log.Description = line;
    log.logger = LOGGER_System;
    //log.hKey[0] = 0;
    log.Category = GL_CAT_SUMMARY;
    log.Event = GL_EVENT_STARTUP;
    GlobalLog(&log);*/

    //PutVal(hProductControlKey,"ProcessLoginNow",1);
    dprintf("InitPscan : %08X\n",cc);
    //PutVal(hMainKey,"Status",3);
    //PutVal(hMainKey,szReg_Val_ServiceRunning,1);
    //PutVal(hMainKey,"ProductVersion",(MAINPRODUCTVERSION*100+SUBPRODUCTVERSION)|(BUILDNUMBER<<16));
    
    return cc;
}

/***************************************************************************/
