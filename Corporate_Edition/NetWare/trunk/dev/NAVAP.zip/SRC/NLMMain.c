//------------------------------------------------------------------------------
//
//      NLMmain.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#define IncDebugParser

#include "pscan.h"
#include "status.h"

BOOL StrNEqual(char *s1,char *s2,int len);

int MaxVolumes;          // gdf 06/13/00

int MainThread=0;
char ConsoleRunning = 0;
DWORD EventHandle;
int MainTgID;
char NewVersionString[128];

int CLibVersion=0;
int NWversion=0;
int NWsubVersion=0;

//char Nothing=0;
char HaveUI = 0;
char LocaleIDString[5];
char FileServerName[50];	// server where rtvscan is running
char VolumeName[50];	    // volume where rtvscan is located
char ProgressCharDone=177;
char ProgressCharNotDone=176;

BOOL gZero=0;

int MainScreenHan=0;

//CLIENT_ARRAY **LoginArray;

//HINSTANCE hInstLang = 0;

#define MIN_RUN_TIME 10 // number of seconds the NLM must run before we will allow it to unload

//extern char DebugLogFile[IMAX_PATH];

// ksr 
//extern char gszDebug[DEBUG_STR_LEN];
char gszDebug[DEBUG_STR_LEN]="";

// ksr extern BOOL doRegDebug;
BOOL doRegDebug = TRUE;
extern BOOL ExitingNormally;

#ifdef MemCheck
//void StartMemLog(void);
#endif // MemCheck
#ifdef SemaCheck
//void StartSemaLog(void);
#endif // SemaCheck


// ksr
extern char **TheStringTable; 


/****************************************************************************/

DWORD FillDriveList(char *list) 
{
	int num,i;
	char str[IMAX_PATH];
	char vol[64];
// gdf need mods here
	
	StrCopy(list,"NW!");

//	num = GetNumberOfVolumes();   // gdf 06/18/00
//	for (i=0;i<num;i++) {         // gdf 06/18/00
	for (i=0; i<MaxVolumes; i++)     // gdf 06/18/00
	{
		memset(vol, 0, sizeof(vol)); //gdf 06/18/00
//		GetVolumeName(i,vol); //gdf 06/18/00
		if(GetVolumeName(i, vol) == ESUCCESS)  // gdf 06/18/00
		{// gdf 06/18/00
			if(vol[0] != NULL)  // gdf 06/18/00
			{ // gdf 06/18/00
				WSprintf(str,"%s:%c;",vol,'F');
				strcat(list,str);
			}  // gdf 06/18/00
		}// gdf 06/18/00
	}		
	list[NumBytes(list)-1] = 0;
	
	return 0;
}

/*********************************************************************/

DWORD GetCurrentDirectory(DWORD size,LPSTR path) 
{
	getcwd(path,size);

	return 0;
}

/*********************************************************************/

BOOL CopyFile(LPCTSTR ExistingFile,LPCTSTR NewFile,BOOL FailIfExists) 
{
	int sHan,dHan;
	int ret=FALSE;

	sHan = open(ExistingFile,O_BINARY|O_RDONLY,0);
	if (sHan != INVALID_HANDLE_VALUE) {
		dHan = open(NewFile,O_WRONLY|O_TRUNC|O_BINARY|(FailIfExists?O_EXCL:0)|O_CREAT,S_IREAD|S_IWRITE);
		if (dHan != INVALID_HANDLE_VALUE) {
			LONG size = lseek(sHan,0,SEEK_END);
			LONG out=0;
			lseek(sHan,0,SEEK_SET);
			ret = FileServerFileCopy(sHan,dHan,0,0,size,&out);
			if (!ret)
				ret = TRUE;
			close(dHan);
			}
		close(sHan);
		}

	return (BOOL)ret;
}

/*********************************************************************/

BOOL MoveFile(LPCTSTR  lpszExisting,LPCTSTR  lpszNew) 
{
	int ret;

	if (CopyFile(lpszExisting,lpszNew,TRUE)) 
	{
		MakeWriteable (lpszExisting,0xfffffffc);
		ret = unlink(lpszExisting);
		if (!ret)
			return TRUE;
		dprintf("Unlink failed on move of %s  (%d)\n",lpszExisting,errno);
		unlink(lpszNew);
	}

	return FALSE;
}

/************************************************************************************/

BOOL GetSid(PSID pSid) 
{
	pSid->ConnectionID = 0;
	StrCopy(pSid->UserName,"NetWare Server");

	return TRUE;
}                      

/************************************************************************************/

/**
DWORD SendMessageTo(PSID sid,char *line) {

	WORD list[10] = {0};
	BYTE rList[10] = {0};

	if (sid->ConnectionID == 0xffffffff) {
		// need to find CinnectionID

		int i,max;
		char name[IMAX_PATH];
		char user[NAME_SIZE];
		char computer[NAME_SIZE];
		WORD type;
		long id;
		BYTE logTime[7];

		GetNames(sid,user,computer);
		max = GetMaximumNumberOfStations();

		for (i=0;i<max;i++) {
			ThreadSwitch();
			/* nwconn.h
			extern int GetConnectionInformation
                        (
                           WORD  connectionNumber,
                           char *objectName,
                           WORD *objectType,
                           long *objectID,
                           BYTE *loginTime
                        );
            ***
			if (GetConnectionInformation((WORD)i,name,&type,&id, (BYTE *)&logTime) == 0 && name[0])  {
				if (!StrComp(name,user)) {
					list[0] = (WORD)i;
					break;
					}
				}
			}

		if (i == max)
			return ERROR_FALSE_SID;
		}
	else
		list[0] = (WORD)sid->ConnectionID;

	while (NumBytes(line) > 55) {
		char *q,*w;
		q = w = line+55;
		while (*q != ' ') {
			q = PrevChar(line,q);
			if (!q || q == line) {
				q = w;
				break;
				}
			}
		*q = 0;
		SendBroadcastMessage(line,list,rList,1);
		delay(250); // if we don't do this the next call will fail
		line = q+1;
		}
	SendBroadcastMessage(line,list,rList,1);

	return rList[0];
}

**/
/****************************************************************************************/
/**/
#ifdef ThreadCheck

///////////////////////////////////////////
#define MAX_THREAD_TRACK 64
///////////////////////////////////////////
typedef struct 
{
	LONG taskID;
	int threadID;
	char name[24];
} th;
th ThreadTracker[MAX_THREAD_TRACK];


///////////////////////////////////////////

void ResetThreadTracking() 
{
	memset( ThreadTracker, 0, sizeof(th)*MAX_THREAD_TRACK );
}


///////////////////////////////////////////

void ThreadReport(BOOL shutdown) 
{
	int i,j=0;

	if(!TrackThreads)
		return;

	//if (shutdown && !debug)
	//	debug = DEBUGLOG|DEBUGSAFELOG;

#define msg "The following threads are being tracked:\n"
	if (shutdown) 
	{
		//LogLine(msg,TRUE);
	}
	else 
	{
		dprintf(msg);
	}
#undef msg

	for( i=0 ; i<MAX_THREAD_TRACK ; i++) 
	{
		if(ThreadTracker[i].taskID) 
		{
			if(shutdown) 
			{
				char line[128]={0};
				if(!j) 
				{
					time_t t = time(NULL);
					//LogLine( "**************************\r\nThread Report\r\n", FALSE );
					//LogLine( ctime(&t), FALSE );
					j++;
				}

				sprintf(line,"%2d 0x%08x %5d (%s)\r\n",i,ThreadTracker[i].threadID,ThreadTracker[i].taskID,ThreadTracker[i].name);
				//LogLine(line,TRUE);
			}
			else 
			{
				dprintf("%2d 0x%08x %5d (%s)\n",i,ThreadTracker[i].threadID,ThreadTracker[i].taskID,ThreadTracker[i].name);
			}
		}
	}

	if(shutdown) 
	{
		debug = 0;
		//if (j)
			//LogLine("**************************\r\n",TRUE);
	}
}

///////////////////////////////////////////

void ThreadStarting( char *name, LONG taskID) 
{
	int i;

	if(!TrackThreads || !taskID) return;

	for( i=0 ; i<MAX_THREAD_TRACK ; i++ ) {
		if( !ThreadTracker[i].taskID ) 	{
			dprintf( "%d: Thread Starting: %x(%s) %d\n", i, taskID, name);
			strncpy( ThreadTracker[i].name, name, 23 );
			ThreadTracker[i].taskID = taskID;
			ThreadTracker[i].threadID = GetThreadID();
			return;
			}
		}
	dprintf("Couldn't store thread %x(%s) in ThreadTracker array!\n", taskID, name);
}

///////////////////////////////////////////

void ThreadEnding( LONG taskID ) 
{
	int i;

	if( !TrackThreads || !taskID ) return;

	for( i=0 ; i<MAX_THREAD_TRACK ; i++)
	{
		if( ThreadTracker[i].taskID == taskID )
		{
			dprintf( "%d: Thread Ending: %x(%s) 0x%08x\n", i, taskID, ThreadTracker[i].name, ThreadTracker[i].threadID);
			memset( &ThreadTracker[i], 0, sizeof(th) );
			return;
		}
	}
	dprintf("Couldn't find thread %x in ThreadTracker array!\n", taskID );
}
///////////////////////////////////////////
#endif // ThreadCheck

/**/


/****************************************************************************************/

typedef struct 
{
	void (*fun)(void *);
	void *p;
	char name[64];
} THREADS;

/************************************************************************************************/

void _st(void *nothing) 
{
	LONG    origTaskID,     newTaskID;
	THREADS *t = (THREADS *)nothing;
	void *p = t->p;
	void (*fun)(void *) = t->fun;

	char tName[64];
	strcpy(tName,t->name);

	RenameThread(GetThreadID(),t->name);

	free(t);

	ThreadsInUse++;
	// ksr
	//dprintf ("Thread %s starting\n",tName);
	dprintf ("Thread %s starting\n",tName);
	newTaskID = AllocateBlockOfTasks(1);
	origTaskID = SetCurrentTask(newTaskID);

#ifdef ThreadCheck
	ThreadStarting(tName,newTaskID);
#endif // ThreadCheck

	fun(p);

#ifdef ThreadCheck
	ThreadEnding(newTaskID);
#endif // ThreadCheck

	SetCurrentTask(origTaskID);
	ReturnBlockOfTasks(newTaskID, 1);
	// ksr
	//dprintf ("Thread %s terminating\n",tName);
	dprintf ("Thread %s terminating\n",tName);
	ThreadsInUse--;
}


/************************************************************************************************/

DWORD rtvBeginThread(void (*fun)(void*),void *p,char *name) 
{
	int rtvtgid;
	THREADS *t;

	t=malloc(sizeof(THREADS));

	if (t) 
	{
		t->fun = fun;
		t->p = p;
		strncpy(t->name,name,sizeof(t->name));
		rtvtgid = BeginThreadGroup(_st,NULL,STACK_SIZE,(void*)t);
		if (rtvtgid != EFAILURE) 
		{
			dprintf("Thread %s created\n",name);
		}
		else 
		{
			dprintf("Thread %s was not created (create fail)\n",name);
			// I would rather lose mem that take the change of freeing it twice.
		}
		// ksr
      NavSetSignals();
		return (rtvtgid==EFAILURE) ? -1 : rtvtgid;
	}
	dprintf("Thread %s was not created (malloc fail)\n",name);
	errno = ENOMEM;
	return -1;
}


/***************************************************************************/


#if 0

DWORD StartNTSService(void) {

	HANDLE han;
	char libpath[IMAX_PATH];

	WSprintf(libpath,NW_SYSTEM_DIR"\\%s","PDS.NLM");
	han = _LoadLibrary(libpath,TRUE);

	if (han == NULL)
		return P_NO_VIRUS_ENGINE;

	return 0;
}

#endif	// 0


/**********************************************************************************************/

LONG InterlockedIncrement(LONG *val) 
{
	*val += 1;
	return *val;
}

/***********************************************************************************************/

LONG InterlockedDecrement(LONG *val) 
{
	*val -= 1;
	return *val;
}

/***********************************************************************************************/

BOOL Check8Dot3 (char *path) 
{
	int
		len=NumBytes(path);
	char
		*s=NULL,
		*r=NULL,
		*q=path;

	if (len>12) { 		// if the section we just looked at is len>12 we have a long name
//		dprintf ("%s is NOT in 8.3 format(1)\n",path);
		return FALSE;
	}

	r=StrChar (q,'.');
	if (r) {			// we have a dot
		*r='\0';		// split the string into parts
		r++;
		s=StrChar (r,'.');
		if (s) {// we have two dots in the section so we are a long name
//			dprintf ("%s is NOT in 8.3 format(2)\n",path);
			return FALSE;
		}

		if (NumBytes (q)>8 || NumBytes(r)>3) {	// if the first part len > 8 or second part len >3 we have a long name
//			dprintf ("%s is NOT in 8.3 format(3)\n",path);
			return FALSE;
		}
	}
	else { 						// there is not dot so
		if (len>8) {			// if len > 8 we have a long name
//			dprintf ("%s is NOT in 8.3 format(4)\n",path);
			return FALSE;
		}
	}

//dprintf ("%s is in 8.3 format\n",path);
// if we get here then the path is in 8.3 format
	return TRUE;
}

/***********************************************************************************************/

BOOL isNSName(char* path,char nameSpace) 
{
	int
		ns,
		ccode;
	char
		server[48],
		volume[16],
		dir[IMAX_PATH],
		buff[IMAX_PATH];
	char
		*r,
		*q,
		*end;

	ns=ccode=0;
	q=end=NULL;
	memset (buff,0,IMAX_PATH);

	if (!path) return TRUE;
	if (NumBytes (path)<1) return TRUE;
//dprintf ("isNSName(%s,%d)\n",path,nameSpace);
	ParsePath (path,server,volume,dir);
//dprintf ("ParsePath=(%s,%s,%s,%s)\n",path,server,volume,dir);
	q=dir;
	if (*q=='/' || *q=='\\')
		q++;

	// first look for non-short characters
	if (StrChar (q,' ') || StrChar (q,'[') || StrChar (q,']') || StrChar (q,',') || StrChar (q,'=') || StrChar (q,';') || StrChar (q,'+'))
		return ((nameSpace==0) ? FALSE : TRUE);		// path has long components so if nameSpace is 0 return false else return true

	for (end=&dir[NumBytes(dir)] ; q && *q && q<=end ; q=NextChar(q)) { // start at the beginning of the path and get a pointer to the end of it
		for (r=q ; q && *q && q<=end && *q!='/' && *q!='\\' ; q=NextChar(q)); // look for the next section

		if (q) *q=0;	// separate the next section
		if (Check8Dot3 (r)==FALSE)	// check to see if section is in 8.3 format
			return ((nameSpace==0) ? FALSE : TRUE);	// if not in 8.3 format return false
	}

//dprintf ("Path has only short components\n");
	// now we know that there are no long components in the path
	// since we only call to check on the shortness of a name we should return true

	return ((nameSpace==0) ? TRUE : FALSE);		// so if nameSpace is 0 return true else return false
}

/***********************************************************************************************/

#include <nwfile.h>
#include <niterror.h>
BOOL ConvertFileName(char *output,char *input,int len,char inputNS,char outputNS) 
{
/*
NWGetDirBaseFromPath (input,inputNS,&volNum,&NSdirBase,&DOSdirBase)
FEMapHandleToVolumeAndDirectory(handle,&volNum,&dirNum)
FEConvertDirectoryNumber (inputNS,volNum,dirNum,outputNS,&destDirNum)
FEMapVolumeAndDirectoryToPathForNS(volNum,destDirNum,outputNS,output,&pathCount)
FEMapVolumeAndDirectoryToPath(volNum,destDirNum,output,&pathCount)
*/
	int
		oldVolNum,
		volNum,
		oldNameSpace,
		ccode;
	char
		server[48],
		volume[16],
		path[IMAX_PATH],
		shortName[IMAX_PATH],
		longPath[IMAX_PATH];
	char
		*q,
		*r,
		*end,
		delim;
	BOOL
		ResetVolNum=FALSE,
		volFound=FALSE;

//dprintf ("ConvertFileName (\"%s\" of len (%d) from NS %d to %d)\n",input,len,inputNS,outputNS);

	if (inputNS==outputNS) {		// don't convert if we don't need to
		dprintf ("files are already in the same namespace\n");
		StrNCopy(output,input,len);
		return TRUE;
	}

	if (ParsePath (input,server,volume,path)==ERROR_SUCCESS) {
		if (GetVolumeNumber (volume,&volNum)==ERROR_SUCCESS) {
			oldVolNum=FESetCWVnum (volNum);
			ResetVolNum=TRUE;
		}
		volFound=TRUE;
//		dprintf ("Path Parsed: (%s)(%s)(%s)\n",server,volume,path);
		Sprintf (output,"%s:",volume);
		StrCopy (longPath,output);
	}
	else {
		dprintf ("Problem parsing path\n");
		StrCopy (path,input);
	}

	oldNameSpace = SetCurrentNameSpace(inputNS);
//dprintf ("Namespace %d to %d\n",oldNameSpace,inputNS);

	q=path;
	if (*q=='\\' || *q=='/')
		q++;

	for (end=&path[NumBytes(path)] ;q && *q && q<=end ; ) { // start at the beginning of the path and get a pointer to the end of it

		for (r=q ; q && *q && q<=end &&*q != ':' && *q != '/' && *q != '\\' ; q=NextChar(q)); // isolate the next section of the path

		delim=*q;									// find out what delimeter is there
		*q=0;										// null terminate the string
		q=NextChar(q);								// move pointer to be ready for the next section

		if (!volFound && delim==':') {				// we have the volume
			Sprintf (output,"%s:%c",r,0);			// put the volume, the colon and the slash in output
			if (q && (*q=='/' || *q=='\\')) 		// there may be a slash after the volume
				q=NextChar(q);						// move to the character after the slash

			StrCopy (longPath,output);				// start building the longpath
			volFound=TRUE;
		}
		else  {
			Sprintf(longPath,"%s\\%s%c",longPath,r,0);										// add the next section to the long path
			memset (shortName,0,IMAX_PATH);
//			dprintf ("GetNameSpaceEntryName(%s,%d,%d)\n",longPath,outputNS,len);
			if ((ccode=NWGetNameSpaceEntryName(longPath,outputNS,IMAX_PATH,shortName))==ERROR_SUCCESS) {	// convert the path to the new namespace
//				dprintf ("Successful: in->[%s] out->(%s)\n",longPath,shortName);
				Sprintf (output,"%s\\%s%c",output,shortName,0);								// add the converted filename to output
			}
			else {
				StrNCopy(output,input,len);
				SetCurrentNameSpace(oldNameSpace);
				dprintf ("problem (%d)-GetNameSpaceEntryName(%s,%d,%d)\n",ccode,longPath,outputNS,len);
				if (ResetVolNum)  FESetCWVnum (oldVolNum);
				return FALSE;
			}
		}
	}
//	dprintf ("Path converted: %s\n",output);
	SetCurrentNameSpace(oldNameSpace);
//	dprintf ("returning true\n");
	if (ResetVolNum)  FESetCWVnum (oldVolNum);
	return TRUE;
}
/**************************************************************************************/
// LONG GetOriginalName (
//		char *srcName, 		// (in) file name to get the original name for
//		char *OriginalName, // (out) original file name
//		LONG srcNS,			// (in) name space of the source file name
//		LONG *OriginalNS	// (out) originating name space
// );
// Gets the original name of the file in the originating name space
// OriginalName and OriginalNS can be NULL
// this function returns the originating name space
// if the function fails returns -1
LONG GetOriginalName (char *srcName,char *OriginalName,LONG srcNS, LONG *OriginalNS) {

	LONG
		ons=-1,
		d;
	int
		oldVolNum,
		volNum,
		v;
	HANDLE
		h=-1;
	BYTE
		oldNS;
	char
		server[48],
		volume[16],
		path[IMAX_PATH];
	BOOL
		ResetNS=FALSE,
		ResetVolNum=FALSE;

	if (!srcName) return -1;

	if (ParsePath (srcName,server,volume,path)==ERROR_SUCCESS) {
		if (GetVolumeNumber (volume,&volNum)==ERROR_SUCCESS) {
			if (FEGetCWVnum() != volNum) {
				oldVolNum=FESetCWVnum (volNum);
				ResetVolNum=TRUE;
			}
		}
	}
	oldNS=SetCurrentNameSpace(srcNS);
	if (oldNS!=255 && oldNS!=srcNS) // only reset if successfull and srcNS doesn't equal oldNS
		ResetNS=TRUE;

	dprintf ("GetOriginalName (%s,%d)\n",srcName,srcNS);
	h=open (srcName,O_RDONLY);

	if (OriginalNS)
		*OriginalNS=-1;

	if (h!=-1) {
//		dprintf ("\thandle (%d)\n",h);
		if (FEMapHandleToVolumeAndDirectory (h,&v,&d)==ERROR_SUCCESS) {
//			dprintf ("\tv:(%d)\n\td:(0x%x)\n",v,d);
			ons=FEGetOriginatingNameSpace (v,d);
			if (ons!=-1) {
//				dprintf ("\t**OriginalNS:(%d)**\n",ons);
				if (!OriginalName) { // if OriginalName is NULL we're done
					dprintf ("OriginalName is NULL so we're done\n");
				}
				else if (srcNS==ons) {
					StrCopy (OriginalName,srcName); // it is already in the originating namespace so just copy over
					dprintf ("\tAlready Original Filename: %s\n",OriginalName);
				}
				else if (ConvertFileName(OriginalName,srcName,IMAX_PATH,srcNS,ons)) {
					dprintf ("\tOriginal Filename: %s\n",OriginalName);
				}
				else {dprintf ("\tERROR Converting file name (%d)(%d)\n",errno,NetWareErrno);}
			}
			else {dprintf ("\tERROR Getting originating name space (%d)(%d)\n",errno,NetWareErrno);}
		}
		else {dprintf ("\tERROR mapping handle to directory (%d)(%d)\n",errno,NetWareErrno);}
		close (h);
	}
	else {dprintf ("\tERROR getting file handle (%d)(%d)\n",errno,NetWareErrno);}

	if (ons==-1 && OriginalName)
		OriginalName[0]='\0';

	if (OriginalNS)
		*OriginalNS=ons;

	if (ResetNS) SetCurrentNameSpace (oldNS);
	if (ResetVolNum) FESetCWVnum (oldVolNum);
	return ons;
}
/***********************************************************************************************/
DWORD SetEA(char *name,char *key,BYTE *data,DWORD len) {

	DWORD cc=ERROR_OPEN_FAIL;
	int eaHandle;
	LONG    accessFlags = 0x00000000;
	char buf[1024];
	DWORD size = (((len/128)*128)+128);

	if (size > sizeof(buf))
		return ERROR_BAD_PARAM;

	EnterCritSec();

	eaHandle = OpenEA(name,0);
	if (eaHandle != -1) {
		memset(buf,0,size);
		memcpy(buf,data,len);
		/* nwextatt.h
		extern int WriteEA
        (
           int         handle,
           const char *keyBuffer,
           const char *dataBuffer,
           LONG        dataBufferSize,
           LONG        accessFlags
        );
        */
		cc = WriteEA(eaHandle,key, (const char *)data,size,accessFlags);
		if (cc == INVALID_HANDLE_VALUE) {
			dprintf("Write EA failed on file %s\n",name);
		}
		else if (cc == size)
			cc = ERROR_SUCCESS;
		else
			cc = ERROR_BAD_EA;

		CloseEA(eaHandle);
		}

	ExitCritSec();

	return cc;
}
/*******************************************************************************************************/
DWORD GetEA(char *name,char *key,BYTE *data,DWORD len) {


	DWORD cc=ERROR_OPEN_FAIL;
	int eaHandle;
	LONG    accessFlags = 0x00000000;
	char buf[1024];
	DWORD size = (((len/128)*128)+128);

	if (size > sizeof(buf))
		return ERROR_BAD_PARAM;

	EnterCritSec();

	eaHandle = OpenEA(name,0);
	if (eaHandle != -1) {

		cc = ReadEA(eaHandle,key,buf,size,&accessFlags);
		if (cc == INVALID_HANDLE_VALUE) {
			dprintf("Read EA failed on file %s\n",name);
		}
		else if (cc == size) {
			memcpy(data,buf,len);
			cc = ERROR_SUCCESS;
			}
		else
			cc = ERROR_BAD_EA;

		CloseEA(eaHandle);
		}

	ExitCritSec();

	return cc;
}
/*****************************************************************************************
DWORD ConvertToLongName(char *output,char *input) {

	return NWGetNameSpaceEntryName(input,4,SYSFILELEN,output);
}
*******************************************************************************************/
#define _A_FILE_MIGRATED   0x00400000
#define _A_FILE_COMPRESSED 0x04000000
BOOL isFileCompressed(int attr) {

	return (attr&_A_FILE_MIGRATED) || (attr&_A_FILE_COMPRESSED);

}
/****************************************************************************************/
BOOL AskIfAbort(void) {

	int i;

	printf("\n\nDebug Error:\nNorton AntiVirus did not load properly during previous startup.\nDo you want to continue loading Virus Protect?\n\nPress 'C' to continue, 'S' to stop.\n\nVirus Protect will load in :   ");
	for(i=0;i<30;i++) {
		printf("\b\b%2u",30-i);
		delay(1000);
		if (kbhit()) {
			char c = toupper(getch());
			if (c == 'C') {
				printf("\n\nVirus Protect will now load.\n");
				return FALSE;
				}
			if (c == 'S') {
				printf("\n\nStopping ... \n");
				return TRUE;
				}
			}
		}

	return FALSE;
}
/**************************************************************************************/
char *MakeNewThreadName(char *add,char *current,char *out) {


	if (debug&DEBUGPRINT) {
		char *q;
		q = StrChar(current,' ');
		if (q == NULL)
			q = current;
		sprintf(out,"VE:%s",q);
		return out;
		}
	else
		return add;
}

/*********************************************************************************************/
/*
int GetCPUUtilization(void) {

	extern long NumberOfPollingLoops;
	extern long MaximumNumberOfPollingLoops;
	long u,m;

	m = max(MaximumNumberOfPollingLoops,1);
	u = NumberOfPollingLoops * 100 + (m >> 1);
	u /= m;
	return(max(min(100,100 - (int)u),0));
}
*/
/*****************************************************************************/
void UpdateServerFiles () {

	DWORD UpdateStatus=0;
	/**
	HKEY hkey;
	
	if (RegOpenKey(hMainKey,UPGRADE_KEY,&hkey) == ERROR_SUCCESS) {
		UpdateStatus=GetVal(hkey,FileServerName,0);
		if (UpdateStatus==STS_NWCOPY_NORMAL)
			CopyUpdatedFiles(FALSE);
		if (UpdateStatus==STS_NWCOPY_FORCE)
			CopyUpdatedFiles(TRUE);
		PutVal (hkey,FileServerName,STS_NWCOPY_NOCOPY);
		RegCloseKey(hkey);
	}
	**/
		//????
		if (UpdateStatus==STS_NWCOPY_NORMAL)
			CopyUpdatedFiles(FALSE);
		if (UpdateStatus==STS_NWCOPY_FORCE)
			CopyUpdatedFiles(TRUE);

}
/*****************************************************************************/


#if 0

HKEY NlmPChkey = NULL;
void RegDebug (void/*BOOL set*/) {

	if (doRegDebug) {
		if (NlmPChkey == NULL)
			RegOpenKey(HKEY_LOCAL_MACHINE,REGHEADER"\\ProductControl",&NlmPChkey);

		GetStr(NlmPChkey,"Debug",gszDebug,sizeof(gszDebug),"");
		debug = ParseDebugFlag(gszDebug);
#ifdef MemCheck
		if (TrackMallocs)
			debug |= DEBUGPRINTALLOC;
		else
			debug &= ~DEBUGPRINTALLOC;
#endif // MemCheck
		}
}

#endif



/*****************************************************************************/
DWORD CopyUpdatedFiles(BOOL force) {

	FILE
		*inf=NULL;
	char
		InfPath[MAX_PATH],
		line[1024];
	BOOL
		CopyingFiles=FALSE;
	DWORD
		dwRet=0;

dprintf ("Copying Updated Files %s\n",force?"FORCED":"NORMAL");

	Sprintf (InfPath,"%s\\Update.inf",ProgramDir);

	inf = fopen (InfPath,"rt");
	if (!inf) return ERROR_GENERAL;

	while (fgets (line, 1024, inf)) {

		if (line[0]=='[') CopyingFiles=FALSE;
		if (!strnicmp (line,"[UpdateNetwareFiles]",20)) {
			CopyingFiles=TRUE;
			continue;
		}
		if (CopyingFiles)
			dwRet+=CopyNewFile(line,force);
		if (feof (inf)) break;
		memset (line,0,1024);
	}
	fclose (inf);

	return dwRet;
}
/*******************************************************************************************/
DWORD SetString(LONG wID,char *NewString) {

	if (TheStringTable == NULL)  	
		return ERROR_GENERAL;

	if (wID < STR_APP_NAME || wID >= IDS_LAST_MESSAGE)
		wID = 998;
 
	TheStringTable[wID - 998] = NewString;
	return ERROR_SUCCESS;
}
/****************************************************************************************/



#if 0

DWORD NullPatFun(void) {
	return VENOTSUPPORTED;
}
/************************************************************************************/

DWORD UnLoadPattFunctions(void) {

	HANDLE han;
	char libname[IMAX_PATH];
	char libpath[IMAX_PATH];
	char line[IMAX_PATH],str[4];

	//GetStr(hMainKey,"VirusEngine",libname,sizeof(libname),"");

	if (libname[0] == 0)
		return P_NO_VIRUS_ENGINE;

	WSprintf(libpath,"%s\\%s",HomeDir,libname);
	han = _LoadLibrary(libpath,FALSE);

	if (han == NULL)
		return P_NO_VIRUS_ENGINE;


	memcpy(str,libname,3);
	str[3] = 0;
	strlwr(str);	

	Sprintf(line,"%s_%s",str,"VEInit");UnimportSymbol(GetNLMHandle(),line); VEInit = (tVEInit )NullPatFun;
	Sprintf(line,"%s_%s",str,"VEDeInit");UnimportSymbol(GetNLMHandle(),line); VEDeInit = (tVEDeInit)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEScanFile");UnimportSymbol(GetNLMHandle(),line); VEScanFile = (tVEScanFile)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEGetVirusBehaviorHeader");UnimportSymbol(GetNLMHandle(),line); VEGetVirusBehaviorHeader = (tVEGetVirusBehaviorHeader)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEScanVirusBehaviorHeader");UnimportSymbol(GetNLMHandle(),line); VEScanVirusBehaviorHeader = (tVEScanVirusBehaviorHeader)NullPatFun;
	Sprintf(line,"%s_%s",str,"VECleanFile");UnimportSymbol(GetNLMHandle(),line); VECleanFile = (tVECleanFile)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEGetInfo");UnimportSymbol(GetNLMHandle(),line); VEGetInfo = (tVEGetInfo)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEGetCriticalDiskData");UnimportSymbol(GetNLMHandle(),line); VEGetCriticalDiskData = (tVEGetCriticalDiskData)NullPatFun;
	Sprintf(line,"%s_%s",str,"VESetCriticalDiskData");UnimportSymbol(GetNLMHandle(),line); VESetCriticalDiskData = (tVESetCriticalDiskData)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEScanCriticalDiskData");UnimportSymbol(GetNLMHandle(),line); VEScanCriticalDiskData = (tVEScanCriticalDiskData)NullPatFun;
	Sprintf(line,"%s_%s",str,"VECleanCriticalDiskData");UnimportSymbol(GetNLMHandle(),line); VECleanCriticalDiskData = (tVECleanCriticalDiskData)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEScanMemory");UnimportSymbol(GetNLMHandle(),line); VEScanMemory = (tVEScanMemory)NullPatFun;
	Sprintf(line,"%s_%s",str,"VELoadPatternFile");UnimportSymbol(GetNLMHandle(),line); VELoadPatternFile = (tVELoadPatternFile)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEFreePatternFiles");UnimportSymbol(GetNLMHandle(),line); VEFreePatternFiles = (tVEFreePatternFiles)NullPatFun;
	Sprintf(line,"%s_%s",str,"VELoadSignature");UnimportSymbol(GetNLMHandle(),line); VELoadSignature = (tVELoadSignature)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEUnloadSignature");UnimportSymbol(GetNLMHandle(),line); VEUnloadSignature = (tVEUnloadSignature)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEEnableSignature");UnimportSymbol(GetNLMHandle(),line); VEEnableSignature = (tVEEnableSignature)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEEnumSignatures");UnimportSymbol(GetNLMHandle(),line); VEEnumSignatures = (tVEEnumSignatures)NullPatFun;
	Sprintf(line,"%s_%s",str,"VEGetVirusInfo");UnimportSymbol(GetNLMHandle(),line); VEGetVirusInfo = (tVEGetVirusInfo)NullPatFun;

	_FreeLibrary(libpath);

	return 0;
}
/****************************************************************************************/
DWORD LoadPattFunctions(void) {

	HANDLE han;
	char libname[IMAX_PATH];
	char libpath[IMAX_PATH];
	char line[IMAX_PATH],str[4];

	GetStr(hMainKey,"VirusEngine",libname,sizeof(libname),"");

	if (libname[0] == 0) {
		dprintf ("libname[0]==0\n");
		return P_NO_VIRUS_ENGINE;
	}

	WSprintf(libpath,"%s\\%s",HomeDir,libname);
	han = _LoadLibrary(libpath,TRUE);

	if (han == NULL) {
		dprintf ("han==NULL\n");
		return P_NO_VIRUS_ENGINE;
	}

	memcpy(str,libname,3);
	str[3] = 0;
	strlwr(str);

	Sprintf(line,"%s_%s",str,"VEInit");if ((VEInit = (tVEInit)ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEDeInit");if ((VEDeInit  = (tVEDeInit )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEScanFile");if ((VEScanFile  = (tVEScanFile )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEGetVirusBehaviorHeader");if ((VEGetVirusBehaviorHeader  = (tVEGetVirusBehaviorHeader )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEScanVirusBehaviorHeader");if ((VEScanVirusBehaviorHeader  = (tVEScanVirusBehaviorHeader )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VECleanFile");if ((VECleanFile  = (tVECleanFile )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEGetInfo");if ((VEGetInfo  = (tVEGetInfo )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEGetCriticalDiskData");if ((VEGetCriticalDiskData  = (tVEGetCriticalDiskData )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VESetCriticalDiskData");if ((VESetCriticalDiskData  = (tVESetCriticalDiskData )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEScanCriticalDiskData");if ((VEScanCriticalDiskData  = (tVEScanCriticalDiskData )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VECleanCriticalDiskData");if ((VECleanCriticalDiskData  = (tVECleanCriticalDiskData )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEScanMemory");if ((VEScanMemory  = (tVEScanMemory )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VELoadPatternFile");if ((VELoadPatternFile  = (tVELoadPatternFile )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEFreePatternFiles");if ((VEFreePatternFiles  = (tVEFreePatternFiles )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VELoadSignature");if ((VELoadSignature  = (tVELoadSignature )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEUnloadSignature");if ((VEUnloadSignature  = (tVEUnloadSignature )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEEnableSignature");if ((VEEnableSignature  = (tVEEnableSignature )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEEnumSignatures");if ((VEEnumSignatures  = (tVEEnumSignatures )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;
	Sprintf(line,"%s_%s",str,"VEGetVirusInfo");if ((VEGetVirusInfo  = (tVEGetVirusInfo )ImportSymbol(GetNLMHandle(),line)) == NULL) return P_INVALID_VIRUS_ENGINE;

	return 0;
}


#endif // 0



/************************************************************************************************/
/*
DWORD GetLoginInfo(void) {

	int i,max,fre;
	char name[IMAX_PATH];
	WORD type;
	long id;
	char str[32];
	BYTE logTime[7];
	int j;
	CBA_NETADDR rawAddress;
	CBA_IPX ipx;

	if (LoginArray == NULL)
		return 0;

	max = GetMaximumNumberOfStations();

	for (i=0;i<MaxClients;i++)
		if (LoginArray[i])
			LoginArray[i]->Flags = CF_TMP;

	for (i=0;i<max;i++) {
		ThreadSwitch();
		if (GetConnectionInformation((WORD)i,name,&type,&id,&logTime) == 0 && name[0])  {
			WSprintf(str,"[%u]",i);
			if (NumBytes(name) > sizeof(name)-2-NumBytes(str)) {
				dprintf("Name too long %s\n");
				continue;
				}
			strcat(name,str);
			for (j=0,fre=-1;j<MaxClients;j++) {
				if (fre==-1&&LoginArray[j]==NULL) {
					fre = j;
					continue;
					}
				if (LoginArray[j] && LoginArray[j]->Flags == CF_TMP && !stricmp(LoginArray[j]->UserName,name)) {
					LoginArray[j]->Flags = CF_LOGIN;
					fre = -1;
					break;
					}
				}

			if (fre != -1) {
				dprintf("adding %s to login list in slot %d\n",name,fre);
				LoginArray[fre] = malloc(sizeof(CLIENT_ARRAY));
				if(LoginArray[fre]) {
					memset(LoginArray[fre],0,sizeof(CLIENT_ARRAY));
					LoginArray[fre]->Flags = CF_LOGIN;
					strncpy(LoginArray[fre]->UserName,name,sizeof(LoginArray[fre]->UserName));
					if (GetInternetAddress(i,(char *)(&ipx.ipxNet),(char *)(&ipx.ipxNode)) == 0) {
						memset(&rawAddress,0,sizeof(CBA_NETADDR));
						rawAddress.netAddr.ipx = ipx;
						NTSBuildAddr(&rawAddress,&LoginArray[fre]->Address,0,CBA_PROTOCOL_IPX);
						}
					}
				}
			}
		}

	for (i=0;i<MaxClients;i++) {
		ThreadSwitch();
		if (LoginArray[i]) {
			if (LoginArray[i]->Flags == CF_TMP) {
				dprintf("removing %s from login list\n",LoginArray[i]->UserName);
				free(LoginArray[i]);
				LoginArray[i] = NULL;
				}
			}
		}

	return 0;
}
*/
/***************************************************************************************************/
/*
void shutdowner(void *nothing) {

//	DWORD dwType;
//	DWORD cbData; //,cc;
//	HKEY hkey;
//	DWORD val;

	REF(nothing);

	NTxSleep(2000);
	RenameThread(GetThreadID(),"RTV Shutdown");
/*
	if (RegOpenKey(HKEY_LOCAL_MACHINE, REGHEADER, &hkey) == ERROR_SUCCESS) {
		char path[IMAX_PATH];
		FILE *file;
		cbData = IMAX_PATH;
		RegQueryValueEx(hkey, "Home Directory", NULL, &dwType,(LPVOID)path, &cbData);
		strcat(path,"\\rss.cmd");
		file = fopen(path,"wt");
		if (file) {
			fputs("PAUSE\n",file);
			fclose(file);
			}
		cbData = IMAX_PATH;
		RegQueryValueEx(hkey, "Home Directory", NULL, &dwType,(LPVOID)path, &cbData);
		strcat(path,"\\rss.nlm");
		RegCloseKey(hkey);
		_LoadLibrary(path,TRUE);
		}
* /
	unload();
	if (MainThread) {
		ResumeThread(MainThread);
		}

}
*/

/************************************************************************************/
/*
DWORD BeginShutdown(void) 
{
	return BeginThreadGroup(shutdowner,NULL,STACK_SIZE,NULL)==0xffffffff?ERROR_BAD_THREAD_START:ERROR_SUCCESS;
}
*/

/************************************************************************************/
/*
void DoRemove(void) 
{
	char path[IMAX_PATH];

	WSprintf(path,"%s\\VPSTART.NLM /REMOVE",HomeDir);

	RenameThread(GetThreadID(),"RTV Remover");

	delay(3000);

	unload();

	LoadLibrary(path);

	if (MainThread)
		ResumeThread(MainThread);
}
*/

/*********************************************************************/
/*
DWORD BeginRemove(void) {

	return BeginThreadGroup((THREAD)DoRemove,NULL,STACK_SIZE,NULL)==0xffffffff?ERROR_BAD_THREAD_START:ERROR_SUCCESS;
}
*/
/*********************************************************************/

DWORD RTShutdown(HANDLE *hDevice) 
{

	if (hDevice)
		*hDevice = 0;

	DriverUnload();
	return 0;
}


/************************************************************************************/

DWORD RTStartup(HANDLE *hDevice) 
{
	if (hDevice)
		*hDevice = 1;
	return DriverStart();
}


/**********************************************************************************/

void CloseNLMStuff(void) 
{
	DWORD ret;

	if( !NLMRunning ) 
		return;
		
	NLMRunning=0;

	if (ConsoleRunning) 
	{
		// ksr CloseConsoleScreen();
		;
	}
	ConsoleRunning = 0;

#ifdef EnableScreenSaver
	ScreenSaveRunning=0;
#endif

	ThreadSwitchWithDelay();

	if (debug&DEBUGPRINT)
		delay(1000);

	if (ThreadCount) 
	{
		int i;
		
		delay( 500 );
		for (i=0; i<(20*60) && ThreadCount; i++ )
			delay( 55 );
	}

	dprintf("Thread Count: %d\n",ThreadCount);
	if (TrackThreads) 
	{
		_printf("We have %d unreleased Threads!",ThreadCount);
		Breakpoint(ThreadCount);
	}
#ifdef ThreadCheck
	ThreadReport(FALSE);
#endif // ThreadCheck

	if (EventHandle) 
	{
		ret=UnregisterForEvent(EventHandle);
		if (ret) 
		{
			dprintf ("UnregisterForEvent returned error: (0x%x)(%d)\n",ret,ret);
		}
		else
			EventHandle=0;
	}

//	dprintf ("Done Closing NLM Stuff\n");

/**
	if (NlmPChkey) 
	{
		RegCloseKey(NlmPChkey);
		NlmPChkey = NULL;
		doRegDebug = FALSE;
	}
**/
	debug = 0;
}


/**********************************************************************************/

int UnloadCheck(void)
{
	int tmpTGID;
	DWORD OldScreenID,NewScreenID;

	tmpTGID = SetThreadGroupID(MainTgID);
	_printf(LS(IDS_CANNOT_UNLOAD));
	OldScreenID = GetCurrentScreen();

	if(1||OldScreenID) 
	{
		/* if OldScreenID == 0 and we call CreateScreen we will abend */
		NewScreenID = CreateScreen("System Console",0);

		if(OldScreenID != NewScreenID)
			(void)SetCurrentScreen(NewScreenID);
		(void)ungetch('n');
		if(OldScreenID != NewScreenID)
			(void)SetCurrentScreen(OldScreenID);
	}

	(void)SetThreadGroupID(tmpTGID);
	return(1);
}


/**********************************************************************************/
/*
void unload()
{
//	StopRegistryEditor();
	DeInitPscan();
	CloseNLMStuff();
}
*/

/************************************************************************************/



#if 0 

void CheckLDSM(void) {

	#define LD_AUTO NW_SYSTEM_DIR"\\LD_AUTO."
	#define LineLen 200

	HANDLE nts;
	char line[LineLen], *cp;
	FILE *in, *out;
	char disabeled = 0, modified = 0;

//	nts = _LoadLibrary("NTS.NLM",FALSE);
	if (nts) {

		memset(line, 0, LineLen);
		strncpy(line, (char *)nts + 0x6D, *((char *)nts + 0x6C)-1);
		if (strstr(line, "LANDesk")) {
		
			_FreeLibrary(NWversion == 3 ? "NW3AGNT.NLM":"NW4AGNT.NLM");
			_FreeLibrary("SMCTRL.NLM");
//			_FreeLibrary("NTS.NLM");
			_FreeLibrary("POLLER.NLM");

		//	edit LD_AUTO.NCF
			in = fopen(LD_AUTO "NCF", "rt");
			if (!in)
				goto Return;

			out = fopen(LD_AUTO "TMP", "wt");
			if (!out) {
				fclose(in);
				goto Return;
			}

			while (fgets(line, LineLen, in)) {

				cp = line;
				while (*cp && isspace(*cp))
					cp ++ ;

				if (!strnicmp(cp, "REM ", 4))
					fputs(line, out);
					
				else if (strstr(line, "load ntsp")) {
					fclose(in);
					fclose(out);
					unlink(LD_AUTO "TMP");
					goto Return;
				}
				
				else if (
					strstr(line, "load nts") ||
					strstr(line, "load smctrl") ||
					strstr(line, "load nw3agnt") ||
					strstr(line, "load nw4agnt") ||
					strstr(line, "load poller")) {
						fprintf(out, "REM %s", line);
						modified=1;
					}

				else
					fputs(line, out);
			}

			fclose(in);
			fclose(out);
			unlink(LD_AUTO "BAK");

			if (modified) {
				if (!MoveFile(LD_AUTO "NCF", LD_AUTO "BAK") ||
					!MoveFile(LD_AUTO "TMP", LD_AUTO "NCF")) {
						if (!access(LD_AUTO "BAK", 0))
							MoveFile(LD_AUTO "BAK", LD_AUTO "NCF");

						unlink(LD_AUTO "NEW");
				}
				else
					disabeled=1;
			}
			else
				unlink(LD_AUTO "TMP");

Return:		_printf(LS(disabeled?IDS_LDSM_DISABLED:IDS_LDSM_UNLOADED));
			_printf(LS(IDS_LDSM_UPDATE));
		}
	}
}

#endif  // 0




/************************************************************************************/
/*
void ServerDown(LONG parameter/*, secondParam* / ) 
{
	//secondParam = secondParam;

	REF(parameter);

	//PutVal(hMainKey,"Status",0);
}
*/

/*************************************************************************************/

void KeepAlive(void) 
{
// Netware has a bug, SUPPRIZE!!! this keeps a thread in our thread group list, thus preventing NW from
// calling exit because of a ExitThread.

	RenameThread(GetThreadID(),"RTV Keeper");
	SuspendThread(GetThreadID());
	
	
Breakpoint( 1 );

   while( SystemRunning )
   {
      ThreadSwitch();
   }


}



#if 0

/*************************************************************************************/
DWORD CheckInstall(void) {

	DWORD cc;// = RegOpenKey(HKEY_LOCAL_MACHINE,REGHEADER,&hMainKey);
	char HomeDirectory[IMAX_PATH];

	if (cc == ERROR_SUCCESS) 
	{
		//GetStr(hMainKey,"Home Directory",HomeDirectory,sizeof(HomeDirectory),"");

		if (HomeDirectory[0] == 0)
			cc = 1;
	}

	return cc;
}
/*************************************************************************************/

#endif  // 0



#define CFNL {	if (CheckForNoLoad(0)) {ExitingNormally=FALSE;goto done;}}

///////////////////////////////////////////////////////////////////////////
// main():
//
//	This function is the starting code for RTVScan.NLM.
//	It does the following things:
//		1)  Verify that we are running on a version of Netware that we support.
//		2)  Set the current working directory to where RTVScan.NLM is located.
//		3)  Start up a suspended thread to keep this process alive.
//		4)  Initialize PSCAN
//		5)  Maintain the NAV netware console UI while RTVScan.NLM is running.
//		6)  DeInitialize PSCAN, if it hasn't been.
//
// void main(
//      int argc,
//      char *argv[] )
//
// Parameters: 
//
// Returns: 
//
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////

void main(int argc,char *argv[]) 
{
	DWORD _debug, cc=0;
	// ksr
	//DWORD debug = 0;
	
	int i=0;
	char brk=0,EnglishOnly=0;
	FILE_SERV_INFO fsinf;
	char *q=NULL,*p=NULL;//,LogStartStop[256];
	time_t t,starttime,endtime;
	int BREAK_FLAG = 1;



//Breakpoint( BREAK_FLAG );
   // ksr  
   SetCtrlCharCheckMode( FALSE );
   SetAutoScreenDestructionMode( FALSE );



//	memset (LogStartStop,0,256);
	MainTgID = GetThreadGroupID();

	//This tells the RegDebug() function to pickup debug flags in the registry.
	doRegDebug = TRUE;

#ifdef ThreadCheck
	ResetThreadTracking();
#endif // ThreadCheck
	
	RenameThread(GetThreadID(),"RTV Main");
	//Get version information about this netware server we are running on.
	GetServerInformation (sizeof(fsinf),&fsinf);
	NWversion=fsinf.netwareVersion;
	NWsubVersion = fsinf.netwareSubVersion;
	//Get the maximum number of volumes supported by this server.
	MaxVolumes   = fsinf.maxVolumesSupported;    // gdf 06/14/00;

	//Record the version information of this netware server
	CLibVersion=(fsinf.CLibMajorVersion*100 + fsinf.CLibMinorVersion)*100;
	if (fsinf.CLibRevision > 0x60)
		CLibVersion += fsinf.CLibRevision - 0x60;

	//The following lines (approximately 20 lines) of code will extract
	//the program directory of RTVScan.NLM from argv[0]
	//Example:  argv[0] = "SYS:\\SYSTEM\\NAV\\RTVSCAN.NLM"
	//then ProgramDir = "SYS:\\SYSTEM\\NAV"

	//Get a pointer to the last '\\' character
	q = StrRChar(argv[0],'\\');
	//Get a pointer to the last '/' character
	p = StrRChar(argv[0],'/');

	//Find the pointer that is closest to the end of the string and set q to it.
	q = (q>p) ? q : p;

	if (q) 
	{
		//Zero the last '\\' character in argv[0]
		*q = 0;

		//Record ProgramDir from argv[0]
		StrCopy (ProgramDir,argv[0]);

		//Extract the volumn name from argv[0]
		q=StrChar (argv[0],':');
		if (q) 
		{
			//NULL the ':' in argv[0]
			*q=0;
			//copy the just the volume name
			StrCopy (VolumeName,argv[0]);
			}
		else
			//Assume SYS as volume name, if no ':' in PragramDir
			StrCopy (VolumeName,"SYS");
		}
	else 
	{
		//If a '\\' or '/' is not found in argv[0]
		//then 
		//Default VolumeName is "SYS"
		StrCopy (VolumeName,"SYS");
		//Default ProgramDir is "SYS:\\SYSTEM" 
		StrCopy (ProgramDir,NW_SYSTEM_DIR);
		}

	//Delete VPDebug.log, so we start with a new one each time
	//sprintf (DebugLogFile,"%s\\VPDebug.log", ProgramDir);
	//unlink (DebugLogFile);
/*
#ifdef MemCheck
	StartMemLog();
#endif // MemCheck
#ifdef SemaCheck
	StartSemaLog();
#endif // SemaCheck
*/
	dprintf("CLib Version = %d\n", CLibVersion);
	//Copying server name: Assume server name is 50 chars or less
	strncpy (FileServerName,fsinf.serverName,50);

	//Locate ':' in ProgramDir string
	//Why didn't we do this check earlier?
	//ProgramDir = SYS:\\NAV
	p = StrChar (ProgramDir, ':');
	if (p) 
	{
		//add '\\' after ':' is there isn't one
		if (*(p+1) != '\\') {
			memmove(p+2, p+1, strlen(p));
			*(p+1) = '\\';
		}
	}
	//exit if no ':' in ProgramDir
	else 
	{
		ExitingNormally=FALSE;
		goto done;
	}

	// Change the current working directory to ProgramDir
	chdir( ProgramDir );

	//Record the current console screen.  Later we will restore it.
	SetAutoScreenDestructionMode(DONT_CHECK_CTRL_CHARS|AUTO_DESTROY_SCREEN);
	MainScreenHan=GetCurrentScreen();
	
	// ksr - replaced unload with NavUnload()
	//signal(SIGTERM, unload);	// run the unload in My Thread... (4.10 needs this)
	NavSetSignals();


	//We do not want to run on a server with System Fault Tolerant level 3 and the SFTIII IO engine.
	//If so, we don't load.
	if (fsinf.SFTLevel==3) 
	{
		//Possible configuration types:  0=Normal, 1=IOEngine(SFTIII), 2=MSEngine(SFTIII) 
		
		// ksr ??? need following???
		if (GetServerConfigurationType()==1) 
		{
			_printf ("Cannot load Norton AntiVirus in the I/O engine of SFTIII servers\n");
			ExitingNormally=FALSE;
			goto done;
		}
	}
	
	//////////////////////////////////////
	//The following lines of code will be parsing the commandline parameter of RTVScan.NLM.
	//This for loop is for commandline parsing.
	for (i=1;i<argc;i++) 
	{
		//CAPITALIZE all arguments
		strupr(argv[i]);

		//This rel allows other processes on the Netware server to run also.
		ThreadSwitchWithDelay();

		//////////////////////////////////////
		//For each loop i, check the first char of string argv[i]
		switch (argv[i][0]) 
		{

		//BREAK - This case means we want to stop at very Breakpoint(brk)
		case 'B':
//This check is only for DEBUG builds because when want 
//to be more strict to know the exact intent of the parameter.
#ifndef DEBUG
			if (StrEqual(argv[i],"BREAK"))
#endif // DEBUG
			{
				brk = 1;
				continue;
			}
			break;

		//DEBUG - This case means to take debug flags from the commandline. 
		case 'D':
			//Get debug flags
			if (StrNEqual(argv[i],"DEBUG=",6)) 
			{
				strcpy(gszDebug, argv[i]+6);
				debug = ParseDebugFlag(gszDebug);
#ifdef MemCheck
				//TrackMallocs is set to TRUE in case M.
				//This means case M must have been set before for this to be affective.
				if (TrackMallocs)
					debug |= DEBUGPRINTALLOC;
				else
					debug &= ~DEBUGPRINTALLOC;
#endif // MemCheck
				//This means RegDebug() will ignore debug flags from the registry,
				//since we have already set our debug flags from the commandline.
				//doRegDebug = FALSE;
				continue;
			}
			break;

		//ENGLISH ONLY - This case means we will be using the English string table.
		//If this is not set, we will set the string table according to 
		//the language of the server we're running on.
		case  'E':
			if (StrEqual(argv[i],"ENGLISH")) 
			{
				EnglishOnly=TRUE;
				continue;
			}
			break;

#ifdef MemCheck
		//MEMORY CHECKING ONLY - This case means we want to track every memory allocation
		//by printing to our debug out.
		case 'M':
#ifndef DEBUG
			if (StrEqual(argv[i],"MEMCHECK"))
#endif// !DEBUG
			{
				TrackMallocs = TRUE;
				continue;
			}
			break;
#endif // MemCheck

		//ASSUMMING: NO VOLUME or MEMORY SCANNING - This case means 
		//no memory scanning or no volume name checking.
		case 'N':
			if (StrEqual(argv[i],"NO_VOLUME_CHECK")) 
			{
				//Setting CheckVolumes to 0 means we will not 
				//be setting the names of the volumes in the VolumeTable.
				CheckVolumes = 0;
				continue;
			}
			if (StrEqual(argv[i],"NOMEMSCAN")) 
			{
				//No memory scanning
				ScanMemory = 0;
				continue;
			}
			break;

//		case 'R':
//			break;

#ifdef SemaCheck
		//SEMACHECK - This case means to track semaphores
		//by outputting semaphore info to debug screen
		//else the debug log if unloading of RTVScan.NLM.
		case 'S':
#ifndef DEBUG
			if (StrEqual(argv[i],"SEMACHECK"))
#endif // !DEBUG
			{
				TrackSemaphores = TRUE;
				continue;
			}
			break;
#endif
#ifdef ThreadCheck
		//THREADCHECK - This case means to track thread information 
		//and provide this information in the debug screen,
		//else the debug log if during unload of RTVScan.NLM.
		case 'T':
#ifndef DEBUG
			if (StrEqual(argv[i],"THREADCHECK"))
#endif // !DEBUG
			{
				TrackThreads = TRUE;
				continue;
			}
			break;
#endif // ThreadCheck
		}
		///////////////end of switch////////////////

		_printf(LS(IDS_BAD_OPTION),argv[i]);
		exit(0);
	}
	///////////////end of for loop////////////////

	//See if we have any debug flags in the registry
	//RegDebug(/*FALSE*/);

	//This is used for debugging.  
	//We would used this breakpoint to see if we 
	//have properly parse the commandline parameters. 
	Breakpoint(brk);

	//This mean we want to be notified when the server is going down.
	//The server will call ServerDown().
	/**
	extern LONG RegisterForEvent
    (
       LONG eventType,
       void (*reportProcedure)( LONG parameter, LONG userParameter ),
       LONG (*warnProcedure)
       (
          void (*OutputRoutine)( const void *controlString, ... ),
          LONG parameter,
          LONG userParameter
       )
    );
    **/
	//EventHandle = RegisterForEvent(EVENT_DOWN_SERVER,ServerDown,0);

	//Check that NAV is installed.  
	//CheckInstall() succeeds if the Home Directory registry value is not empty.
	/**
	cc = CheckInstall();
	if(cc != ERROR_SUCCESS) {
		_printf(LS(IDS_INVALID_SETUP1));
		_printf(LS(IDS_INVALID_SETUP2));
		_printf(LS(IDS_INVALID_SETUP3));
		goto done;
	}
	**/

	//Log that we are starting
	/*
	if (debug&DEBUGLOG) 
	{
		t=time(NULL);
		sprintf(LogStartStop, "\n\nRTVSCAN.NLM is Starting at %s", ctime(&t));
		LogLine(LogStartStop, TRUE);
	}
	*/
	//Restore the server console UI to its original screen that we removed earlier.
	SetCurrentScreen (MainScreenHan);
	DisplayScreen (MainScreenHan);

	//Check if the user wants us to exit.
	CFNL

	//Set the proper string table for us to use.  If EnglishOnly == FALSE, 
	//we will load the string table for the string table for the current OS.
	if (OpenStringTable(EnglishOnly) != ERROR_SUCCESS) 
	{
		ExitingNormally=FALSE;
		goto done;
	}

	//show our version and build number
	wsprintf(NewVersionString,"%u.%02u.%u",MAINPRODUCTVERSION,SUBPRODUCTVERSION,BUILDNUMBER);
//	SetString(IDS_VERSION,NewVersionString);
	printf ("%s - ",NewVersionString);

	//Show "Please wait, Norton AntiVirus initializing\n"
	printf(LS(IDS_NLM_LOADING));

	ThreadSwitchWithDelay();

	//Check if the user wants us to exit. If '~' is typed on the keyboard.
	CFNL

	//Validate license
	cc = CheckTimeOut(NULL);
	if (cc&0x80000000) 
	{
		if (cc == 0x80000000) 
		{
			_printf(LS(IDS_INVALID_LICENSE));
		}
		else 
		{
			_printf(LS(IDS_TRIAL_EXPIRED));
		}
		goto done;
	}

	//Check if the user wants us to exit. If '~' is typed on the keyboard.
	CFNL

	//Make sure we are running for a netware server newer than version 3.12g
	if (CLibVersion < 31207 /* v3.12g */) 
	{
		ExitingNormally=FALSE;
		_printf("%s\r\n  %s\r\n  %s\r\n",LS(IDS_UPDATING_CLIB1),LS(IDS_UPDATING_CLIB2),LS(IDS_UPDATING_CLIB3));
		
		goto done;
	}

	// ksr no need
	// CheckLDSM();

	//Create a suspended thread. 
	//If we keep one thread suspended in our thread group list, 
	//thus preventing NW from calling exit because of a ExitThread.
//Breakpoint( 1 );
	BeginThreadGroup((THREAD)KeepAlive,NULL,STACK_SIZE,NULL);


	cc = InitPscan();

	//Record our start time
	starttime=time(NULL);

#ifdef ThreadCheck
	ThreadReport(FALSE);
#endif // ThreadCheck


	if (cc) 
	{
		_printf(LS(IDS_ERROR_LDVP_START),cc,GetErrorText(cc));
	}
	else 
	{
		_printf(LS(IDS_LDVP_INSTALLED));
		ConsoleRunning = 1;
		
		//Update virus definition - by copying the new pattern file to the local login directory (%VPHOME%\Login)
		// ksr 
		// ??? UpdateLoginPatternFile();
		
		//Check if the user wants us to exit. If '~' is typed on the keyboard.
				
		
		if (!CheckForNoLoad(3000)) 
		{
			//Bring up our netware console UI.  A return from this call means
			//we are in the process of unloading RTVScan.NLM
			
			// ksr
			// ??? StartConsoleScreen();
			delay (500);
		}
				
		if( !SystemRunning )
			//We have been unloaded. Let the unload function do the cleanup. just go to sleep here
			//This call will block because I am suspending myself.
			//The code responsible for unloading is also responsible for resuming this thread.
			SuspendThread( MainThread=GetThreadID() ); 

//?????


		if( !SystemRunning )
			//DeInitialization has already been completed,
			//so we are done.
			goto done;
	}
	//Record our end time
	endtime = time (NULL);
	//If we have not been running for more than MIN_RUN_TIME, currently MIN_RUN_TIME = 10 (seconds)
	//then we will wait a little to give the startup process a chance to complete.
	if  (endtime-starttime < MIN_RUN_TIME) 
		// because if we try to DeInit too soon we will hang waiting for threads to die.
		delay (((MIN_RUN_TIME+1)-(endtime-starttime))*1000);

#ifdef ThreadCheck
	ThreadReport(FALSE);
#endif // ThreadCheck


	//--------------------------------------------------------------------------
	// ksr
   //Printf( MSG_WAITING_FOR_CLIENT );

   // keyboard drive 
   while( SystemRunning )
   {
      if( kbhit() )
      {
         char  buf[16];
         buf[0] = getch();
         if( buf[0] == ALT_F4 )  // ESCAPE_KEY 
         {
            buf[0] = getch();
           // PressEscapeToQuit();

            SystemRunning = 0;
            raise( SIGTERM );
         }
         else if( buf[0] == 0x03 )     // CTRL_C_KEY
            ;
      }
      else
         ThreadSwitch();
   }

//Breakpoint( 1 );

   //delay( 50 );

	// ksr - it is called by NavUnload
	// DeInitPscan();


done:

#ifdef ThreadCheck
	if (TrackThreads)
		ThreadReport(TRUE);
#endif // ThreadCheck

	CloseStringTable();
	_debug = debug&(/*DEBUGLOG|*/DEBUGTIMESTAMP/*|DEBUGSAFELOG*/);
	CloseNLMStuff(); // debug is now 0
	if (_debug/*&DEBUGLOG*/) 
	{
		t=time(NULL);
		//sprintf(LogStartStop,"NAVAP.NLM is Unloading at %s\n",ctime (&t));
		debug = _debug;
		//LogLine(LogStartStop,TRUE);
		debug = 0;
	}

#ifdef SemaCheck
	if (TrackSemaphores)
		ReportSemaUsage(TRUE);
#endif // SemaCheck

#ifdef MemCheck
	if (TrackMallocs)
		ReportMemoryUsage(TRUE);
#endif // MemCheck

	// exit(0);
	NavExit( 1 );
}


/**********************************************************************************************/

BOOL CheckForNoLoad( int time )  
{
	char c;

	delay (50);
	if (kbhit()) 
	{
		c=getch();
		if (toupper(c)=='~') 
		{
			_printf ("Aborting RTVScan Load\n");
			delay (time);
			return TRUE;
		}
	}

	return FALSE;
}


/****************************************************************************/
//void StartBox(PINFECTION Inf)
void StartBox(PEVENTBLOCK eb)
{
	if (eb->Special)
		_printf("%s%c\r\n\r\n",(char *)eb->Special,
								9,                  //_GetVal(eb->hKey,
								' ');               //"Beep",1)?'\a':' ');
}

