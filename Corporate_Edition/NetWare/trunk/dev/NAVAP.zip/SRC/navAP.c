//------------------------------------------------------------------------------
//
//      navAP.c -- 
//
//
//      ANSIL Project
//
//              Ansil for NetWare
//
//              Symantec Corporation Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//              
//
//
//      Author:
//              Kamy Rahimi           May-1-2001
//              Kamy@CrossColors.com
//              Phone:  (650) 322-9777
//
//
//      Modifications:
//
//
//
//------------------------------------------------------------------------------
 	
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <nwtypes.h>
#include <nwthread.h>
#include <nwerrno.h>
#include <nwadv.h>
#include <nwconio.h>
#include <time.h>
//#include <signal.h>
#include "pscan.h"

//#define HANDLEDCOMMAND  0
//#define NOTMYCOMMAND    1

// Prototypes 

void    HandleStatRequest(void *dummy);

// Globals

static  LONG    StatCommandThread;


//------------------------------------------------------------------------------
//
//      
//      Description:
//
//
//
//      
//
//              
//              
//
//
//------------------------------------------------------------------------------
 
#define	mySTACK_SIZE		8192
 	
int	NavBeginThread(
							//THREAD   function,
							void (*function)(void *),
							void     *arg
							)
{
	int	status = ESUCCESS;		// 0
	void *stackPtr = NULL;
	unsigned int stackSize = mySTACK_SIZE;
	//void *arg =  NULL;

	// int   BeginThread( void (*func)( void * ), 
	//							 void *stackPtr,
   // 				       unsigned int stackSize, 
   //							 void *arg );
	
	status = BeginThread( function, stackPtr, stackSize, arg );
	
   if ( status == EFAILURE )	// -1
   {
      printf( "Error: Couldn't start fundtion %s thread!\n", function );
      return( 1 );
   }
	NavSetSignals();

   ThreadSwitch(); // let them run at least once...

   return( 0 );
}


//------------------------------------------------------------------------------
//
//      
//      Description:
//
//
//
//      
//
//              
//              
//
//
//------------------------------------------------------------------------------
 
void TwiddleThumbs( void )
{
	time_t	start_time, new_time ;
	int	minutes, hours, seconds, elapsed ;
	char string[20] ;

	start_time = time (0) ;
	//sprintf (&string[0],FmtMsgs[MSG_111]) ;
	printf (&string[0]) ;
	while (1)
	{
		new_time = time (0) ;
		elapsed = (new_time - start_time) ;
		hours = elapsed / 3600 ;
		minutes = (elapsed - (hours * 3600)) / 60 ;
		seconds = elapsed % 60 ;
		//sprintf (&string[0], FmtMsgs[MSG_112], hours, minutes, seconds) ;
		printf (&string[0]) ;
		//sprintf (&string[0],FmtMsgs[MSG_113]) ;
		printf (&string[0]) ;
		NTxSleep( 1000 ) ;
	}
}


//------------------------------------------------------------------------------
//
//      
//      Description:
//
//
//
//      
//
//              
//              
//
//
//------------------------------------------------------------------------------

extern HANDLE hSemEvent;
 
void NavUnload( int signalCondition )
{

   switch( signalCondition )
   {
      case SIGINT:   // Ctrl-C 
         //printf( MSG_CTRL_C_DETECTED );
         break;

      case SIGTERM:
         // printf( MSG_CTRL_C_DETECTED ); 
         break;
   }
	SetCtrlCharCheckMode( TRUE );
   /**
   while( waitingThreads )
      ThreadSwitch();
   **/
   delay( 50 );

   if( hSemEvent != NULL )
      CloseLocalSemaphore( hSemEvent );
      
	DeInitPscan();
	CloseNLMStuff();
      
//   CancelSleepAESProcessEvent( (struct AESProcessStructure *)&AESProcess );

}


//------------------------------------------------------------------------------
//
//      
//      Description:
//
//
//
//      
//
//              
//              
//
//
//------------------------------------------------------------------------------

void  NavSetSignals( void )
{
   signal( SIGINT, NavUnload );    // Control-C 
   signal( SIGTERM, NavUnload );   // unload command 
   signal( SIGABRT, NavUnload );   // abort 
}


//------------------------------------------------------------------------------
//
//      
//      Description:
//
//
//
//      
//
//              
//              
//
//
//------------------------------------------------------------------------------
 
void  NavExit( int flag )
{
   //******* create a confirm box *******
   /*
	WriteInstructions( "Press F1 to view a help screen", ipPtr );
   NWSSetDynamicMessage( DYNAMIC_MESSAGE_ONE, "Exit Allodyne Monitor?",
                         &nutHdl->messages );

   NWSPushHelpContext( CONFIRM_BOX, nutHdl ); 

   cCode = NWSConfirm( DYNAMIC_MESSAGE_ONE, 10, 40, 1,
                       NULL, nutHdl, NULL);

    NWSPopHelpContext( nutHdl );
   */
   if( flag )
   {
//     	NWSPopHelpContext( nutHdl );
      NavUnload( 0 );
      exit( 0 );
   }
   else
   {
      NavUnload( 0 );
   }
 
}


//------------------------------------------------------------------------------

