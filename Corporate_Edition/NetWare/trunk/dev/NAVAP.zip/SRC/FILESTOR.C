//------------------------------------------------------------------------------
//
//      FileStor.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#include "pscan.h"
#include "FIOOpen.c"

//#ifdef NLM
	extern int MaxVolumes;  // gdf 06/16/00
//#endif

/**
#if defined(SERVER) && defined(WIN32)
#define USING_NAVAP

#define SYM_WIN32
#define SYM_EXPORT
#include "apcomm.h"
#include "actions.h"
#define HFILE HANDLE
#define PHFILE HFILE
#include "apquar.h"

HANDLE hNAVAP = NULL;

//  MMENDON 09-30-2000: Change for AutoProtect early shutdown
#if defined(WIN95)
extern BOOL gbNotifyNavapVxdSysShutdown;
#endif
//  MMENDON 09-30-2000: End change for AutoProtect early shutdown



extern HANDLE hNAVAPDefsNotify;
extern CRITICAL_SECTION rHandleLock;
void RefreshNAVAPStatistics(void);


CRITICAL_SECTION RTSErrorLoggingLock;
BOOL gbLoggedRTSLoadError = FALSE;


#include <pshpack1.h>
typedef struct
{
    char szText[145];
    BYTE bSubDirectory;
    WORD wBits;
} OLDEXCLUDEITEM;

#define LEXCLUSION_SIZE 260
typedef struct
{
    char szText[LEXCLUSION_SIZE + 1];
    BYTE bSubDirectory;
    WORD wBits;
} LEXCLUDE_DAT;
#include <poppack.h>

#define excVIRUS_FOUND 0x0004  //from ctsn.h. Not including ctsn.h - don't want platform.h

// MMENDON 1/30/2000:  change for extension exclusions
#define EXT_DELIM _T(',')
#define STR_EXT_DELIM _T(",")
#define WILDCARD _T("*.")
// MMENDON 1/30/2000:  end change for extension exclusions

// TCASHIN 2/24/00 Changes to preserve security attributes
extern PFNGetFileSecurityDesc   pfnGetFileSecurityDesc;
extern PFNSetFileSecurityDesc   pfnSetFileSecurityDesc;
extern PFNFreeFileSecurityDesc  pfnFreeFileSecurityDesc;
// TCASHIN 2/24/00 End changes to preserve security attributes

DWORD NTStartService ( char * pszName, char * pszImage );
DWORD NTStopService ( char * pszName );
void LogRTSLoadError(void);
void DisplayRTSLoadError(void); 
void SetNAVAPNotificationHandle ( HANDLE hNotify );

BOOL WINAPI APServiceStart ( char * pszName, char * pszLocation );
BOOL WINAPI APServiceStop ( char * pszName );

BOOL StartNAVAP();
BOOL StopNAVAP();

BOOL DecodeNAVAPQuarantineFile ( PNAVAP_EVENTPROGRESSREPORTPACKET pPacket, LPSTR lpFileName, DWORD *lpdwFileStatus, PFILE_ACTION lpAction );
BOOL DoFileWipe(LPCTSTR  lpFilename);

PNAVAP_CONFIG mallocAndBuildNAVAPConfiguration();
DWORD ConvertToVirusLikeAction ( DWORD action );
DWORD ConvertToAPAction ( DWORD action );

DWORD GetModuleLocation (PSTR pszPath);
LEXCLUDE_DAT * PrepareExclusions ( DWORD * count );
BOOL GetExclusionListFromRegistry(HKEY hKey, DWORD * lpdwExclusionIndex, DWORD dwExclusions, LEXCLUDE_DAT * lpExclusionList);
BOOL ConvertToAPPath(LPCTSTR pcszExceptionValName, char * pszConvertedOEMPath);
extern void ReloadAPVirusDefinitions();

// MMENDON 1/30/2000:  change for extension exclusions
BOOL CheckForExclusions(LPCSTR lpszRegKey, HKEY *lphExcKey, DWORD *lpdwExclusions);
BOOL CheckForExtensionExclusions(LPSTR lpszExtensionList, DWORD * lpdwExclusions);
BOOL GetExtensionCount(LPTSTR lpszExtList, DWORD *lpdwCounter);
BOOL GetExtensionExclusionsFromList(LPTSTR lpszExtList, DWORD * lpdwExclusionIndex, LEXCLUDE_DAT * lpExclusionList);
// MMENDON 1/30/2000:  end change for extension exclusions

// MMENDON 1/30/2000:  fix for STS defect #332943
BOOL GetAutoProtectTempDir(LPSTR lpAPTempDir);
// MMENDON 1/30/2000:  end fix for STS defect #332943

#endif
**/


//#ifndef SERVER
static DWORD emptycall(void) {return ERROR_FUNCTION_NO_SUPPORTED;}
//#endif

DWORD	MyFSOpen(PSNODE node,DWORD access);
DWORD myaccess(PSNODE node,int type);
//HANDLE FindFirstNode(HANDLE parent,DWORD ID,char *path,PQNODE query,PSNODE node);
//DWORD  FindNextNode(HANDLE handle,PQNODE query,PSNODE node);
DWORD CreateSNode(DWORD ID,char *path,PSNODE node);
DWORD  ReleaseSNode(PSNODE node);
DWORD  mFindClose(HANDLE handle);
DWORD  NodeHasVirus(PSNODE node,PEVENTBLOCK eb);
DWORD  Deinit(HANDLE handle);
DWORD  BeginRTSWatch(PROCESSRTSNODE process,PSNODE node,void *UserContext);
DWORD  StopRTSWatches(void);
DWORD  RemoveNode(PSNODE node);
DWORD  FillInstanceBlocks(void);
DWORD  GetState(PSNODE node,BYTE *Data);
DWORD  SetState(PSNODE node,BYTE *Data);
DWORD  ReloadRTSConfig(void);
//DWORD  Reinit(DWORD Flags);
DWORD GetExtendedData(PSNODE node,char *KeyName,BYTE *Data,DWORD len);
DWORD SetExtendedData(PSNODE node,char *KeyName,BYTE *Data,DWORD len);
//DWORD GetFullFindKey(HANDLE handle,char *buffer);
//DWORD GetFullNodeKey(PSNODE node,char *buffer);
//VOID ReadRegistry2(VOID);
//VOID WriteRegistry2(VOID);
DWORD ChangeUser(char *name,HANDLE token);
DWORD fsFormatMessage(char
 *msgbuf, char *msgfmt, PEVENTBLOCK eb) {REF(msgbuf);REF(msgfmt);REF(eb);return ERROR_FUNCTION_NOT_SUPPORTED;}

/*
#if defined _MSC_VER
#pragma warning(disable: 4232)
#endif // _MSC_VER
*/
SFILETABLE FileTable = {MyFSOpen,
								(DWORD(*)(DWORD))close,
								(DWORD(*)(DWORD,void*,DWORD))read,
								(DWORD(*)(DWORD,void*,DWORD))write,
								(DWORD(*)(DWORD,long,DWORD))lseek,
								myaccess,GetState,SetState,
								GetExtendedData,SetExtendedData//,GetFullNodeKey
								};
/*
#if defined _MSC_VER
#pragma warning(default: 4232)
#endif // _MSC_VER
*/

NODEFUNCTIONS NFunctions = {(RELEASESNODE)ReleaseSNode,(NODEHASVIRUS)NodeHasVirus,(REMOVENODE)RemoveNode};
SFUNCTIONS Functions = 
				{
								//FindFirstNode,
								//FindNextNode,
								CreateSNode,
								//GetFullFindKey,
								//mFindClose,
								Deinit,
//#ifdef SERVER
								BeginRTSWatch,
								StopRTSWatches,
								FillInstanceBlocks,
								ReloadRTSConfig,
//#else
//				(BEGINRTSWATCH)emptycall,(STOPRTSWATCHES)emptycall,FillInstanceBlocks,(RELOADRTSCONFIG)emptycall
//#endif //SERVER
								//,Reinit,
								(PROCESSPACKET)emptycall,
								//fsFormatMessage,
								ChangeUser
				};

#define MAX_THREADS 10

STORAGESTATUS FileSystemStatus = {0};
STORAGEDATA FileSystemData;
STORAGEINFO FileSystemInfoTable = 
				{
					sizeof(STORAGEINFO),1,0,NULL,
					&Functions, 
					//0,
					&FileSystemStatus,"FileSystem","FileSys.inf",
					IT_CAN_WALK|IT_CAN_RTS|IT_CAN_RTS_SKIP,
					&FileSystemData,MAX_THREADS
				};
PSSFUNCTIONS SFunctions = NULL;
BOOL Inited = FALSE;

#undef dprintf
#define dprintf if(SFunctions && SFunctions->dPrintf && *SFunctions->debug&DEBUGPRINT) SFunctions->dPrintf
/*
#define sCloseKey SFunctions->Close
#define sOpekKey SFunctions->Open
#define sCreateKey SFunctions->Create
#define sGetVal SFunctions->GetVal
#define sGetStr SFunctions->GetStr
#define sPutVal SFunctions->PutVal
#define sPutStr SFunctions->PutStr
#define sEnumKey SFunctions->EnumKey
#define sGetData SFunctions->GetData
*/

/************************************************************************************************************/

//HKEY hFileSysKey=0;

DWORD CurrentFlags = 0;
/*
#ifdef WIN32
// Add an additional item to the Array for UNC's.
DRIVE_TABLE DriveTable[27];
#else
DRIVE_TABLE DriveTable[26];
#endif
*/
//#ifdef SERVER

//#ifdef NLM
BOOL FSInited=FALSE;
//#endif //def NLM

char isOn = FALSE;
DWORD gdwSoftmice,gdwZipFile,gdwZipDepth,gdwOnOff,gdwClientNotify;
DWORD gdwFloppys,gdwNetworks,gdwHardDisks,gdwCDRoms,gdwTrap,gdwCache,gdwFileType,gdwTypes;
DWORD gdwReads,gdwWrites,gdwExecs,gdwHoldOnClose;
DWORD gdwHaveExceptionDirs,gdwCheckRemoveable,gdwHaveSkipExts;
DWORD gdwCheckForBadOpCode;
char gszSkipExts[EXT_LIST_SIZE];
char gszTrapExts[IMAX_PATH];
//char gszZipExts[EXT_LIST_SIZE];
char gszExts[EXT_LIST_SIZE];
char gszDriveList[2048];
char gszReportFormat[512];

//#if !defined(USING_NAVAP)  // ??? ksr
HANDLE  hDevice=0;
//#endif

HANDLE hFileMap=0;
BOOL fShutDown[MAX_THREADS];
static HANDLE Mutex = 0;

/*
#ifdef WIN32  

//============================================================================
static void StartCS(void) {
	if (Mutex == 0)
		Mutex = CreateMutex(NULL,FALSE,NULL);

	WaitForSingleObject(Mutex,INFINITE);
}
//============================================================================
static void EndCS(void) {

	ReleaseMutex(Mutex);
}
#endif // WIN32
*/

/**************************************************************/
void UpdateDriveTables(void) {
/**
#ifdef WIN23 /// <------------------------------------------------------------------------------ is this a bug ???? EVAN 98.11.12

	int i;
	char symbolic[10];
	char tmp[10];

	for (i=0;i<26;i++) {
		WSprintf(symbolic,"%c:",i+'A');
		DriveTable[i].Wanted = (*gszDriveList == 0 || strstr(gszDriveList,symbolic));
		}
#endif //WIN23
**/

}
/*****************************************************************************************/

//#ifdef NLM
#define mbstowcs strncpy
#define mwcscat strcat
#define L
//#endif // NLM


/*****************************************************************************************/
/******************************************************************************/

void UpdateSysPrams(void) 
{
/*
#if defined(USING_NAVAP)
    PNAVAP_CONFIG pConfig;
    static DWORD dwHeuristicsLevel = 0xFFFFFFFF;

    if ( pConfig = mallocAndBuildNAVAPConfiguration() )
    {
        UpdateDriveTables();

        NAVAPiReloadConfiguration ( hNAVAP, pConfig );

        // if the heuristics level has changed, the defs need to be reloaded
        if(dwHeuristicsLevel == 0xFFFFFFFF)
            dwHeuristicsLevel = pConfig->dw_uFileHeuristicLevel;
        else
        {
            if(dwHeuristicsLevel != pConfig->dw_uFileHeuristicLevel)
            {
                ReloadAPVirusDefinitions();
                dwHeuristicsLevel = pConfig->dw_uFileHeuristicLevel;
            }
        }

        free ( pConfig );
    }

#else 
*/
	PSYS_PRAMS SysPrams;
	DWORD retval;

	SysPrams = malloc(sizeof(SYS_PRAMS));
	if (!SysPrams)
		return;

	UpdateDriveTables();

	DeviceIoControl(hDevice,(ULONG)IOCTL_GET_SYS_PRAMS,NULL,0,SysPrams,
							sizeof(SYS_PRAMS),&retval,NULL);
	if (SysPrams->MySize != sizeof(SYS_PRAMS))
	{
		dprintf("SysPrams WRONG SIZE, not updating!\n");
		free(SysPrams);
		return;
		}

	SysPrams->DoWrites       = (char)gdwWrites;
	SysPrams->DoReads        = (char)gdwReads;
	SysPrams->DoExecs        = (char)gdwExecs;
	SysPrams->DoFloppy       = (char)gdwFloppys;
	SysPrams->DoHardDisk     = (char)gdwHardDisks;
	SysPrams->DoCDRom        = (char)gdwCDRoms;
	SysPrams->DoTrap         = (char)gdwTrap;
	SysPrams->DoCache        = (char)gdwCache;
	SysPrams->DoNetwork      = (char)gdwNetworks;
	SysPrams->HoldOnClose    = (char)gdwHoldOnClose;
	SysPrams->DoFloppyBoot   = (char)gdwCheckRemoveable;

	if (gdwFileType==1) 
	{
		mbstowcs(SysPrams->ExtList,gszExts,sizeof(SysPrams->ExtList)/sizeof(SysPrams->ExtList[0]));
		if (gdwTrap) 
		{
//#ifdef NLM
			strcat(SysPrams->ExtList,gszTrapExts);
/**
#else
			WCHAR tmp[65];
			mbstowcs(tmp,gszTrapExts,64);
			mwcscat(SysPrams->ExtList,(WORD *) L",");
			mwcscat(SysPrams->ExtList,tmp);
#endif //NLM
*/
		}

//		if (gdwZipFile) {  Extensions are now added in the UI
//#ifdef NLM
//			strcat(SysPrams->ExtList,gszZipExts);
//#else
//			WCHAR tmp[65];
//			mbstowcs(tmp,gszZipExts,64);
//			mwcscat(SysPrams->ExtList,(WORD *)L",");
//			mwcscat(SysPrams->ExtList,tmp);
//#endif //NLM
//		}
	}
	else
		SysPrams->ExtList[0] = 0;
/*
#ifdef WIN32
	memcpy(SysPrams->DriveTable,DriveTable,sizeof(SysPrams->DriveTable));
#endif// WIN32
*/

//#ifdef NLM
//	StrCopy(SysPrams->DriveList,"111111111111111111111111111111111"/*gszDriveList*/);
	memset(SysPrams->DriveList, 0, sizeof(SysPrams->DriveList));   
 	if( MaxVolumes > sizeof(SysPrams->DriveList) )  // gdf 06/16/00
 		memset(SysPrams->DriveList, 0x31, MaxVolumes-1);    // gdf 06/16/00
 	else    // gdf 06/16/00
 		memset(SysPrams->DriveList, 0x31, MaxVolumes);
//#endif // NLM

	mbstowcs(SysPrams->ClientDirectory,ClientDir,IMAX_PATH);
	DeviceIoControl(hDevice,(ULONG)IOCTL_SET_SYS_PRAMS,SysPrams,sizeof(SYS_PRAMS),NULL,0,&retval,NULL);
	free(SysPrams);
//#endif // USING_NAVAP
}


/********************************************************************************************************************/
//#ifdef NLM

void CheckFSInit()
{
	if(!FSInited) // because we want the file system to be initialized prior to calling DriverHook
	{
		int c=600;
		for( ; c && !FSInited ; c--)
		{
			delay(100);
		}
	}
}
//#endif //def NLM


/*************************************************************************/

DWORD ReloadRTSConfig(void) 
{
	//ReadRegistry2();

	if (gdwOnOff != (DWORD)isOn) 
   {
		if (gdwOnOff) 
      {
//#ifdef NLM
			CheckFSInit();
//#endif //def NLM

//#if !defined (USING_NAVAP)

            DriverHook();
/*
#else
            // On Win32, we want to notify the user (log and message box) if AutoProtect failed to load.
            if(DriverHook() != ERROR_SUCCESS)
            {
                   // An error loading AP has occurred.  Log the error and notify the user.
                   LogRTSLoadError();
                   MyBeginThread((THREAD)DisplayRTSLoadError,NULL,"");
            }
#endif //!USING_NAVAP
*/
      }
		else
			DriverUnHook();
	}

	ThreadSwitch();

	if (isOn) 
   {
		UpdateSysPrams();
	}

	pStatBlock->Status =
			(gdwReads              ?0x00000001:0) |
			(gdwWrites             ?0x00000002:0) |
			(gdwExecs              ?0x00000004:0) |
			(gdwFloppys            ?0x00000008:0) |
			(gdwNetworks           ?0x00000010:0) |
			(gdwHardDisks          ?0x00000020:0) |
			(gdwZipFile            ?0x00000040:0) |
			(gdwSoftmice           ?0x00000080:0) |
			(gdwOnOff              ?0x00000100:0) |
			(gdwClientNotify       ?0x00000200:0) |
			(gdwTrap               ?0x00000400:0) |
			(gdwCDRoms             ?0x00000800:0) |
			(gdwHaveExceptionDirs  ?0x00002000:0) |
			(gdwCheckRemoveable    ?0x00004000:0) |
			(gdwHoldOnClose        ?0x00008000:0) |
			(gdwHaveSkipExts       ?0x00010000:0) ;

    
//#if !defined (USING_NAVAP)   // On Win32 there is no reason to call this block again!
    
	if (gdwOnOff != (DWORD)isOn) 
   {  
      // sometimes the first hook fails
		if (gdwOnOff) 
      {
//#ifdef NLM
			CheckFSInit();
//#endif //def NLM
			DriverHook();
		}
		else
			DriverUnHook();
	}
//#endif  //!USING_NAVAP

	FileSystemData.ZipDepth = gdwZipDepth;
	FileSystemData.FileType = gdwFileType;
	FileSystemData.Trap = gdwTrap;
	FileSystemData.Types = gdwTypes;
	StrCopy(FileSystemData.Exts,gszExts) ;
	StrCopy(FileSystemData.ZipExts,"") ;
	StrCopy(FileSystemData.TrapExts,gszTrapExts) ;
	FileSystemData.ZipFile = gdwZipFile;
	FileSystemData.Softmice = gdwSoftmice;

	return ERROR_SUCCESS;
}




// ksr
#if 0


/******************************************************************************************************/
DWORD CheckSFunctions()
{
	int i;
// we will abend/GPF if hFileSysKey is zero or SFunctions is still NULL
// but first give the file storage a chance to initialize;
	for( i=0 ; i<200 && ( !hFileSysKey || !SFunctions ) ; i++ )
		NTxSleep( 100 );

	if( !hFileSysKey || !SFunctions )
		return 0xffffffff;

	return ERROR_SUCCESS;
}
/******************************************************************************************************/

VOID ReadRegistry2(VOID) {

//	Read realtime options

	char line[IMAX_PATH+64];

	if(CheckSFunctions()!=ERROR_SUCCESS)
		return;

	WSprintf(line,"%s\\INFECTED",HomeDir);

// ksr
/*
	gdwCache = sGetVal(hFileSysKey, "Cache", 1);
	gdwCDRoms = sGetVal(hFileSysKey, "CDRoms", 1);
	gdwCheckForBadOpCode = sGetVal(hFileSysKey,"CheckForBadOpCode",0);
	gdwCheckRemoveable =sGetVal(hFileSysKey,"CheckRemoveable",1);
	gdwClientNotify = sGetVal(hFileSysKey, "ClientNotify", 1);
	sGetStr(hFileSysKey, "ClientReportFormat", gszReportFormat, sizeof(gszReportFormat),LS(IDS_CLIENT_BLOCK_MSG));
	sGetStr(hFileSysKey, "DriveList", gszDriveList, sizeof(gszDriveList),"");
	gdwExecs = sGetVal(hFileSysKey, "Execs", 0);
	gdwFloppys = sGetVal(hFileSysKey, "Floppys", 1);
	gdwHardDisks = sGetVal(hFileSysKey, "HardDisks", 1);
	gdwHaveExceptionDirs = sGetVal(hFileSysKey,"HaveExceptionDirs",0);
	gdwHoldOnClose = sGetVal(hFileSysKey, "HoldOnClose", 1);
	gdwNetworks = sGetVal(hFileSysKey, "Networks", 0);
	gdwOnOff = sGetVal(hFileSysKey, "OnOff", 1);
	gdwReads = sGetVal(hFileSysKey, "Reads", 0);
	gdwSoftmice = sGetVal(hFileSysKey, "Softmice", 1);
	gdwTrap = sGetVal(hFileSysKey, "Trap", 0);
	sGetStr(hFileSysKey, "TrapConfig\\Exts", gszTrapExts, sizeof(gszTrapExts),"EXE,COM,DLL,SYS");
	gdwWrites = sGetVal(hFileSysKey, "Writes", 1);

	gdwFileType = sGetVal(hFileSysKey, "FileType", 1);
	gdwTypes = sGetVal(hFileSysKey, "Types", 0);
    // MMENDON 08-21-2000 STS defect 340457:  if error reading exts from registry, want to
    //                                        scan all files, not just 8 extensions
    sGetStr(hFileSysKey, "Exts", gszExts, sizeof(gszExts),"");
    if(!gszExts[0])
    {
        gdwFileType = 0;
        dprintf("Error getting RTS extensions.  Scanning all files.\n");
    }
    // MMENDON 08-21-2000 End STS defect 340457

	sGetStr(hFileSysKey, "SkipExts", gszSkipExts, sizeof(gszSkipExts),"");
	gdwHaveSkipExts = gszSkipExts[0]?1:0;

	gdwZipFile = sGetVal(hFileSysKey, "ZipFile", 1);
//	sGetStr(hFileSysKey, "ZipExts", gszZipExts, sizeof(gszZipExts),"ZIP,ARJ,LHA,LZH,CO_,EX_,DL_,DO_");
	gdwZipDepth = sGetVal(hFileSysKey, "ZipDepth", 1);
**/

}
/*************************************************************************************/

/*
VOID WriteRegistry2(VOID)
{
	if(CheckSFunctions()!=ERROR_SUCCESS)
		return;

	sPutVal(hFileSysKey, "Cache", gdwCache);
	sPutVal(hFileSysKey, "CDRoms", gdwCDRoms);
	sPutVal(hFileSysKey, "CheckForBadOpCode", gdwCheckForBadOpCode);
	sPutVal(hFileSysKey, "CheckRemoveable",gdwCheckRemoveable);
	sPutVal(hFileSysKey, "ClientNotify", gdwClientNotify);
	sPutStr(hFileSysKey, "ClientReportFormat",gszReportFormat);
	sPutStr(hFileSysKey, "DriveList", gszDriveList);
	sPutVal(hFileSysKey, "Execs", gdwExecs);
	sPutVal(hFileSysKey, "Floppys", gdwFloppys);
	sPutVal(hFileSysKey, "HardDisks", gdwHardDisks);
	sPutVal(hFileSysKey, "HaveExceptionDirs",gdwHaveExceptionDirs);
	sPutVal(hFileSysKey, "HoldOnClose", gdwHoldOnClose);
	sPutVal(hFileSysKey, "Networks", gdwNetworks);
	sPutVal(hFileSysKey, "OnOff", gdwOnOff);
	sPutVal(hFileSysKey, "Reads", gdwReads);
	sPutVal(hFileSysKey, "Softmice", gdwSoftmice);
	sPutVal(hFileSysKey, "Trap", gdwTrap);
	sPutStr(hFileSysKey, "TrapConfig\\Exts", gszTrapExts);
	sPutVal(hFileSysKey, "Writes", gdwWrites);
	sPutVal(hFileSysKey, "Types", gdwTypes);
	
//	tmm: this variable is never changed, so it doesn't need to be written out
//	sPutStr(hFileSysKey, "SkipExts", gszSkipExts);

    // MMENDON 08-21-2000 STS defect 340457:  if error reading exts from registry, extensions global string will be "".
    //                                        want to scan all files, but not write values back to registry.
    if(gszExts[0])
    {
        sPutStr(hFileSysKey, "Exts", gszExts);
        sPutVal(hFileSysKey, "FileType", gdwFileType);
    }
	else
	{
        dprintf("Error getting RTS extensions.  Not saving extension settings.\n");
	}

    // MMENDON 08-21-2000 End STS defect 340457

	sPutVal(hFileSysKey, "ZipFile", gdwZipFile);
//	sPutStr(hFileSysKey, "ZipExts", gszZipExts);
	sPutVal(hFileSysKey, "ZipDepth", gdwZipDepth);

}
**/

// ksr
#endif // 0



//============================================================================
/*****************************************************************************/
/*****************************************************************************/
void DumpData(unsigned char *data,int len) {

	int i;
	FILE *file;

	for (i=0;i<len;i++) {
		if (i%16 == 0) {
			dprintf("\n%04X:  ",i);
			}
		dprintf("%02X ",data[i]);
		if (i%8 == 0) {
			dprintf(" ");
			}
		if (i%4 == 0) {
			dprintf(" ");
			}
		}

	file = fopen("version.dmp","wt");
	if (file) {
		for (i=0;i<len;i++) {
			if (i%16 == 0)
				fprintf(file,"\n%04X:  ",i);
			fprintf(file,"%02X ",data[i]);
			if (i%8 == 0)
				fprintf(file," ");
			if (i%4 == 0)
				fprintf(file," ");
			}
		fclose(file);
		}
}
/*****************************************************************************/
/*
#ifdef WINNT
DWORD AnalyzeKernel(BYTE *data) {
    REF ( data );
	return 0;

}
//*****************************************************************************
DWORD ReadExtraKernelData(void) {
	return 0;
}
#endif //WINNT
*/

/*****************************************************************************/

DWORD DriverHook(void) 
{
/*
#if defined(USING_NAVAP)

    HCURSOR hCur = SetCursor(LoadCursor(NULL,IDC_APPSTARTING));

    if ( StartNAVAP() )
    {
        isOn = TRUE;
        gdwOnOff = TRUE;
        //WriteRegistry2();

        SetCursor(hCur);

        return ERROR_SUCCESS;
    }

    

    SetCursor(hCur);


    return P_PSCAN_START_ERROR;

#else
*/
	DWORD dw,cc,ret=0;
	
/**
#ifdef WINNT
	unsigned char data[64];

	ReadExtraKernelData();
#endif // WINNT
**/

	if (hDevice) 
	{
		cc = DeviceIoControl(hDevice,(ULONG)IOCTL_START_CAPTURE,NULL,0,&ret,sizeof(ret),&dw,NULL);
		if (cc)
			cc = ret;
		else
			return P_PSCAN_START_ERROR;

		if (cc == 0) 
		{
			dprintf("Hook Successful\n");
done:
			isOn = TRUE;
			gdwOnOff = TRUE;
			//WriteRegistry2();
			return ERROR_SUCCESS;
			}
		else if (cc == K_ALREADY_RUNNING) 
		{
			dprintf("WARRNING - Hook was already active, reattached\n");
			goto done;
			}
/**
#ifdef WINNT
		else if (cc == K_HOOK_FAILED) {
			dprintf("Hook Un-Successful\n");
			return P_HOOK_BAD;
			}
		else if (cc == K_NO_VERSION_MATCH) {
			DeviceIoControl(hDevice,(ULONG)IOCTL_INQUIRE_SYSTEM,NULL,0,data,64,&dw,NULL);
			DumpData(data,64);
			dprintf("\nAnalyzing data...\n");
			if (AnalyzeKernel(data) == ERROR_SUCCESS) {
				cc = DeviceIoControl(hDevice,(ULONG)IOCTL_START_CAPTURE,NULL,0,&ret,sizeof(ret),&dw,NULL);
				if (cc)
					cc = ret;
				else
					return P_PSCAN_START_ERROR;
				if (cc == 0)
					goto done;
				}
			dprintf("Hook Un-Successful\n");
			return P_HOOK_BAD;
			}
#endif// WINNT
**/
		dprintf("Unknown return code %08X from kernel\n",cc);
		//sPutVal(hFileSysKey, "KernelHookCode",cc);
		return P_BAD_KERNAL_CODE;
		}
	return P_NO_DEVICE_HANDLE;
//#endif
}

/********************************************************************************/

BOOL _DriverUnHook(BOOL write) 
{
/*
#if defined(USING_NAVAP)

    HCURSOR hCur = SetCursor(LoadCursor(NULL,IDC_APPSTARTING));

    if ( StopNAVAP() )
    {
        if ( write )
        {
            isOn = FALSE;
            gdwOnOff = FALSE;
            //WriteRegistry2();
        }

        SetCursor(hCur);

        return TRUE;
    }

    SetCursor(hCur);

    return FALSE;

#else
*/
	DWORD dw;

	if(hDevice) 
	{
		if (DeviceIoControl(hDevice,(ULONG)IOCTL_END_CAPTURE,NULL,0,NULL,0,&dw,NULL)) 
		{
			dprintf("Un-Hook Successful\n");
			if (write) 
			{
				isOn = FALSE;
				gdwOnOff = FALSE;
				//WriteRegistry2();
			}
			return TRUE;
		}
		else 
		{
			dprintf("Un-Hook Un-Successful\n");
			return FALSE;
		}
	}
	return FALSE;
//#endif
}

/*******************************************************************************/

BOOL DriverUnHook(void) 
{
	return _DriverUnHook(TRUE);
}

/*********************************************************************************************************/

int Installer(int remove) 
{
/*
#if defined(USING_NAVAP)
    REF(remove);
    return 0;
#else
*/
	DWORD cc;
	
/**
#ifdef WIN32
	HCURSOR hCur = SetCursor(LoadCursor(NULL,IDC_APPSTARTING));
#endif // WIN32
**/
	if (remove) 
	{
		cc = RTShutdown(&hDevice);
		dprintf(".");
	}
	else
		if (!(cc = RTStartup(&hDevice))) 
		{
			UpdateSysPrams();
		}
/*
#ifdef WIN32
	SetCursor(hCur);
#endif // WIN32
*/
	//if (cc) {
		//sPutVal(hFileSysKey, "KernelStartCode", cc);
	//	}
	
	return cc?P_PSCAN_INSTALL_ERROR:ERROR_SUCCESS;
	
//#endif
}
//#endif  //SERVER

/****************************************************************************************/
char *GetDriveFromInstanceID(DWORD ID) {

	PIDEF cur = FileSystemInfoTable.InstanceBlocks;
	DWORD i;

	for (i=0;i<FileSystemInfoTable.InstanceCount;i++) {
		if (cur[i].InstanceID == ID)
			return cur[i].DisplayName;
		}

	return "[EMPTY]:";
}
/****************************************************************************************/
DWORD GetInstanceIDFromPath(char *path) {

	char *q;
	PIDEF cur = FileSystemInfoTable.InstanceBlocks;
	DWORD i=0;

	q = StrChar(path,':');
	if (q) {
		char c = q[1];
		q[1] = 0;
		for (i=0;i<FileSystemInfoTable.InstanceCount;i++)
			if (!stricmp(cur[i].DisplayName,path))
				break;
		q[1] = c;
		}

/*
#ifdef WIN32
	//check if the path is UNC
    if(path[0] == '\\' && path[1] == '\\')
    {
        i = FileSystemInfoTable.InstanceCount - 1;
        i = cur[i].InstanceID;
        return i;
    }
#endif
*/

	return i==FileSystemInfoTable.InstanceCount?0:cur[i].InstanceID;
}
/****************************************************************************************/
DWORD FillInstanceBlocks(void) {
/*
#ifdef WIN32
	UINT u,old;
	char vol[NAME_SIZE];
	char name[NAME_SIZE];
	BOOL cc;
	int i;
	PIDEF cur;
	char symbolic[16];
	char real[64];
	char tmp[16];
	int count=0;

	old = SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOOPENFILEERRORBOX);
	cur = FileSystemInfoTable.InstanceBlocks;

	memset(DriveTable,0,sizeof(DriveTable));

	for (i=0;i<26;i++) {
		WSprintf(symbolic,"%c:",i+'A');
		DriveTable[i].Wanted = TRUE;

		WSprintf(tmp,"%s\\",symbolic);
		DriveTable[i].Type = GetDriveType(tmp);

		if (QueryDosDevice(symbolic,real,128)) {
			mbstowcs(DriveTable[i].Real,real,128);
			mbstowcs(DriveTable[i].Symbolic,symbolic,10);
			}

		u = DriveTable[i].Type;
		cc = FALSE;
		memset(cur,0,sizeof(IDEF));
		switch(u) {
			case DRIVE_CDROM:
			case DRIVE_FIXED:
				cc=GetVolumeInformation(tmp,vol,sizeof(vol),NULL,NULL,NULL,name,sizeof(name));
				cur->InstanceID = i+128;
				goto x;
			case DRIVE_REMOTE:
				cur->InstanceID = i+256;
				goto x;
			case DRIVE_REMOVABLE:
				cur->InstanceID = i+1;
x:				cur->Type = IT_CAN_WALK|IT_CAN_RTS;
				cur->Type |= (u==DRIVE_CDROM?IT_CDROM:u==DRIVE_FIXED?IT_FIXED:u==DRIVE_REMOTE?IT_REMOTE:IT_REMOVABLE);
				strcpy(cur->DisplayName,symbolic);
				if (cc)
					strcpy(cur->VolumeName,vol);
				cur++;
				count++;
				break;
			}
		}

#ifdef WIN32
        // Extended the DriveTable[] by 1, to include the InstanceID for a UNC path.
        // The last item in DriveTable[] is the InstanceID for a UNC path.
	    memset( cur, 0, sizeof(IDEF) );
        DriveTable[i].Type = DRIVE_REMOTE;
        cur->InstanceID = i + 384;
        count++;
#endif

	FileSystemInfoTable.InstanceCount = count;

	SetErrorMode(old);
#endif // WIN32
**/

//#ifdef NLM
	PIDEF cur;
//	FILE_SERV_INFO fsInfo;  //gdf 04/08/00

	int  i, num, cnt=0; //gdf 04/08/00

//	char str[IMAX_PATH];
	char vol[64];

//	memset (&fsInfo, 0, sizeof(FILE_SERV_INFO));  //gdf 04/08/00
//	GetServerInformation(sizeof (FILE_SERV_INFO),&fsInfo); // gdf 04/08/00
//	MaxVolumes = fsInfo.maxVolumesSupported;  // gdf 04/08/00

	cur = FileSystemInfoTable.InstanceBlocks;

// gdf 03/24/00 The code in the following for loop was changed to scan
// the entire Netware "VOLID" table (0 - max volumes) not just 0 -
// number of volumes.  This deals with the case in which volumes do not
// reside in the "VOLID" sequentiall beginning with "VOLID[0]".  The
// Netware API GetServerInformation is used to find the max supported
// volume value.
	
//	num = GetNumberOfVolumes();         gdf 03/24/00
//	for (i=0;i<num;i++,cur++) {         gdf 03/24/00
	for (i=0; i<MaxVolumes; i++)     // gdf 03/24/00
	{
		memset(vol, 0, sizeof(vol)); //gdf 03/24/00
//		GetVolumeName(i,vol);   // gdf 03/24/00
		if(GetVolumeName(i, vol) == ESUCCESS)  // gdf 03/24/00
		{
			if(vol[0] != NULL)
			{
				cnt++;
				memset(cur,0,sizeof(IDEF));
				cur->InstanceID = i+512;
				cur->Type = IT_CAN_WALK|IT_CAN_RTS;
				cur->Type |= IT_FIXED;
				WSprintf(cur->DisplayName,"%s:",vol);
//		WSprintf(cur->VolumeName,"%s:",vol);				
				cur++;
			}
		}
	}		

//	FileSystemInfoTable.InstanceCount = i;
	FileSystemInfoTable.InstanceCount = cnt;  // gdf 03/24/00
//#endif //NLM
	return ERROR_SUCCESS;
}


/*********************************************************************************************************/

void FileTimer(void) 
{
	while (Inited) 
	{
/*
#if defined(USING_NAVAP)
        RefreshNAVAPStatistics();
#endif
*/
		NTxSleep(1000);
		}
}


/*********************************************************************************************************/

/*
DWORD Reinit(DWORD flags) 
{
	//HKEY hkey;

//#ifdef SERVER
	if ((flags&S_WANT_RTS) && !(CurrentFlags&S_WANT_RTS)) 
	{
		CurrentFlags |= S_WANT_CONFIG | S_WANT_WALK;
	}
//#endif //SERVEr

	if ((flags&S_WANT_WALK) && !(CurrentFlags&S_WANT_WALK)) 
	{
//#ifdef NLM //EA 11/16 support for scanning more than 32 volumes i.e support for max no of volumes the server supports
		FileSystemInfoTable.InstanceBlocks = malloc(sizeof(IDEF)*MaxVolumes);
//#else
//		FileSystemInfoTable.InstanceBlocks = malloc(sizeof(IDEF)*32);
//#endif
		if (FileSystemInfoTable.InstanceBlocks == NULL)
			return ERROR_MEMORY;

		FillInstanceBlocks();
		CurrentFlags |= S_WANT_WALK;
	}

   /* ksr ???
	if ((flags&S_WANT_CONFIG) && !(CurrentFlags&S_WANT_CONFIG)) {
		sCreateKey(NULL, "FileSystem\\RealTimeScan", &hkey);
		hFileSysKey = FileSystemInfoTable.hRTSConfigKey = hkey;
		CurrentFlags |= S_WANT_CONFIG;
		}
		** /

//#ifdef SERVER
	if ((flags&S_WANT_RTS) && !(CurrentFlags&S_WANT_RTS)) 
	{
		//ReadRegistry2();
		//WriteRegistry2();
		
		Installer(0);
		
//#ifdef NLM
		FSInited=TRUE;
//#endif //def NLM

		ReloadRTSConfig();
		
#if defined(USING_NAVAP)
		MyBeginThread((THREAD)FileTimer,NULL,"RTV File Timer");
#endif

		CurrentFlags |= S_WANT_RTS;
	}
		
//#endif //SERVER

	return ERROR_SUCCESS;
}
*/

/*********************************************************************************************************/

DWORD  FileStorageInit(DWORD flags,PSTORAGEINFO *info,HANDLE *han,PSSFUNCTIONS sFunctions) 
{
	//HKEY hkey;

	if (Inited)
		return 0xffffffff;
/*
#if defined(USING_NAVAP)
    
    InitializeCriticalSection(&RTSErrorLoggingLock);
    
    // flag for determining if an error has been logged if AutoProtect failed to load.
    // Only want to log the error once per file storage init.
    EnterCriticalSection(&RTSErrorLoggingLock);
        gbLoggedRTSLoadError = FALSE;
    LeaveCriticalSection(&RTSErrorLoggingLock);
    
    if ( !NAVAPiInit ( APServiceStart, APServiceStop ) )
        return 0xffffffff;
#endif
*/
	SFunctions = sFunctions;
	//hFileSysKey = NULL;
	CurrentFlags = flags;

	if (flags&(S_WANT_WALK|S_WANT_RTS)) 
	{
//#ifdef NLM //EA 11/16 support for scanning more than 32 volumes i.e support for max no of volumes the server supports
		FileSystemInfoTable.InstanceBlocks = malloc(sizeof(IDEF)*MaxVolumes);
//#else
//		FileSystemInfoTable.InstanceBlocks = malloc(sizeof(IDEF)*32);
//#endif
		if (FileSystemInfoTable.InstanceBlocks == NULL)
        {
/*
#if defined(USING_NAVAP)
            NAVAPiDeInit();
#endif
*/
			return ERROR_MEMORY;
        }

		FillInstanceBlocks();
		CurrentFlags |= S_WANT_WALK;
	}


	*info = &FileSystemInfoTable;
	*han = (HANDLE)1;

   /** ksr
	if (flags&(S_WANT_CONFIG|S_WANT_RTS)) {
		sCreateKey((HKEY)HKEY_VP_STORAGE_REALTIME, "FileSystem", &hkey);
		hFileSysKey = FileSystemInfoTable.hRTSConfigKey = hkey;
		CurrentFlags |= S_WANT_CONFIG;
		}
		**/

//#ifdef SERVER
	if (flags&S_WANT_RTS) 
	{
		//ReadRegistry2();
		//WriteRegistry2();
		Installer(0);
		
//#ifdef NLM
		FSInited=TRUE;
//#endif //def NLM

		ReloadRTSConfig();

/*		 ksr ????

#if defined(USING_NAVAP)
		MyBeginThread((THREAD)FileTimer,NULL,"RTV File Timer");
#endif
*/
	}
//#endif //SERVER

	Inited = TRUE;
	return ERROR_SUCCESS;
}


/************************************************************************************************************/

DWORD  Deinit(HANDLE handle) 
{

	if (handle == (HANDLE)1 && Inited) 
	{
		if (CurrentFlags&S_WANT_RTS) 
		{
//#ifdef SERVER
			if (isOn) 
			{
				dprintf("Un hooking from file system\n");
				_DriverUnHook(FALSE);
				}

			NTxSleep(250); // give things a chance to settle down

			Installer(1);

			NTxSleep(250); // give things a chance to settle down
//#endif //SERVER
			}

        NAVFree(FileSystemInfoTable.InstanceBlocks);

      /**
		if (hFileSysKey)
			sCloseKey(hFileSysKey);
		**/

		Inited = FALSE;
/*		
#if defined(USING_NAVAP)
        DeleteCriticalSection(&RTSErrorLoggingLock);
        NAVAPiDeInit();
#endif
*/
		return ERROR_SUCCESS;
	}
	else
		return 0xffffffff;
}


/***********************************************************************************************************/

DWORD GetExtendedData(PSNODE node,char *KeyName,BYTE *Data,DWORD len) 
{
//#if defined (WINNT) || defined(NLM)
	return GetEA(((PFILE_ACTION)(node->Context))->AnsiName,KeyName,Data,len);
/*
#else
	REF(node);
	REF(KeyName);
	REF(Data);
	REF(len);
	return ERROR_FUNCTION_NOT_SUPPORTED;
#endif  //defined (WINNT) || defined(NLM)
*/
}


/***********************************************************************************************************/

DWORD SetExtendedData(PSNODE node,char *KeyName,BYTE *Data,DWORD len) 
{
//#if defined (WINNT) || defined(NLM)
	return SetEA(((PFILE_ACTION)(node->Context))->AnsiName,KeyName,Data,len);
/*#else
	REF(node);
	REF(KeyName);
	REF(Data);
	REF(len);
	return ERROR_FUNCTION_NOT_SUPPORTED;
#endif //defined (WINNT) || defined(NLM)
*/
}


/***********************************************************************************************************/

DWORD  GetState(PSNODE node,BYTE *Data) 
{
	return GetFileState(((PFILE_ACTION)(node->Context))->AnsiName,Data);
}


/***********************************************************************************************************/

DWORD  SetState(PSNODE node,BYTE *Data) {
	return SetFileState(((PFILE_ACTION)(node->Context))->AnsiName,Data);
}


/***********************************************************************************************************/

DWORD	myaccess(PSNODE node,int type) {
/*
#ifdef WIN32
	if (type == 2 || type == 55) 
    {
        // if the file is being quarantined by AutoProtect, the file name needs to come from a different
        // location.  AnsiName is the name of the actual file that AP has already deleted.  AP created a temp file
        // whose name can be found in node->Context->Process.  This is the file name that needs to be passed
        // when checking if the volume can be written to.  Fix for STS defect #147907.
        if( node->Operations & FA_COMING_FROM_NAVAP && (LPTSTR)((PFILE_ACTION)node->Context)->Process )
		{
			if (!isDiskWriteable((LPTSTR)((PFILE_ACTION)node->Context)->Process))
				return 0xffffffff;
		}
        else
        {
		    if (!isDiskWriteable(((PFILE_ACTION)(node->Context))->AnsiName))
			    return 0xffffffff;
        }
		 if (type == 55)
			return 0;
	}
#endif //WIN32
*/

	return access(((PFILE_ACTION)(node->Context))->AnsiName,type);
}


/***********************************************************************************************************/

DWORD	MyFSOpen(PSNODE node,DWORD access) 
{
/*
#ifndef NLM    //ML
    if ( ( node->Operations & FA_COMING_FROM_NAVAP ) && ( ((PFILE_ACTION)node->Context)->Process ) )
        return FIOOpen ( (LPTSTR)((PFILE_ACTION)node->Context)->Process, access );
#endif
*/
	return FIOOpen(((PFILE_ACTION)(node->Context))->AnsiName,access);
}
/***********************************************************************************************************/
/*
#if defined _MSC_VER
#pragma warning(disable: 4200)
#endif // _MSC_VER
*/

typedef struct {
	HANDLE han;
	DWORD ID;
	WIN32_FIND_DATA fd;
	char path[];
	} MYFD;

/*
#if defined _MSC_VER
#pragma warning(default: 4200)
#endif // _MSC_VER
*/
/**********************************************************************************************************/
DWORD FillSNode(PFILE_ACTION Action,PSNODE node) {

	char *q;

	node->Sid           = Action->TokenUser.Sid;
	node->UID           = Action->UID;
	node->InternalPath  = Action->AnsiName;
	node->IO            = &FileTable;
	node->Flags         = N_FILENODE;
	node->Operations    = Action->Flags;
	node->Context       = (void *)Action;
	node->Functions     = &NFunctions;

	q = StrRChar(node->Description,'.');
	if (q)
		StrNCopy(node->Ext,q+1,sizeof(node->Ext));

	q = StrRChar (node->Description,'\\');
	if (q)
		StrNCopy(node->Name,q+1,sizeof(node->Name));
	else
		StrNCopy(node->Name,node->Description,sizeof(node->Name));

	return ERROR_SUCCESS;
}
/************************************************************************************************************/
DWORD ProcessNodeFile(MYFD *mfd,PQNODE query,PSNODE node) {

	char *name;
	char *key = 0;
	char *q;
    BYTE Data[1024];
	PFILE_ACTION Action=0;
	
	int   i;

/*

#ifdef WIN32  

//#if defined(NLM) || defined(WIN32)	 // gdf 07/19/00 //EA 07/20/2000 start fix for STS 340035
    char szTempPath[IMAX_PATH] = "\0";
//#ifdef NLM //gdf 07/19/00 
  	char szLongPath[IMAX_PATH] = "\0"; //gdf 07/19/00
  	char *pos; //gdf 07/19/00
  	if (mfd->fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY) //EA 07/20/2000 do the conversion only for directory since filenames are
  	{														//not displayed and it was also causing a condn of short path
  		memset(szLongPath, 0, IMAX_PATH);  //gdf 07/19/00	//with long file name attached to it
  		memset(szTempPath, 0, IMAX_PATH);  //gdf 07/19/00
  		WSprintf(szTempPath, "%s\\%s",mfd->path, mfd->fd.cFileName);   //gdf 07/19/00
  		ConvertToLongName(szLongPath, szTempPath, IMAX_PATH, 0); //gdf 07/19/00
  
  		pos = strrchr(szLongPath, '\\');  //gdf 07/19/00
   
  		if(pos && *(pos+1)!= 0)   //gdf 07/19/00
  			strcpy(mfd->fd.cFileName, pos+1);   //gdf 07/19/00
  	}
#endif	   //EA 07/20/2000 end fix for STS 340035
**/

    // save the cFileName to retain the LFN.
    key = mfd->fd.cFileName;
	name = mfd->fd.cFileName;
//#else
  	//int 
  	i = NumBytes(mfd->fd.cFileName);
   
  	if (i > MAX_USED_PATH)
      {
          name = mfd->fd.cAlternateFileName;
          key = mfd->fd.cAlternateFileName;
      }
  	else
      {
  		name = mfd->fd.cFileName;
          key = mfd->fd.cFileName;
      }
//#endif

	if (query) {
		query->Flags = 0;
		strcpy(query->Name,name);
		strcpy(query->Key,key);
		q = StrRChar(name,'.');
		if (q)
			StrNCopy(query->Ext,q+1,sizeof(query->Ext));
		}

	if (mfd->fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY) 
	{
		if (query == NULL)
			return 0xffffffff;
		if (mfd->fd.cFileName[0] != '.') 
		{
			query->Flags = N_DIRNODE;
			}
		else
			return 0xffffffff;
		}
	else 
	{

		if (NumBytes(mfd->path) + NumBytes(name) > IMAX_PATH)
			return ERROR_NO_MORE_ROOM;

		if (node) 
		{
			Action = malloc(sizeof(FILE_ACTION));
			if (Action == NULL)
				return ERROR_MEMORY;

			memset(Action,0,sizeof(FILE_ACTION));
			memset(node,0,sizeof(SNODE));
			}

		if (query) {
			query->Flags = N_ENDNODE;
			if (isFileCompressed(mfd->fd.dwFileAttributes))
				query->Flags |= N_COMPRESSED;
			}

		if (node) 
		{
		/**
#ifdef WIN32
            // If the use of LFN results in a failure to access
            // the file try using the SFN.  This seems to solve
            // the problem with certain High-Ascii characters.
            WSprintf(szTempPath, "%s\\%s",mfd->path,name);

            if( lstrlen(szTempPath) +1 >= MAX_PATH || (GetFileState(szTempPath, &Data) == ERROR_FILE_NOT_FOUND)  )
            {
                if( mfd->fd.cAlternateFileName && (lstrlen(mfd->fd.cAlternateFileName) > 0) )
                    name = mfd->fd.cAlternateFileName;
                else
                    ERROR_NO_MORE_ROOM;
            }
#endif
**/

			WSprintf(Action->AnsiName,"%s\\%s",mfd->path,name);
			Action->TokenUser.Sid = MainSid;

			node->InstanceID = mfd->ID;
			StrCopy(node->Description,Action->AnsiName);
			FillSNode(Action,node);
			}
		}

	return ERROR_SUCCESS;
}
/***********************************************************************************************************/
DWORD CreateSNode(DWORD InstanceID,char *path,PSNODE node) {

	PFILE_ACTION Action;

	memset(node,0,sizeof(SNODE));

	Action = malloc(sizeof(FILE_ACTION));
	if (Action) {
		memset(Action,0,sizeof(FILE_ACTION));


		if (InstanceID >= 2048 && InstanceID < 2049) { // they want a boot memory node
			WSprintf(node->Description, LS(IDS_S_SCANNING_MEM));
			WSprintf(Action->AnsiName,"%s",node->Description); // does not work for japan

			Action->TokenUser.Sid = MainSid;
			node->InstanceID = InstanceID;
			FillSNode(Action,node);
			node->Flags = N_MEMNODE;
			return ERROR_SUCCESS;
			}

		if (InstanceID >= 1024 && InstanceID < 1152) { // they want a boot sector node
			int i = InstanceID - 1024;
			if (i >= 26) {
				WSprintf(node->Description,LS(IDS_NODEDESC_MBR),i-26);
				WSprintf(Action->AnsiName,"%c:",i-26+'C'); // does not work for japan
				}
			else {
				WSprintf(node->Description,LS(IDS_NODEDESC_BOOTSECTOR),i+'A');
				WSprintf(Action->AnsiName,"%c:",i+'A');
				}

			Action->TokenUser.Sid = MainSid;
			node->InstanceID = InstanceID;
			FillSNode(Action,node);
			node->Flags = N_BOOTNODE;
			return ERROR_SUCCESS;
			}

/**
#ifdef WIN32
        //  UNC paths will have an InstanceID greateer than 384 and less than 1024
        if( InstanceID >= 384 && InstanceID < 1024 )
        {

            if (access(path,0)) {
			    free(Action);
			    return 2;
			}

            StrCopy(Action->AnsiName, path);
            StrCopy(node->Description, path);
            node->InstanceID = InstanceID;

            //rchinta - TODO: Secure Environment Issue.  Is the following code
            // appropriate for console initiated scans in the absence of 
            // a logged on user for VirusSweeps etc. ?

            // preferred - Using the User SID instead of the System SID (MainSid).
            GetSid(&Action->TokenUser.Sid);

            // Action->TokenUser.Sid = MainSid;
            FillSNode(Action, node);
            return ERROR_SUCCESS;
        }
#endif
**/

		WSprintf(Action->AnsiName,"%s%s",GetDriveFromInstanceID(InstanceID),path);

		if (access(Action->AnsiName,0)) {
			free(Action);
			return 2;
			}

		Action->TokenUser.Sid = MainSid;
		node->InstanceID = InstanceID;
		StrCopy(node->Description,Action->AnsiName);
		FillSNode(Action,node);
		}
	else
		return ERROR_MEMORY;

	return ERROR_SUCCESS;
}
/***********************************************************************************************************/
/*
HANDLE FindFirstNode(HANDLE parent,DWORD InstanceID,char *path,PQNODE query,PSNODE node) {

	HANDLE h;
	char p[IMAX_PATH];
	MYFD *mfd;
	MYFD *pmfd = (MYFD*)parent;
	DWORD cc;

	if (node)
		memset(node,0,sizeof(SNODE));

	if (pmfd)
		WSprintf(p,"%s\\%s",pmfd->path,path);
	else
		WSprintf(p,"%s%s",GetDriveFromInstanceID(InstanceID),path);
/*
#ifdef WIN32
	if (isRemovableGone(p))
		return (HANDLE)ERROR_NOT_READY;
#endif //WIN32
** /
	cc = ERROR_MEMORY;
	mfd = malloc(sizeof(MYFD)+NumBytes(p)+1);
	if (mfd) {
//#ifdef NLM   // gdf 07/19/00 //EA 07/20/2000 start fix for STS 340035
  		char szTempConvLongPath[IMAX_PATH];
  		char szTempSFNPath[MAX_PATH];  // gdf 07/19/00
  		char szVolPath[IMAX_PATH];
  		memset(szTempConvLongPath, 0, IMAX_PATH);  // gdf 07/19/00
  		memset(szTempSFNPath, 0, MAX_PATH);  // gdf 07/19/00
  		//EA 07/20/2000 Need to convert the vol path until the dir to long since otherwise it will be a combination of short and long
  		memset(szVolPath, 0 , IMAX_PATH);
  		if (pmfd)
  		{
  			strcpy(szVolPath,pmfd->path);
  		}
  		else
  		{
  			strcpy(szVolPath,GetDriveFromInstanceID(InstanceID));
  			szVolPath[strlen(szVolPath) - 1] = '\0';
  
  		}
  		if(ConvertToLongName(szTempConvLongPath, szVolPath, IMAX_PATH, 0) == TRUE)
  			WSprintf(szTempConvLongPath,"%s\\%s",szTempConvLongPath,path);
  		else
  			strcpy(szTempConvLongPath,p);
  		if(ConvertToShortName(szTempSFNPath, szTempConvLongPath, MAX_PATH, 4))  // gdf 07/19/00
  			strcpy(p, szTempSFNPath);   // gdf 07/19/00
  		dprintf("The short format of szTempSFNPath %s\r\n",szTempSFNPath);
//#endif //EA 07/20/2000 end fix for STS 340035
		StrCopy(mfd->path,p);
		StrCat(p,"\\*.*");
		h = FindFirstFile(p,&mfd->fd);
		cc = ERROR_NO_MORE;
		if (h != INVALID_HANDLE_VALUE) {
			mfd->han = h;
			mfd->ID = InstanceID;
			cc = 0;
			do  {
				if (cc == 0xffffffff) {
					cc = FindNextFile(mfd->han,&mfd->fd);
					if (!cc) {
						cc = ERROR_NO_MORE;
						break;
						}
					}
				cc = ProcessNodeFile(mfd,query,node);
				} while (cc == 0xffffffff);
			if (cc == ERROR_SUCCESS)
				return (HANDLE)mfd;
			FindClose(h);
			}
			/*
#ifdef WIN32
        else
            {
                DWORD dwError = GetLastError();
                switch(dwError)
                {
                // Fix for STS#339403.  Trapped a few more errors.  It is
                // possible there are other errors that may need to be trapped too.
                case ERROR_ACCESS_DENIED:
                case ERROR_UNRECOGNIZED_VOLUME:
                case ERROR_BAD_NETPATH:
                case ERROR_BAD_NET_NAME:
                case ERROR_DEV_NOT_EXIST:
                case ERROR_NETNAME_DELETED:
                case ERROR_NETWORK_ACCESS_DENIED:
            	    dprintf("FindFirstFile fails - Access denied to Path (win32 error code: %d)\n", dwError);
                    free(mfd);
                    return (HANDLE)ERROR_ACCESS_DENIED;
                    break;
                default:
                    break;
                }
            }
#endif
** /
		free(mfd);
		}

	dprintf("FindFirstFile fails because %08X\n",cc);
	return INVALID_HANDLE_VALUE;
}
*/

/***********************************************************************************************************/
/*
DWORD  FindNextNode(HANDLE handle,PQNODE query,PSNODE node) {

	DWORD cc;
	MYFD *mfd = (MYFD*)handle;

	if (node)
		memset(node,0,sizeof(SNODE));

	do 
	{
		cc = FindNextFile(mfd->han,&mfd->fd);

		if (!cc) 
		{
			cc = ERROR_NO_MORE;
			break;
			}

		cc = ProcessNodeFile(mfd,query,node);
		} while (cc == 0xffffffff);

	return cc;
}
*/
/***********************************************************************************************************/
DWORD  ReleaseSNode(PSNODE node) {

	NAVFree(node->Context);
	return 0;
}
/***********************************************************************************************************/
/*
DWORD GetFullNodeKey(PSNODE node,char *buffer) {

	char *q = StrChar(((PFILE_ACTION)(node->Context))->AnsiName,':');
	if (q) {
		StrCopy(buffer,q+1);
		return ERROR_SUCCESS;
		}
	return ERROR_GENERAL; // this should NEVER happen
}
*/

/***********************************************************************************************************/
/*
DWORD GetFullFindKey(HANDLE handle,char *buffer) {

	MYFD *mfd = (MYFD*)handle;

	StrCopy(buffer,mfd->path+2);

	return ERROR_SUCCESS;
}
*/

/***********************************************************************************************************/
/*
DWORD  mFindClose(HANDLE handle) {

	MYFD *mfd = (MYFD*)handle;
	DWORD cc;

	cc = FindClose(mfd->han);
	free(mfd);
	return cc;
}
*/


/***********************************************************************************************************/

DWORD  NodeHasVirus(PSNODE node,PEVENTBLOCK eb) {
	REF(node);REF(eb);

	return ERROR_SUCCESS;
}


/***********************************************************************************************************/
//#ifdef SERVER

DWORD ProcessAction(PROCESSRTSNODE Process,PSNODE node,void *UserContext,PFILE_ACTION Action) 
{
	DWORD cc;
//	char *q;

/*
#ifdef WIN32
	BOOL oem = FALSE;
#endif //WIN32
*/
	memset(node,0,sizeof(SNODE));

/*
#ifdef WIN32  // input is UNICODE might be long or short
    if ( !(Action->Flags & FA_COMING_FROM_NAVAP) || !(Action->Flags & FA_SCAN_BOOT_SECTOR) )
    {
    // MMENDON 04-07-2000:  STS defect 332261 - ConvertFileName is converting the AnsiName
    //                                          to a short name. When the file is quarantined,
    //                                          the LongPathName cannot be determined because
    //                                          AutoProtect has already deleted the file.
    //                                          When the file is coming from AP, we will no longer
    //                                          call ConvertFileName.
        if(Action->Flags & FA_COMING_FROM_NAVAP)
        {                          //Name is unicode
	        if (Action->Name[0]) 
            {
		        Action->AnsiName[0] = 0;
		        if(-1 == wcstombs(Action->AnsiName,Action->Name,sizeof(Action->AnsiName))) 
                {
			        WideCharToMultiByte(CP_OEMCP,0,Action->Name,-1,Action->AnsiName,sizeof(Action->AnsiName),NULL,NULL);
			        oem = TRUE;
			    }
            }
	        GetLongPathName(Action->AnsiName,Action->LongPathName, sizeof(Action->LongPathName));
        }
        else
	        oem = ConvertFileName(Action->LongPathName,Action->AnsiName,Action->Name,sizeof(Action->AnsiName));
    // MMENDON 04-07-2000:  End STS defect 332261
    }
    else
    {
        oem = FALSE;
        StrCopy ( Action->LongPathName, Action->AnsiName );
    }
	StrCopy(node->Description,Action->LongPathName);
#endif //WIN32
**/

//#ifdef NLM  // input is in namespace of Action->NameSpace  Output the namespace 0 name and long filename
	if (isNSName(Action->Name,0)) {					// if it is a short name
		StrCopy (Action->AnsiName,Action->Name);	// copy it to ansi name
		StrCopy (node->Description,Action->Name);	// copy it to ansi name
		}
	else {											// else convert to short
		if (!ConvertToShortName(Action->AnsiName,Action->Name,sizeof(Action->AnsiName),Action->NameSpace)) {
			StrCopy (Action->AnsiName,Action->Name);	// copy it to ansi name
			dprintf ("Failed on ConvertToShortName\n");
			}
		StrCopy(node->Description,Action->Name);
		}
//#endif //NLM

	node->InstanceID    = GetInstanceIDFromPath(Action->AnsiName);
	FillSNode(Action,node);
    if ( Action->Flags & FA_COMING_FROM_NAVAP )
        node->Flags = N_RTSNODE | ( ( Action->Flags & FA_SCAN_BOOT_SECTOR ) ? N_BOOTNODE : N_FILENODE );
    else
        node->Flags = N_RTSNODE | N_FILENODE;

/*
#ifdef WIN32
	if (oem) {
		oem = !AreFileApisANSI();
		SetFileApisToOEM();
		}

  	if (!(node->Operations & FA_COMING_FROM_NAVAP) && gdwCheckRemoveable && DriveTable[Action->DriveIndex].Type == DRIVE_REMOVABLE) {
  		node->Operations |= FA_SCAN_BOOT_SECTOR;
  		}

	if (debug) { // norton does not want the easter egg showing up
		if (*(DWORD *)Action->AnsiName == *(DWORD *)"C:\\~") {
			if (*(DWORD *)(Action->AnsiName+4) == *(DWORD *)"LDVP")
				if (*(DWORD *)(Action->AnsiName+8) == *(DWORD *)"!!!.")
					if (*(DWORD *)(Action->AnsiName+12) == *(DWORD *)"COM") {
						dprintf("Found Easter Egg\n");
						MyBeginThread((THREAD)EasterEgg,NULL,"EasterEgg");
						}
			}
		}
#endif //WIN32
**/
	cc = Process(node,UserContext);

/**
#ifdef WIN32
	if (!oem)
		SetFileApisToANSI();
#endif //WIN32
**/
	return cc;
}
//#endif //SERVER


/***********************************************************************************************************/

//#ifdef SERVER

DWORD  BeginRTSWatch(PROCESSRTSNODE Process,PSNODE node,void *UserContext) 
{
/*
#if defined(USING_NAVAP)

    DWORD dwData;
    DWORD dwRealData;
    BYTE * pbyPacket;
    DWORD dwIOCode;
    PNAVAP_EVENTPROGRESSREPORTPACKET pPacket;
    PNAVAP_SCANMOUNTEDDEVICEPACKET pScanDevPacket;
    FILE_ACTION Action;
    BOOL cc;
    int slot;
    static LONG lUID = 1;
    char szQuarantineFile[260];
    DWORD dwFileStatus = 0xFFFFFFFF;

    pbyPacket = (BYTE *) malloc ( dwData = 2000 );
    if ( !pbyPacket )
        return 0;

    LOCK();
    for (slot=0;slot<MAX_THREADS;slot++)
        if (fShutDown[slot] == E_UNUSED) 
        {
            fShutDown[slot] = E_STARTED;
            break;
            }
    UNLOCK();

    do 
    {
        dprintf("+%u",slot) ;

        if (fShutDown[slot] != E_STARTED)
            break;

        dwRealData = dwData;
        cc = NAVAPiWaitForPacket ( pbyPacket, &dwRealData );

        if (fShutDown[slot] != E_STARTED)
            break;

        if (!cc) {
            break;
            }

        if ( dwRealData > dwData )
        {
            free ( pbyPacket );
            pbyPacket = (BYTE *) malloc ( dwData = dwRealData );
            if ( !pbyPacket )
                break;
            continue;
        }

        dwIOCode = *((DWORD *)pbyPacket);

        if ( dwIOCode == NAVAP_COMM_EVENTPROGRESSREPORT )
        {
            dwRealData -= sizeof(DWORD);
            pPacket = (PNAVAP_EVENTPROGRESSREPORTPACKET)&((DWORD *)pbyPacket)[1];

            if ( pPacket->dwLastSequencePacket && pPacket->dwAVContext == AVCONTEXT_SCANFILE )
            {
                __try {
                    if (Inited) {
                        BOOL bActionOK = TRUE;
                        BOOL bQuarFile = FALSE;

                        memset ( &Action, 0, sizeof(Action) );
                        GetSid(&Action.TokenUser.Sid);
                        Action.UID = InterlockedIncrement ( &lUID );

                        WideCharToMultiByte ( CP_ACP,
                                              0,
                                              &pPacket->szStringArray[pPacket->dwFileDeviceInTroubleIndex],
                                              -1,
                                              Action.AnsiName,
                                              sizeof(Action.AnsiName),
                                              NULL,
                                              NULL );
                        WideCharToMultiByte ( CP_ACP,
                                              0,
                                              &pPacket->szStringArray[pPacket->dwVirusNameIndex],
                                              -1,
                                              Action.VirusName,
                                              sizeof(Action.VirusName),
                                              NULL,
                                              NULL );
                        Action.VirusID = pPacket->dwVirusID;
                        // MMENDON 4/20/2000:  change for STS defect #333309
                        Action.Cleanable = pPacket->dwVirusCleanable;
                        Action.Deletable = pPacket->dwVirusDeletable;
                        // MMENDON 4/20/2000:  end change for STS defect #333309

                        // MMENDON 11/15/2000:  Terminal Server support.  Passing sessionID from kernel
                        Action.SessionID = pPacket->rUser.dwTerminalServerSessionID;
                        // MMENDON 11/15/2000:  End Terminal Server support.

                        switch ( pPacket->dwAction )
                        {
                        case AVACTION_CONTINUE:   Action.action = AC_NOTHING; Action.Flags = FA_COMING_FROM_NAVAP | FA_READ; break;
                        case AVACTION_STOP:       Action.action = AC_NOTHING; Action.Flags = FA_COMING_FROM_NAVAP | FA_READ | FA_BEFORE_OPEN; break;
                        case AVACTION_REPAIR:     Action.action = AC_CLEAN;   Action.Flags = FA_COMING_FROM_NAVAP | FA_READ; bQuarFile = DecodeNAVAPQuarantineFile ( pPacket, szQuarantineFile, &dwFileStatus, &Action ); break;
                        case AVACTION_DELETE:     Action.action = AC_DEL;     Action.Flags = FA_COMING_FROM_NAVAP | FA_READ | FA_BEFORE_OPEN; break;
                        case AVACTION_QUARANTINE: Action.action = AC_MOVE;    Action.Flags = FA_COMING_FROM_NAVAP | FA_READ | FA_BEFORE_OPEN; bActionOK = bQuarFile = DecodeNAVAPQuarantineFile ( pPacket, szQuarantineFile, &dwFileStatus, &Action ); break;
                        // case AVACTION_OK:
                        // case AVACTION_EXCLUDE:
                        // case AVACTION_MOVE:
                        // case AVACTION_RENAME:
                        // case AVACTION_SHUTDOWN:
                        default:
                            bActionOK = FALSE;
                        }

                        Action.Thread = (ULONG)pPacket;
                        // if file is to be quarantined, get the file name.
                        // if backed up to quarantine, set the flag for later processing
                        if ( bQuarFile )
                        {
                            Action.Process = (ULONG)szQuarantineFile;
                            if(QFILE_STATUS_BACKUP_FILE & dwFileStatus)
                                Action.Flags |= FA_BACKUP_TO_QUARANTINE;
                        }
                        // Check for macro virus so logging and alerting is done correctly
                        if(pPacket->dwMacroVirus)
                            Action.APVirusType = VEFILEMACROVIRUS;
                        else
                            Action.APVirusType = VEFILEVIRUS;

                        if ( bActionOK )
    	                    Action.Status = ProcessAction(Process,node,UserContext,&Action);
    	                }
                    else
    	                Action.Status = 0;
                    }
                __except(1) {
                    Action.Status = 0;
                    pStatBlock->Exceptions++;
                    }
            }
        }

        if ( dwIOCode == NAVAP_COMM_SCANMOUNTEDDEVICE )
        {
            char device;
            BOOL bDevice = FALSE;
            
            pScanDevPacket = (PNAVAP_SCANMOUNTEDDEVICEPACKET)&((DWORD *)pbyPacket)[1];
            device = (char)pScanDevPacket->szDevice[0];
            __try{
                memset ( &Action, 0, sizeof(Action) );
                GetSid(&Action.TokenUser.Sid);
                Action.UID = InterlockedIncrement ( &lUID );
                Action.Flags = FA_COMING_FROM_NAVAP | FA_SCAN_BOOT_SECTOR;
                Action.AnsiName[0] = device;
                strcat ( Action.AnsiName, ":" );
                if ( device >= 'A' && device <= 'Z' )
                    {
                    Action.DriveIndex = device - 'A';
                    bDevice = TRUE;
                    }
                if ( device >= 'a' && device <= 'z' )
                    {
                    Action.DriveIndex = device - 'a';
                    bDevice = TRUE;
                    }
                Action.Status = bDevice ? ProcessAction(Process,node,UserContext,&Action) : 0;
                }
            __except(1) {
                Action.Status = 0;
                pStatBlock->Exceptions++;
                }
        }
    } while ( SystemRunning );

	LOCK();
	fShutDown[slot] = E_UNUSED;
	UNLOCK();
	return 0;

#else // !USING_NAVAP
*/
	HANDLE hDrv=0;
	DWORD dwData;
	FILE_ACTION Action;
	BOOL cc;
	int slot;

	LOCK();
	for (slot=0;slot<MAX_THREADS;slot++)
		if (fShutDown[slot] == E_UNUSED) 
		{
			fShutDown[slot] = E_STARTED;
			break;
		}
	UNLOCK();

/**
#ifdef WINNT
	hDrv=CreateFile("\\\\.\\Pscan5",GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL/*|FILE_FLAG_OVERLAPPED****,NULL);
	if (hDrv == (HANDLE)-1)
		return P_NO_DEVICE_HANDLE;
#endif //WINNT
*/
	if (debug&DEBUGPRINT) {
		dprintf("Starting Scanning Thread.\n") ;
		}

	dwData = 100;
/*
#ifdef WINNT
	SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_HIGHEST);
//	SetPriorityClass(GetCurrentProcess(),REALTIME_PRIORITY_CLASS	 /* HIGH_PRIORITY_CLASS*);
#endif //WINNT
*/

	do 
	{
		dprintf("+%u",slot) ;

		if (fShutDown[slot] != E_STARTED)
			break;

		cc = !DeviceIoControl (hDrv, (DWORD)IOCTL_GET_ACTION, NULL, 0, &Action, sizeof (FILE_ACTION), &dwData, NULL) ;
		if (fShutDown[slot] != E_STARTED)
			break;

		if (cc) 
		{
error:
			dprintf("Error %u in DeviceIoControl\n",cc);
			break;
			}

		if (dwData == sizeof(FILE_ACTION)) 
		{
		/*
#ifdef WINNT
			if (hAccessToken && (DriveTable[Action.DriveIndex].Type==DRIVE_REMOTE)) {
				cc = ImpersonateLoggedOnUser(hAccessToken);
				dprintf("Tried to impersonate %u\n",cc);
				}
#endif //WINNT
*/
			__try {
				if (Inited) {
					Action.Status = ProcessAction(Process,node,UserContext,&Action);
					}
				else
					Action.Status = 0;
				}
/*
//#ifndef NLM
			__except(1) {
				Action.Status = 0;
				pStatBlock->Exceptions++;
				}
//#endif //NLM
*/

/*
#ifdef WINNT
			if (cc)
				RevertToSelf();
#endif //WINNT
*/
			cc = !DeviceIoControl (hDrv, (DWORD)IOCTL_COMPLETE_ACTION, &Action, sizeof (FILE_ACTION), NULL,0,&dwData, NULL) ;
			if (cc)
				goto error;
			}
						
			// ksr - added
			ThreadSwitch();
						
		} while ( SystemRunning );
/*
#ifdef WINNT
	CloseHandle(hDrv);
#endif //WINNT
*/
	LOCK();
	fShutDown[slot] = E_UNUSED;
	UNLOCK();
	
	return 0;

//#endif // USING_NAVAP
}
//#endif //SERVER


/***********************************************************************************************************/

//#ifdef SERVER

DWORD  StopRTSWatches(void )
{
	DWORD retval=0;
	int i,j;

	dprintf(".") ;

	LOCK();
	for(i=0;i<MAX_THREADS;i++) {
		if (fShutDown[i])
			fShutDown[i] = E_SHUTDOWN;
		}
	UNLOCK();
/*
#if defined(USING_NAVAP)
    REF(retval);
    NAVAPiReleaseWaiters();
#else
*/
	DeviceIoControl(hDevice,(ULONG)IOCTL_INTEL_SHUTDOWN,NULL,0,NULL,0,&retval,NULL);
//#endif

	for(j=0;j<MAX_THREADS;j++)
		for (i=0;i<1*18&&fShutDown[j]==E_SHUTDOWN;i++) {
			NTxSleep(55);
			dprintf(".");
			}
/*
#if defined(USING_NAVAP)
    NAVAPiBlockWaiters();
#endif
*/
	dprintf(".") ;
	return 0;
}
//#endif //SERVER


/***********************************************************************************************************/

DWORD  RemoveNode(PSNODE node) 
{
	FILE *file;
	PFILE_ACTION Action = (PFILE_ACTION)node->Context;
	/*
#ifndef NLM    //ML
    LPTSTR pszName = ( node->Operations & FA_COMING_FROM_NAVAP ) && ( ((PFILE_ACTION)node->Context)->Process ) ?
                        (LPTSTR)((PFILE_ACTION)node->Context)->Process :
                        Action->AnsiName;
#else //ML: if this is NLM
*/
    LPTSTR pszName = Action->AnsiName;
//#endif

	_my_chmod(pszName,1,FA_NORMAL);

	file = fopen(pszName,"w");
	if (file) 
	{
		fputs("WAS VIRUS!!! DESTROYED",file);
		fclose(file);
		}

	return unlink(pszName)==0?ERROR_SUCCESS:0xffffffff;
}


/***********************************************************************************************************/

DWORD ChangeUser(char *name,HANDLE x) 
{
	dprintf("File system was notified of new user %s:%u\n",name,x);

	return ERROR_SUCCESS;
}


/***********************************************************************************************************/
/*
#if defined(USING_NAVAP)

BOOL WINAPI APServiceStart ( char * pszName, char * pszLocation )
{
/*
#if defined(WINNT)
    return NTStartService ( pszName, pszLocation ) == 0 ? TRUE : FALSE;
#else
* /
    REF(pszName);
    REF(pszLocation);
    return TRUE;
//#endif
}


BOOL WINAPI APServiceStop ( char * pszName )
{
/*
#if defined(WINNT)
    return NTStopService ( pszName ) == 0 ? TRUE : FALSE;
#else
* /
    REF(pszName);
    return TRUE;
//#endif
}
*/




#if 0



BOOL StartNAVAP()
{
    if ( !hNAVAP )
    {
        char szLocation[260];

        if ( !GetModuleLocation ( szLocation ) )
        {
            PNAVAP_CONFIG pConfig = mallocAndBuildNAVAPConfiguration();

            if ( pConfig )
            {
                HANDLE hAP = NAVAPiStart ( szLocation );

                if ( hAP )
                {
                    if ( NAVAPiControlledInit ( hAP, pConfig ) )
                    {
                        SetNAVAPNotificationHandle ( hNAVAP = hAP );
                        hAP = NULL;
                    }
                }

                if ( hAP )
                    NAVAPiStop ( hAP );

                free ( pConfig );
            }
        }
    }
 
    // MMENDON 07-19-2000 - STS defect #340445:  Realtime stats displayed
    //                      in UI are now only to be file system stats and
    //                      no longer include mail realtime stats.
    //                      Setting 
    if(hNAVAP)
    {
        pStatBlock->LastVirusFoundAction = 0;
        pStatBlock->TimeStarted = vtime(0);
    }
        // MMENDON 07-19-2000 - STS defect #340445:  End change

    return hNAVAP ? TRUE : FALSE;
}

BOOL StopNAVAP()
{
    if ( hNAVAP )
    {
    //  MMENDON 09-30-2000 On Win9x, AutoProtect is unloaded early in the
    //                     shutdown process, opening a hole for infections 
    //                     to occur. If gbNotifyNavapVxdSysShutdown is TRUE, 
    //                     AutoProtect andNAVEX15.VXD, NAVENG.VXD will not          
    //                     be unloaded by rtvscn95. A handle is opened to 
    //                     NAVAP.VXD without the DELETE_ON_CLOSE flag and 
    //                     then closed.  This keeps the driver from being 
    //                     unloaded when rtvscn95 deletes DriverComm.  
    //                     DriverComm originally called CreateFile for 
    //                     NAVAP.VXD with the DELETE_ON_CLOSE flag set.
    //                     gbNotifyNavapVxdSysShutdown is true when the system 
    //                     is shutting down.  
/*
#if defined(WIN95)    

        if(gbNotifyNavapVxdSysShutdown)
        {
            TCHAR szPrefix[]  = _T("\\\\.\\");
            TCHAR szModule[] = _T("NAVAP.VXD");
            LPTSTR pszFullPath = NULL;
            TCHAR szPath[IMAX_PATH];
            HANDLE hDriver = INVALID_HANDLE_VALUE;
            size_t nPathSize;

            // Get the sfn path for NAVAP.VXD and convert it
            // to a form usable by CreateFile i.e.
            //  \\.\c:\progra~1\norton~1\navap.vxd
            if (GetModuleLocation( szPath ) == 0)
            {
                if(GetShortPathName(szPath, szPath, IMAX_PATH))
                {

                    nPathSize = _tcslen(szPrefix) + _tcslen(szModule) +
                                1 + _tcslen(szPath) + 1;
                                
                    // Allocate memory for the full path and 
                    pszFullPath = (LPTSTR) malloc(nPathSize);

                    if ( pszFullPath )
                    {
                        _tcscpy ( pszFullPath, szPrefix);
                        _tcscat ( pszFullPath, szPath);
                        _tcscat ( pszFullPath, "\\");
                        _tcscat ( pszFullPath, szModule);

                        // Open handle to vxd  without delete_on_close flag set
                        // then close it.
                        hDriver = CreateFile ( pszFullPath,
                                                0,
                                                0,
                                                NULL,
                                                0,
                                                0,
                                                NULL );

                        if(hDriver != INVALID_HANDLE_VALUE)
                        {
                            CloseHandle(hDriver);
                        }
                        free(pszFullPath);
                    }
                }
            }
            
            //  MMENDON 10-06-2000: Change for AutoProtect early shutdown
            //  Nullify the defs handle so an invalid
            //  handle will not be used to tell AP to
            //  load or unload its defs.

            EnterCriticalSection ( &rHandleLock );
                if(hNAVAPDefsNotify)
                    hNAVAPDefsNotify = NULL;
            LeaveCriticalSection ( &rHandleLock );

            //  MMENDON 10-06-2000: End change for AutoProtect early shutdown
        }
        else   // if StopNAVAP is being called at a time
               // other than system shutdown
        {
            SetNAVAPNotificationHandle ( NULL );
            NAVAPiControlledDeInit ( hNAVAP );
        }

#else
        // NT platforms
        SetNAVAPNotificationHandle ( NULL );
        NAVAPiControlledDeInit ( hNAVAP );

#endif
*/
    //  MMENDON 09-30-2000: End change for AutoProtect early shutdown
        
        NAVAPiStop ( hNAVAP );
        hNAVAP = NULL;


        // MMENDON 07-19-2000 - STS defect #340445:  Realtime stats displayed
        //                      in UI are now only to be file system stats and
        //                      no longer include mail realtime stats.
        //                      When AP is disabled, need to clear the status structure
        //                      Undid fix for STS defect 331636
        
        pStatBlock->LastVirusFoundAction = 0;
        memset(&pStatBlock->TimeStarted, 0, sizeof(pStatBlock->TimeStarted));
        memset(&pStatBlock->LastVirusFoundTime, 0, sizeof(pStatBlock->LastVirusFoundTime));
        pStatBlock->TotalScaned = 0;
        pStatBlock->VirusesFound = 0;
        pStatBlock->LastVirusFoundName[0] = 0;
        pStatBlock->LastVirusFoundFile[0] = 0;
        pStatBlock->LastVirusFoundUserName[0] = 0;
        memset ( &pStatBlock->LastVirusFoundUser, 0, sizeof(pStatBlock->LastVirusFoundUser) );
        pStatBlock->LastScaned[0] = 0;
        // MMENDON 07-19-2000 - STS defect #340445:  End change
    }

    return TRUE;
}




///////////////////////////////////////////////////////////////////////////////
//
// Function name: GetAutoProtectTempDir
//
// Description  : Get the AP temp directory for quarantine files.  Create it
//                if it does not exist.  
//
// Return Values: True if directory exists or created successfully
//                False otherwise  
//
// Argument     : [in/out] LPTSTR lpAPTempDir - Buffer to receive the AP temp
//                         directory.
//
///////////////////////////////////////////////////////////////////////////////
// MMENDON: 04-11-2000 - fix for STS defect #332943
// MMENDON: 02-01-2001 - fix for scandisk restart issue
///////////////////////////////////////////////////////////////////////////////

BOOL GetAutoProtectTempDir(LPSTR lpAPTempDir)
{
    TCHAR   szAppData[MAX_PATH] = {0};
    DWORD  dwError;
    BOOL   bSuccess = FALSE;
    DWORD dwAttrib;
    
    // check for a valid parameter
    if(!lpAPTempDir)
    {
        dprintf("GetAutoProtectTempDir param is NULL\n");
        return(FALSE);
    }

    // Attempt to get NAV's application dir and create an AP temp directory
    if (GetAppDataDirectory(NAV_COMMON_APP_DATA, szAppData) == ERROR_SUCCESS )
    {
        wsprintf(lpAPTempDir, "%s\\%s",szAppData, AUTOPROTECT_TEMP_DIR );
        
        // check to see if the directory exists
        dwAttrib = GetFileAttributes(lpAPTempDir);
        
        // if GetFileAttributes returned successfully
        if(dwAttrib != -1)
        {
            // check for directory attribute
            if(dwAttrib & FILE_ATTRIBUTE_DIRECTORY)
            {
                bSuccess = TRUE;
            }
            else
            {
                // GetFileAttributes succeeded, but returned attributes are not for a directory
                dprintf("GetAutoProtectTempDir: GetFileAttributes() , returned %ld\n", dwAttrib);
            }
        }
        // error in call to GetFileAttributes()
        else
        {
            // check error code for directory not found.  If true, create directory.
            dwError = GetLastError();
            if ( dwError == ERROR_FILE_NOT_FOUND || dwError == ERROR_PATH_NOT_FOUND )
            {
                if ( CreateDirectory(lpAPTempDir, NULL) )
                {
                    // set the correct access rights on the directory
                    if(SetDirectoryAccessAttributes(lpAPTempDir) == ERROR_SUCCESS)
                        bSuccess = TRUE;
                }
                else  // check to see if directory already exists
                {
                    dwError = GetLastError();
                    dprintf("GetAutoProtectTempDir: CreateDirectory() failed, error: %ld\n", dwError);
                }
            }
            else
            {
                dprintf("GetAutoProtectTempDir: GetFileAttributes() failed, error: %ld\n", dwError);
            }
        } //    if(dwAttrib != -1)
    }  //if (GetAppDataDirectory

            // if the directory doesn't exist or wasn't created
    if(!bSuccess)
    {
        lpAPTempDir[0] = '\0';
        dprintf("Error creating AP temp directory\n");
    }
    
    return(bSuccess);
}



PNAVAP_CONFIG mallocAndBuildNAVAPConfiguration()
{
    NAVAP_CONFIG Config;
    char *pConfig;
    DWORD DynamicLength = sizeof(Config);
    char szPath[260];
    char szTempPath[260];
    char szQuarantineLocation[260];
    char szMoveLocation[260];
    char szRenameExtension[260];
    char szAlertText[] = "";
    char szProgramExtensionList[EXT_LIST_SIZE];
    char szSpoolFileLocation[260];
    char szNAVAPLocation[260];
    char szNAVEXINFLocation[260];
    DWORD dwExclusionItems, dwExclusionLItems;
    PVOID pExclusionItems, pExclusionLItems;
    char *pszParse, *pszNext;
    DWORD a1, a2, am1, am2, dwAction;
    DWORD dwHeuristics;

    // Prepare dynamic length parameters.

    if ( GetModuleLocation ( szPath ) )
        return NULL;

    //  MMENDON 1/30/2000:  fix for STS defect #332943
    //                      For Win2k security, AP will
    //                      now be creating temp files for
    //                      quarantine in a directory off of
    //                      the NAV application dir (NAV dir
    //                      on NT4 and 9x, Applications dir on Win2k.
/*
    a1 = GetTempPath ( sizeof(szTempPath)/sizeof(*szTempPath), szTempPath );
    if ( a1 == 0 || a1 > sizeof(szTempPath)/sizeof(*szTempPath) )
        return NULL;
*/
    if(!GetAutoProtectTempDir(szTempPath))
        return(NULL);
    
    //  MMENDON 1/30/2000:  End fix for STS defect #332943

    if ( !CharToOem ( szPath, szPath ) )
        return NULL;

    if ( !CharToOem ( szTempPath, szTempPath ) )
        return NULL;

    strcpy ( szQuarantineLocation, szTempPath );

    strcpy ( szMoveLocation, szTempPath );

    strcpy ( szRenameExtension, "VIR" );

    // MMENDON 08-21-2000 STS defect 340457:  if error reading exts from registry, szProgramExtensionList will be "".
    //                                        want to scan all files in this case.
    
    /** ksr
    
    Config.dw_bScanAllFiles = sGetVal(hFileSysKey, "FileType", 1) == 1 ? FALSE : TRUE;
    sGetStr(hFileSysKey, "Exts", szProgramExtensionList, sizeof(szProgramExtensionList),"");
    if(!szProgramExtensionList[0])
    {
        Config.dw_bScanAllFiles = TRUE;
        dprintf("Error getting AP extensions.  Scanning all files.\n");
    }
    **/
   // MMENDON 08-21-2000 End STS defect 340457

        
        
    strcpy ( szSpoolFileLocation, szPath );

    strcpy ( szNAVAPLocation, szPath );

    strcpy ( szNAVEXINFLocation, szPath );

    // Prepare the exclusions list.

    dwExclusionItems = 0;
    dwExclusionLItems = 0;
    pExclusionItems = NULL;
    pExclusionLItems = NULL;
    pExclusionLItems = PrepareExclusions(&dwExclusionLItems);
    
    //*******  MMENDON: 2/08/00: Prescan exclusions change
        
    if(dwExclusionLItems)
        Config.dw_bExclusions = TRUE;
    else
        Config.dw_bExclusions = FALSE;
    
    //*******  MMENDON: 2/08/00: end prescan exclusions change
    
    
    // Initialize the configuration.

    // Startup options (used only with NAVAP_COMM_CONTROLLEDINITEX)
    Config.dw_bStartupScanMemory = FALSE;
    Config.dw_bStartupScanUpperMemory = FALSE;
    Config.dw_bStartupRunDOSAutoProtect = FALSE;

    // Global options
    Config.dw_bNAVAPCanBeDisabled = TRUE;

/**
    // File scan (known virus detection)
    dwHeuristics = sGetVal(hFileSysKey, szReg_Val_Heuristics, 1);
    if(dwHeuristics)
        Config.dw_uFileHeuristicLevel = sGetVal(hFileSysKey, szReg_Val_HeuristicsLevel, 2);
    else
        Config.dw_uFileHeuristicLevel = 0;

    Config.dw_bScanFileOnExecute = sGetVal ( hFileSysKey, "Reads", 1 );
    Config.dw_bScanFileOnOpen = Config.dw_bScanFileOnExecute;
    Config.dw_bScanFileOnCreate = sGetVal ( hFileSysKey, "Writes", 1 );

    a1  = sGetVal(hFileSysKey,"FirstAction",AC_NOTHING);
    a2  = sGetVal(hFileSysKey,"SecondAction",AC_NOTHING);
    am1 = sGetVal(hFileSysKey,"FirstMacroAction",AC_NOTHING);
    am2 = sGetVal(hFileSysKey,"SecondMacroAction",AC_NOTHING);

    a1 = ConvertToAPAction ( a1 );
    a2 = ConvertToAPAction ( a2 );
    am1 = ConvertToAPAction ( am1 );
    am2 = ConvertToAPAction ( am2 );

    Config.adw_auScanFileExeActions[0] = a1;
    Config.adw_auScanFileExeActions[1] = a2;
    Config.adw_auScanFileExeActions[2] = MAINACTION_DENYACCESS;
    Config.adw_auScanFileMacroActions[0] = am1;
    Config.adw_auScanFileMacroActions[1] = am2;
    Config.adw_auScanFileMacroActions[2] = MAINACTION_DENYACCESS;
**/
    Config.dw_uScanFilePrompts = 0;

    Config.dw_bDeleteInfectedOnCreate = TRUE;

                                    // Device scan
    Config.dw_bScanDeviceUponAccess = sGetVal(hFileSysKey, szReg_Val_ScanFloppyBROnAccess,1);
    Config.dw_bScanBootDeviceUponBoot = FALSE;
    Config.dw_bScanNonBootDevicesUponBoot = FALSE;

   // ksr
   /**????
    dwAction = sGetVal(hFileSysKey, szReg_Val_FloppyBRAction,AC_CLEAN);
    dwAction = ConvertToAPAction ( dwAction );
    **/
    Config.adw_auScanDeviceUponAccessActions[0] = dwAction;
    Config.adw_auScanDeviceUponAccessActions[1] = MAINACTION_LAST;
    Config.adw_auScanDeviceUponAccessActions[2] = MAINACTION_LAST;
    Config.adw_auScanDeviceUponBootActions[0] = MAINACTION_PROMPT;
    Config.adw_auScanDeviceUponBootActions[1] = MAINACTION_LAST;
    Config.adw_auScanDeviceUponBootActions[2] = MAINACTION_LAST;

    Config.dw_uScanDevicePrompts = fPROMPTACTION_OK;

                                    // Behavior block
    /**n ksr
    dwAction = sGetVal(hFileSysKey, szReg_Val_LowLevelFormat,1);
    dwAction = ConvertToVirusLikeAction ( dwAction );
    Config.adw_auFormatHardDiskActions[0] = dwAction;
    Config.adw_auFormatHardDiskActions[1] = MAINACTION_LAST;
    Config.adw_auFormatHardDiskActions[2] = MAINACTION_LAST;
    
    dwAction = sGetVal(hFileSysKey, szReg_Val_HardDriveBRWrite,1);
    dwAction = ConvertToVirusLikeAction ( dwAction );
    Config.adw_auWriteToHDBootRecordsActions[0] = dwAction;
    Config.adw_auWriteToHDBootRecordsActions[1] = MAINACTION_LAST;
    Config.adw_auWriteToHDBootRecordsActions[2] = MAINACTION_LAST;

    dwAction = sGetVal(hFileSysKey, szReg_Val_FloppyBRWrite,0);
    dwAction = ConvertToVirusLikeAction ( dwAction );
    Config.adw_auWriteToFDBootRecordActions[0] = dwAction;
    Config.adw_auWriteToFDBootRecordActions[1] = MAINACTION_LAST;
    Config.adw_auWriteToFDBootRecordActions[2] = MAINACTION_LAST;
   **/
   
   
    Config.adw_auWriteToProgramFilesActions[0] = MAINACTION_ALLOW;
    Config.adw_auWriteToProgramFilesActions[1] = MAINACTION_LAST;
    Config.adw_auWriteToProgramFilesActions[2] = MAINACTION_LAST;
    Config.adw_auROAttributeClearActions[0] = MAINACTION_ALLOW;
    Config.adw_auROAttributeClearActions[1] = MAINACTION_LAST;
    Config.adw_auROAttributeClearActions[2] = MAINACTION_LAST;

    Config.dw_uBehaviorBlockPrompts = fPROMPTACTION_STOP | fPROMPTACTION_CONTINUE;
    
    // File repair options
    /** ksr
    Config.dw_bBackupBeforeRepair = sGetVal(hFileSysKey, szReg_Val_BackupToQuarantine, TRUE);
    **/

    // File quarantine options
    Config.idx_pszQuarantineLocation = DynamicLength;
    DynamicLength += strlen ( szQuarantineLocation ) + 1;

    // File move options
    Config.idx_pszMoveLocation = DynamicLength;
    DynamicLength += strlen ( szMoveLocation ) + 1;

    // File rename options
    Config.idx_pszRenameExtension = DynamicLength;
    DynamicLength += strlen ( szRenameExtension ) + 1;

    // Workstation alerts
    Config.dw_bDisplayAlert = FALSE;
    Config.dw_bAudibleAlert = FALSE;
    Config.dw_uAudibleAlertDelay = 100;
    // remove virus-like activity alerts
    if(sGetVal(hFileSysKey, szReg_Val_RemoveAlert, 0))
        Config.dw_uAlertTimeOut = sGetVal(hFileSysKey, szReg_Val_RemoveAlertSeconds, 1);
    else
        Config.dw_uAlertTimeOut = 0;

    Config.dw_bScanNetwork = sGetVal ( hFileSysKey, szReg_Val_ScanNetwork, 1 );
        
    Config.idx_pszAlertText = DynamicLength;
    DynamicLength += strlen ( szAlertText ) + 1;

    // List of program extensions
    // mmendon, 10/14/99, fix for AP crash
    // the dynamic length need 2 added to it here instead of 1 because the kernel
    // mode parser requires 2 NULL chars at the end of the extension list.
    // One null char delimits the last extension,the last null char delimits the list.
    // Memsetting the allocated memory to zero below so that the list delimiter will be 0.
    Config.idx_pszzProgramExtensionList = DynamicLength;
    DynamicLength += strlen ( szProgramExtensionList ) + 2;

    // Long custom alert
    Config.idx_pszLongCustomAlert = 0;

    // Spool file
    Config.idx_pszSpoolFileLocation = DynamicLength;
    DynamicLength += strlen ( szSpoolFileLocation ) + 1;


    //*******  MMENDON: 1/27/00: Prescan exclusions change
    
    Config.dw_bCheckExcludePrescan = sGetVal ( hFileSysKey, szReg_Val_PrescanExclude, 0 );
    
    //*******  MMENDON: 1/27/00: end prescan exclusions change
    
    // Number of exclusion and long exclusion items, as well as arrays of exclusion and long exclusion items.
    Config.dwExclusionItems = dwExclusionItems;
    Config.dwExclusionLItems = dwExclusionLItems;
    Config.idx_arExclusionItems = DynamicLength;
    DynamicLength += dwExclusionItems * sizeof(OLDEXCLUDEITEM);
    Config.idx_arExclusionLItems = DynamicLength;
    DynamicLength += dwExclusionLItems * sizeof(LEXCLUDE_DAT);

    // Other options.  Used only with NAVAP_COMM_CONTROLLEDINITEX)
    Config.idx_pszAVAPILocation = 0;
    Config.idx_pszNAVAPLocation = DynamicLength;
    DynamicLength += strlen ( szNAVAPLocation ) + 1;
    Config.idx_pszNAVEXINFLocation = DynamicLength;
    DynamicLength += strlen ( szNAVEXINFLocation ) + 1;

    // Allocate memory for the configuration.

    pConfig = (char *) malloc ( DynamicLength );
    

    if ( pConfig )
    {
        // mmendon, 10/14/99, fix for AP crash
        // the extension list needs 2 NULL chars at the end because the kernel
        // mode parser expects 2 NULL chars. One null char delimits the last extension, 
        // the last null char delimits the list.  I made room for the second null
        // char above, am zeroing all memory.

        memset(pConfig, 0, DynamicLength);
        
        // Copy the configuration.

        pConfig = (char *) pConfig;

        memcpy ( pConfig, &Config, sizeof(Config) );
        strcpy ( &pConfig[Config.idx_pszQuarantineLocation], szQuarantineLocation );
        strcpy ( &pConfig[Config.idx_pszMoveLocation], szMoveLocation );
        strcpy ( &pConfig[Config.idx_pszRenameExtension], szRenameExtension );
        strcpy ( &pConfig[Config.idx_pszAlertText], szAlertText );
        strcpy ( &pConfig[Config.idx_pszzProgramExtensionList], szProgramExtensionList );
        strcpy ( &pConfig[Config.idx_pszSpoolFileLocation], szSpoolFileLocation );
        strcpy ( &pConfig[Config.idx_pszAlertText], szAlertText );
        strcpy ( &pConfig[Config.idx_pszAlertText], szAlertText );
        if ( dwExclusionItems )
            memcpy ( &pConfig[Config.idx_arExclusionItems], pExclusionItems, dwExclusionItems * sizeof(OLDEXCLUDEITEM) );
        if ( dwExclusionLItems )
            memcpy ( &pConfig[Config.idx_arExclusionLItems], pExclusionLItems, dwExclusionLItems * sizeof(LEXCLUDE_DAT) );
        strcpy ( &pConfig[Config.idx_pszNAVAPLocation], szNAVAPLocation );
        strcpy ( &pConfig[Config.idx_pszNAVEXINFLocation], szNAVEXINFLocation );

        // Fix up the program extension list, such that it contains 0-terminated strings.

        for ( pszParse = &pConfig[Config.idx_pszzProgramExtensionList]; *pszParse; )
        {
            pszNext = CharNext ( pszParse );

            if ( *pszParse == ',' )
                *pszParse = 0;

            pszParse = pszNext;
        }               
    }

    if ( dwExclusionLItems )
        free ( pExclusionLItems );

    if ( dwExclusionItems )
        free ( pExclusionItems );

    return (PNAVAP_CONFIG)pConfig;
}


DWORD ConvertToVirusLikeAction ( DWORD action )
{
    switch  (action )
    {
        case 0:
            action = MAINACTION_ALLOW;
            break;
        case 1:
            action = MAINACTION_PROMPT;
            break;
        case 2:
            action = MAINACTION_DONOTALLOW_NOTIFY;
            break;
        default:
            action = MAINACTION_PROMPT;
    }

    return action;
}


DWORD ConvertToAPAction ( DWORD action )
{
    switch ( action )
    {
        case AC_CLEAN:
            action = MAINACTION_REPAIR;
            break;
        case AC_MOVE:
            action = MAINACTION_QUARANTINE;
            break;
        case AC_DEL:
            action = MAINACTION_DELETE;
            break;
        case AC_NOTHING:
            action = MAINACTION_DENYACCESS;
            break;
        default:
            action = MAINACTION_DENYACCESS;
    }

    return action;
}

DWORD GetModuleLocation(PSTR pszPath)
{
    if ( GetModuleFileName ( NULL, pszPath, 260 ) )
    {
        PSTR pszParse, pszLast;
        for ( pszParse = pszPath, pszLast = NULL; *pszParse; pszParse = CharNext ( pszParse ) )
            if ( *pszParse == '\\' || *pszParse == '/' )
                pszLast = pszParse;
        if ( pszLast ) {
            *pszLast = 0;
        }
        return 0;
    }
    return MINUS_ONE;
}

VOID WINAPI AssertFailedLine ( const LPSTR lpFileName, int iLine )
{
    REF(lpFileName);
    REF(iLine);
}

BOOL DecodeNAVAPQuarantineFile ( PNAVAP_EVENTPROGRESSREPORTPACKET pPacket, LPSTR lpFileName, DWORD *lpdwFileStatus, PFILE_ACTION lpAction )
{
    BOOL bResult = FALSE;
    HANDLE hInFile = NULL;
	HANDLE hOutFile = NULL;
    QFILE_AP_HEADER_STRUCT rHeader;
    DWORD dwSize;
    DWORD dwPtr = 0;
    PVOID pvBuffer = NULL;
    char szTempFile[260];
    char szTempPath[260];
    char* pszDir;
    LPBYTE lpSecurityDesc = NULL;

    
    if(!pPacket || !lpFileName  || !lpdwFileStatus || !lpAction)
        return(FALSE);
    
    *lpdwFileStatus = 0xFFFFFFFF;  //set this here so it can be checked on return

    // is there an AP temp file?  If so, get the name
    if ( !pPacket->dwMovedRenamedFileIndex )
		goto Cleanup;

	WideCharToMultiByte ( CP_ACP,
                              0,
                              &pPacket->szStringArray[pPacket->dwMovedRenamedFileIndex],
                              -1,
                              lpFileName,
                              260,
                              NULL,
                              NULL );

    // Get the security descriptor for the file
    if ( pfnGetFileSecurityDesc )
    {
        if ( !pfnGetFileSecurityDesc(lpFileName, &lpSecurityDesc) )
            goto Cleanup;
    }

	// open the input file from AP
     hInFile = CreateFile ( lpFileName, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL );
	if ( hInFile == INVALID_HANDLE_VALUE )
    {
		hInFile = NULL;
        goto Cleanup;
    }

    
    // find the AP file directory

    lstrcpy(szTempPath, lpFileName);
    pszDir = _tcsrchr(szTempPath, '\\');
    if( pszDir != NULL )
    {
        CharNext(pszDir);
        *pszDir =  _T('\0');  
    }

    // get the temp file name
    if( !GetTempFileName(szTempPath, "APQ", 0, szTempFile) )
        goto Cleanup;
    
    // open the temp file for writing
    hOutFile = CreateFile ( szTempFile, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL );
	if ( hOutFile == INVALID_HANDLE_VALUE )
    {
		hOutFile = NULL;
        goto Cleanup;
    }

    
    // read in the AP file header data
    if ( !ReadFile( hInFile, &rHeader, sizeof(rHeader), &dwSize, NULL ) ) 
         goto Cleanup;

    if( dwSize != sizeof(rHeader))
        goto Cleanup;
        
    dwSize = GetFileSize ( hInFile, NULL );
    if((dwSize == 0xFFFFFFFF)  || (dwSize != rHeader.dwHeaderBytes + rHeader.FileInfo.dwOriginalFileSize)  )
        goto Cleanup;
    
    
    // transfer data from the input file to the output file and get needed values from the AP header
    pvBuffer = malloc ( QUARANTINE_TRANSFER_BUFFER_SIZE );
    if(!pvBuffer)
        goto Cleanup;
    
    //get the file status, specifically looking for a backup to quarantine flag
    *lpdwFileStatus = rHeader.FileInfo.dwFileStatus;
    // get the file times out of the header and add then to the FILEACTION struct for use by
    // quarantine later
    FileTimeTotime_t(&rHeader.FileInfo.ftOriginalFileDateAccessed, &(lpAction->APFileAccessTime));
    FileTimeTotime_t(&rHeader.FileInfo.ftOriginalFileDateWritten, &(lpAction->APFileModifiedTime));
    FileTimeTotime_t(&rHeader.FileInfo.ftOriginalFileDateCreated, &(lpAction->APFileCreateTime));
    
    dwSize -= rHeader.dwHeaderBytes;

    // set the input file ptr beyond the AP header
    if ( SetFilePointer ( hInFile, dwPtr + rHeader.dwHeaderBytes, NULL, FILE_BEGIN ) != dwPtr + rHeader.dwHeaderBytes )
        goto Cleanup;
    
    while ( dwSize )
    {
          DWORD dwXfer, dwWrite;

          // read from the input file
          if ( !ReadFile ( hInFile, pvBuffer, min(dwSize,QUARANTINE_TRANSFER_BUFFER_SIZE), &dwXfer, NULL ) )
            goto Cleanup;

          if ( dwXfer != min(dwSize,QUARANTINE_TRANSFER_BUFFER_SIZE) )
            goto Cleanup;

         // write to the output file 
          if ( !WriteFile ( hOutFile, pvBuffer, dwXfer, &dwWrite, NULL ) )
            goto Cleanup;

          if ( dwXfer != dwWrite )
            goto Cleanup;

         dwSize -= dwWrite;
    }

   if(!CloseHandle(hOutFile))
   {
		hOutFile = NULL;
		goto Cleanup;
   }
   hOutFile = NULL;

    // if we are here, the ouput file was successfully written.  Delete input file from AP
    
    // Set the security descriptor for the new file
    if (pfnSetFileSecurityDesc)
        pfnSetFileSecurityDesc( szTempFile, lpSecurityDesc );

    CloseHandle(hInFile);
    hInFile = NULL;
    
	// Delete the input file
	DoFileWipe(lpFileName);

	// set Quarantine file name to the output file that was created
	lstrcpy(lpFileName, szTempFile);

    // If we are here, all has worked perfectly and we can update the return value
    bResult = TRUE;

Cleanup:    

    if(hInFile)
        CloseHandle(hInFile);

    if(hOutFile)
        CloseHandle(hOutFile);
                           
    if(pvBuffer)
        free ( pvBuffer );

    // Free the security descriptor if we have one.
    if ( pfnFreeFileSecurityDesc && lpSecurityDesc )
        pfnFreeFileSecurityDesc( lpSecurityDesc );

	// if there has been some error in this function the original file needs to be retained,
	//  and the output file needs to be deleted
    if(!bResult)
	{
        //  Delete the file
	    DoFileWipe(szTempFile);         
    }

    return bResult;
}

/************************************************************************
 *                                                                      *
 * Description:                                                         *
 *  This function:                                                      *
 *                 1. Overwrites the entire file with zeros             *
 *                 2. Truncates the file to 0 bytes in size.            *
 *                 3. Deletes the file.                                 *
 *                                                                      *
 * Parameters:                                                          *
 *  lpFilename     Full Path of the file to Wipe.                       *
 *                                                                      *
 * Returns:                                                             *
 *  TRUE if successful, FALSE otherwise.                                *
 *                                                                      *
 *                                                                      *    
 *  // modified from symkrnl FileWipe()                                  *        
 ************************************************************************/

BOOL DoFileWipe(LPCTSTR  lpFileName)
{
    HANDLE  hFile = NULL;
    PVOID lpvBuffer = NULL;
    const DWORD   dwMaxBytesToWrite = 0x8000;
    DWORD   dwBytesToWrite;
    DWORD  dwFileSize;
    DWORD  dwBytesLeft;
    DWORD  dwBytesWritten;
    BOOL   bResult = FALSE;

    
    if(lpFileName == NULL)
        return(FALSE);

    // open the  file for writing
    hFile = CreateFile ( lpFileName, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL );
	if ( hFile == INVALID_HANDLE_VALUE )
    {
		hFile = NULL;
        goto Cleanup;
    }

    dwFileSize = GetFileSize ( hFile, NULL );
    if(dwFileSize == 0xFFFFFFFF)
        goto Cleanup;

   // allocate a buffer 0x8000 bytes
    lpvBuffer = malloc ( dwMaxBytesToWrite );
    if(!lpvBuffer)
        goto Cleanup;
    
    memset(lpvBuffer, 0, dwMaxBytesToWrite);
    
    dwBytesLeft = dwFileSize;
    
    // seek to the beginning of the file
    if(SetFilePointer ( hFile, 0, NULL, FILE_BEGIN ) != (DWORD)0)
         goto Cleanup;

    
    // we cannot write more than 0x8000 bytes at a time
    while (dwBytesLeft)             
    {
         dwBytesToWrite = dwBytesLeft > dwMaxBytesToWrite ?
                         dwMaxBytesToWrite : dwBytesLeft;

         if (!WriteFile ( hFile, lpvBuffer, dwBytesToWrite, &dwBytesWritten, NULL))
            goto Cleanup;

         if(dwBytesWritten != dwBytesToWrite)
            goto Cleanup;

         dwBytesLeft -= dwBytesToWrite;
    }
    
    // for truncation purposes seek to the beginning of our file
    if(SetFilePointer ( hFile, 0, NULL, FILE_BEGIN ) != (DWORD)0)
         goto Cleanup;

    // set the end of the file at the beginning
    SetEndOfFile(hFile);

Cleanup:
                                
    if (hFile)
        CloseHandle(hFile);

    if (lpvBuffer)
        free(lpvBuffer);

    // always try to delete the file
    bResult = DeleteFile(lpFileName);

    return (bResult);
}

// MMENDON 1/30/2000:  Support for extension exclusions

//*******************************************************************************************
//
//  LEXCLUDE_DAT * PrepareExclusions ( DWORD * count )
//
// The function should determine whether there are exclusions. If there are exclusions, 
// allocate an array of LEXCLUDE_DAT with the number of exclusions. If the allocation 
// fails, or if there are no exclusions, return NULL, and set *count = 0.  Otherwise, return 
// a pointer to the array, and set *count to contain the number of exclusions.  The memory 
// should be allocated with malloc.
//
// Parameters:
//
// DWORD * count = pointer to a buffer that can be filled with the number of exclusions.
//                  This value is 0 if there are no exclusions or an error occurs while
//                  getting the exclusions.
// Return:
//          pointer to array of LEXCLUDE_DAT structs.  If there are no exclusions or an
//          error occurs while getting the exclusions, NULL will be return.  If the return
//          is NULL, this function will clean up any allocated memory.  Otherwise, the calling
//          function must clean up the memory.
//
// mmendon, May 1, 1999
// mmendon, January 30, 2000: revised to support extension exclusions
//
//********************************************************************************************

// ksr
//#if 0



LEXCLUDE_DAT * PrepareExclusions ( DWORD * count )
{
    PVOID pvExclusionList = NULL;
    LEXCLUDE_DAT * APExclusionArray = NULL;
    DWORD dwFileExclusions = 0, dwDirectoryExclusions = 0, dwExclusions = 0, dwExtensionExclusions = 0;
    DWORD dwExclusionIndex, dwEnumIndex;
	HKEY hDirKey, hFileKey;
    BOOL bFileExclusions, bDirExclusions, bExtensionExclusions;
    char szExtensionExclusionList[EXT_LIST_SIZE];


    // check for folder, file and extension exclusions. If none, set count to 0 and return NULL.
    // if there are any exclusions, the Reg value HaveExceptionsDirs will be set to 1
    // so don't need to check HaveExceptionFiles
    if(!gdwHaveExceptionDirs)
    {
        *count = 0;
        return(NULL);
    }
    

    // Check to see how many exclusions of each type there are
    bDirExclusions = CheckForExclusions(szReg_Key_NoScanDir, &hDirKey, &dwDirectoryExclusions);
    bFileExclusions = CheckForExclusions(szReg_Key_NoScanFiles, &hFileKey, &dwFileExclusions);
    bExtensionExclusions = CheckForExtensionExclusions(szExtensionExclusionList,&dwExtensionExclusions);

  	// verify there really are exclusions
    dwExclusions = dwFileExclusions + dwDirectoryExclusions + dwExtensionExclusions;
    if(dwExclusions == 0)
    {
        if(bDirExclusions)
            sCloseKey(hDirKey);
        if(bFileExclusions)
            sCloseKey(hFileKey);
        *count = 0;
        return(NULL);
    }

    // allocate enough memory to hold all of the exclusions in the format needed by AP
    // if allocation fails, set count to 0 and return NULL
    pvExclusionList = malloc((int)dwExclusions * sizeof(LEXCLUDE_DAT));
    if(!pvExclusionList)
    { 
        *count = 0;
        if(bDirExclusions)
            sCloseKey(hDirKey);
        if(bFileExclusions)
            sCloseKey(hFileKey);
        dprintf("ERROR:  memory allocation failed for exclusion list\n");
        return(NULL);
    }
    
    APExclusionArray = (LEXCLUDE_DAT *)pvExclusionList;

       // Get the directory and file exclusions from the registry
   dwExclusionIndex = 0;
   if(bDirExclusions)
        GetExclusionListFromRegistry(hDirKey, &dwExclusionIndex, dwDirectoryExclusions, APExclusionArray);
   if(bFileExclusions)
        GetExclusionListFromRegistry(hFileKey, &dwExclusionIndex, dwFileExclusions, APExclusionArray);
   if(bExtensionExclusions)
       GetExtensionExclusionsFromList(szExtensionExclusionList, &dwExclusionIndex, APExclusionArray);
   
   
   // Every item listed in the registry may not be a valid AP exclusion (mail exclusions)
   // Adjust the number of exclusions here if necessary.  The calling function will use
   // only the number of items returned, but will free the entire allocated array if the
   // number of items > 0.  Otherwise, I need to free the array.
   if(dwExclusions > dwExclusionIndex)
       dwExclusions = dwExclusionIndex;

   dprintf("Exclusions count: %ld\n", dwExclusions);
 
   if(dwExclusions == 0)
   { 
        *count = 0;
        if(bDirExclusions)
            sCloseKey(hDirKey);
        if(bFileExclusions)
            sCloseKey(hFileKey);
        free(pvExclusionList);
        return(NULL);
   }

   // DEBUG: output exclusions in console
   for(dwEnumIndex = 0; dwEnumIndex < dwExclusions; ++dwEnumIndex)
        dprintf("%ld: %s  %d, %d\n", dwEnumIndex, 
                    APExclusionArray[dwEnumIndex].szText, APExclusionArray[dwEnumIndex].bSubDirectory,
                    APExclusionArray[dwEnumIndex].wBits);
    
    // cleanup
    if(bDirExclusions)
        sCloseKey(hDirKey);
    if(bFileExclusions)
        sCloseKey(hFileKey);

    // return the pointer to the allocated array.  Memory is freed in the calling function.
    *count = dwExclusions;

    return (APExclusionArray);
}


// ksr
#endif 0



//*******************************************************************************************
//
//  BOOL CheckForExclusions(LPCSTR lpszRegKey, HKEY *lphExcKey, DWORD *lpdwExclusions)
//
// This function checks the registry for  exclusions and returns the number of exclusions, if any
//
// Parameters:
//
// LPCSTR lpszRegKey = Name of reg key to open
// HKEY *lphExcKey = uninitialized pointer for opening the registry key
// DWORD *lpdwExclusions = buffer for returning number of exclusions
// 
// Return:
//      TRUE if the exclusion key exists and no error occurred.  
//      The input HKEY * points to an open registry key handle and must be closed by the caller.
//      
//      FALSE if the exclusion key does not exist or an error occurred 
//      The input HKEY * will be closed in this function
//      
//
// mmendon, January 30, 2000
//
//********************************************************************************************

// ksr
#if 0

BOOL CheckForExclusions(LPCSTR lpszRegKey, HKEY *lphExcKey, DWORD *lpdwExclusions)
{
    
    // check for valid input
    if(!lpszRegKey || !lphExcKey || !lpdwExclusions || !hFileSysKey)
    {
        dprintf("Null pointer in CheckForExclusions\n");
        return(FALSE);
    }

    // open the file and directory exclusions reg keys
    if (sOpekKey(hFileSysKey,lpszRegKey, lphExcKey) != ERROR_SUCCESS) 
    {
        *lpdwExclusions = 0;
        return(FALSE);
    }

    // Get number of file and directory exclusions 
    if(RegQueryInfoKey(*lphExcKey, NULL, NULL, NULL, NULL, NULL, NULL, 
                    lpdwExclusions, NULL, NULL, NULL, NULL) != ERROR_SUCCESS)
    {
        *lpdwExclusions = 0;
        sCloseKey(*lphExcKey);
        dprintf("Error querying reg key for exclusions\n");
        return(FALSE);
    }

    return(TRUE);
}



//*******************************************************************************************
//
//  BOOL CheckForExtensionExclusions(LPSTR lpszExtensionList, DWORD * lpdwExclusions)
//
// This function checks for extension exclusions and returns the count.

//
// Parameters:
//
// LPSTR lpszExtensionList = pointer to the extension exclusion list
// DWORD * lpdwExclusions = pointer to a buffer for the number of extension exclusions
//
// Return:
//          TRUE if there were no errors.  lpdwExtensions points to the number of exclusions
//          FALSE if there was an error.
//
// mmendon, January 30, 2000
//
//********************************************************************************************

BOOL CheckForExtensionExclusions(LPSTR lpszExtensionList, DWORD * lpdwExclusions)
{

    // check for valid input
    if(!lpszExtensionList || !lpdwExclusions || !hFileSysKey)
    {
        dprintf("Null pointer in CheckForExtensionExclusions\n");
        return(FALSE);
    }

    // get the string from the registry, placing it in the provided buffer
    sGetStr(hFileSysKey, szReg_Val_ExcludedExtensions, lpszExtensionList, EXT_LIST_SIZE,"");
    
    //count the items in the list
    if(GetExtensionCount(lpszExtensionList, lpdwExclusions))
        return TRUE;

    // error getting count
    *lpdwExclusions = 0;
    return(FALSE);
}


//*******************************************************************************************
//
//  BOOL GetExtensionCount(LPTSTR lpszExtList, DWORD *lpdwCounter)
//
// This function get the number of extension exclusions and expects the list to be in format
//  \0; ext\0; ext,ext,...,ext\0; ext,ext,...,ext,\0
//
// Parameters:
//
// LPTSTR lpszExtList = pointer to the extension list
// DWORD *lpdwCounter = pointer to a buffer for returning the number of extension exclusions
//
// Return:
//          TRUE if there were no errors.  lpdwCounter points to the number of exclusions
//          FALSE if there was an error.
//
// mmendon, January 30, 2000
//
//********************************************************************************************

BOOL GetExtensionCount(LPTSTR lpszExtList, DWORD *lpdwCounter)
{
	BOOL bContinue = TRUE;
	WORD wState = 0;
	BOOL bSuccess = TRUE;
	LPTSTR lpszRunner = lpszExtList;
	
	// verify function input
	if(!lpszExtList || !lpdwCounter)
	{
		dprintf("Null pointer in GetExtensionCount\n");
		return (FALSE);
	}
	
	
	// loop through all chars in list until error or end
	while(bContinue)
	{
		switch(wState)
		{
			case 0:		// beginning of list	

						if(*lpszRunner == _T('\0')) wState = 1;			// list is empty
						else if(*lpszRunner == EXT_DELIM) wState = 99;  // error, comma shouldn't be here
						else											// first extension
						{	
							++(*lpdwCounter);
							lpszRunner = CharNext(lpszRunner);
							wState = 2;
						}
						break;

			case 1:		// end of list

						bContinue = FALSE;
						bSuccess = TRUE;
						break;

			case 2:		// extension character

						if(*lpszRunner == _T('\0')) wState = 1;			// end of list
						else if(*lpszRunner == EXT_DELIM)				// marks the end of an extension
						{
							lpszRunner = CharNext(lpszRunner);			
							wState = 3;
						}
						else											// another alphanum
						{	
							lpszRunner = CharNext(lpszRunner);
							wState = 2;
						}
						break;

			case 3:
						if(*lpszRunner == _T('\0')) wState = 1;			// end of list
						else if(*lpszRunner == EXT_DELIM) wState = 99;  // error, comma shouldn't be here
						else											// we found another extension
						{	
							++(*lpdwCounter);
							lpszRunner = CharNext(lpszRunner);
							wState = 2;
						}
						break;

			case 99:					// if we're here, this is an invalid list
	
			default:
						bContinue = FALSE;
						bSuccess = FALSE;
						*lpdwCounter = 0;
						dprintf("Error in get extension exclusion count.\n");
						break;
		
		}
	}

    return (bSuccess);
}




//*******************************************************************************************
//
//  BOOL GetExtensionExclusionsFromList(LPTSTR lpszExtList, DWORD * lpdwExclusionIndex, 
//                                      LEXCLUDE_DAT * lpExclusionList)
//
// This function parses the extension exclusion list and adds them to the exclusion array.
//
// Parameters:
//
// LPTSTR lpszExtList = pointer to the extension list
// DWORD * lpdwExclusionIndex = a pointer to the buffer of the current index in the exclusions array
// LEXCLUDE_DAT * lpExclusionList = a pointer to the exclusions array
//
// Return:
//          TRUE if no error.  *lpdwExclusionIndex is updated to the new array index
//          FALSE if error
//          
//
// mmendon, January 30, 2000
//
//********************************************************************************************

BOOL GetExtensionExclusionsFromList(LPTSTR lpszExtList, DWORD * lpdwExclusionIndex, LEXCLUDE_DAT * lpExclusionList)
{
	
	LPTSTR lpszToken = NULL;
	TCHAR szExtensions[EXT_LIST_SIZE];
	TCHAR szExclusion[EXT_LIST_SIZE + 2];
	
	
	// verify function input
	if(!lpszExtList || !lpdwExclusionIndex || !lpExclusionList)
	{
		dprintf("Null pointer in GetExtensionCount\n");
		return (FALSE);
	}

	// get a copy of the extension list to pass to strtok
	_tcscpy(szExtensions, lpszExtList);

	//get the first extension
	lpszToken = _tcstok(szExtensions, STR_EXT_DELIM);
	if(!lpszToken)
	{
		dprintf("Nothing in extension exclusion list.\n");
		return (TRUE);
	}
	
	// add the wildcard character for AP (*.) to the beginning of the extension
	_tcscpy(szExclusion, WILDCARD);
	_tcscat(szExclusion, lpszToken);

	// insert the exclusion into the exclusion list
	CharToOemA(szExclusion, lpExclusionList[*lpdwExclusionIndex].szText);
    lpExclusionList[*lpdwExclusionIndex].bSubDirectory = (BYTE)0;
    lpExclusionList[*lpdwExclusionIndex].wBits = (WORD)excVIRUS_FOUND;
    ++(*lpdwExclusionIndex);

	//get any other extensions in the list
	do
	{
		lpszToken = _tcstok(NULL, STR_EXT_DELIM);
		if(lpszToken)
		{
			_tcscpy(szExclusion, WILDCARD);
			_tcscat(szExclusion, lpszToken);
			CharToOemA(szExclusion, lpExclusionList[*lpdwExclusionIndex].szText);
			lpExclusionList[*lpdwExclusionIndex].bSubDirectory = (BYTE)0;
			lpExclusionList[*lpdwExclusionIndex].wBits = (WORD)excVIRUS_FOUND;
    		++(*lpdwExclusionIndex);

		}
	}while(lpszToken);


	return(TRUE);
	
}


// MMENDON 1/30/2000:  end change for extension exclusions


//*******************************************************************************************
//
//  BOOL GetExclusionListFromRegistry(HKEY hKey, DWORD * lpdwExclusionIndex, DWORD dwExclusions, 
//                                      LEXCLUDE_DAT * lpExclusionList)
//
// This function adds to a list of exclusions found under the passed-in reg key
// return true if successful, false if not.  The calling function cleans up the 
// exclusions list if this function fails
//
// Parameters:
//
// HKEY hKey                        : open registry key where values will be read from
// DWORD * lpdwExclusionIndex       : dword buffer for getting the current index and 
//                                    returning the updated index in the exclusion list 
//                                    (lpExclusionList)
// DWORD dwExclusions               : the number of exclusions to be processed
// LEXCLUDE_DAT * lpExclusionList   : pointer to an allocated block of memory where the 
//                                    registry exclusions can be put
// 
// Return:
//          TRUE  : always
//
// mmendon, May 1, 1999
//
//********************************************************************************************

BOOL GetExclusionListFromRegistry(HKEY hKey, DWORD * lpdwExclusionIndex, DWORD dwExclusions, LEXCLUDE_DAT * lpExclusionList)
{
 
         TCHAR szExceptionValName[LEXCLUSION_SIZE];
    DWORD dwExceptionValNameSize, dwExceptionValSize,  dwExceptionVal, dwEnumIndex;
 
    // enumerate through reg values and put all of the valid values into the passed-in exclusions list
    for(dwEnumIndex = 0; dwEnumIndex < dwExclusions; ++dwEnumIndex)
    {
       dwExceptionValNameSize = LEXCLUSION_SIZE;
	   dwExceptionValSize = sizeof(DWORD);
        
       if(RegEnumValue(  hKey, dwEnumIndex, szExceptionValName, &dwExceptionValNameSize,
                        NULL, NULL, (BYTE*)&dwExceptionVal, &dwExceptionValSize) 
            != ERROR_SUCCESS) 
       {
           dprintf("Could not enumerate exclusion reg value\n");
       }
       
       else if(ConvertToAPPath(szExceptionValName, lpExclusionList[*lpdwExclusionIndex].szText))
       {
           lpExclusionList[*lpdwExclusionIndex].bSubDirectory = (BYTE)dwExceptionVal;
           lpExclusionList[*lpdwExclusionIndex].wBits = (WORD)excVIRUS_FOUND;
           ++(*lpdwExclusionIndex);
       }
    }
    return(TRUE);
}


//*******************************************************************************************
//
//  BOOL ConvertToAPPath(const char * pcszInRegPath, char * pszOutConvertedPath)
//
// This function takes the exclusion value name read from the registry and converts it to
// a path/file name that AP can use.  If successful, the converted path is placed in
// szConvertedOEMPath and function returns true.  If unsuccessful, szConvertedPath is 
// empty and function returns false
// 
//
// Parameters:
//
// const char * pcszInRegPath : The reg name string
// char * pszOutConvertedPath : A buffer for returning the converted string
// 
// Return:
//          TRUE  : if able to get valid exclusion
//          FALSE : if not valid AP exclusion
//
// mmendon, May 1, 1999
//
// rchinta, Feb 3, 2000  - modified exclusions processing to accept both formats,
//          i.e. drive letter and path format or [StorageType,ID]\path format.  This
//          change was made to accomodate LFNs.
//
//********************************************************************************************

BOOL ConvertToAPPath(LPCTSTR pcszInRegPath, char * pszOutConvertedPath)
{
        
    TCHAR szInputBuffer[LEXCLUSION_SIZE];  // this buffer is used for string manipulation and the contents
    LPTSTR pID, pAfterID, pTemp;           // should be accessed only from the pointers pID, pAfterID, and pTemp
    DWORD DriveID;
             
    // Empty the return string
    pszOutConvertedPath[0] = '\0';

    // check that the exclusion is a valid AP exclusion, could be a mail exclusion        
    if(_tcsncmp(pcszInRegPath, _T("["), 1) == 0  &&
    _tcsncmp(CharNext(pcszInRegPath), _T(szStorage_File), _tcslen(_T(szStorage_File))) == 0)
    {
        goto ConvertStorageIDtoDrive;
    }
    else if( _tcsncmp(CharNext(pcszInRegPath), _T(":"), lstrlen(_T(":"))) == 0 )
    {
        if( (_tcsncmp(CharNext(pcszInRegPath), _T(":\\"), lstrlen(_T(":\\"))) == 0) || (lstrlen(pcszInRegPath) == 2) )
        {
            // MMENDON 08-16-2000 STS defect 135487
            // AP expects an SFN if available
            _tcscpy(pszOutConvertedPath, pcszInRegPath);        
            GetShortPathName(pszOutConvertedPath, pszOutConvertedPath, LEXCLUSION_SIZE);
            dprintf("lfn exclusion: %s, sfn exclusion: %s\n", pcszInRegPath, pszOutConvertedPath);
            // MMENDON 08-16-2000 End fix for STS defect 135487

            // convert the path to OEM for AP
            CharToOemA( pszOutConvertedPath, pszOutConvertedPath);

            return(TRUE);
        }
    
    }
    else
    {
        dprintf("Exclusion is not FileSystem exclusion: %s\n", szInputBuffer); 
        return(FALSE);
    }

ConvertStorageIDtoDrive:

    // get a copy of the input string I can manipulate
    _tcscpy(szInputBuffer, pcszInRegPath);
      
    // these strings from the registry have the format [FileSystem,<drive ID#>]\path
    // I need the drive ID# which should start one char after ','
    pID = _tcschr(szInputBuffer, _T(','));
    if(!pID)
    {
        dprintf("ERROR:  error parsing %s\n", szInputBuffer); 
        return(FALSE);
    }
    pID = CharNext(pID);
    
    // find the end of the Drive ID
    pAfterID = _tcschr(pID, _T(']'));
    if(!pAfterID)
    {
        dprintf("ERROR:  error parsing %s\n", szInputBuffer); 
        return(FALSE);
    }

    // Move the pointer to the next char which is the beginning of the path then null the previous 
    // char to end the ID string (don't need the ']'), 
    pTemp = pAfterID;
    pAfterID = CharNext(pAfterID);
    *pTemp =  _T('\0');
        
    // Convert the drive ID to a dword and get its drive letter designation so
    // the path can be built
    DriveID = _ttol(pID);
    strcpy(pszOutConvertedPath, GetDriveFromInstanceID(DriveID));
    
    // if unable to get a drive letter, then the mapping may not currently
    // exist.  Need to do conversion to get drive here in case mapping is recreated after
    // AP has already loaded.
    if(strcmp(pszOutConvertedPath, "[EMPTY]:") == 0)
    {
        char szDrives[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
           
        dprintf("could not get a drive letter for the ID. %s\n", pszOutConvertedPath); 
        // make sure drive number is within proper range
        if(DriveID < 1  || DriveID >= 512)
        {
            dprintf("could not get a drive letter for the ID. %s\n", pszOutConvertedPath); 
            pszOutConvertedPath[0] = '\0';
            return(FALSE);
        }

        if(DriveID < 128)                       // removable drive
            pszOutConvertedPath[0] = szDrives[DriveID - 1];
        else if (DriveID < 256)                 // local fixed drive and CD-ROM
            pszOutConvertedPath[0] = szDrives[DriveID - 128];
        else                                    // DriveID < 512:  Network drive
            pszOutConvertedPath[0] = szDrives[DriveID - 256];
        pszOutConvertedPath[1] = ':';
        pszOutConvertedPath[2] = '\0';
            
    }
    
    _tcscat(pszOutConvertedPath, pAfterID);
    
    // MMENDON 08-16-2000 STS defect 135487
    // AP expects an SFN if available
    dprintf("lfn exclusion: %s", pszOutConvertedPath);
    GetShortPathName( pszOutConvertedPath, pszOutConvertedPath, LEXCLUSION_SIZE);
    dprintf(", sfn exclusion: %s\n", pszOutConvertedPath);
    // MMENDON 08-16-2000 End fix for STS defect 135487

    // convert the path to OEM for AP
    CharToOemA( pszOutConvertedPath, pszOutConvertedPath);
    
    return(TRUE);
}

void RefreshNAVAPStatistics(void)
    {
    PNAVAP_STATUSPACKET pNAVAPStat = NULL;

    
    //  MMENDON 09-30-2000: Change for AutoProtect early shutdown
    //                      If the system is shutting down, on
    //                      9x hNAVAPDefs will still be valid, but
    //                      don't want to get anymore statistics
    //                      from AP kernel.
#if defined(WIN95)
    if(gbNotifyNavapVxdSysShutdown)
        return;
#endif
//  MMENDON 09-30-2000: End change for AutoProtect early shutdown


    EnterCriticalSection ( &rHandleLock );

    if ( hNAVAPDefsNotify )
    {
        DWORD dwSize = sizeof(NAVAP_STATUSPACKET);

        while ( pNAVAPStat = (PNAVAP_STATUSPACKET) malloc ( dwSize ) )
        {
            DWORD dwOldSize = dwSize;

            pNAVAPStat->dwSize = dwSize;

            if ( !NAVAPiGetStatus ( hNAVAPDefsNotify, pNAVAPStat ) )
                {
                free ( pNAVAPStat );
                pNAVAPStat = NULL;
                break;
                }

            if ( pNAVAPStat->dwSize <= dwOldSize )
                break;

            dwSize = pNAVAPStat->dwSize;

            free ( pNAVAPStat );
        }
    }

    LeaveCriticalSection ( &rHandleLock );

    if ( pNAVAPStat )
        {
        //(PSID)&pStatBlock->LastUser

        pStatBlock->TotalScaned = pNAVAPStat->dwFilesScannedSinceStartup;
        //pStatBlock->TimeStarted;
        pStatBlock->VirusesFound = pNAVAPStat->dwInfectedFilesFoundSinceStartup;
        //pStatBlock->LastVirusFoundTime;
        //pStatBlock->DriverErr;
        //pStatBlock->Exceptions;
        //pStatBlock->Status;
        //pStatBlock->LastVirusFoundAction;

        if ( !WideCharToMultiByte ( CP_ACP,
                                    0,
                                    &pNAVAPStat->szStringArray[pNAVAPStat->dwLastVirusFoundIndex],
                                    -1,
                                    pStatBlock->LastVirusFoundName,
                                    sizeof(pStatBlock->LastVirusFoundName),
                                    NULL,
                                    NULL ) )
            pStatBlock->LastVirusFoundName[0] = 0;

        if ( !WideCharToMultiByte ( CP_ACP,
                                    0,
                                    L"", // &pNAVAPStat->szStringArray[pNAVAPStat->???],
                                    -1,
                                    pStatBlock->LastVirusFoundUserName,
                                    sizeof(pStatBlock->LastVirusFoundUserName),
                                    NULL,
                                    NULL ) )
            pStatBlock->LastVirusFoundUserName[0] = 0;

        if ( !WideCharToMultiByte ( CP_ACP,
                                    0,
                                    &pNAVAPStat->szStringArray[pNAVAPStat->dwLastInfectedFileFoundIndex],
                                    -1,
                                    pStatBlock->LastVirusFoundFile,
                                    sizeof(pStatBlock->LastVirusFoundFile),
                                    NULL,
                                    NULL ) )
            pStatBlock->LastVirusFoundFile[0] = 0;

        if ( !WideCharToMultiByte ( CP_ACP,
                                    0,
                                    &pNAVAPStat->szStringArray[pNAVAPStat->dwLastFileScannedIndex],
                                    -1,
                                    pStatBlock->LastScaned,
                                    sizeof(pStatBlock->LastScaned),
                                    NULL,
                                    NULL ) )
            pStatBlock->LastScaned[0] = 0;

        free ( pNAVAPStat );
        }
    }



//*******************************************************************************************
//
//  void LogRTSLoadError()
//
// This function writes a log entry when AutoProtect fails to load.
// 
//
// Parameters:
//              none
// 
// Return:
//          none
//
//
// mmendon, June 20, 2000
//
//
//********************************************************************************************
/*
void LogRTSLoadError(void)
{

    EVENTBLOCK log;
    char line[IMAX_PATH];

    EnterCriticalSection(&RTSErrorLoggingLock);
    if(gbLoggedRTSLoadError)
    {
        LeaveCriticalSection(&RTSErrorLoggingLock);
        return;
    }
    else
    {
        gbLoggedRTSLoadError = TRUE;
        LeaveCriticalSection(&RTSErrorLoggingLock);
    }
        memset(&log,0,sizeof(log));
	    WSprintf(line,LS(IDS_RTS_LOAD_ERROR));
	    log.Description = line;
	    log.logger = LOGGER_System;
	    log.hKey[0] = 0;
	    log.Category = GL_CAT_SUMMARY;
	    log.Event = GL_EVENT_RTS_LOAD_ERROR;
	    GlobalLog(&log);

}
*/

//*******************************************************************************************
//
// void DisplayRTSLoadError(void) 
//
// This function displays a message box notifying the user that AP failed to load.
// 
//
// Parameters:
//          none
// 
// Return:
//          none
//
//
// mmendon, June 20, 2000
//
//
//********************************************************************************************

void DisplayRTSLoadError(void) 
{
    
    char szAppName[IMAX_PATH];
    char szLoadError[IMAX_PATH];
	
    strcpy(szAppName, LS(STR_APP_NAME));
    strcpy(szLoadError, LS(IDS_RTS_LOAD_ERROR));
    MessageBox(NULL, szLoadError, szAppName, MB_OK|MB_ICONEXCLAMATION|MB_TOPMOST);

}

#endif
