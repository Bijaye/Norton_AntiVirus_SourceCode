//------------------------------------------------------------------------------
//
//      NLM.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

/*
#ifdef GLUE
#include <unistd.h>
#include <nwfile.h>
#include <nwtime.h>
#include <sys\stat.h>
#else
*/
#include "pscan.h"
#include "finetime.h"

// ksr
#include <nwTime.h>

BOOL ExitingNormally=TRUE;
BOOL bAbortFind=FALSE;

DWORD ThreadCount=0;
DWORD MessageFileLanguageID;

char ProgramDir[IMAX_PATH];	   // directory path where rtvscan.nlm was run from (including volume)
char NLMRunning=1;
DWORD debug = 0;
//char DebugLogFile[IMAX_PATH];

//#ifdef SERVER
extern char ProgressCharDone;
extern char ProgressCharNotDone;
//#endif

BOOL FreeTheStringTable = FALSE;
int languageID=4;
char *UnknownString = "--Unknown String--";


/* ???
#if defined(NLMCGI)
	#include "WebMsgs.c"  // default strings
#else 
*/
   // ksr
	//#include "acta.c"  // default strings
	#include "acta2.h"  // default strings
//#endif


char **TheStringTable = _CompiledStringTable;
static int Mutex=0;
//#endif


int MySetFileInfo(char *file,struct stat *stbuf) 
{
/**/
	struct DOSDateTime {
		struct _DOSDate DD;
		struct _DOSTime DT;
	} DC,DLU,DLA,DLa;

	// convert calendar time to DOS style date and time
	_ConvertTimeToDOS(stbuf->st_ctime,&DC.DD,&DC.DT);       // create date and time
	_ConvertTimeToDOS(stbuf->st_atime,&DLA.DD,&DLA.DT);     // Last access date and time
	_ConvertTimeToDOS(stbuf->st_btime,&DLa.DD,&DLa.DT);     // Last archive date and time
	_ConvertTimeToDOS(stbuf->st_mtime,&DLU.DD,&DLU.DT);     // Last update/modify date and time
/**/
	return SetFileInfo(file,6 /* Hidden and System */,stbuf->st_attr,(char *)&DC,
						(char *)&DLA.DD,(char *)&DLU,(char *)&DLa,stbuf->st_uid);
}

/*********************************************************************/

int PurgeFile (char *file) {
	SetPurgeFlag( file );
	return unlink( file );
}
/*********************************************************************/

void SetPurgeFlag (char *file) {

	struct stat Stats;

	if( stat( file, &Stats ) !=0 )
		return;

	if( Stats.st_attr & _A_IMMPURG ) // purge flag is already set
		return;

	Stats.st_attr |= _A_IMMPURG;	// and set them to read/write
	MySetFileInfo( file, &Stats );		// and write to the file
}

//#ifndef GLUE
//#if defined(SERVER) || defined(NLMCGI) || defined(START)
/************************************************************************************/
/**
VOID _printf(char *format,...) {

	va_list marker;
	char line[1024];
	char *outFormat="\rRTVSCAN: %s\a\r\n";
	char *p1 = StrRep(line,"\n","\r\n"), *p2;
	va_start(marker, format);

	vSprintf(line,format,marker);

	if (NWversion == 3 && NWsubVersion == 11) {
		#define _outFormat (firstLine ? outFormat : cont)
		char firstLine = 1, *cont="%s\r\n";
		int len;

		while ((len = strlen(p1)) > 0) {
Next:		if (len > 80) {
				char *bs = NULL,	// Last back slash
					 *ws = NULL;	// Last white space

				for (p2 = p1; p2 - p1 < 77; p2 = NextChar(p2)) {
					if (*p2 == '\\') {
						if (p2 - p1 >= 60)
							bs = p2;
					}

					else if (isspace(*p2)) {
						if (*p2 == '\r' && *(p2 + 1) == '\n') {
							*p2 = 0;
							ConsolePrintf(_outFormat, p1);
							firstLine = 0;
							p1 = p2 + 2;
							len = strlen(p1);
							goto Next;
						}

						else if (p2 - p1 >= 60)
							ws = p2;
					}
				}

				if ((!bs && !ws)) {	// break it here, no white space
					len = *p2;
					*p2 = 0;
					ConsolePrintf(_outFormat, p1);
					firstLine = 0;
					*p2 = len;
					p1 = p2;
				}

				else if (bs > ws) {
					*bs = 0;
					ConsolePrintf(_outFormat, p1);
					firstLine = 0;
					p1 = bs - 2;
					*p1 = ' ';
					*(p1 + 1) = ' ';
					*bs = '\\';
				}

				else {
					*ws = 0;
					ConsolePrintf(_outFormat, p1);
					firstLine = 0;
					p1 = ws + 1;
				}
			}

			else {
				ConsolePrintf(_outFormat, p1);
				break;
			}
		}
	}

	else
		ConsolePrintf(outFormat,p1);

	if (debug&DEBUGLOG)
		LogLine(line,FALSE);

	va_end(marker);
}

**/


/********************************************************************************/

char *GetRealLSPointer(LONG wID) {

	if (TheStringTable == NULL)
		return "<<<NO MESSAGES>>>";

	if (wID < STR_APP_NAME || wID >= IDS_LAST_MESSAGE)
		wID = 998;

	return TheStringTable[wID - 998];
}


/*********************************************************************/
/*The LoadString function loads a string resource from the executable file
associated with a specified module, copies the string into a buffer, and
appends a terminating null character.*/
/*int LoadString(HINSTANCE  hinst,UINT  wID,LPTSTR  lpBuffer,int  cchBuffer) {

	REF(hinst);

	strncpy(lpBuffer,LS(wID),cchBuffer-1);
	lpBuffer[cchBuffer-1] = 0;
	return NumBytes(lpBuffer);
}
*/
/****************************************************************************/
DWORD CloseStringTable() {

	if (FreeTheStringTable)
		free(TheStringTable);

	return 0;
}
/****************************************************************************/
void LoadStringTable(void) {

#define HdrMsg "NetWare Message File: navAP.nlm"

	struct
	{
		char	Header[100];
		short	unknown1;
		long	unknown2,
				LanguageID,
				NumberOfMessages,
				unknown3;
	} hdr;

	FILE* fp=NULL;
	char libpath[IMAX_PATH];
	DWORD ccode = 0;
	int i;
	long size;
	DWORD *tmp = NULL;

	// ksr ???   _printf (LS(IDS_LOADING_LANG),MSG_FILE);
	printf (LS(IDS_LOADING_LANG),MSG_FILE);

	if (NWversion == 3)
		WSprintf(libpath,"%s\\%s", ProgramDir, MSG_FILE);

	else 
	{

		int (*GetLanguageID)(void);

		GetLanguageID = ImportSymbol(GetNLMHandle(), "GetCurrentOSLanguageID");
		if (!GetLanguageID) {
			// ksr ???   _printf("Cannot get the current language id\n");
			printf("Cannot get the current language id\n");
			ccode = 1;
			goto Return;
		}

		languageID = GetLanguageID();
		if (languageID == 4)
			goto Return;

		WSprintf(libpath, NW_SYSTEM_DIR"\\NLS\\%d\\%s", languageID, MSG_FILE);
	}

	fp = fopen (libpath,"rb");
	if (!fp) {
		_printf("Cannot open \"%s\": %s\n", libpath, strerror(errno));
		ccode = 1;
		goto Return;
	}

	if (fseek(fp, 0, SEEK_END)) {
		_printf("Cannot determine the size of \"%s\": %s\n", libpath, strerror(errno));
		ccode = 1;
		goto Return;
	}

	size = ftell(fp) - 0x76;
	if (size < 0) {
		_printf("Cannot determine the size of \"%s\": %s\n", libpath, strerror(errno));
		ccode = 1;
		goto Return;
	}

	if (fseek(fp, 0, SEEK_SET)) {
		_printf("Cannot rewind \"%s\": %s\n", libpath, strerror(errno));
		ccode = 1;
		goto Return;
	}

	if (fread(&hdr, sizeof(hdr), 1, fp) != 1) {
		_printf("Cannot read \"%s\": %s\n", libpath, strerror(errno));
		ccode = 1;
		goto Return;
	}

	if (strncmp(hdr.Header, HdrMsg, sizeof(HdrMsg) - 1)) {
		_printf("Message file \"%s\" is invalid\n", libpath);
		ccode = 1;
		goto Return;
	}

/** ???
	if (messageCount != hdr.NumberOfMessages) {
		_printf("The message file \"%s\" does not match the NLM!\n", libpath);
		ccode = 1;
		goto Return;;
	}
**/
	if (NWversion == 4 && languageID != hdr.LanguageID) 
	{
		_printf("The message file \"%s\" language ID is %d, should be %d!\n",
				libpath, hdr.LanguageID, languageID);

		ccode = 1;
		goto Return;;
	}

	MessageFileLanguageID = hdr.LanguageID;

//	read MSG_FILE
	tmp = malloc(size);
	if (!tmp) 
	{
		_printf("Cannot allocate memory for \"%s\\n", libpath);
		ccode = 1;
		goto Return;
	}

	if (fread(tmp, size, 1, fp) != 1) 
	{
		_printf("Cannot read \"%s\": %s\n", libpath, strerror(errno));
		ccode = 1;
		goto Return;
	}

	// This Fixes all the offsets in the file just loaded to be pointers in memory.
	for (i = 0; i < hdr.NumberOfMessages; i++)
		tmp[i] += (DWORD)tmp;

	FreeTheStringTable = TRUE;
	TheStringTable = (char **)tmp;
	
	tmp = NULL;
//#ifdef SERVER
	ProgressCharDone='>';
	ProgressCharNotDone='-';
//#endif

Return:
	if (fp)
		fclose(fp);

	if (tmp)
		free(tmp);

	if (ccode)
		_printf("Unable to load language module: %s\a\nUsing English Instead\a\n", MSG_FILE);

	else
		_printf(LS(IDS_USING_LANG_MODULE), MSG_FILE);
}
/********************************************************************************************/
DWORD OpenStringTable(BOOL EnglishOnly) {

	int NWversion;
	int NWsubVersion;
	FILE_SERV_INFO fsinf;

	GetServerInformation (sizeof(fsinf),&fsinf);
	NWversion=fsinf.netwareVersion;
	NWsubVersion = fsinf.netwareSubVersion;

	if (NWversion == 4) {
		if (!access(MSG_FILE, 0)) { // Move the message file to sys:\system\nlm\???

			int msg;
			char newName[100];
			DWORD messageID;

			if ((msg = open(MSG_FILE, O_RDONLY)) == -1) {
				_printf("Unable to open %s\\%s: %s!\n", ProgramDir, MSG_FILE, strerror(errno));
				return 1;
				}

			if (lseek(msg, 0x6A, SEEK_SET) == -1) {
				_printf("Unable to position %s\\%s: %s!\n", ProgramDir, MSG_FILE, strerror(errno));
				close(msg);
				return 1;
				}

			if (read(msg, &messageID, sizeof(DWORD)) != sizeof(DWORD)) {
				_printf("Unable to read %s\\%s: %s!\n", ProgramDir, MSG_FILE, strerror(errno));
				close(msg);
				return 1;
				}

			close(msg);

			sprintf(newName, NW_SYSTEM_DIR"\\NLS\\%d\\%s", messageID, MSG_FILE);
			VerifyPath( newName );

			if (MyCopyFile(MSG_FILE, newName))
				_printf("Unable to copy %s\\%s: English will be used!\n", ProgramDir, MSG_FILE);

			else if (unlink(MSG_FILE))
				_printf("Unable to delete %s\\%s: %s!\n", ProgramDir, MSG_FILE, strerror(errno));

			_printf("The language message file \"%s\" has been moved to\n \"%s\"\n", MSG_FILE, newName);
			}

		LoadStringTable();
		}
	else if (!EnglishOnly && !access(MSG_FILE, 0))
		LoadStringTable();

	return 0;
}
/****************************************************************************/
BOOL StrEqual(char *s1,char *s2) {// returns TRUE if the strings are the same

	int i;

	if (strlen(s1)!=strlen(s2)) return FALSE;

	for (i=0 ; i<strlen(s1) && i<strlen(s2) ; i++)
		if (s1[i]!=s2[i])
			return FALSE;

	return TRUE;
}
/***********************************************************************************************/
BOOL StrNEqual(char *s1,char *s2,int len) {// returns TRUE if the strings are the same

	int i, l1 = strlen(s1), l2 = strlen(s2);

	if (l1 < len || l2 < len) return FALSE;

	for (i=0; i<len; i++)
		if (s1[i]!=s2[i])
			return FALSE;

	return TRUE;
}
/***********************************************************************************************/
char *StrChar(char *s,char c) {  // fix bug in japanese After311.NLM
	if (*s != c)
		s = NWLstrchr(s,c);
	return s;
}
/************************************************************************************/
// I have removed the code to keep open the log, having a locked open log makes it useless at a debuging tool.
// it's not that big of a deal to open and close it all the time.
// CC :)
/*
DWORD LogLine(char *line, BOOL write) {

	static time_t prevTime = 0;
	FILE *fp = NULL;
	int i;

	if (!debug&DEBUGLOG)
		return 1;

	LOCK();

	for (i = 0; !fp && i < 5; i++) {
		fp = fopen(DebugLogFile, "at");
		if (!fp) delay(50);
		}

	if (!fp) {
		UNLOCK();
		return 1;
		}

	if (debug&DEBUGTIMESTAMP) {
		time_t currTime = time(NULL);

		if (prevTime != currTime) {
			prevTime = currTime;
			fprintf(fp, "\n##############################################################################\n                           %s", ctime(&currTime));
			}
		}

	if (line)
		fprintf(fp, "%s", line);

	REF(write);

	fclose(fp);

	UNLOCK();
	
	return 0;
}
*/
//#endif


/************************************************************************************/
//#if defined (SERVER) || defined(NLMCGI) || defined(START)
/************************************************************************************/
DWORD LookupAccountSid(void *computer,PSID sid,char *UserName,DWORD *cbUserName,char *DomainName,DWORD *cbDomainName,DWORD *peUse) {

	char ComputerName[IMAX_PATH];
	WORD type;
	long id;
	BYTE logTime[32];
	char lUserName[IMAX_PATH];

	REF(computer);
	REF(peUse);

	if (sid->UserName[0] == 0) {
		GetConnectionInformation((WORD)sid->ConnectionID, lUserName,&type,&id,
											&logTime );
		strncpy(sid->UserName,lUserName,sizeof(sid->UserName));
		sid->UserName[sizeof(sid->UserName)-1] = 0;
		}

//	NTSGetComputerName(ComputerName,NULL);
   GetFileServerName( 0, ComputerName );

	strncpy(UserName,sid->UserName,*cbUserName);
	UserName[*cbUserName-1] = 0;
	*cbUserName = NumBytes(UserName) + 1;

	strncpy(DomainName,ComputerName,*cbDomainName);
	DomainName[*cbDomainName-1] = 0;
	*cbDomainName = NumBytes(DomainName) + 1;

	return 0;
}




#if 0





/*****************************************************************************************************/


void FindAllSappingServers(void) {

	long	objectID;
	char
			objName[48],
			objProp,
			objFlag,
			objSecurity,
			propFlags,
			propVal[128];
	int   ccode,k,cd;
	CBA_NETADDR rawAddress;
	WORD objType;
	unsigned short prot=CBA_PROTOCOL_IPX;

//	FILE *fp=fopen ("SYS:\\BindList.txt","wt");
	objectID = (DWORD) -1;

	do {
		ccode = ScanBinderyObject("*",OT_WILD, &objectID,objName,&objType, &objProp, &objFlag, &objSecurity);
//		if (fp) fprintf (fp,"[%d:0x](%x)",ccode,objType);
		if (ccode == 0 && (objType==0x4 || objType==0x640)) { // only get property values for NetWare and NT File servers
//			if (fp) fprintf (fp,"%s",objType,objName);
			ccode = ReadPropertyValue(objName,objType,"NET_ADDRESS",1,propVal,&objFlag,&propFlags);
			if (ccode == 0) {
				memset(&rawAddress,0,sizeof(CBA_NETADDR));
				memcpy(&rawAddress.netAddr.ipx,propVal, sizeof(rawAddress.netAddr.ipx));
				k = 0;
				do {
					cd = CBASendPing(CBA_ID_LDVP,CBA_ID_LDVP,NULL,&rawAddress,(unsigned char)prot,0,NULL,0);
					if (cd == -4)
						NTxSleep(20);
					} while (cd == -4 && k++ < 5 && !bAbortFind);
//				if (fp) fprintf (fp,"<%d>",cd);
				}
//			if (fp) fprintf (fp,"\n");
			}
		} while (!ccode);
//	if (fp) fclose (fp);
}
/************************************************************************************/
char ResolveAddress(char *name,CBA_NETADDR *rawAddress,unsigned short *prot) {

	char foundAddress = 0;
	BYTE val[129],b1,b2;
	struct hostent *pHE;
	typedef struct hostent he;
	typedef he*(*tghbn)( struct nwsockent *nwsktctx,char *);
	struct nwsockent nwSocketCtx = {0};


	if (ReadPropertyValue(name,4,"NET_ADDRESS",1,val,&b1,&b2) == 0) {
		memset(rawAddress,0,sizeof(CBA_NETADDR));
		memcpy(&rawAddress->netAddr.ipx,val, sizeof(rawAddress->netAddr.ipx));
		*prot = CBA_PROTOCOL_IPX;
		foundAddress = 1;
		}
	else {
		// now try IP space
		tghbn ghbn = (tghbn)ImportSymbol(GetNLMHandle(),"NWgethostbyname");
		if (ghbn != NULL) {
			memset(rawAddress,0,sizeof(CBA_NETADDR));
			pHE = ghbn(&nwSocketCtx,name);
			if(pHE) {
				memcpy(&rawAddress->netAddr.ipAddr,pHE->h_addr_list[0],sizeof(rawAddress->netAddr.ipAddr));
				*prot = CBA_PROTOCOL_IP;
				foundAddress = 1;
				}
			UnimportSymbol(GetNLMHandle(),"NWgethostbyname");
			}

//	      pHE = gethostbyname(name);

		}
	return foundAddress;
}

#endif 0





int DebugTGID=0;


/************************************************************************************/
void DebugScreen(void *nothing) {

	int ScreenHan;

	REF(nothing);

	ThreadCount++;
	ScreenHan = CreateScreen("RTVSCAN - Debug",DONT_CHECK_CTRL_CHARS|AUTO_DESTROY_SCREEN);
	if (ScreenHan==EFAILURE || ScreenHan==NULL) {
		RingTheBell();
		ThreadCount--;
		return;
	}
	SetCurrentScreen(ScreenHan);
	SetAutoScreenDestructionMode(TRUE);

	DebugTGID = GetThreadGroupID();

	RenameThread(GetThreadID(),"RTV Debug");
	ThreadCount--;

	while( NLMRunning && debug&DEBUGPRINT )
		delay(500);

	DestroyScreen (ScreenHan);
	ScreenHan=0;
	DebugTGID=0;
}


/************************************************************************************/

VOID Real_dprintf(char *format,...) 
{
	va_list marker;
	char line[1024];
	int tgid=0;

	if (debug&DEBUGPRINT) 
	{
		if (DebugTGID == 0) 
		{
			BeginThreadGroup(DebugScreen,NULL,STACK_SIZE,NULL);
			delay(100);
		}
		if (DebugTGID) 
		{
            DWORD dwFineTime;

			tgid = SetThreadGroupID(DebugTGID);
			va_start(marker, format);
            dwFineTime = GetFineLinearTime( );

            NWsprintf(line,"%u.%03u|",dwFineTime / 1000, dwFineTime % 1000 );
			NWvsprintf(line+strlen(line),format,marker);
			va_end(marker);
			NWprintf("%s",line);
//#ifdef SERVER
			//if (debug&DEBUGLOG)
			//	LogLine(line,FALSE);
//#endif
			SetThreadGroupID(tgid);
		}
	}
}




// Took out of defined (SERVER)...
// ksr

/*********************************************************************/

BOOL MyCopyFile(char *from,char *to) 
{
	struct stat
		sStat;
	int
		sHan=-1,
		dHan=-1,
		ccode=-1;

	if (!to || !from)
		return FALSE;

	memset (&sStat,0,sizeof(struct stat));

	dprintf ("Copying File %s -> %s\n",from,to);
	ThreadSwitchWithDelay();

	sHan = open(from,O_BINARY|O_RDONLY);
	if (sHan != INVALID_HANDLE_VALUE) 
	{
		dHan = open(to,O_WRONLY|O_TRUNC|O_BINARY|O_CREAT,S_IWRITE|S_IREAD);
		if (dHan == INVALID_HANDLE_VALUE)
		 {		// maybe the file is read-only
			dprintf ("\tMyCopyFile Open 1 %s Failed: %d-Destination file may be read only\n",to,errno);
			MakeWriteable (to,0xfffffffc);
			dHan = open(to,O_WRONLY|O_TRUNC|O_BINARY|O_CREAT,S_IWRITE|S_IREAD);
			if (dHan == INVALID_HANDLE_VALUE)
			{
				dprintf ("\tUnable to open file: %s\n",to);
			}
		}
		if (dHan != INVALID_HANDLE_VALUE)
		{
			LONG size = lseek(sHan,0,SEEK_END);
			LONG out=0;
			lseek(sHan,0,SEEK_SET);
//			ccode=MasterFileCopy(NULL, from , NULL, to, COPY_ALWAYS|COPY_SAVE_DATE);
			ccode=FileServerFileCopy(sHan,dHan,0,0,size,&out);
			switch (ccode) {
			case ERROR_SUCCESS:
				break;
			default:
/*
#ifdef START
				LogInstallMessage("File Copy failed with error code of %d (%02x)\n",ccode,ccode);
#endif
*/
				close(dHan);
				close(sHan);
				return ccode;
			}
			close(dHan);
		}
		else 
		{
/*
#ifdef START
			LogInstallMessage("\tMyCopyFile open 2 %s failed with errno: %d\n",to,errno);
#endif
*/
			ccode=errno;
		}
		close(sHan);
	}
	else 
	{
/*
#ifdef START
		LogInstallMessage("\tMyCopyFile open 3 %s failed with errno: %d\n",from,errno);
#endif
*/
		ccode=errno;
	}
	sHan = open(from,O_BINARY|O_RDONLY); // set the file time on the destination to the same as the
	if (sHan != INVALID_HANDLE_VALUE) 
	{
		if (fstat(sHan,&sStat)==0) 
		{
//			sStat.st_attr |= 0x01;
			MySetFileInfo (to,&sStat);
		}
		close (sHan);
	}
	return ccode;
}


// Moved out of the following defined
// ksr


/*******************************************************************************************/
void MakeWriteable (char *file,DWORD mask) {

	struct stat Stats;
	int cc, han;

	han = open(file,O_RDONLY);
	if (han != INVALID_HANDLE_VALUE) {
		cc = fstat(han,&Stats);
		close (han);

		if (!cc) {		// so get the current attributes
			Stats.st_attr &= mask;	// and set them to read/write
			MySetFileInfo (file,&Stats);		// and write to the file
		}
		else {
			dprintf("Cannot get attributes for %s: %s!", file, strerror(errno));
		}
	}
}



//#if defined(SERVER) || defined(NLMCGI) || defined(START)
/**************************************************************************************************/
DWORD GetFileState(char *path,void *data) {

	return stat(path,(struct stat*)data);
}
/****************************************************************************************************/
DWORD SetFileState(char *path,void *data) {

	return MySetFileInfo(path,(struct stat*)data);
}
/*********************************************************************************************************/
DWORD GetFileDate(char *Path,VTIME *Time) {

	struct stat stat;
	DWORD ret;
	VTIME t;

	ret = GetFileState(Path,&stat);
	if (ret == ERROR_SUCCESS) {
		t = vtime(stat.st_mtime);
		*Time = t;
		}

	return ret;
}
/*********************************************************************************************************/
DWORD SetFileDate(char *Path,VTIME *Time) {

	DWORD ret;
	struct stat stat;

	ret = GetFileState(Path,&stat);
	if (ret == ERROR_SUCCESS) {
		stat.st_mtime = VTime2TimeT(*Time);
		ret =  SetFileState(Path,&stat);
		}

	return ret;
}
/***************************************************************************************************/
DWORD random(DWORD max) {

	DWORD r1,r2;

	r1=rand();
	r2=(rand()<<16)+r1;
	return r2%max;
}

/*************************************************************************************/
/*********************************************************************/
HANDLE _LoadLibrary(char *name,char Load) {

	long hNLM;
	int i;
	char *q,*prams;
	int cc;
	DWORD OldScreenID,NewScreenID;

//      q = name;
//      while (q && *q && *q != ' ') q=NextChar(q);

	if (Load) {
		dprintf ("Attempting to load: %s\n",name);
		}

	q=strchr (name,' ');
	if (q) {
		prams = NextChar(q);
		*q=0;
		}
	else
		prams = NULL;

	q = name + NumBytes(name) - 1;
	while (q > name && *q != ':' && *q != '/' && *q != '\\')
		q=NWPrevChar(name,q);
	/* not enabled for multi byte*/

	hNLM = FindNLMHandle(q==name?q:q+1);

	if (hNLM) {
		if (Load) {
			dprintf ("\t%s Already Loaded\n",name);
			}
		return hNLM;
		}

	if (!Load) {
		return 0;
		}

	OldScreenID = GetCurrentScreen();
	if(OldScreenID) {
		NewScreenID = CreateScreen("System Console",0);
		if(OldScreenID != NewScreenID)
			(void)SetCurrentScreen(NewScreenID);
		}

	cc = spawnlp (P_NOWAIT,name,name,prams,NULL);

	if (OldScreenID)
		if(OldScreenID != NewScreenID)
			(void)SetCurrentScreen(OldScreenID);


	if (cc) {
		dprintf("\t%s spawnlp failed\n",name);
		return 0;
		}

	dprintf("looking for '%s' \n",q==name?q:q+1);
	for (i=0;i<60&&!hNLM;i++) {
		delay(100);
		hNLM = FindNLMHandle(q==name?q:q+1);
		}

	dprintf ("\t%s Loaded\n",name);
	NTxSleep(2000); // Trend's nlm will crash if we call VEInit before waiting a little after load.
	return hNLM;
}
/****************************************************************************************/
void nlm_FreeLibrary(HANDLE hNLM) {

	typedef struct {
		char stuff[48];
		char len;
		char name[1];
		} HNLM;

	HNLM *h = (HNLM *)hNLM;
	if (h->len == strlen(h->name)) {
		_FreeLibrary(h->name);
		}
}
/************************************************************************************************/
void _FreeLibrary(char *name) {

	char *q;
	char line[64];
	int  cnt=150;

	q = StrRChar(name,'\\');
	if (q == NULL)
		q = name;
	else
		q++;

	WSprintf(line,"UNLOAD %s",q);

	system(line);

	do {
		delay(1000);
	} while (_LoadLibrary(q, FALSE) && cnt-- > 0);
}
/***************************************************************************************/
/**/


char *_strncpy(char *d,char *s,int n) {
	char *org=d;
	n--;
	while(n&&*s) {
		*d++=*s++;
		n--;
		}
	*d=0;
	return org;
}		//MLR Fixed
/**/


HANDLE FindFirstFile(LPCTSTR path,WIN32_FIND_DATA *fd) {

	DIR *dir;

	dir = opendir(path);

	if (dir) {
		fd->dir = readdir(dir);
		if (fd->dir) {
			fd->dwFileAttributes = fd->dir->d_attr;
			//fd->cFileName = fd->dir->d_name; // gdf 07/19/00
			memset(fd->cFileName, 0, IMAX_PATH);// gdf 07/19/00
			strcpy(fd->cFileName, fd->dir->d_name);// gdf 07/19/00
			StrNCopy(fd->cAlternateFileName,fd->dir->d_name,14);
			fd->cAlternateFileName[13] = 0;
			}
		else {
			closedir(dir);
			dir = (DIR *)INVALID_HANDLE_VALUE;
			}
		}
	else
		dir = (DIR *)INVALID_HANDLE_VALUE;

	return (HANDLE)dir;
}
/*********************************************************************/
BOOL FindNextFile(HANDLE han,WIN32_FIND_DATA *fd) {

	BOOL ret = FALSE;

	fd->dir = readdir((DIR *)han);
	if (fd->dir) {
		fd->dwFileAttributes = fd->dir->d_attr;
		//fd->cFileName = fd->dir->d_name; // gdf 07/19/00
		memset(fd->cFileName, 0, IMAX_PATH);// gdf 07/19/00
		strcpy(fd->cFileName, fd->dir->d_name);// gdf 07/19/00
		StrNCopy(fd->cAlternateFileName,fd->dir->d_name,14);
		fd->cAlternateFileName[13] = 0;
		ret = TRUE;
		}
	return ret;
}


/*********************************************************************/

/*
BOOL FindClose(HANDLE han) {

	DIR *dir = (DIR *)han;

	closedir(dir);

	return 1;
}
*/
//#endif // SERVER || NLMCGI || START


//#ifndef GLUE

/************************************************************************/
void InitializeCriticalSection(LPCRITICAL_SECTION lock) {

	lock->ThreadID = 0;
	lock->inuse = 0;
}
/************************************************************************/
void EnterCriticalSection(LPCRITICAL_SECTION lock) {

	int id = GetThreadID();

	while (lock->inuse && lock->ThreadID != id)
		delay (20);

	lock->ThreadID = id;
	lock->inuse++;
}
/************************************************************************/
void LeaveCriticalSection(LPCRITICAL_SECTION lock) {

	lock->inuse--;
}
/************************************************************************/
void DeleteCriticalSection(LPCRITICAL_SECTION lock) {
	lock->inuse = 0;
	lock->ThreadID = 0;
}
//#endif // !GLUE
/************************************************************************/


// ksr
// from win32.c
#undef NumChars
#undef StrRChar
///#undef StrChar
#undef StrStr
#undef NextChar
#undef PrevChar
/*********************************************************************************************/
/**
char *_NextChar(char *s) {
	return CharNext(s);
}
//-********************************************************************************************

char *_PrevChar(char *b,char *s) {
	return CharPrev(b,s);
}




//*********************************************************************************************
int _NumChars(char *s) {

	int i;
	for (i=0;*s;i++)s=NextChar(s);	// _NextChar(s);
	return i;
}
//*********************************************************************************************
char *_StrRChar(char *s,char c) {

	char *last=NULL;

	while (*s) {
		if (*s == c)
			last = s;
		s=NextChar(s); //_NextChar(s);
		}

	return last;
}
//*********************************************************************************************

char *_StrChar(char *s,char c) {

	while (*s) {
		if (*s == c)
			return s;
		s=_NextChar(s);
		}

	return NULL;
}

//*********************************************************************************************

char *_StrStr(char *s,char *s2) {

	int i = _NumChars(s2);
	int j = _NumChars(s);

	while (*s&&j>=i) {
		if (!strncmp(s,s2,i))
			return s;
		s=NextChar(s); // _NextChar(s);
		j--;
		}
	return NULL;
}
**/

//------------------------------------------------------------------------------
// end from win32.c