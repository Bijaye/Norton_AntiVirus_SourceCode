//------------------------------------------------------------------------------
//
//      Walker.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#include "pscan.h"
#include "filetime.h"

VTIME TimeOfLastScan;

#ifdef MemCheck
#define MemLoc  ,__FILE__, __LINE__
#define MemArgs , char *file, int line
#define MemFree(x) MyNLMFree(x, file, line)
#else
#define MemLoc
#define MemArgs
#define MemFree(x) free(x)
#endif // MemCheck

static HANDLE Mutex = 0;
char ScanMemory = 1;
char StoppingAllScans = 0;
int g_iFileCount = 0;

/*
#ifdef WIN32
#include "ClientReg.h"
extern PFNProcessCanUpdateRegKey       pfnProcessCanUpdateRegKey;
extern PFNSfcIsFileProtected           pfnSfcIsFileProtected;

typedef BOOL ( WINAPI *PFNGetDiskFreeSpaceEx )(
    LPTSTR          lpDirectoryName,
    PULARGE_INTEGER lpFreeBytesAvailableToCaller,
    PULARGE_INTEGER lpTotalNumberOfBytes,
    PULARGE_INTEGER lpTotalNumberOfFreeBytes
    );

PFNGetDiskFreeSpaceEx pfnGetDiskFreeSpaceEx = NULL;


BOOL  CheckFreeDiskSpace (DWORD dwBytesNeeded, LPTSTR pszDrive);
DWORD CheckFreeDiskSpaceForScan(DWORD dwTempBytes, DWORD dwAppDataBytes);

HANDLE hCurrentMutexOwner = NULL;
extern HANDLE hAsyncScanMutex;

//============================================================================
static void StartCS(void) {
	if (Mutex == 0)
		Mutex = CreateMutex(NULL,FALSE,NULL);

	WaitForSingleObject(Mutex,INFINITE);
}
//============================================================================
static void EndCS(void) {

	ReleaseMutex(Mutex);
}
#endif
*/


/****************************************************************************************************/
//#ifdef SERVER
/****************************************************************************************************/
/****************************************************************************************************/
/****************************************************************************************************/
/*DWORD MSCB(PSCAN_STATUS block,PEVENTBLOCK inf) {

}
*/
//#endif
/****************************************************************************/
DWORD ScanID=1;
PSCAN_STATUS HeadScan = NULL;
/******************************************************************************/
int _isExtWanted(char *list, char *ext) {
	int pLen = 0, rLen = 0;
	char *p1, *p2, *q, *r1, *r2;
	char Ext[MAX_USED_EXT];
       
	StrNCopy(Ext,ext,sizeof(Ext)-1);
	Ext[sizeof(Ext)-1] = 0;
	StrUpper(Ext);

	for (p1 = p2 = list; p1; p1 = (*q ? NextChar(q) : NULL)) {
		q = StrChar(p1, ',');
		if (!q)
			q = p1 + NumBytes(p1);

		for (r1 = r2 = Ext; ;
			p2 = NextChar(p1), pLen = p2 - p1, p1 = p2,
			r2 = NextChar(r1), rLen = r2 - r1, r1 = r2) {

			if (p1 >= q) {
				if (!(*r1))
					return 1;

				break;
			}

			if (!(*r1))
				break;		// End if Ext - no match here

			if (*p1 == '?')
				continue;	// i.e., '?' matches ANY char, even wchars

			if (pLen != rLen || *p1 != *r1)
				break;		// Dosen't match

		//	This assumes ONLY 1 or 2 byte characters!
			if (pLen > 1 && *(p1 - 1) != *(r1 - 1))
				break;		// PrevChar dosen't match
		}
	}

	return 0;
}
/******************************************************************************/
int isExtWanted(char *list,char *name) {

	char *ext;
	int ret = (*list == '*')?1:0;

	if (ret)
		return ret;

	ext = StrRChar(name,'\\');
	if (!ext)
		ext = name;
	ext = StrRChar(ext,'.');

	if (ext)
		return _isExtWanted(list,ext+1);

	return 0;
}
/*
#ifndef NLM  //ML
BOOL HWIsNEC(void)
{
    static      BOOL bIsNEC = FALSE;
    static      BOOL bTested = FALSE;

    if (!bTested)
        {
        UINT    uType;


        bTested = TRUE;
                                        // Get main KB type
        uType = GetKeyboardType(0);
        if (uType == 7)                 // '7' is japanese keyboard type
            {
                                        // Get the sub-type.
            uType = GetKeyboardType(1);
            if (uType >= 0x0D01)
                bIsNEC = TRUE;
            }

        }
    return(bIsNEC);
}
#endif
*/
/**********************************************************************************/
DWORD ModifyScanStatus(PSCAN_STATUS block, DWORD status) {

	if (block->Status == status)
		return 0;

	block->Status = status;
	//PutVal(block->hkey,"Status",block->Status);

//#ifdef SERVER
	UpdateIDInServerStatus(block->han,block->Status);
//#endif

	NotifyProgress(block);

	return 0;
}
/******************************************************************************/
int ScanOneFile(PSCAN_STATUS block,PSTORAGEOBJECT so,DWORD Flags) {

	LONG cc;
    int  iRetValue = 0;
	BOOL bIsFileProtected = FALSE;	// could be TRUE only on Windows 2000

    FILETIMEDATA filetimeinfo = {0};


    // Save the file's last access time so we can restore it after the scan 
    SaveLastAccessTime(so->Node->InternalPath, &filetimeinfo);
    
	StrCopy(block->CurrentFile,so->Node->Description);
	NotifyProgress(block);

	cc = DoTheScan(so,Flags);

	if (cc != VEOK) {
		if (cc == VEBREAKSCAN) {
			block->Status = S_STOPPING;
			goto All_Done; // returns 0
			}
		else {
			if (cc == VEFILESKIPPED)
				goto All_Done; // returns 0

			if (so->Node->IO->access(so->Node,0) == 0) {
				//EVENTBLOCK log;
				char line[IMAX_PATH+64];

				//memset(&log,0,sizeof(log));

                if(cc == VEBACKUPFAILED)
        	        WSprintf(line, LS(IDS_ERR_ZIP_OMITTED_NOBACKUP), so->Node->Description);
                else
				    WSprintf(line,LS(IDS_ERR_OPEN_FILE),so->Node->Description,cc);
				/*
				log.Description = line;
				log.logger = block->logger;
				//log.hKey[0] = block->hkey;
				log.Category = GL_CAT_SUMMARY;
				log.Event = GL_EVENT_FILE_NOT_OPEN;
				GlobalLog(&log);*/

				block->NotOpen++;
				dprintf("Walker asked to scan %s but was unable.  cc = %08X\n",so->Node->Description,cc);
				}
			goto All_Done; // returns 0
			}
		}

	block->Scanned++;

//#ifndef WIN32
	if ((so->ReturnCode&WAS_VIRUS_MASK)) {
		block->Infected++;
		}
//#endif

    iRetValue = block->Infected;

All_Done:
/*
#ifdef WIN32
	if(pfnSfcIsFileProtected)
	{
		WCHAR wszFileName[IMAX_PATH] = L"";
		DWORD dwRet;

        if(MultiByteToWideChar(CP_ACP, 0, so->Node->InternalPath, -1, wszFileName, sizeof(wszFileName)/sizeof(wszFileName[0])) != 0)
		{
			BOOL bRet = pfnSfcIsFileProtected(NULL, wszFileName);
			dwRet = GetLastError();

			if(bRet)
			{
				bIsFileProtected = TRUE;
			}
			else if ( dwRet != ERROR_FILE_NOT_FOUND )
            {
				dprintf("Failed to determine if the %s is under Windows File Protection, Error: %d\n", so->Node->InternalPath, dwRet);				
            }
		}
		else
			dprintf("Failed to convert %s from ANSI to UNICODE before determining if the file under WFP\n", so->Node->InternalPath);
	}
#endif
*/
	// Do not restore file access time for files under Windows File Protection on Windows 2000
    // Put the file's times back as they were before the scan 
	if(!bIsFileProtected)
		RestoreLastAccessTime(&filetimeinfo);

	return iRetValue;
}
/******************************************************************************/

DWORD WaitForUtil(/*HKEY hkey*/) {

   DWORD bUtilizationEnabled = 1;//GetVal(hkey,"CpuUtilization",0);

	DWORD wanted = 1;//GetVal(hkey,"WantedUtilization",3) * 20;

	DWORD util = 50 /* default */;
    
    if ( bUtilizationEnabled)
    {
        // ??? util = GetCPUUtilization();
    }

	if (wanted > 100)
    {
		wanted = 100;
    }

	ThreadSwitch();

	if (util > wanted)
    {
		NTxSleep(20);
    }

	return 0;
}

/******************************************************************************/

/*
DWORD _DoDir(PSCAN_STATUS block,DWORD ID,char *path,BOOL recurse,PSTORAGEOBJECT so,HANDLE parent,char *FullPath) {

	HANDLE h;
	DWORD CurDir;
	int cc=ERROR_SUCCESS;
	BOOL noScan=FALSE;
	//bnm try allocation and deleting here, so we won't be building on the stack
	//QNODE query;
	QNODE *pQuery;
	//bnm end
	char *fullpath=0;
	BOOL freeFullPath=FALSE;
/*
#ifdef WIN32
    DWORD dwError = ERROR_SUCCESS;
    BOOL bPreScanExclude = ( GetVal(block->hkey,"HaveExceptionFiles",1) && GetVal(block->hkey, szReg_Val_PrescanExclude,0) );
#endif
** /
//	if (FullPath && FullPath[0] == 0)
//		FullPath = NULL;

	ThreadSwitch();
	if (FullPath && block->NoScanDir)
		noScan = isNoScanDir(block->NoScanDir,so->Info,ID,FullPath);

	if (noScan) {
		dprintf("Skipping directory %s\n",path);
		}

	if ((CurDir = block->CurDir++) >= block->MaxDir) {
		int dwTmp;
		DWORD *tmp = realloc(block->FileCounts,(dwTmp=512+block->MaxDir)*sizeof(DWORD));
		if (tmp == NULL) {
			dprintf ("Memory Allocation Error in DoDir\n");
			return ERROR_MEMORY;
			}

		block->MaxDir = dwTmp;
		block->FileCounts = tmp;
		}

	if (block->Status == S_SCANNING_DIRS) {
		block->Dirs++;
		block->FileCounts[CurDir] = 0;
		}

	dprintf("Searching Directory %s\n",path);
	//bnm start malloc for the QNODE structure
	pQuery = malloc (sizeof(QNODE)); 
	if(pQuery)
	{// if mem was allocated
	//bnm use the pointer to call findfirstnode
	h = so->Info->Functions->FindFirstNode(parent,ID,path,pQuery,so->Node);
	//	h = so->Info->Functions->FindFirstNode(parent,ID,path,&query,so->Node);
	//bnm end
/*
#ifdef WIN32
    dwError = (DWORD)h;
    // Scan is denied access to directory due to insufficient privileges
    // for the current thread (on NT) or due to empty removable Drives (9x and NT).
    if( dwError == ERROR_ACCESS_DENIED || dwError == ERROR_NOT_READY) {
        if(recurse && !(noScan&0x080000000) && (block->Status == S_SCANNING_DIRS)){
		    EVENTBLOCK log;
		    char line[IMAX_PATH+64];

            if(dwError == ERROR_ACCESS_DENIED)
            {
		        WSprintf(line, LS(IDS_ERR_ACCESS_DIRECTORY), GetDriveFromInstanceID(ID), FullPath);
            }
            else
            {
		        WSprintf(line, LS(IDS_ERROR_DRIVE_NOT_READY), GetDriveFromInstanceID(ID), FullPath);
            }

        	dprintf(line);

		    memset(&log,0,sizeof(log));
		    log.Description = line;
		    log.logger = block->logger;
		    log.hKey[0] = block->hkey;
		    log.Category = GL_CAT_SUMMARY;
		    log.Event = GL_EVENT_FILE_NOT_OPEN;
            block->NotOpen++;
		    GlobalLog(&log);
            }

		//bnm start
		free(pQuery);
		//bnm end
        return cc;

        }
   else if (h != INVALID_HANDLE_VALUE) {
#else
** /
    if (h != INVALID_HANDLE_VALUE) {
//#endif   // WIN32


#ifdef DEBUG_SCAN_INFO
	    int iLocalDirCount = 1;
#endif
		do  {

			//bnm use pQuesry   if (query.Flags&N_DIRNODE) {
			if (pQuery->Flags&N_DIRNODE) {
				if (recurse && !(noScan&0x80000000)) {
					if (FullPath) {
						//bnm use pQuery fullpath = malloc((FullPath?NumBytes(FullPath):0)+NumBytes(query.Key)+10);
						fullpath = malloc((FullPath?NumBytes(FullPath):0)+NumBytes(pQuery->Key)+10);
						if (fullpath) {
							// bnm use pQuery WSprintf(fullpath,"%s\\%s",FullPath,query.Key+(query.Key[0]=='\\'?1:0));
							WSprintf(fullpath,"%s\\%s",FullPath,pQuery->Key+(pQuery->Key[0]=='\\'?1:0));
							freeFullPath=TRUE;
							}
						}
					else
						fullpath = NULL;

					// bnm use pQuery cc=_DoDir(block,ID,query.Key,recurse,so,h,fullpath);
					cc=_DoDir(block,ID,pQuery->Key,recurse,so,h,fullpath);
					if (freeFullPath) {
						free(fullpath);
						freeFullPath=FALSE;
						}
					}
				}

			// bnm use pQuery if (query.Flags&N_ENDNODE) {
			if (pQuery->Flags&N_ENDNODE) {
				BOOL wanted=FALSE;
/*
#ifdef WIN32    
                // The following change ensures that VESCANALLFILES is used
                // only when ScanType is SCANALLFILES.
				DWORD Flags=VENORMALSCAN|(block->ScanType&0x3fffff);

                // Save the Flag for PreScanExclude to use when scanning files within containers.
                if (bPreScanExclude)
                    Flags |= VEPRESCANEXCLUDE;

				if (block->ScanType&SCANALLFILES) {
                    Flags |= VESCANALLFILES;
#else   // !WIN32 
** /
				DWORD Flags=VESCANALLFILES|(block->ScanType&0x3fffff);

				if (block->ScanType&SCANALLFILES) {
                    Flags |= VESCANALLFILES;
//#endif  // WIN32
					wanted = TRUE;
					}
				else if (block->ScanType&SCANBYTYPE) {
					wanted = TRUE;
					Flags |= VESCANBYTYPE;

					if (block->ScanType&SCANBYTYPEARCH)
						Flags |= VESCANBYTYPEARCH;

					if (block->ScanType&SCANBYTYPEEXEC)
						Flags |= VESCANBYTYPEEXEC;

					if (block->ScanType&SCANBYTYPEOLE)
						Flags |= VESCANBYTYPEOLE;
					}

				else
					{
					// bnm use pQuery else if (_isExtWanted(block->ExtList,query.Ext))
					if (_isExtWanted(block->ExtList,pQuery->Ext))
						wanted = TRUE;
					// bnm use pQuery else if (_isExtWanted(block->ZipExtList,query.Ext))
					else if (_isExtWanted(block->ZipExtList,pQuery->Ext))
						wanted = TRUE;
					}
/*
#ifdef WIN32
                if (bPreScanExclude && GetVal(block->hkey, szReg_Val_ExcludedByExtensions,0) )
                {
                    //bnm use pQuery if (_isExtWanted(block->ExcludedExtList, query.Ext))
                    if (_isExtWanted(block->ExcludedExtList, pQuery->Ext))
                        wanted = FALSE;
                }
#endif
** /
				if (wanted && !noScan) {
					if (block->Status == S_SCANNING_DIRS) {
						// bnm use pQuery if ((block->ScanType&SYSCOMPRESSED) || !(query.Flags&N_COMPRESSED)) {
						if ((block->ScanType&SYSCOMPRESSED) || !(pQuery->Flags&N_COMPRESSED)) {
							block->Files++;
							block->FileCounts[CurDir]++;
#ifdef DEBUG_SCAN_INFO
							// bnm use pQuery dprintf("block->ScanType: %08X,      query.Flags: %08X\n", block->ScanType, query.Flags);
							dprintf("block->ScanType: %08X,      query.Flags: %08X\n", block->ScanType, pQuery->Flags);
							dprintf("block->Files: %08d\tblock->FileCounts[CurDir] = %08d\tCurDir=%08d\n", block->Files, block->FileCounts[CurDir], CurDir);
							dprintf( "g_iFileCount: %08d\tiLocalDirCount= %08d\n", g_iFileCount++, iLocalDirCount++);
							// bnm use pQuery dprintf("Filename: '%s'\n", query.Key);
							dprintf("Filename: '%s'\n", pQuery->Key);
#endif
							}
						}
					else if (block->Status == S_SCANNING_FILES) {
// 09/21/99: MLOPEZ
// The important part of the fix for defect #146468
// The way this code appears to be working is as follows:
// The code iterates through the file system and creates an
// array of the number of files in each directory as well as
// a global count of the number of files that we will scan
// The code then iterates through the file system a second time
// and run into problems when indexing into the array to skip files
// if it already hit a certain number because there is no information
// to tie the directory by name to the index in the array and if a 
// directory is added between the 2 iterations that the virus scan performs
// (and by the way NAV does create a temporary directory in between the 2 
// iterations, which creates this condition 100% of the time)
// then you get some pretty severe mismatching for all directories placed 
// on the scan after the NAV directory and you do not scan a good number of 
// files which you should be scanning.  For those who are curious about the 
// other part of the problem with defect #146468 it is that it does not 
// update the UI once the scan is complete.

// #ifndef NLM

#if 0   // This is now ignored for all platforms. TCASHIN 9/22/99
        // Marco's additional debugging info can be turned on by
        // #defining DEBUG_SCAN_INFO.

						if (block->FileCounts[CurDir]-- != 0) {
#else
							{
#endif
							//bnm use pQuery if ((block->ScanType&SYSCOMPRESSED)|| !(query.Flags&N_COMPRESSED)) {
							if ((block->ScanType&SYSCOMPRESSED)|| !(pQuery->Flags&N_COMPRESSED)) {
/*
#ifdef WIN32    // used for prescan exclusion processing
                                HKEY hKey[3];
#endif
** /								if (FullPath) {
								//bnm use pQuery fullpath = malloc((FullPath?NumBytes(FullPath):0)+NumBytes(query.Key)+10);
									fullpath = malloc((FullPath?NumBytes(FullPath):0)+NumBytes(pQuery->Key)+10);
									if (fullpath) {
										//bnm use pQuery WSprintf(fullpath,"%s\\%s",FullPath,query.Key);
										WSprintf(fullpath,"%s\\%s",FullPath,pQuery->Key);
										//so->FullKey = fullpath;
										freeFullPath=TRUE;
											}
									}
								//else
									//so->FullKey = NULL;

								block->FileCounts[CurDir]--;
#ifdef DEBUG_SCAN_INFO
								//bnm use pQuery dprintf("block->ScanType: %08X,      query.Flags: %08X\n", block->ScanType, query.Flags);
								dprintf("block->ScanType: %08X,      query.Flags: %08X\n", block->ScanType, pQuery->Flags);
								dprintf( "g_iFileCount: %08d\tiLocalDirCount= %08d\n", g_iFileCount++, iLocalDirCount++);
#endif
/*
#ifdef WIN32    // Prescan Exclusion processing
                                hKey[0] = block->hkey;
		                        if ( !( bPreScanExclude && isNodeException(hKey, "FileExceptions",so) ) )
                                { 
                                    ScanOneFile(block,so,Flags);
                                }
#else           // No prescan exclusion processing for non-WIN32 platforms
** /
                                ScanOneFile(block,so,Flags);
//#endif

								if (freeFullPath) {
									free(fullpath);
									freeFullPath=FALSE;
									}
								}
							}
						}
					}
				if (so->Node)
					so->Node->Functions->ReleaseSNode(so->Node);
				}
			if (block->Status == S_SCANNING_DIRS) {
				NotifyProgress(block);
				ThreadSwitch();
				}
			else
				WaitForUtil(/*block->hkey** /);

			if (block->Status == S_STOPPING || StoppingAllScans)
				break;
			// use pQuery } while(cc==ERROR_SUCCESS && so->Info->Functions->FindNextNode(h,&query,so->Node)==ERROR_SUCCESS);
			} while(cc==ERROR_SUCCESS && so->Info->Functions->FindNextNode(h,pQuery,so->Node)==ERROR_SUCCESS);
		so->Info->Functions->FindClose(h);
		}

		//bnm delete 
		free(pQuery);
	}// bnm check for pQuery malloc
	else
		cc = ERROR_MEMORY;
	// end else check for pQuery malloc


	return cc;
}
*/

/******************************************************************************/
/*
DWORD DoDir(PSCAN_STATUS block,char *path,BOOL recurse) { // this path = [FileSystem,128]\program files\ ...

	PSTORAGEOBJECT so;
	DWORD ID;
	PSTORAGEITEM Item = GetStorageAndIDFromPath(&path,&ID);
	DWORD cc;

	if (Item == NULL)
		return 1;
/*
#ifdef WIN32
    if (ID == 0)
    {
        if(recurse && (block->Status == S_SCANNING_DIRS))
        {
		    EVENTBLOCK log;
		    char line[IMAX_PATH+64];

            // Unable to obtain the Instance ID since the path was not found.
            // An Instance ID is required to check if the current path needs
            // to be excluded.  So a Scan Ommission error will be logged.
	        WSprintf(line, LS(IDS_ERR_ACCESS_DIRECTORY), path, "");

        	dprintf(line);

		    memset(&log,0,sizeof(log));
		    log.Description = line;
		    log.logger = block->logger;
		    log.hKey[0] = block->hkey;
		    log.Category = GL_CAT_SUMMARY;
		    log.Event = GL_EVENT_FILE_NOT_OPEN;
            block->NotOpen++;
		    GlobalLog(&log);
        }

        return 1;
    }
#endif
** /
	if (block->Status == S_SCANNING_DIRS)
		so = malloc(sizeof(STORAGEOBJECT));
	else if (block->Status == S_SCANNING_FILES)
		so = malloc(sizeof(STORAGEOBJECT)+sizeof(SNODE));
	else
		return 1;

	if (so == NULL) {
		dprintf ("Memory Allocation Error in DoDir\n");
		return ERROR_MEMORY;
		}

	memset(so,0,sizeof(STORAGEOBJECT));
	so->Info = Item->Info;

	if (block->Status == S_SCANNING_FILES)
		so->Node = (PSNODE)(so+1);

	so->block = block;
	so->Flags = FA_SCANNING_FILE | FA_WALKSCAN;

    g_iFileCount = 1;
	cc = _DoDir(block,ID,path,recurse,so,NULL,path);

	free(so);

	return cc;
}
*/


/******************************************************************************/

DWORD DoFile(PSCAN_STATUS block,char *path,char *namestring) { // this path = [FileSystem,128]\program files\ ...    OR  C:\program files\ ...

	PSTORAGEOBJECT so;
	PSTORAGEITEM Item;
	DWORD cc = ERROR_SUCCESS;
	DWORD ID;

	if (block->Status == S_SCANNING_DIRS)
		block->Files++;
	else {
		Item = GetStorageAndIDFromPath(&path,&ID);

		if (Item == NULL)
			return 1;
/*
#ifdef WIN32
        if (ID == 0)
        {
		    EVENTBLOCK log;
		    char line[IMAX_PATH+64];

            // Unable to obtain the Instance ID since the path was not found.
            // An Instance ID is required to check if the current path needs
            // to be excluded.  So a Scan Ommission error will be logged.
	        WSprintf(line, LS(IDS_ERR_ACCESS_DIRECTORY), path, "");

        	dprintf(line);

		    memset(&log,0,sizeof(log));
		    log.Description = line;
		    log.logger = block->logger;
		    log.hKey[0] = block->hkey;
		    log.Category = GL_CAT_SUMMARY;
		    log.Event = GL_EVENT_FILE_NOT_OPEN;
            block->NotOpen++;
		    GlobalLog(&log);

            return 1;
        }
#endif
*/
		so = malloc(sizeof(STORAGEOBJECT)+sizeof(SNODE));
		if (so == NULL) {
			dprintf ("Memory Allocation Error in DoDir\n");
			return ERROR_MEMORY;
			}

		memset(so,0,sizeof(STORAGEOBJECT));
		//so->FullKey = path;
		so->Info = Item->Info;
		so->Node = (PSNODE)(so+1);
		so->block = block;
		so->Flags = FA_SCANNING_FILE | FA_WALKSCAN;
		cc = so->Info->Functions->CreateSNode(ID,path,so->Node);

		if (cc == ERROR_SUCCESS) {
			DWORD Flags = block->ScanType&(~MYSCANFLAGS);
			if (block->ScanType&SCANBYTYPE) {
				Flags |= VESCANBYTYPE;

				if (block->ScanType&SCANBYTYPEARCH)
					Flags |= VESCANBYTYPEARCH;

				if (block->ScanType&SCANBYTYPEEXEC)
					Flags |= VESCANBYTYPEEXEC;

				if (block->ScanType&SCANBYTYPEOLE)
					Flags |= VESCANBYTYPEOLE;
				}

            if ( namestring )
                strcpy( so->Node->Description, namestring );

			ScanOneFile(block,so,Flags);
			so->Node->Functions->ReleaseSNode(so->Node);
			}
		free(so);
		}

	return cc;
}
/******************************************************************************/
void SetUsedBit(PSCAN_STATUS block,char *path) { // path is in [FileSystem,128]\foo ...
// this entire function is a FileSystem Hack that by-passes the StorageManager
// we do not want to scan the boot sector of drives we don't scan.
// we also

	int i;
	int ID;
	char *q = StrChar(path,',');


	if (*(DWORD *)path != *(DWORD *)"[Fil") {
		if (path[1] != ':')
			return;
		i = path[0];
		if (i > 'Z')
			i = i-'a';
		else
			i = i-'A';
		}
	else {
		if (q == NULL)
			return;

		q++;

		ID = atoi(q);
		if (ID < 128)
			i = ID-1;
		else if (ID < 256)
			i = ID - 128;
		else
			i = ID - 256;
		}

	block->DrivesUsed |= (1<<i);
	block->WriteCheck = 0;
}
/******************************************************************************/
/*
DWORD DoDirs(PSCAN_STATUS block) 
{

	//HKEY hkey;
	char dir[IMAX_PATH];
	DWORD recurse;
	DWORD index;
	DWORD dirlen;
	DWORD rlen;
	DWORD cc=ERROR_SUCCESS;
	DWORD drives = 0; //????
	DWORD type = 0;  //????

	if (block->Status == S_SCANNING_DIRS) 
    {
		block->ScanType = VESLOWSCAN;
		//type=GetVal(block->hkey,"FileType",0);      // By default scan All File Types
		if (type==0) 
        {
			block->ScanType |= SCANALLFILES;
		}
		else if (type==1) 
        { // ZipExts are added in the UI now, if not set then do the right thing
			//GetStr(block->hkey,"Exts",block->ExtList,sizeof(block->ExtList),"");
			if (!*block->ExtList) 
            {
                // MMENDON 08-21-2000 STS defect 340457  
                // if error reading exts from registry, want to scan all files.
                block->ScanType |= SCANALLFILES;
                dprintf("Error reading manual extensions from registry.  Scanning all files.\n");
                // MMENDON 08-21-2000 End STS defect 340457  
			}
		}
		else if (type==2) 
        {
			//type=GetVal(block->hkey,"Types",7);
			block->ScanType |= SCANBYTYPE |
					(type&SCAN_BY_TYPE_ARCHIVES?SCANBYTYPEARCH:0) |
					(type&SCAN_BY_TYPE_EXECUTABLE?SCANBYTYPEEXEC:0) |
					(type&SCAN_BY_TYPE_OLE?SCANBYTYPEOLE:0);
		}
/*
#ifdef WIN32
        // Get wild card exclusions
        if( GetVal(block->hkey, szReg_Val_ExcludedByExtensions, 0) )
        {
            GetStr(block->hkey, szReg_Val_ExcludedExtensions, block->ExcludedExtList, sizeof(block->ExcludedExtList), "");
        }
#endif
** /
		block->Dirs = 0;
		block->Files = 0;
/*
		block->ScanType |= (GetVal(block->hkey,"ZipFile",1)?VEEXPANDFILES:0) |
							(GetVal(block->hkey,"DoCompressed",1)?SYSCOMPRESSED:0)|
							(GetVal(block->hkey,"SoftMice",1)?VEMUTATIONSCAN:0);

		block->ZipDepth = GetVal(block->hkey,"ZipDepth",3);
** /
		// tmm: if we are scanning compressed files, get the zip ext list, just in case we're scanning by extension!
		block->ZipExtList[0] = 0/*NULL*/;
		//if (block->ScanType & VEEXPANDFILES)
			//GetStr(block->hkey,"ZipExts",block->ZipExtList,sizeof(block->ZipExtList),DEFAULT_ARC_EXTS);
/*
#ifndef NLM  //ML
        // If the registry value does not exist, then by default backup before repair is turned on
        block->dwBackupToQuarantine = GetVal(block->hkey, szReg_Val_BackupToQuarantine, 1);
#endif
** /		PreReadNoScanDirs(//block->hkey,
                        &block->NoScanDir);
	}

	block->CurDir = 0;

	//if ((drives = GetVal(block->hkey,"ScanAllDrives",1)) != 0) 
    {  // Scan All Fixed Drives.
		char *q;
		char *list = malloc(1024);
		char *e;
		char *w;
		DWORD Index = 0;
		if (list) 
        {
			do 
            {
				QueryDriveList(list,&Index,0);
				q = StrChar(list,'!');
				if (q) 
                {
					q++;
					e = StrChar(q,';');
					if (e)
						*e = 0;
//					q = strtok(q,";");
					while (q) 
                    {
						w = StrChar(q,']');
						if (w) 
                        {
							BOOL ok=FALSE;
							char old;
							switch (old=w[1]) 
                            {
								case 'F': ok = (drives&1 )?TRUE:FALSE; break;
								case 'R': ok = (drives&2 )?TRUE:FALSE; break;
								case 'N': ok = (drives&4 )?TRUE:FALSE; break;
								case 'C': ok = (drives&8 )?TRUE:FALSE; break;
								case 'M': ok = (drives&16)?TRUE:FALSE; break;
							}
							if (ok) 
                            {
								w[1] = 0;
								SetUsedBit(block,q);
								cc=DoDir(block,q,TRUE);
								w[1] = old;
							}
						}
						if (e) 
                        {
							q = e+1;
							e = StrChar(q,';');
							if (e)
								*e = 0;
						}
						else
							q = NULL;
//						q = strtok(NULL,";");
					}
				}
			} while (Index);
			free(list);
		}
		else 
        {
			cc=ERROR_MEMORY;
		}
		if (cc!=ERROR_SUCCESS) 
        {
			dprintf ("Error in DoDirs: %d 0x%x\n",cc,cc);
			return cc;
		}
	}
	/*
	else 
    {
		//if (RegOpenKey(block->hkey,"Directories",&hkey) == ERROR_SUCCESS) 
        {
			dirlen = sizeof(dir);
			rlen = sizeof(recurse);
			index=0;
			//while (RegEnumValue(hkey,index++,dir,&dirlen,NULL,NULL,(LPBYTE)&recurse,&rlen) == ERROR_SUCCESS) 
            {
				if (block->Status == S_STOPPING || StoppingAllScans)
					break;
				SetUsedBit(block,dir);
				cc=DoDir(block,dir,recurse);
				dirlen = sizeof(dir);
				rlen = sizeof(recurse);
			}

			//RegCloseKey(hkey);
		}

		if (cc!=ERROR_SUCCESS) 
        {
			dprintf ("Error in DoDirs: %d 0x%x\n",cc,cc);
			return cc;
		}

		//if (RegOpenKey(block->hkey,"Files",&hkey) == ERROR_SUCCESS) 
        {
			dirlen = sizeof(dir);
			index=0;
			//while (RegEnumValue(hkey,index++,dir,&dirlen,NULL,NULL,NULL,NULL) == ERROR_SUCCESS) 
            {
				if (block->Status == S_STOPPING || StoppingAllScans)
					break;
				SetUsedBit(block,dir);
				DoFile(block,dir,NULL);
				dirlen = sizeof(dir);
			}

			//RegCloseKey(hkey);
		}
	}
	** /
	return cc;
}

*/

/******************************************************************************/
DWORD GetHandleOfScan(DWORD ScanID,DWORD *han) {

	PSCAN_STATUS cur;
	DWORD ret = ERROR_NO_SCAN;

	LOCK();
	cur = HeadScan;
	while (cur) {
		if (cur->ScanID == ScanID) {
			ret = ERROR_SUCCESS;
			*han = cur->han;
			cur->time = time(NULL);
			break;
			}
		cur = cur->next;
		}
	UNLOCK();

	return ret;
}
/******************************************************************************/
DWORD GetScanStatus(DWORD han,PSCAN_STATUS *block) {

	PSCAN_STATUS cur;
	DWORD ret = ERROR_NO_SCAN;

	LOCK();
	cur = HeadScan;
	while (cur) {
		if (cur->han == han) {
			ret = ERROR_SUCCESS;
			*block = cur;
			cur->time = time(NULL);
			break;
			}
		cur = cur->next;
		}
	UNLOCK();

	return ret;
}
/******************************************************************************/
/*
DWORD FreeScanStatus(PSCAN_STATUS cur) {

	char line[IMAX_PATH];

	if (cur) {

        // Force the scan to stop before freeing up the memory
        // Note: Code fragment was taken out of StopScan()
        if (ScanRunning(cur->Status)) 
            {
            ModifyScanStatus(cur, S_STOPPING);
            while(ScanRunning(cur->Status))
                NTxSleep(128);
            }

		if (cur->FileCounts)
			free(cur->FileCounts);
		if (cur->FileState)
			free(cur->FileState);

		PreReadNoScanDirs(NULL,&cur->NoScanDir);

		dprintf("Freeing Scan Block %08X han = %u\n",cur,cur->han);
		cur->Size = 0;
		/*
#ifdef WIN32
		{  char str[64];
			HKEY hkey;
			if (RegOpenKey(hMainKey,"CurrentMaps",&hkey) == ERROR_SUCCESS) {
				WSprintf(str,"LDVPScanMap_%u",cur->iScanNumber);
				RegDeleteValue(hkey,str);
				RegCloseKey(hkey);
				}
		}

		if (cur->dlg)
			free(cur->dlg);
#endif

		// Fix for STS#330336.
		// Check to make sure that the key is still open before attempting
		// to use it since the scan could have been completed along with
		// clean up. 
		//if(cur->hkey)
		{
			//GetStr(cur->hkey,"DelWhenDoneName",line,sizeof(line),"");
			if (line[0]) {
				//HKEY hkey;
				char *q = StrRChar(line,'\\');
				DWORD RootID = GetVal(cur->hkey,"DelWhenDoneKey",0);
				if (q != NULL && RootID != 0) {
					*q = 0;
					if (RegOpenKey(VpRegBase[RootID&0xff].hBase,line,&hkey) == ERROR_SUCCESS) {
						RegDelKeys(hkey,q+1);
						RegCloseKey(hkey);
						}
					}
				}

			RegCloseKey(cur->hkey);
		}

		if (cur->pFree)  // this frees myself
			cur->pFree(cur MemLoc);
		}

	return 0;
}
*/


/******************************************************************************/
DWORD StopAllScans(void) {

	PSCAN_STATUS cur;
	int i;

	LOCK();
	StoppingAllScans = 1;

	cur = HeadScan;

	while (cur) {
	/*
#ifdef WIN32
        if (cur->Status == S_QUEUED)
        {
            ModifyScanStatus(cur, S_ABORTED);
        }
        else
#endif
*/
		    if (ScanRunning(cur->Status))
			    cur->Status = S_STOPPING;

		cur = cur->next;
		}

	NTxSleep(128);

	cur = HeadScan;

	while (cur) {
//#ifdef SERVER
		RemoveIDFromServerStatus(cur->han);
//#endif
		for (i=0;ScanRunning(cur->Status);i++) {
			if (i%(20*10)) {
				dprintf("Scan %08X still locked\n",cur);
				}
			NTxSleep(50);
			}
		cur = cur->next;
		}
	UNLOCK();
	return ERROR_SUCCESS;
}
/******************************************************************************/
// can only be called when all thread are known to be stopped
DWORD FreeAllScans(void) {

	PSCAN_STATUS cur,last;
	
//#ifdef NLM
	// clear references to the list of completed scans - they will
	// be freed next, and we don't want any references hanging around

	FreeUIScanList( );
//#endif

	LOCK();

	cur = HeadScan;
	HeadScan = NULL;
	UNLOCK();

	while (cur) {
		last = cur;
		cur = cur->next;
		FreeScanStatus(last);
		}
	return ERROR_SUCCESS;
}
/******************************************************************************/
/*
DWORD CheckScans(void) {

	PSCAN_STATUS cur,last=NULL,rem;

	LOCK();
	cur = HeadScan;
	while (cur) {
		rem = NULL;
		if (cur->inuse == 0 && !ScanRunning(cur->Status) && cur->time + (/*5** /60) < (DWORD)time(NULL)) {
			rem = cur;
			if (last)
				last->next = rem->next;
			else
				HeadScan = rem->next;
//#ifdef SERVER
			RemoveIDFromServerStatus(rem->han);
//#endif
			}

		if (rem == NULL)
			last = cur;

		cur = cur->next;

		if (rem != NULL)
			FreeScanStatus(rem);
      ThreadSwitch();
		}

	UNLOCK();

	return 0;
}
*/

/******************************************************************************/
DWORD StopScan(DWORD han,BOOL async) {

	PSCAN_STATUS block;
	DWORD ret;

	dprintf ("Stopping Scan: %d\n",han);
	ret = GetScanStatus(han,&block);
	if (ret == ERROR_SUCCESS) {
		if (ScanRunning(block->Status)) {
			ModifyScanStatus(block,S_STOPPING);
			while(!async && ScanRunning(block->Status))
				NTxSleep(128);
			}
		else
			ret = ERROR_SCAN_ALREADY_STOPPED;
		}
	dprintf ("\tStopped. returning: %d (0x%x)\n",ret,ret);
	return ret;
}
/******************************************************************************/



/*
DWORD DoBootScan(PSCAN_STATUS block) {

	BYTE *CritData;
	VESTATUS cc;
	int i;
	int drive;
    TCHAR szRoot[] = "?:\\";
#ifndef NLM
    unsigned int driveType = DRIVE_UNKNOWN;
#endif
	USEVE

	dprintf ("Do Boot Scan\n");
	//if (GetVal(block->hkey,"ScanBootSector",1)) {
		dprintf ("Scanning Boot Sector\n");
		ModifyScanStatus(block,S_SCANNING_BOOT);

		CritData = malloc(VeInfo->wCriticalDiskDataSize);
		if (CritData) {
			for (i=0;i<28;i++) {
#ifndef NLM  //ML
				if ((block->DrivesUsed&(1<<i)) || ((i >= 26) && !HWIsNEC()))  {
#else
				if ((block->DrivesUsed&(1<<i)) || (i >= 26) )  {
#endif
					if (i >= 26)
                        {
                        // master boot record scan is performed for valid disk
                        // numbers 0x80 and 0x81
						drive = 0x80 + i - 26;
						dprintf("Scanning Master Boot %08x\n", drive);
                        }
					else
                        {
                        // boot record scan is performed for valid drive
                        // letters A: through Z:
						drive = i;
/*
#ifndef NLM  //ML
                        szRoot[0] = (TCHAR)(i + 'A');
                        driveType = GetDriveType(szRoot);

                        // On network drives, do not attempt to scan the boot sector
                        // On NEC, only perform boot scan on removables
                        if( (driveType == DRIVE_REMOTE) || (HWIsNEC() && driveType  != DRIVE_REMOVABLE) )
                            {
                                continue;
                            }

						dprintf("Scanning Boot Sector %d\n", drive);
#endif //.. ifndef NLM
*** /                        }
					CALLVE;
					cc = VEGetCriticalDiskData(VEhan,drive,CritData);
					RETVE;
					if (cc == VEOK) {
						VEDISKINFO di;
						STORAGEOBJECT rso,*so=&rso;
//						char line[128];
						SNODE node;

						memset(so,0,sizeof(STORAGEOBJECT));
						memset(&node,0,sizeof(SNODE));

						so->Flags = FA_WALKSCAN | FA_SCANNING_BOOT_SECTOR;
						so->block = block;

						so->Node = &node;
						so->Info = FileStorageItem->Info;

						cc = so->Info->Functions->CreateSNode(1024+i,NULL,so->Node);
						if (cc == ERROR_SUCCESS) {

							StrCopy(block->CurrentFile,so->Node->Description);

							memset(&di,0,sizeof(VEDISKINFO));
							di.wSize = sizeof(VEDISKINFO);
							di.appContext = (VECONTEXT)so;
							di.pCriticalDiskData = CritData;
							di.dwScanType = (block->ScanType&(~MYSCANFLAGS))&(VESLOWSCAN|VEFASTSCAN);

							CALLVE;
							VEScanCriticalDiskData(VEhan,&di);
							RETVE;
							so->Node->Functions->ReleaseSNode(so->Node);
							}
						}
					}
				}
			free(CritData);
			}
		else return ERROR_MEMORY;
		}

	return 0;
}
*/

/******************************************************************************/
VESTATUS MemStat(DWORD total,DWORD done,VECONTEXT Context) {

	dprintf("total = %u  done = %u context = %08X\n",total,done,Context);

	return VEOK;
}
/******************************************************************************/
/*
DWORD DoMemScan(PSCAN_STATUS block) {

	VEMEMINFO mi;
	STORAGEOBJECT rso,*so=&rso;
	SNODE node;
	DWORD cc;
	USEVE

	//if (ScanMemory && GetVal(block->hkey,"ScanMemory",0)) {
		dprintf ("Scanning Memory\n");
		ModifyScanStatus(block,S_SCANNING_MEM);

		memset(so,0,sizeof(STORAGEOBJECT));
		memset(&node,0,sizeof(SNODE));

		so->Flags = FA_WALKSCAN | FA_SCANNING_MEMORY;
		so->block = block;

		so->Node = &node;
		so->Info = FileStorageItem->Info;

		cc = so->Info->Functions->CreateSNode(2048,NULL,so->Node);
		if (cc == ERROR_SUCCESS) {
			StrCopy(block->CurrentFile,so->Node->Description);
			memset(&mi,0,sizeof(VEMEMINFO));
			mi.wSize = sizeof(VEMEMINFO);
			mi.appContext = (VECONTEXT)so;
			mi.dwScanType = (block->ScanType&(~MYSCANFLAGS))&(VESLOWSCAN|VEFASTSCAN);
			mi.cbMemoryStatus = MemStat;
			mi.dwBreakSize = 1024;

			CALLVE;
			cc = VEScanMemory(VEhan,&mi);
			RETVE;

			so->Node->Functions->ReleaseSNode(so->Node);
			}
		dprintf("mem ret = %08X\n",cc);

		}
	return 0;
}

*/



/******************************************************************************/

#if 0


void _ScanThread(PSCAN_STATUS block) {

	EVENTBLOCK log;
	char line[256];
	char str[64];
	char aborted=FALSE;
	char *locktable[20];
	int lockcount=0;
	int i;
	char *p1,*p2,*p3;
	/*
#ifdef WIN32
	UINT old;
    DWORD dwTempBytesNeeded = 0;
    DWORD dwAppDataBytesNeeded = 0;
    char szAppName[64];
    DWORD dwRet = ERROR_SUCCESS;
#endif //WIN32

#if defined(CLIENT) || defined(WIN95)
	DWORD slot=0xffffffff;
#endif


#ifdef WIN32
    dwTempBytesNeeded = GetVal(block->hkey, szReg_Val_NeededFreeDiskSpace, MIN_DISK_SPACE_FOR_SCAN);
    dwAppDataBytesNeeded = GetVal(block->hkey, szReg_Val_NeededFreeDataDiskSpace, MIN_DATA_DISK_SPACE_FOR_SCAN);

    if( dwTempBytesNeeded < MIN_DISK_SPACE_FOR_SCAN )
        dwTempBytesNeeded = MIN_DISK_SPACE_FOR_SCAN;

    if( dwAppDataBytesNeeded < MIN_DATA_DISK_SPACE_FOR_SCAN )
        dwAppDataBytesNeeded = MIN_DATA_DISK_SPACE_FOR_SCAN;

    dwRet = CheckFreeDiskSpaceForScan(dwTempBytesNeeded, dwAppDataBytesNeeded);
    if(dwRet != ERROR_SUCCESS)
    {
        block->GroupID = GetVal(block->hkey,"GroupID",0);
        block->time = time(NULL);
    
        if(dwRet == ERROR_NOT_ENOUGH_DISK_SPACE)
    	    WSprintf(line,"%s",LS(IDS_ERROR_DISKSPACE));
        else
            WSprintf(line, "%s",LS(IDS_ERROR_READ_DISKSPACE_DATA));

        dprintf (line);
        ModifyScanStatus(block,S_ABORTED);

    	if (GetVal(block->hkey, szReg_Value_DisplayStatusDlg, 0))
        {
            // Scan Failed due to low disk space
            lstrcpy(szAppName, LS(STR_APP_NAME));
            MessageBox(NULL, line, szAppName, MB_OK | MB_ICONSTOP);
        }

	    memset(&log,0,sizeof(log));
	    log.Description = line;
	    log.logger = block->logger;
	    log.hKey[0] = block->hkey;
	    log.Category = GL_CAT_SUMMARY;
	    log.Event = GL_EVENT_SCAN_ABORT;
	    log.ScanID = block->ScanID;
	    log.GroupID = block->GroupID;
	    GlobalLog(&log);
    
        goto Abort;
    }

	dprintf("CheckFreeDiskSpaceForScan successfull \n");
#endif


#if defined(CLIENT) || defined(WIN95)
	InitThreadForScan(&slot);
#endif

#ifdef WIN32
	old = SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOOPENFILEERRORBOX);

    // Disable AP for an On-demand Scan
    GetAPFunctions();
    DisableAP();

#endif
*/

	TimeOfLastScan = vtime(0);
	PutData(hMainKey,"TimeOfLastScan",&TimeOfLastScan,sizeof(VTIME));


//#ifdef SERVER
/*
#ifdef WINNT
	// Attempt to ReStartPongEngine only if the current thread has appropriate privileges
	if(pfnProcessCanUpdateRegKey  && hAccessToken)
	{
		DWORD bCanUpdate = FALSE;
		pfnProcessCanUpdateRegKey(hAccessToken, HKEY_LOCAL_MACHINE, szReg_Key_Main, (ULONG *)&bCanUpdate);
		if(bCanUpdate)
		{
			ReStartPongEngine(FALSE);
			dprintf("Completed ReStartPongEngine() after checking user privileges \n");
		}
	}
#else // !WINNT 
*/
	
	ReStartPongEngine(FALSE);
	
	
//#endif // end of !WINNT
//#endif // end of SERVER

	//block->GroupID = GetVal(block->hkey,"GroupID",0);
	block->time = time(NULL);
	block->StartTime = vtime(0);
	dprintf ("Scan Started at %s",ctime((const time_t *)&block->time));
	ModifyScanStatus(block,S_STARTED);
/*
#ifdef WIN32
	if (GetVal(block->hkey,"DisplayStatusDialog",0))
		CreateScanStatusDialog(block);
#endif
*/
	memset(&log,0,sizeof(log));

	p1 = locktable[lockcount++] = LSlock(IDS_SERVER_SCAN_START);
	//p2 = locktable[lockcount++] = GetVal(block->hkey,"ScanAllDrives",0)?LSlock(IDS_ALL_DRIVES):LSlock(IDS_SELECT_DRIVE);
	//p3 = locktable[lockcount++] = GetVal(block->hkey,"FileType",0)?LSlock(IDS_SELECT_EXTENSIONS):LSlock(IDS_ALL_EXTENSIONS);
	WSprintf(line,p1,p2,p3);

	log.Description = line;
	log.logger = block->logger;
	//log.hKey[0] = block->hkey;
	log.Category = GL_CAT_SUMMARY;
	log.Event = GL_EVENT_SCAN_START;
	log.ScanID = block->ScanID;
	log.GroupID = block->GroupID;
	GlobalLog(&log);
	OpenInfectionHandle(&block->InfHan);

	for (i=0;i<lockcount;i++)
		LSfree(locktable[i]);

	ThreadSwitchWithDelay();

	dprintf ("Scanning Directories\n");
	ModifyScanStatus(block,S_SCANNING_DIRS);

	DoDirs(block);

	if (block->Status == S_STOPPING || StoppingAllScans) {
		aborted = TRUE;
		goto done;
		}
	ThreadSwitchWithDelay();

/* ksr ???
	DoBootScan(block);
	if (block->Status == S_STOPPING || StoppingAllScans) {
		aborted = TRUE;
		goto done;
		}
    dprintf("Finished Boot Scanning\n");
	ThreadSwitchWithDelay();

	DoMemScan(block);
	if (block->Status == S_STOPPING || StoppingAllScans) {
		aborted = TRUE;
		goto done;
		}
	ThreadSwitchWithDelay();

	dprintf ("Scanning Files\n");
	ModifyScanStatus(block,S_SCANNING_FILES);

	DoDirs(block);

    if (block->Status == S_STOPPING || StoppingAllScans) {
		aborted = TRUE;
		goto done;
		}
	ThreadSwitchWithDelay();
*/


done:
/*
#ifdef WIN32
	SetErrorMode(old);

    // Enable AP when done with the On-demand Scan
    EnableAP();
    FreeNAVAP();

#endif
*/
	if (!aborted)
		NTxSleep(8000);  // Give alert threads and remote dialogs a change to get virus packets before we tell them the scan is done
		
	ModifyScanStatus(block,aborted?S_ABORTED:S_DONE);
	dprintf ("Done Status: %s\n",aborted?"aborted":"completed");
	memset(&log,0,sizeof(log));
	WSprintf(line,LS(IDS_LOG_SCAN_COMPLETE),aborted?LS(IDS_SCAN_ABORTED):LS(IDS_SCAN_COMPLETE),
		block->Viruses,block->Infected,block->Scanned,block->NotOpen);

//	PutVal(block->hkey,"RunningTime",time(NULL)-block->time);

	CloseInfectionHandle(block->InfHan);

	WSprintf(str,"%u:%u:%u:%u",block->Viruses,block->Infected,block->Scanned,block->NotOpen);

	log.Description = line;
	log.EventData = (PBYTE)str;
	log.logger = block->logger;
//	log.hKey[0] = block->hkey;
	log.Category = GL_CAT_SUMMARY;
	log.Event = aborted ? GL_EVENT_SCAN_ABORT: GL_EVENT_SCAN_STOP;
	log.ScanID = block->ScanID;
	log.GroupID = block->GroupID;
	GlobalLog(&log);

/*
#if defined(CLIENT) || defined(WIN95)
	DeInitThreadForScan(&slot);
#endif
//	PutVal(block->hkey,"SendReport",0);

#if defined(SERVER) && defined(WIN32)
	  // HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK
	  // HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK
	  // HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK
	  // HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK
	{ // HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK HACK
	OSVERSIONINFO v;
	v.dwOSVersionInfoSize = sizeof(v);
	GetVersionEx(&v);
	if (v.dwPlatformId == VER_PLATFORM_WIN32_NT) {
		if (v.dwMajorVersion == 3) {
			if (GetVal(block->hkey,"FileType",0) == 0) {
				char path[IMAX_PATH];
				char file[IMAX_PATH];
				GetWindowsDirectory(path,IMAX_PATH);
				WSprintf(file,"%s\\system32\\config\\SOFTWARE",path);	_my_chmod(file,1,FA_ARCH);
				WSprintf(file,"%s\\system32\\config\\SYSTEM",path);	_my_chmod(file,1,FA_ARCH);
				WSprintf(file,"%s\\system32\\config\\DEFAULT",path);	_my_chmod(file,1,FA_ARCH);
				WSprintf(file,"%c:\\pagefile.sys",path[0]);	_my_chmod(file,1,FA_ARCH);
				}
			}
		}
	}

#endif


#ifdef SERVER
	if (GetVal(block->hkey,"AutoRepeatForever",0)&&!StoppingAllScans) {
		HKEY hkey;
// un comment these lines if you want to do resources checking for repeet scans.
//		RemoveIDFromServerStatus(block->han);
//		block->time = 0;
//		hkey = block->hkey;
//		CheckScans();
		DUPKEY(block->hkey,&hkey);
		StartServerScan(hkey,NULL);
		}
#endif
*/
Abort:
	//03/14/2000 Gary Figgins return to netware monitor screen if monitor running
	//#ifdef NLM
	switchToMonitorScreen();
	//#endif
	if (block->FileCounts) {
		free(block->FileCounts);
		block->FileCounts = NULL;
		}
	if (block->FileState) {
		free(block->FileState);
		block->FileState = NULL;
		}

	// let FreeScanStatus close key, delete it and free it.
}


 /*************************************************************************************************/
//#ifdef NLM
 //03/14/2000 Gary Figgins function to search all available screens for monitor screen
 //and switch to monitor if found
void switchToMonitorScreen(void)
{
	char namebuf[80], buff[80];
    char NW5[] = {"NetWare 5 Console Monitor"};
	char NW4[] = {"NetWare 4.x Console Monitor"};
    char NW3[] = {"Monitor Screen"};

	int screenId, screenHandle, screenfound=FALSE;
	LONG attributes;

	for(screenId = NULL; screenId=ScanScreens(screenId, buff, &attributes); )
	{

		//   A NULL return from GetScreenInfo indicates a non CLIB
		//   (OS type) screen.   So, pass "screenId", cast as char*
		//   to CreateScreen  instead of an ascii screen name.
		//   This returns a handle which can be used in other API's.

		memset(namebuf, 0, sizeof(namebuf)); 
		
		screenHandle = GetScreenInfo(screenId, namebuf, NULL);
		if(!screenHandle)
		{
			if(stricmp(namebuf, NW5) && stricmp(namebuf, NW4) && stricmp(namebuf, NW3))
				continue;
			else
			{
				screenHandle = CreateScreen((char*)screenId, NULL);
				screenfound = TRUE;
				break;
			}
		}
        else
		{
			if(stricmp(namebuf, NW5) && stricmp(namebuf, NW4) && stricmp(namebuf, NW3))
				continue;
			else
			{

				screenfound = TRUE;
				break;
			}
		}
	}

	if(screenfound)
	{
		if(!CheckIfScreenDisplayed(screenHandle, FALSE))
		{
			SetCurrentScreen(screenHandle);
			DisplayScreen(screenHandle);
		}
	}
	return;
}


#endif 0




/*
#ifdef WIN32

///////////////////////////////////////////////////////////////////////////////
//
// Function name: IsAsyncScanRemote
//
// Description  : Determine if the Asynchronous scan is setup by the Admin
//               
//
//
// Return Values: TRUE if the asynchronous scan is a remote scan.
//
// Argument     : [in]   pointer to SCAN_STATUS that contains all the information about
//                       the current scan.
//
///////////////////////////////////////////////////////////////////////////////
// 7/23/2000 -   RCHINTA
///////////////////////////////////////////////////////////////////////////////

BOOL IsAsyncScanRemote(PSCAN_STATUS block)
{
    TCHAR   szScanOptionName[MAX_PATH]= "";
	TCHAR   szScanTitleData[MAX_PATH] = "";
	DWORD	dwIndex = 0,
			dwSize = sizeof(szScanOptionName),
			dwTitleDataSize = sizeof(szScanTitleData);
    BOOL    bRemoteScan = FALSE;

	// Determine if the Value Name "TransmanStatusDialogTitle" exists in the Scan options.
    // This value name is present for all the scans that are started from the console.           
	while( ERROR_NO_MORE_ITEMS != RegEnumValue( block->hkey,
												dwIndex,
												szScanOptionName,
												&dwSize,
												NULL,
												NULL,
												(BYTE*)szScanTitleData,
												&dwTitleDataSize ) )
    {
        if(lstrcmp(szScanOptionName, szReg_Value_Transman_ScanTitle) == 0)
        {
            bRemoteScan = TRUE;
            break;
        }

        dwIndex++;
        dwSize = sizeof(szScanOptionName);
        dwTitleDataSize = sizeof(szScanTitleData);
    }

	return bRemoteScan;
}


///////////////////////////////////////////////////////////////////////////////
//
// Function name: IsAsyncScanQueued
//
// Description  : Determine if the Asynchronous scan is Queued.  Asynchronous
//                scans will be queued when another scan is already in progress.
//                All the scans initiated from the console and the user setup scheduled
//                scans on the client (not the admin scheduled scans from the console)
//                will always be queued if there is another scan in progress.  The user
//                will be queried to determine if they want the scan queued when the
//                scan is initiated interactively from the client on the client system.
//
//               
//
//
// Return Values: TRUE if the asynchronous scan is queued.
//
// Argument     : [in]   pointer to SCAN_STATUS that contains all the information about
//                       the current scan.
//
///////////////////////////////////////////////////////////////////////////////
// 6/15/2000 -   RCHINTA
// 7/24/2000 -   RCHINTA modified to use IsAsyncScanRemote()
///////////////////////////////////////////////////////////////////////////////

BOOL IsAsyncScanQueued(PSCAN_STATUS block)
{
    BOOL    bRemoteScan = FALSE;
    TCHAR   szTemp[MAX_PATH] = "";   

	// Is this a remote async Scan?
	bRemoteScan = IsAsyncScanRemote(block);

    // Query the user to Queue an aysnc scan only for the local scans initiated by the 
    // user on the client and if they are not scheduled scans.
    if(!bRemoteScan && !(block->logger == LOGGER_Scheduled) )
    {
        wsprintf(szTemp, LS(IDS_SCAN_QUEUED), block->han, block->Status);
        dprintf("Scan %08X is Queued\n", block->han);

        if(IDCANCEL == MessageBox(NULL, szTemp, LS(STR_APP_NAME), MB_OKCANCEL | MB_ICONINFORMATION | MB_SYSTEMMODAL ))
        {
            block->Status = S_ABORTED;
            return FALSE;
        }
    }

    // Queue the Scan
    ModifyScanStatus(block, S_QUEUED);

    return TRUE;

}

///////////////////////////////////////////////////////////////////////////////
//
// Function name: WaitForAsyncScan
//
// Description  : Each scan thread will own hAsyncScanMutex until the scan is
//                completed (i.e. until _ScanThread() returns)
//
// Return Values: NONE
//
// Argument     : [in]   pointer to SCAN_STATUS that contains all the information about
//                       the current scan.
//
///////////////////////////////////////////////////////////////////////////////
// 6/15/2000 -   RCHINTA
///////////////////////////////////////////////////////////////////////////////

void WaitForAsyncScan(PSCAN_STATUS block)
{

    TCHAR szTemp[MAX_PATH];

    switch (WaitForSingleObject(hAsyncScanMutex, INFINITE)) {

    case WAIT_OBJECT_0 :  
        
        LOCK();

        if(hCurrentMutexOwner)
        {
            CloseHandle(hCurrentMutexOwner);
            hCurrentMutexOwner = NULL;
        }

        DuplicateHandle(GetCurrentProcess(), GetCurrentThread(), GetCurrentProcess(), &hCurrentMutexOwner, 0,
                            FALSE, DUPLICATE_SAME_ACCESS);
        dprintf("The scan thread %08X locked the Async Scan Mutex\n", hCurrentMutexOwner);
        UNLOCK();
        break;

    case WAIT_ABANDONED :
        
        LOCK();

        dprintf("Abandoned Async Scan Mutex \n");

        if(hCurrentMutexOwner)
        {
            CloseHandle(hCurrentMutexOwner);
            hCurrentMutexOwner = NULL;
        }

        DuplicateHandle(GetCurrentProcess(), GetCurrentThread(), GetCurrentProcess(), &hCurrentMutexOwner, 0,
                            FALSE, DUPLICATE_SAME_ACCESS);
        UNLOCK();

        break;

    case WAIT_FAILED:
        {
        DWORD dwError = GetLastError();
    	EVENTBLOCK log;  
        LPVOID lpMsgBuf;

        FormatMessage(     FORMAT_MESSAGE_ALLOCATE_BUFFER | 
            FORMAT_MESSAGE_FROM_SYSTEM |     FORMAT_MESSAGE_IGNORE_INSERTS,    NULL,
            dwError,
            MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), 
            (LPTSTR) &lpMsgBuf,    0,    NULL );

        wsprintf(szTemp, LS(IDS_ASYNC_SCAN_ABORTED), block->han, lpMsgBuf);
        dprintf("%s", szTemp);

        LocalFree( lpMsgBuf );

        // Log the error when synchronizing scans
        memset(&log,0,sizeof(log));
	    log.Description = szTemp;
	    log.logger = block->logger;
	    log.hKey[0] = block->hkey;
	    log.Category = GL_CAT_SUMMARY;
	    log.Event = GL_EVENT_SCAN_ABORT;
	    log.ScanID = block->ScanID;
	    log.GroupID = block->GroupID;
	    GlobalLog(&log);
        return;
        break;
        }

    } 

    return;
}


#endif
*/

/*************************************************************************************************/
 
 
void ScanThread(PSCAN_STATUS block) 
{
/*
#if defined(SERVER) && defined(WINNT)

	DWORD cc = 0;

#endif
*/
/*    
#ifdef WIN32

	TCHAR szline[MAX_PATH] = {0};

#if defined(SERVER) && defined(WINNT)

	//
	//	Removes the check for the reg key "NeedAccessToNetwork" since we now
	//  impersonate in all cases.
	//

	// Impersonate only for client scans initiated by the user
	if (!IsAsyncScanRemote(block) && hAccessToken )
    {
		dprintf("Walk scan needs user access rights ");
		cc = ImpersonateLoggedOnUser(hAccessToken);
		if (cc)
		{ 
            dprintf("OK\n"); 
        }
		else
		{ 
            dprintf("FAIL (%08X\n",GetLastError()); 
        }
	}
	else
		dprintf("No user impersonation necessary\n");

#endif // SERVER && WINNT
    
	// synchronize only asynchronous scans
    if(hAsyncScanMutex && (block->dwAsync == 1) )
    {

        DWORD dwExitCode = STILL_ACTIVE; 
    
        LOCK();

        if(hCurrentMutexOwner)
            GetExitCodeThread(hCurrentMutexOwner, &dwExitCode);

        // Is another scan in progress?
        if(hCurrentMutexOwner && dwExitCode == STILL_ACTIVE)
        {
            // Determine if the current async scan is queued
            if(!IsAsyncScanQueued(block))
                return;  // Aborting the scan since the user does not want the scan queued.          
        }
        UNLOCK();

        // Wait until (and lock the mutex) until the asynchronous scan is completed
        WaitForAsyncScan(block);

        if(!ScanRunning(block->Status))
        {
            dprintf("The asynchronous scan thread %08X was stopped/aborted before actually scanning \n", block->han);
            return;
        }
    
    }

#endif // end WIN32
*/
	__try 
    {
		_ScanThread(block);
    }
	__except(1) 
    {
		ModifyScanStatus(block,S_ABORTED);
		dprintf("Walking thread crashed\n");
	}

/*
#ifdef WIN32

    if(hAsyncScanMutex  && (block->dwAsync == 1))
    {

#ifdef _DEBUG
        if(GetVal(hMainKey, _T("ProductControl\\AbandonAsyncScanMutex"), 0) == 1)
        {
            dprintf("Abandoning the Async Scan Mutex after completing the Scan %08X\n", block->han);
            return;
        }
#endif // end _DEBUG

        LOCK();
        if(hCurrentMutexOwner)
        {
            CloseHandle(hCurrentMutexOwner);
            hCurrentMutexOwner = NULL;
        }

        if(ReleaseMutex(hAsyncScanMutex))
            dprintf("Releasing the Async Scan Mutex for Scan %08X\n", block->han);

        UNLOCK();

    } // end of processing hAsyncScanMutex && block->dwAsync
	
	// Close the subkey for the current Scan since the Scan is complete.
	// Fix for STS#330336.
	/*
	if(block->hkey)
	{
		GetStr(block->hkey,"DelWhenDoneName", szline,sizeof(szline),"");
		if (szline[0]) {
			HKEY hkey;
			char *q = StrRChar(szline,'\\');
			DWORD RootID = GetVal(block->hkey,"DelWhenDoneKey",0);
			if (q != NULL && RootID != 0) {
				*q = 0;
				if (RegOpenKey(VpRegBase[RootID&0xff].hBase,szline,&hkey) == ERROR_SUCCESS) {
					RegDelKeys(hkey,q+1);
					RegCloseKey(hkey);
					}
				}
			}

		dprintf("Closing the subkey for the Scan %08X", block->hkey);
		RegCloseKey(block->hkey);
		block->hkey = NULL;
	} // end of block->hkey Cleanup
   *****
#if defined(SERVER) && defined(WINNT)
	if (cc)
		RevertToSelf();
#endif // SERVER && WINNT

#endif  //end WIN32
*/
}

///////////////////////////////////////////////////////////////////////////////
//
// Function name: CheckForActiveScans
//
// Description  : This function determines if a scan with a ScanID of dwScanID is
//                present in the pool of the currently active scans (represented
//                by the linked list - HeadScan).
//
// Return type  : DWORD
//
// Returns      : ERROR_SCAN_IN_PROGRESS    if the scan with dwScanID is present 
//                                          in the pool of active scans
//                ERROR_SUCCESS             if the scan with dwScanID is not in the 
//                                          pool of active scans.
//
///////////////////////////////////////////////////////////////////////////////
// 7/09/2000 - RCHINTA
///////////////////////////////////////////////////////////////////////////////
DWORD CheckForActiveScans(DWORD dwScanID) 
{

	PSCAN_STATUS cur;
	DWORD dwRet = ERROR_SUCCESS;

	LOCK();
	cur = HeadScan;
	while (cur) {
        if (cur->ScanID == dwScanID) {
            dwRet = ERROR_SCAN_IN_PROGRESS;
            break;
            }
		cur = cur->next;
		}

	UNLOCK();

	return dwRet;
}


/******************************************************************************/




#if 0



DWORD StartScan(//HKEY hkey,
                  DWORD *han,SCANCBVIRUS cbVirus,SCANCBPROG cbProgress,
                  PSCAN_STATUS block,BOOL async,void *context) {

	char line[128];
	int stgid;
//#ifdef NLM
//	BOOL SchedScan=(block==NULL);
//#endif

	dprintf ("Trying to Start Scan\n");

	if (ScanRunning(GetVal(hkey,szReg_Value_ScanStatus,S_NEVER_RUN))) {
        // ScanRunning() will always return TRUE if a scan was not
        // properly terminated by a system crash or reboot.  Let the
        // scan start if the scan is not in the pool of active scans
        // (represented by HeadScan). 
        DWORD dwScanID = GetVal(hkey, "ScanID", 0);
        if(CheckForActiveScans(dwScanID) == ERROR_SCAN_IN_PROGRESS) {
	        RegCloseKey(hkey);
	        dprintf ("Scan in progress\n");
	        return ERROR_SCAN_IN_PROGRESS;
            }
		}

	if (block == NULL) {
		block = malloc(sizeof(SCAN_STATUS));
		if (block == NULL) {
			RegCloseKey(hkey);
			dprintf ("Mem Allocation Error for block\n");
			return ERROR_MEMORY;
			}
		memset(block,0,sizeof(SCAN_STATUS));
		block->pFree = Pfree;
		}
	else {
		if (block->Size != sizeof(SCAN_STATUS)) {
			dprintf ("Bad Parameter Error: %d != %d\n",block->Size,sizeof(SCAN_STATUS));
			block->pFree(block MemLoc);
			return ERROR_BAD_PARAM;
			}
		}

	block->han = ScanID++;

	block->time = time(NULL);
	// MH 08.23.00
	// Add the global scan count to the generated scan ID to make it
	// more unique.  When two or more scheduled scans were created to
	// run at the same time, duplicate scan IDs were being generated.
	block->ScanID = ScanID + time(NULL);
	//PutVal(hkey,"ScanID",block->ScanID);
	//block->hkey = hkey;
	//block->logger = GetVal(hkey,"Logger",LOGGER_Manual);
	block->cbVirus = cbVirus;
	block->cbProgress = cbProgress;
	block->Size = sizeof(SCAN_STATUS);
	block->FileCounts =  malloc(sizeof(DWORD)*512);
	block->context = context;

	if (block->FileCounts == NULL) {
		RegCloseKey(hkey);
		free (block);
		dprintf ("Mem allocation error for FileCounts\n");
		return ERROR_MEMORY;
	}
	block->FileState = malloc(1024);
	if (block->FileState == NULL) {
		RegCloseKey(hkey);
		free (block->FileCounts);
		free (block);
		dprintf ("Mem allocation error for FileState\n");
		return ERROR_MEMORY;
	}

	// Zero out the allocated memory
	memset(block->FileState, 0, 1024);

	block->MaxDir = 512;

	LOCK();
	block->next = HeadScan;
	HeadScan = block;
	UNLOCK();

//#ifdef SERVER
	AddIDToServerStatus(block->han);
//#endif

	ModifyScanStatus(block,S_STARTING);

	WSprintf(line,"RTV Scan %08X",block->han);
	RegDeleteValue(hkey,"DelWhenDone");

	if (async) {
        dprintf("Starting Async Scan:  %s\n", line);

        block->dwAsync = 1;
		if ((stgid=MyBeginThread((THREAD)ScanThread,block,line)) == 0xffffffff) {
			block->time = 0;      // If thread does not really start but this function says it does, we will lose memory here.
			RegCloseKey(hkey);
			block->pFree(block MemLoc);
			dprintf ("Couldn't begin Scan Thread Group: %d\n",errno);
			return ERROR_MEMORY;
			}
		dprintf ("Scan Thread Group Started: %d\n",stgid);
		if (han)
			*han = block->han;
//#ifdef NLM
			NotifyUIofScanStart(block->han);
//#endif
		}
	else
    {
        block->dwAsync = 0;
        dprintf("Starting Sync Scan: %s \n", line);
		ScanThread(block);
    }

	return 0;
}


/******************************************************************************/
//#ifdef SERVER
void iMyFree(void *b MemArgs) {

	PSCAN_STATUS block = (PSCAN_STATUS)b;
//#ifdef NLM
	MemFree(block);
//#endif
/*
#ifdef WIN32
	HANDLE hFileMap = block->hFileMap;
	UnmapViewOfFile(block);
	CloseHandle(hFileMap);
#endif
*/
}


/******************************************************************************/
DWORD iScanNumber=0;

DWORD StartServerScan(HKEY hkey,DWORD *han) {

	DWORD cc;
	PSCAN_STATUS block=0;
	/*
#ifdef WIN32
	HANDLE hFileMap;
	char FileName[64];
#ifdef REAL_SERVICE
	PSECURITY_DESCRIPTOR    pSD;
	SECURITY_ATTRIBUTES     sa;
#endif
#endif
*/
	if (hkey == NULL) {
		if ((cc=RegOpenKey(hMainKey,"LocalScans\\ManualScan",&hkey)) == ERROR_SUCCESS) {
			if (ScanRunning(GetVal(hkey,"Status",S_NEVER_RUN))) {
                // ScanRunning() will always return TRUE if a scan was not
                // properly terminated by a system crash or reboot.  Let the
                // scan start if the scan is not in the pool of active scans
                // (represented by HeadScan). 
                DWORD dwScanID = GetVal(hkey, "ScanID", 0);
                if( CheckForActiveScans(dwScanID) == ERROR_SCAN_IN_PROGRESS) {
	    			RegCloseKey(hkey);
		    		return ERROR_SCAN_IN_PROGRESS;
                    } // end CheckForActiveScans()
				}//end ScanRunning()
			} // end RegOpenKey - LocalScans\\ManualScan
		else
			return cc;
		}// end (hKey == NULL)

//#ifdef NLM
	block = malloc(sizeof(SCAN_STATUS));
	if (block == NULL)
		return ERROR_MEMORY;
	memset(block,0,sizeof(SCAN_STATUS));
//#endif

/*
#ifdef WIN32
#ifdef REAL_SERVICE
	pSD = (PSECURITY_DESCRIPTOR) LocalAlloc(LPTR,SECURITY_DESCRIPTOR_MIN_LENGTH);

	if (pSD == NULL)
		return P_SEC_ALLOC_FAIL;

	if (!InitializeSecurityDescriptor(pSD, SECURITY_DESCRIPTOR_REVISION)) {
		LocalFree((HLOCAL)pSD);
		return P_INIT_DES_FAIL;
		}

	// add a NULL disc. ACL to the security descriptor.
	//
	if (!SetSecurityDescriptorDacl(pSD, TRUE, (PACL) NULL, FALSE)) {
		LocalFree((HLOCAL)pSD);
		return P_SET_DES_FAIL;
		}

	sa.nLength = sizeof(sa);
	sa.lpSecurityDescriptor = pSD;
	sa.bInheritHandle = TRUE;       // why not...
	#define PSA &sa
#else
	#define PSA NULL
#endif

	WSprintf(FileName,"LDVPScanMap_%u",iScanNumber++);

	hFileMap = CreateFileMapping((HANDLE)0xffffffff,PSA,PAGE_READWRITE,0,sizeof(SCAN_STATUS),FileName);
	if (hFileMap)
		block = MapViewOfFile(hFileMap,FILE_MAP_WRITE,0,0,0);
	if (!block) {
		CloseHandle(hFileMap);
		return ERROR_MEMORY;
		}
	memset(block,0,sizeof(SCAN_STATUS));
	block->hFileMap = hFileMap;
	block->iScanNumber = iScanNumber-1;
	PutStr(hkey,"CurrentFileMapName",FileName);
	{char str[64];
	wsprintf(str,"CurrentMaps\\%s",FileName);
	PutVal(hMainKey,str,1);
	}
#endif
*/
	block->Size = sizeof(SCAN_STATUS);
	block->pFree = iMyFree;


	cc = StartScan(hkey,han,NULL,NULL,block,1,NULL);
	dprintf ("Start Scan returned: %d 0x%x\n",cc,cc);
	return cc;
}

//#endif

#endif 0




/********************************************************************************************************
/*
#ifndef NLM
DWORD DoSyncScan(HKEY hkey,char *path,char *FullPath,char *namestring,BOOL children,char *exts,SCANCBVIRUS cbVirus,SCANCBPROG cbProgress,SCANCBINFO cbScanInfo,void *context,BOOL bScanSystem) {

	SCAN_STATUS block;
	DWORD slot;
	BOOL aborted=FALSE;

    BOOL bFail = FALSE;

#ifdef WIN32
    char szAppName[64];
    char line[256];
    DWORD dwTempBytesNeeded = 0;
    DWORD dwAppDataBytesNeeded = 0;
    DWORD dwRet = ERROR_SUCCESS;
    EVENTBLOCK log;
#endif

	if (!path && !FullPath)
		return ERROR_BAD_PARAM;

	if (path && FullPath)
		return ERROR_BAD_PARAM;

//	if (!ScansOK)
//		return ERROR_SCAN_ENGINE_NOT_READY;

	memset(&block,0,sizeof(SCAN_STATUS));

	block.hkey = hkey;
	strcpy(block.ExtList,"*");

	if (path) {
		if (exts && *exts)
			strcpy(block.ExtList,exts);
		}

	block.Status = S_STARTED;
	block.cbVirus = cbVirus;
	block.cbProgress = cbProgress;
    block.cbScanInfo = cbScanInfo;
	block.context = context;

#ifdef WIN32

    dwTempBytesNeeded = GetVal(block.hkey, szReg_Val_NeededFreeDiskSpace, MIN_DISK_SPACE_FOR_SCAN);
    dwAppDataBytesNeeded = GetVal(block.hkey, szReg_Val_NeededFreeDataDiskSpace, MIN_DATA_DISK_SPACE_FOR_SCAN);

    if( dwTempBytesNeeded < MIN_DISK_SPACE_FOR_SCAN )
        dwTempBytesNeeded = MIN_DISK_SPACE_FOR_SCAN;

    if( dwAppDataBytesNeeded < MIN_DATA_DISK_SPACE_FOR_SCAN )
        dwAppDataBytesNeeded = MIN_DATA_DISK_SPACE_FOR_SCAN;

    dwRet = CheckFreeDiskSpaceForScan(dwTempBytesNeeded, dwAppDataBytesNeeded);
    if(dwRet != ERROR_SUCCESS)
    {
        block.GroupID = GetVal(block.hkey,"GroupID",0);

        if(dwRet == ERROR_NOT_ENOUGH_DISK_SPACE)
	        WSprintf(line,"%s",LS(IDS_ERROR_DISKSPACE));
        else
	        WSprintf(line,"%s",LS(IDS_ERROR_READ_DISKSPACE_DATA));

        dprintf (line);
        ModifyScanStatus(&block,S_ABORTED);

    	if (GetVal(block.hkey, szReg_Value_DisplayStatusDlg, 0))
        {
            // Scan Failed due to low disk space
            lstrcpy(szAppName, LS(STR_APP_NAME));
            MessageBox(NULL, line, szAppName, MB_OK | MB_ICONSTOP);
        }

	    memset(&log,0,sizeof(log));
	    log.Description = line;
	    log.logger = block.logger;
	    log.hKey[0] = block.hkey;
	    log.Category = GL_CAT_SUMMARY;
	    log.Event = GL_EVENT_SCAN_ABORT;
	    log.ScanID = block.ScanID;
	    log.GroupID = block.GroupID;
	    GlobalLog(&log);
    
        return 1;
    }

	if (GetVal(block.hkey,"DisplayStatusDialog",0))
		CreateScanStatusDialog(&block);
#endif

	InitThreadForScan(&slot);

	block.logger = LOGGER_Manual;
	OpenInfectionHandle(&block.InfHan);

	ModifyScanStatus(&block,S_SCANNING_DIRS);
	block.ScanType =	(GetVal(block.hkey,"ZipFile",1)?VEEXPANDFILES:0) |
							VESLOWSCAN |
							(GetVal(block.hkey,"SoftMice",1)?VEMUTATIONSCAN:0);


	SetUsedBit(&block,path?path:FullPath);

	if (FullPath) {
		if (bScanSystem) {
			DoBootScan(&block);
			DoMemScan(&block);
			}

        // To enable Scanning inside compressed files 
        // in an async scan (Defwatch or QConvert).
#ifdef WIN32
        block.ScanType |= SCANALLFILES;
        block.ZipDepth = GetVal(block.hkey,"ZipDepth",3);
#endif

		ModifyScanStatus(&block,S_SCANNING_FILES);
		if(DoFile(&block,FullPath,namestring) != ERROR_SUCCESS)
            {
            bFail = TRUE;
            goto done;   //TODO: change this to be more meaningfull
            }
		}
	else {
		if (block.Status == S_STOPPING || StoppingAllScans) {
			aborted = TRUE;
			goto done;
			}
		DoDir(&block,path,children);
		ThreadSwitchWithDelay();

		block.CurDir = 0;

		if (bScanSystem) {
			DoBootScan(&block);
			if (block.Status == S_STOPPING || StoppingAllScans) {
				aborted = TRUE;
				goto done;
				}
			DoMemScan(&block);
			if (block.Status == S_STOPPING || StoppingAllScans) {
				aborted = TRUE;
				goto done;
				}
			}

		ModifyScanStatus(&block,S_SCANNING_FILES);
		DoDir(&block,path,children);
		if (block.Status == S_STOPPING || StoppingAllScans) {
			aborted = TRUE;
			goto done;
			}
		ThreadSwitchWithDelay();
		}


done:

	ModifyScanStatus(&block,aborted?S_ABORTED:S_DONE);

	CloseInfectionHandle(block.InfHan);

	DeInitThreadForScan(&slot);

    if (bFail)
        return 1;
    else
	    return 0;
}
#endif


#ifdef WIN32


///////////////////////////////////////////////////////////////////////////////
//
// Function name: GetNAVAppPath
//
// Description  : Gets the path where NAV is installed from the registry
//
// Return type  : BOOL
//
// Returns      : TRUE    if NAV Application path was obtained
//                FALSE   failed to obtain NAV Application path  
//
//
///////////////////////////////////////////////////////////////////////////////
// 4/13/99 - RCHINTA: Borrowed from ShellScan and Modified
// 7/11/2000 - RCHINTA: Moved from Decproc.cpp to be available for CLISCAN.DLL
///////////////////////////////////////////////////////////////////////////////
BOOL GetNAVAppPath(LPTSTR lpszLibPath)
{
    DWORD   dwSize = MAX_PATH;
    HKEY    hKey;
    LONG    lRet;

    // 
    // Open installed apps regkey.
    //     
    lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, szReg_Key_Main, 0, KEY_READ, &hKey ); 

    if( ERROR_SUCCESS != lRet)
        return FALSE;

    lRet = RegQueryValueEx(hKey, szReg_Val_HomeDir, NULL, 
                           NULL, (LPBYTE)lpszLibPath, &dwSize);

    RegCloseKey( hKey );

    if( ERROR_SUCCESS != lRet )
        return FALSE;

    return TRUE;

}


///////////////////////////////////////////////////////////////////////////////
//
// Function name: CheckFreeDiskSpaceForScan
//
// Description  : See if there is enough space to perform a scan.
//                
// Argument     dwTempBytes: [in] space required for temporary files 
//              dwAppDataBytes: [in] space required for Application data 
//                              (and user data)
//
// Return Values: ERROR_SUCCESS if there is enough room.
//                ERROR_NOT_ENOUGH_DISK_SPACE if ther is not enough disk space
//                ERROR_BAD_PRAMS if any of the directories have bad path names
//                ERROR_APPDATA_PATH_NOT_FOUND  or
//                ERROR_USERDATA_PATH_NOT_FOUND if the required directories
//                were not found
//
///////////////////////////////////////////////////////////////////////////////
// 7/12/2000 - RCHINTA: 
///////////////////////////////////////////////////////////////////////////////
DWORD  CheckFreeDiskSpaceForScan (DWORD dwTempBytes, DWORD dwAppDataBytes)
{
    TCHAR           szTempData[MAX_PATH] = {0}; // for temp files
    TCHAR           szUserData[MAX_PATH] = {0}; // for user app data, like user logs, etc
    TCHAR           szAppData[MAX_PATH] = {0};  // for common app data, like admin logs, etc
    LPTSTR          lpTemp = NULL;
    DWORD           dwRet;
    DWORD           dwClientType;

    if(!GetTempPath(sizeof(szTempData), szTempData))
    {
        dprintf("Could not obtain the location of the Temporary Directory from Windows\n");
        return ERROR_TEMP_PATH_NOT_FOUND;
    }

    // Parse the file name to get the drive
    if( lpTemp = _tcschr(szTempData, '\\') )
    {
        // Null terminate after the leftmost '\'
        lpTemp = CharNext( lpTemp );
        *lpTemp = '\0';
    }
    else
    {
        // We should not ever get here. There will
        // alway be a fully qualified path. In case
        // we ever get here, fail.

        dwRet = ERROR_BAD_PRAMS;
        goto Done;
    }

    if(!CheckFreeDiskSpace(dwTempBytes, szTempData))
    {
        dprintf("Not enough disk space for Temp files on Drive %s\n", szTempData);
        dwRet = ERROR_NOT_ENOUGH_DISK_SPACE;
        goto Done;
    }


    dwRet = GetAppDataDirectory(NAV_COMMON_APP_DATA, szAppData);

    if(dwRet != ERROR_SUCCESS)
    {
        dprintf("Failed to obtain the NAV Application directory\n");
        dwRet = ERROR_APPDATA_PATH_NOT_FOUND;
        goto Done;
    }

    lpTemp = NULL;
    if( lpTemp = _tcschr(szAppData, '\\') )
    {
        //Null terminate after the leftmost '\'
        lpTemp = CharNext( lpTemp );
        *lpTemp = '\0';
    }
    else
    {
        dwRet = ERROR_BAD_PRAMS;
        goto Done;
    }

    if(!CheckFreeDiskSpace(dwAppDataBytes, szAppData))
    {
        dprintf("Not enough disk space for Common Application Data files on Drive %s\n", szAppData);
        dwRet = ERROR_NOT_ENOUGH_DISK_SPACE;
        goto Done;
    }

    // Get the client type
    dwClientType = GetVal(hMainKey,"ClientType",0);

    // Check for user directory only on Win 2k clients.
    if( IsWinNT() && (dwClientType == 1 || dwClientType == 2) )
    {

        dwRet = GetAppDataDirectory(NAV_USER_APP_DATA, szUserData);
        if(dwRet != ERROR_SUCCESS)
        {
            dprintf("Failed to obtain the User data directory\n");
            dwRet = ERROR_USERDATA_PATH_NOT_FOUND;
            goto Done;
        }

        lpTemp = NULL;
        if( lpTemp = _tcschr(szUserData, '\\') )
        {
            //Null terminate after the leftmost '\'
            lpTemp = CharNext( lpTemp );
            *lpTemp = '\0';
        }
        else
        {
            dwRet = ERROR_BAD_PRAMS;
            goto Done;
        }

        if(!CheckFreeDiskSpace(dwAppDataBytes, szUserData))
        {
            dprintf("Not enough disk space for User Application Data files on Drive %s\n", szUserData);
            dwRet = ERROR_NOT_ENOUGH_DISK_SPACE;
            goto Done;
        }

        dwRet = ERROR_SUCCESS;
    }

Done:

    return dwRet;
}


///////////////////////////////////////////////////////////////////////////////
//
// Function name: CheckFreeDiskSpace
//
// Description  : See if there is enough space to perform a scan.
//
//                Jump through several hoops for Win32. All other platforms
//                return TRUE for now. If any system call for disk space info
//                fails, return FALSE.
//
//
// Return Values: TRUE if there is enough room.
//
// Argument     dwBytesNeeded: [in]   DWORD Required disk space.
//              pszDriveToCheck: [in] pointer to the path to determine the free 
//                                    space
//
///////////////////////////////////////////////////////////////////////////////
// 8/20/99 -   RCHINTA: Modified the version in PSCAN\COMMON\SRC\vbin.c 
// 7/12/2000 - RCHINTA: Modified to do the disk space calculations only.
///////////////////////////////////////////////////////////////////////////////
BOOL CheckFreeDiskSpace(DWORD dwBytesNeeded, LPTSTR pszDriveToCheck)
{
    ULARGE_INTEGER  liTotalFreeBytes = {0};
    ULARGE_INTEGER  liCallerFreeBytes = {0};
    ULARGE_INTEGER  liTotalBytes = {0};
    ULARGE_INTEGER  liBytesNeeded = {0};
    DWORD           dwFreeBytes = 0;
    HINSTANCE       hInstance = NULL;
    BOOL            bResult = FALSE;
    BOOL            bUseOldMethod = TRUE;

    // See if we can load Kernel32
    hInstance = LoadLibrary( _T("KERNEL32") );

    if ( hInstance )
    {
        // Get the function pointer.
        pfnGetDiskFreeSpaceEx = (PFNGetDiskFreeSpaceEx) GetProcAddress( hInstance, "GetDiskFreeSpaceExA" );
    }

    if ( pfnGetDiskFreeSpaceEx )
    {
        // We're good to go. Get free disk space.
        bResult = pfnGetDiskFreeSpaceEx( pszDriveToCheck,
                                           &liCallerFreeBytes,
                                           &liTotalBytes,
                                           &liTotalFreeBytes );
        // Good result?
        if ( bResult )
        {
            // Yep. Now check the values ... free disk space and the needed space
            liBytesNeeded.LowPart = dwBytesNeeded;

            if ( liCallerFreeBytes.QuadPart > liBytesNeeded.QuadPart )
                bResult = TRUE;
            else
                bResult = FALSE;

            bUseOldMethod = FALSE;
        }
    }

    // Was there a problem with the new call? Are we going to use the old method?
    if ( bUseOldMethod )
    {
        // We have to. This is specified in the MS documentation.

        DWORD   dwSectorsPerCluster = 0;
        DWORD   dwBytesPerSector = 0;
        DWORD   dwNumberOfFreeClusters = 0;
        DWORD   dwTotalNumberOfClusters = 0;

        // Yep. Now check the values ... free disk space 
        bResult = GetDiskFreeSpace( pszDriveToCheck,
                                    &dwSectorsPerCluster,
                                    &dwBytesPerSector,  
                                    &dwNumberOfFreeClusters,
                                    &dwTotalNumberOfClusters );

        // Did the call succeed?
        if ( bResult )
        {
            // Yep. Calculate the free space.
            dwFreeBytes = dwSectorsPerCluster * dwBytesPerSector * dwNumberOfFreeClusters;

            if ( dwFreeBytes > dwBytesNeeded )
                bResult = TRUE;
            else
                bResult = FALSE;
        }
    }
    

    // Free the DLL.
    if ( hInstance )
        FreeLibrary( hInstance );

    return bResult;
}

#endif
*/