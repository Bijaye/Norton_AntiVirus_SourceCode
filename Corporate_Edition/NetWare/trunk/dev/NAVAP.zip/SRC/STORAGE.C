//------------------------------------------------------------------------------
//
//      Storage.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#include "pscan.h"

/**
#if defined(SERVER) && defined(WIN32)
#define USING_NAVAP
#define SYM_WIN32
#define SYM_EXPORT
#include "apcomm.h"
#endif
**/

//static DWORD emptycall(void) {return ERROR_FUNCTION_NO_SUPPORTED;}


/****************************************************************************************************/
/** ksr
#define RegStart(x)                                                      \
	DWORD x##Key(HKEY hBasekey,char *path,HKEY *hkey) {                   \
	char key[IMAX_PATH];                                                  \
	DWORD RootID = (DWORD)hBasekey;                                       \
	if ((RootID&HKEY_VP_MASK) == HKEY_VP_MASK_EQ) {                       \
		WSprintf(key,VpRegBase[RootID&0xff].Key,path);                     \
		return Reg##x##Key(VpRegBase[RootID&0xff].hBase,key,hkey);         \
		}                                                                  \
	return Reg##x##Key(hBasekey,path,hkey);                               \
}

RegStart(Open)
RegStart(Create)

DWORD CloseKey(HKEY hkey){return RegCloseKey(hkey);}
DWORD EnumKey(HKEY hkey,DWORD index,char *name,DWORD size) {return RegEnumKey(hkey,index,name,size);}
DWORD EnumValue(HKEY hkey,DWORD index,char *name,DWORD *namesize,DWORD *type,BYTE *data,DWORD *datasize){return RegEnumValue(hkey,index,name,namesize,NULL,type,data,datasize);}
DWORD DupKey(HKEY hkey,HKEY *hnkey){return DUPKEY(hkey,hnkey);}

**/


BOOL  VerifyValidStorageType();
BOOL  CheckDriveIsHidden(LPSTR lpItem, DWORD dwHiddenDrives);

/****************************************************************************************************/

SSFUNCTIONS SSfuns = 
{
	FormatVirusMessage,
	//PutVal,
	//GetVal,
	//PutStr,
	//GetStr,
	//OpenKey,
	//CreateKey,
	//CloseKey,
	//PutData,
	//GetData,
	Real_dprintf,
	//GlobalLog,
	&debug
	//EnumKey,
	//EnumValue,
	//DupKey
};


STORAGEITEM *StorageList;
PSTORAGEITEM FileStorageItem=NULL;
BOOL StorageManagerActive=FALSE;
BOOL StorageManagerStarted=FALSE;
DWORD StorageManagerFlags = 0;

/************************************************************************************************************/

static HANDLE Mutex = 0;
/**
#ifdef WIN32
//============================================================================
static void StartCS(void) {
	if (Mutex == 0)
		Mutex = CreateMutex(NULL,FALSE,NULL);
	WaitForSingleObject(Mutex,INFINITE);
}
//============================================================================
static void EndCS(void) {
	ReleaseMutex(Mutex);
}
#endif
**/
/************************************************************************************************************/
/************************************************************************************************************/
//============================================================================
//#ifdef SERVER

VOID APIENTRY StopStorageRTS(PSTORAGEITEM Item)
{
	int i;

	Item->Info->Functions->StopRTSWatches();

	for (i=0;i<1*18 && Item->ThreadCount;i++) 
	{
		NTxSleep(55);
		}
//#ifdef NLM
	dprintf("Threads In Use: %d\n",Item->ThreadCount);
	if( Item->ThreadCount )
		_printf("We have <%d> unreleased Threads!",Item->ThreadCount);
	
	
	Breakpoint(TrackThreads && Item->ThreadCount);			// REMOVE THIS BEFORE SHIPPING!!!
	
	
 #ifdef ThreadCheck
	ThreadReport(FALSE);
 #endif // ThreadCheck
//#endif
}


PVBM VBMHead = NULL;

/*******************************************************************/
/*
DWORD TrapStuffStart(PSTORAGEOBJECT so) {

	VEFILEBINFO vi;
	VESTATUS cc;
	USEVE
	PVBM block = malloc(sizeof(VBM)+VeInfo->dwBehaviorDataSize);

	if (block == NULL)
		return ERROR_MEMORY;

	memset(block,0,sizeof(VBM)+VeInfo->dwBehaviorDataSize);
	memset(&vi,0,sizeof(VEFILEBINFO));
	block->pData = (BYTE *)(block+1);
	block->UID = so->Node->UID;
	block->Time = time(NULL);

	vi.wSize = sizeof(VEFILEBINFO);

	if (VeInfo->wSize == sizeof(VEINFO10)) {
		vi.pszFileName = so->Node->InternalPath;
		}
	else if (VeInfo->wSize == sizeof(VEINFO)) {
		vi.fileContext = (pVEFILECONTEXT)so->Node;
		vi.dwFileType = VEUSEFILEIOTABLE;
		}
	else {
		free(block);
		return P_VERSION_MISMATCH;
		}

	vi.pData = block->pData;
	vi.appContext = (VECONTEXT)so;

	CALLVE;
	cc = VEGetVirusBehaviorHeader(VEhan,&vi);
	RETVE;
	if (cc != VEOK) {
		free(block);
		return cc;
		}

	LOCK();
	block->Next = VBMHead;
	VBMHead = block;
	UNLOCK();

	return ERROR_SUCCESS;
}


/*******************************************************************

DWORD TrapStuffStop(PSTORAGEOBJECT so) {

	VEFILEBINFO vi;
	VESTATUS cc;
	PVBM cur = VBMHead,last=NULL;
	USEVE

	LOCK();

	while (cur) {
		if ((cur->UID&0xffffff) == (so->Node->UID&0xffffff)) {
			if (last)
				last->Next = cur->Next;
			else
				VBMHead = cur->Next;
			UNLOCK();

			memset(&vi,0,sizeof(VEFILEBINFO));

			vi.wSize = sizeof(VEFILEBINFO);

			if (VeInfo->wSize == sizeof(VEINFO10)) {
				vi.pszFileName = so->Node->InternalPath;
				}
			else if (VeInfo->wSize == sizeof(VEINFO)) {
				vi.fileContext = (pVEFILECONTEXT)so->Node;
				vi.dwFileType = VEUSEFILEIOTABLE;
				}
			else {
				free(cur);
				return P_VERSION_MISMATCH;
				}

			vi.pData = cur->pData;
			vi.appContext = (VECONTEXT)so;

			so->Flags &= ~FA_SCANNING_MASK;
			so->Flags |= FA_SCANNING_BEHAVIOR;

			CALLVE;
			cc = VEScanVirusBehaviorHeader(VEhan,&vi);
			RETVE;

			free(cur);
			return cc;
			}
		last = cur;
		cur = cur->Next;
		}

	UNLOCK();
	return ERROR_NOT_IN_LIST;
}
*/

//============================================================================
/*
DWORD ScanBootSector(PSTORAGEOBJECT so) {

	BYTE *CritData;
	VEDISKINFO di;
 //	char line[128];
	VESTATUS cc;
	DWORD ID;
	USEVE

	if (so->Node->InstanceID < 128)
		ID = so->Node->InstanceID - 1;
	else if (so->Node->InstanceID < 256)
		ID = so->Node->InstanceID - 128;
	else if (so->Node->InstanceID < 512)
		ID = so->Node->InstanceID - 256;
	else
		return 0;

	CritData = malloc(VeInfo->wCriticalDiskDataSize);
	if (CritData) {
		CALLVE;
		cc = VEGetCriticalDiskData(VEhan,ID,CritData);
		RETVE;
		if (cc == VEOK) {
			memset(&di,0,sizeof(VEDISKINFO));

			so->Flags &= ~FA_SCANNING_MASK;
			so->Flags |= FA_SCANNING_BOOT_SECTOR;

			di.wSize = sizeof(VEDISKINFO);
			di.appContext = (VECONTEXT)so;
			di.pCriticalDiskData = CritData;
			di.dwScanType = VENORMALSCAN;


			CALLVE;
			VEScanCriticalDiskData(VEhan,&di);
			RETVE;
			}
		free(CritData);
		}
	return 0;
}

*/

//============================================================================
DWORD AdjustReturnCode(DWORD Prev,DWORD New) 
{

	if (Prev == ERROR_SUCCESS || New == DENY_ACCESS)
		return New;

	if (New == ERROR_SUCCESS)
		return Prev;

	if (Prev == DENY_ACCESS)
		return Prev;

	// at this point both are non-zero and nither are DenyAccess, so just retun the most current
	// any non-zero return code will cause the file to NOT be in the clean cache.
	return New;
}


//============================================================================

DWORD ProcessRTSNode(PSNODE node,PSTORAGEITEM Item) 
{
	STORAGEOBJECT rso,*so=&rso;
	DWORD cc;
	DWORD ret = ERROR_SUCCESS;
	BOOL Skip = FALSE;

	dprintf("%s%s%s%s%s%s%s [%d] '%s'\n",
		(node->Operations&FA_FILE_NEEDS_SCAN)?"S":" ",
		(node->Operations&FA_READ)?"R":" ",
		(node->Operations&FA_WRITE)?"W":" ",
		(node->Operations&FA_EXEC)?"E":" ",
		(node->Operations&FA_CLIENT_REQUEST)?"C":" ",
		(node->Operations&FA_SCAN_BOOT_SECTOR)?"B":" ",
		(node->Operations&FA_DELETE)?"D":" ",
		node->IO->access(node,0),
		node->Description);

	memset(so,0,sizeof(STORAGEOBJECT));

	so->Info       = Item->Info;
	so->Node       = node;
	so->ReturnCode = 0;
	so->Flags      = FA_RTSSCAN;
/* ??? ksr
	if (node->Operations&FA_SCAN_BOOT_SECTOR) 
	{
		ScanBootSector(so);
		if (so->ReturnCode) 
		{
			ret =  AdjustReturnCode(ret,so->ReturnCode);
		}
        if ( node->Operations&FA_COMING_FROM_NAVAP )
            return ret;
	}
*/
    if ( node->Operations&FA_COMING_FROM_NAVAP )
    {
        VEVIRUSINFO vi;

        so->Flags &= ~FA_SCANNING_MASK;
        so->Flags |= FA_SCANNING_FILE;
        so->ReturnCode = 0;

        memset(&vi,0,sizeof(vi));
        vi.appContext = (VECONTEXT) so;
        StrNCopy(vi.szVirusName,((PFILE_ACTION)(so->Node->Context))->VirusName,sizeof(vi.szVirusName));
/*
#ifndef NLM
        vi.dwVirusType = ((PFILE_ACTION)(so->Node->Context))->APVirusType;
        vi.dwVirusID = ((PFILE_ACTION)(so->Node->Context))->VirusID;
        // MMENDON 04/20/2000:  Fix for STS defect #333309
        //                      Setting cleanable and deletable flags for
        //                      later use in quarantine and virus history.
        //                      
        if(((PFILE_ACTION)(so->Node->Context))->Cleanable == 1)
            vi.dwCleanInfo = VECLEANABLE;
        else
            vi.dwCleanInfo = VENOTCLEANABLE;

        if(((PFILE_ACTION)(so->Node->Context))->Deletable == 1)
            vi.dwDeleteInfo = VEDELETABLE;
        else
            vi.dwDeleteInfo = VENOTDELETABLE;
        // MMENDON 04/20/2000:  End fix for STS defect #333309
#else
*/
        vi.dwVirusType = VEFILEVIRUS;

//#endif
        vi.dwSigHandle = 0;
        
        
        // ksr ???
        //CallBack ( 0, &vi );
        
     
        return ret;
   }

	if (node->IO->access(node,0))
		return AdjustReturnCode(ret,CAN_NOT_SCAN); // returning 0 will place file in clean cache, and we don't know that it clean.

	else if ((Item->Info->Type&IT_CAN_RTS_SKIP)&&Item->NoScanDir) 
	{
		char path[IMAX_PATH];
		if (so->Node->IO->GetFullKey(so->Node,path) == ERROR_SUCCESS)
			if (isNoScanDir(Item->NoScanDir,Item->Info,so->Node->InstanceID,path))
				node->Operations &= ~(FA_FILE_NEEDS_SCAN | FA_GET_TRAP_DATA | FA_USE_TRAP_DATA);
	}

	if (((node->Operations&FA_READ) || (node->Operations&FA_EXEC) || (node->Operations&FA_WRITE)) &&
		 (node->Operations&FA_FILE_NEEDS_SCAN) &&  
		 (!Item->Info->RTSData->Trap || (Item->Info->RTSData->FileType != 1 || 
		 _isExtWanted(Item->Info->RTSData->Exts,node->Ext) || 
		 _isExtWanted(Item->Info->RTSData->ZipExts,node->Ext))))
	{
		DWORD dwScanType;

		dwScanType = VESLOWSCAN|(Item->Info->RTSData->ZipFile?VEEXPANDFILES:0)|(Item->Info->RTSData->Softmice?VEMUTATIONSCAN:0);

		if (Item->Info->RTSData->FileType==0)
			dwScanType |= VESCANALLFILES;
		else if (Item->Info->RTSData->FileType==2)
			dwScanType |= VESCANBYTYPE|((Item->Info->RTSData->Types&1)?VESCANBYTYPEARCH:0)|((Item->Info->RTSData->Types&2)?VESCANBYTYPEEXEC:0)|((Item->Info->RTSData->Types&4)?VESCANBYTYPEOLE:0);

		cc = DoTheScan(so,dwScanType);

		if (cc != VEOK) 
		{
			if (cc == VEFILESKIPPED)
				Skip = TRUE;

			if (node->IO->access(node,0) == 0) 
			{
				dprintf("Kernel asked to scan %s but user was unable.  cc = %08X\n",node->Description,cc);
			}
			so->ReturnCode = CAN_NOT_SCAN;
		}

        // MMENDON 07-19-2000 - STS defect #340445:  Don't update stats 
        //                      if coming from mail realtime scanners
		if (!Skip && !(node->Flags&N_MAILNODE)) 
		{
			ret = AdjustReturnCode(ret,so->ReturnCode);
			pStatBlock->TotalScaned++;
			StrCopy(pStatBlock->LastScaned,node->Description);
			pStatBlock->LastUser = node->Sid;
		}
	}

	if ((node->Flags&N_FILENODE) && ((node->Operations&FA_USE_TRAP_DATA) || (node->Operations&FA_GET_TRAP_DATA))) 
	{
		so->ReturnCode = ERROR_SUCCESS;
		/* ksr ???
		if (Item->Info->RTSData->Trap && _isExtWanted(Item->Info->RTSData->TrapExts,node->Ext)) 
		{
			if (node->Operations&FA_GET_TRAP_DATA)
				TrapStuffStart(so);

			if (node->Operations&FA_USE_TRAP_DATA)
				TrapStuffStop(so);
		}
		ret = AdjustReturnCode(ret,so->ReturnCode);
		**/
	}

	if (!(ret&WAS_VIRUS_MASK))  // last file was not infected. used by callback to skip logging repeat infections of same file
		LastInfectedFile[0] = 0;

	return ret;
}


/*******************************************************************/

void StorageRTSThread(PSTORAGEITEM Item) 
{
	SNODE node;
/**
#ifdef WIN32
	UINT old;
	old = SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOOPENFILEERRORBOX);
#endif
**/
/*
#if defined(USING_NAVAP)
    NAVAPiUnprotectProcess();
#endif
*/
	LOCK();
	Item->ThreadCount++;
	Item->UseCount++;
	UNLOCK();

	__try {
		Item->Info->Functions->BeginRTSWatch((PROCESSRTSNODE)ProcessRTSNode,&node,Item);
		}
	__except(1) {
		dprintf("Storage %s caused a GPF in BeginRTSWatch\n",Item->Name);
		}

	LOCK();
	Item->ThreadCount--;
	Item->UseCount--;
	UNLOCK();
/*
#if defined(USING_NAVAP)
    NAVAPiProtectProcess();
#endif
*/
/**
#ifdef WIN32
	SetErrorMode(old);
#endif
**/

}


/************************************************************************************************************/

DWORD StartStorageRTS(PSTORAGEITEM Item) 
{
	int i;
	
	for (i=0;i<Item->Info->MaxThreads;i++) 
	{
		char line[64];
		
		WSprintf(line,"RTV Checker %u for %s",i,Item->Name);
		MyBeginThread((THREAD)StorageRTSThread,Item,line);
	}

	return ERROR_SUCCESS;
}


/*********************************************************************************************************/

void WatchRTSConfig(PSTORAGEITEM item) 
{
	DWORD cc = 0;

	if( SystemRunning /*&& item->Info->hRTSConfigKey */ ) // ???? key
		goto first;

	while( SystemRunning /*&& item->Info->hRTSConfigKey*/ ) 
	{
		//cc = RegNotifyChangeKeyValue(item->Info->hRTSConfigKey,TRUE,REG_NOTIFY_CHANGE_LAST_SET,NULL,FALSE);
		if( SystemRunning /*&& item->Info->hRTSConfigKey*/ ) 
		{
			if (cc == ERROR_SUCCESS)
				dprintf("%s Reg change noted, re-reading.\n",item->Name);
first:	__try 
			{
				item->Info->Functions->ReloadRTSConfig();
				if (item->Info->Type&IT_CAN_RTS_SKIP)
					PreReadNoScanDirs(/*item->Info->hRTSConfigKey,*/&item->NoScanDir);
			}
			__except(1) 
			{
				dprintf("GPF in Storage %s in ReloadRTSConfig\n",item->Name);
			}
		}
		// ksr
		ThreadSwitch();
	}

}
//#endif


/************************************************************************************************************/
/*
DWORD VerifyStorageManagerState(DWORD Flags) {

	if (!StorageManagerStarted) {
		if (MyBeginThread((THREAD)StorageManagerStart,(void *)Flags,"RTV Storage Start") == 0xffffffff) {
			return ERROR_MEMORY;
			}

		while (!StorageManagerActive)
			NTxSleep(55);
		}

	if (Flags != StorageManagerFlags) {
		PSTORAGEITEM Item;

		Item = StorageList;

		while(Item) {
			Item->Info->Functions->Reinit(Flags);
			Item = Item->Next;
			}

		StorageManagerFlags = Flags;
		}
	return ERROR_SUCCESS;
}
*/


/**********************************************************************************************************/

void NotifyStorageOfNewUserThread(PSTORAGEITEM Item) 
{
Breakpoint( 1 );
	__try 
	{
		Item->Info->Functions->ChangeUser
//#ifdef SERVER
			(CurrentUserName,hAccessToken);
			/*
#else
			("CLIENT",0);
#endif*/

	}
	__except(1) 
	{
		dprintf("Storage %s caused crash in NotifyStorageOfNewUser\n",Item->Name);
	}

	return;
}


/************************************************************************************************************/

void StorageManagerStart(DWORD Flags) 
{
	int index=0;
	char name[IMAX_PATH];
	char str[IMAX_PATH];
	char path[IMAX_PATH];
	char fullpath[IMAX_PATH];
/**
#ifdef WIN32
	char tmp[IMAX_PATH];
#endif
**/
	HANDLE Module,Handle;
	STORAGEINIT Init;
	DWORD cc;
	PSTORAGEINFO Info;
	PSTORAGEITEM Item;
//	HKEY hkey;
//	HKEY hckey;

//#ifdef SERVER
	Flags |= S_WANT_RTS;
//#endif

//#ifdef SERVER
	#define MS "ServiceStorageStartCode"
	/*
#else
	#define MS "ClientStorageStartCode"
#endif
   */

	StorageManagerStarted = TRUE;
	StorageManagerFlags = Flags;

/**
	PutVal(hMainKey,"InstalledProducts",1);

	if (RegCreateKey(hMainKey,"Storages",&hkey) == ERROR_SUCCESS) {
	*/
		Module = 0;
		StrCopy(name,"FileSystem");

		Init = FileStorageInit;	// compiler takes it as a function, params?
		//RegCreateKey(hkey,name,&hckey);
		goto file;

      /*
		while (RegEnumKey(hkey,index++,name,sizeof(name))  == ERROR_SUCCESS) {
			if (RegOpenKey(hkey,name,&hckey) == ERROR_SUCCESS) {
			
				if (!strcmp(name,"FileSystem"))
					continue;
      */
      //--------------------------------------------------------------
      // ksr ????
      //
		while ( SystemRunning ) 
		{
				// ksr ??? what is he trying to do here ?!
            //if ( !VerifyValidStorageType(name) )
            //   continue;

				dprintf("checking storage reg value for %s\n",name);
				//PutVal(hckey,"ServiceStatus",0);
				//PutVal(hckey,MS,0xffffffff);
				//GetStr(hckey,"ServiceDllName",str,sizeof(str),"");
				if (*str == 0) 
				{
					dprintf("No ServiceDLLName\n");
					cc = ERROR_NO_DLL_NAME;
				}
				else 
				{
				/*
					GetStr(hckey,"ServiceDllPath",path,sizeof(path),HomeDir);
#ifdef WIN32
					GetCurrentDirectory(sizeof(tmp),tmp);
					SetCurrentDirectory(path);
#endif
              */
					
					
					WSprintf(fullpath,"%s\\%s",path,str);					
					// ksr ???? Module = LoadLibrary(fullpath);
					Module = 1;
					
					
					/*
#ifdef WIN32
					SetCurrentDirectory(tmp);
#endif */
					if (Module == NULL) 
					{
						dprintf("Load failed [%s]\n",fullpath);
						cc = ERROR_DLL_LOAD_FAIL;
					}
					else 
					{
						//GetStr(hckey,"ServiceDllEntryPoint",str,sizeof(str),"Init");
						
						// ksr ???
						//Init = (STORAGEINIT)GetProcAddress(Module,str);
						Init = (STORAGEINIT)1;
						if (Init) 
						{
file: 					dprintf("Loading storage %s\n",name);
							cc = Init(Flags,&Info,&Handle,&SSfuns);
							if (cc != ERROR_SUCCESS) 
							{
								dprintf("Init failed with [%08X]\n",cc);
								goto error;
							}
							else
							{
								if (Info->Size != sizeof(STORAGEINFO) || stricmp(name,Info->Name)) 
								{
									Info->Functions->Deinit(Handle);
									dprintf("Stroage %s is wrong version\n",name);
									goto error;
								}
								Item = malloc(sizeof(STORAGEITEM));
								if (Item) 
								{
									if (Init == FileStorageInit)
										FileStorageItem = Item;
									dprintf("Successful load of Storage %s\n",name);
									cc = ERROR_SUCCESS;
									memset(Item,0,sizeof(STORAGEITEM));
									Item->Module = Module;
									Item->Handle = Handle;
									Item->Info = Info;
									Item->Next = StorageList;
									strcpy(Item->Name,name);
									StorageList = Item;
									//PutVal(hckey,"ServiceStatus",1);
									//PutVal(hMainKey,"InstalledProducts",GetVal(hckey,"Type",0)|GetVal(hMainKey,"InstalledProducts",1));
//#ifdef SERVER
									if ((Flags&S_WANT_RTS) && (Info->Type&IT_CAN_RTS))
									{
										char line[32];
										WSprintf(line,"RTV WC %s",name);
										MyBeginThread((THREAD)WatchRTSConfig,Item,line);
										StartStorageRTS(Item);
									}
//#endif
									WSprintf(str,"New User Notify for %s",name);
									MyBeginThread((THREAD)NotifyStorageOfNewUserThread,Item,str); // tell them what the current user is.
									dprintf("All tasks complete for load of storage %s\n",name);
								}
								else
								{
									dprintf("Memory fail\n");
									Info->Functions->Deinit(Handle);
									goto error;
								}
							}
						}
						else 
						{
							dprintf("Get ProcAddress failed looking for [%s]\n",str);
							cc = ERROR_NO_PROC_ADDRESS;
error:					if(Module)
								FreeLibrary(Module);
						}
					}
				}
					/**
				PutVal(hckey,MS,cc);
				RegCloseKey(hckey);
				}
			}
		RegCloseKey(hkey);
	**/
			// ksr  ???
			ThreadSwitch();
			
		}  // while
	
	StorageManagerActive = TRUE;
	dprintf("Storage Manager now active\n");
}


/************************************************************************************************************/

DWORD StorageManagerStop(long *status) 
{
	PSTORAGEITEM Item,x=NULL;
	int i;

	if (!StorageManagerActive)
		goto done;

	LOCK();
	Item = StorageList;
	StorageList = NULL;
	StorageManagerActive = FALSE;
	UNLOCK();

	if (status)
		*status = 1;

	while(Item) 
	{
		if (status == NULL && strcmp(Item->Name,"FileSystem"))  // we had a terminal GPF I just want to unhook the RTS in the file system.
			continue;

		__try 
		{
//#ifdef SERVER
			dprintf("Stop RTS threads for %s\n",Item->Name);
			StopStorageRTS(Item);
			if (Item->Info->Type&IT_CAN_RTS_SKIP)
				PreReadNoScanDirs(/*NULL,*/&Item->NoScanDir);
//#endif
			for (i=0;i<4*5&&Item->UseCount;i++) 
			{
            dprintf("~");
				NTxSleep(250);
			}
			if (Item->UseCount == 0) 
			{
				DWORD cc;
				dprintf("Calling Deinit for storage %s\n",Item->Name);
				cc = Item->Info->Functions->Deinit(Item->Handle);
				if (cc) {
					dprintf("Deinit of storage %s failed with %08X\n",Item->Name,cc);
					}
				if (Item->Module)
					FreeLibrary(Item->Module);
				x = Item;
				dprintf("Released storage %s\n",Item->Name);
			}
			else 
			{
				dprintf("storage %s Failed to release RTS threads\n",Item->Name);
				x = NULL;
			}
		}
		__except(1) 
		{
			dprintf("GPF in stutdown of storage %s\n",Item->Name);
		}
		Item = Item->Next;
		if (x)
      {
			free(x);
            x = NULL;
      }
		}

done:
	if (status)
		*status = 2;

	return ERROR_SUCCESS;
}
/************************************************************************************************************/
PSTORAGEITEM GetStorageFromName(char *name) {

	PSTORAGEITEM Item;

	if (!StorageManagerActive)
		return NULL;

	Item = StorageList;

	while(Item) 
	{
		if (!stricmp(Item->Info->Name,name))
			return Item;
		Item = Item->Next;
	}

	return NULL;

}
/************************************************************************************************************/
PSTORAGEITEM GetStorageAndIDFromPath(char **Path,DWORD *ID) {

	PSTORAGEITEM Item;
	char *q,*w;
	char *path = *Path;

	if (!StorageManagerActive)
		return NULL;

	Item = StorageList;

	q = StrChar(path,':');
	w = StrChar(path,'\\');

	if (q) 
	{
		if (!w || (q < w)) 
		{
			FileStorageItem->Info->Functions->RefreshInstanceData();
			*ID = GetInstanceIDFromPath(path);
/**
#ifdef WIN32
            if(*ID == 0)
                *Path = path;
            else
#endif
**/
			    *Path = q+1;

			return FileStorageItem;
			}
		}
/**
#ifdef WIN32
	// Check if the path is UNC
    if (path[0] == '\\' && path[1] == '\\')
    {
        FileStorageItem->Info->Functions->RefreshInstanceData();
        *ID = GetInstanceIDFromPath(path);
        return FileStorageItem;
    }
#endif
**/
	if (path[0] != '[')
		return NULL;

	q = StrChar(path,']');
	if (q == NULL)
		return NULL;

	path++;
	*q = 0;
	*Path = q+1;
	q = StrChar(path,',');

	if (q == NULL)
		return NULL;

	*q++ = 0;

	while(Item) 
	{
		Item->Info->Functions->RefreshInstanceData();
		if (!stricmp(path,Item->Info->Name)) 
		{
			*ID = atoi(q);
			return Item;
		}
		Item = Item->Next;
	}

	return NULL;
}
/************************************************************************************************************/
DWORD QueryDriveList(char *list,DWORD *Index,DWORD dwHiddenDrives) {

	PSTORAGEITEM    Item;
    char            str[128] = {0};
	DWORD           i;
	char            type = 0;
	DWORD           index=0;
	DWORD           len = 0;


	StrCopy(list,"GENERIC!");
	len = strlen(list);

	if (!StorageManagerActive)
		return ERROR_SUCCESS;

	Item = StorageList;

	while(Item) 
   {
		if (*Index == 0)
			Item->Info->Functions->RefreshInstanceData();

		for (i=0;i<Item->Info->InstanceCount;i++) 
      {
			if (index >= *Index) 
         {
				if (Item->Info->InstanceBlocks[i].Type&IT_CAN_WALK) 
             {
					switch(Item->Info->InstanceBlocks[i].Type&IT_TYPES) 
               {
						case IT_REMOVABLE:   type = 'R';break;
						case IT_FIXED:       type = 'F';break;
						case IT_REMOTE:      type = 'N';break;
						case IT_CDROM:       type = 'C';break;
						case IT_MAIL:        type = 'M';break;
						case IT_OTHER:       type = 'O';break;
						case IT_VBIN:        type = 'V';break;
						case IT_GATEWAY:     type = 'G';break;
						default: 
							 str[0] = 0;
							 type = 0;
					}

                    if ( type && !CheckDriveIsHidden( (LPSTR)&Item->Info->InstanceBlocks[i].DisplayName, dwHiddenDrives) )
                    {
						WSprintf(str,"[%s,%u]%c,%s,%s;",
									Item->Info->Name,
									Item->Info->InstanceBlocks[i].InstanceID,
									type,
									Item->Info->InstanceBlocks[i].DisplayName,
									Item->Info->InstanceBlocks[i].VolumeName);

						len += strlen(str);
						if (*str)
							strcat(list,str);
						if (len > 800) 
						{
							*Index = index;
							list[strlen(list)-1] = 0;
							return ERROR_SUCCESS;
						}
                    }
				}
			}
			index++;
		}
		Item = Item->Next;
	}

	*Index = 0;
	list[strlen(list)-1] = 0;
	return ERROR_SUCCESS;
}


/***********************************************************************************************************************/
/***********************************************************************************************************************/
//#ifdef SERVER
/*
DWORD NotifyStoragesOfNewUser(char *NewUserName) 
{
	PSTORAGEITEM Item;

	REF(NewUserName);

	if (!StorageManagerActive)
		return ERROR_GENERAL;

	Item = StorageList;

	while(Item) 
	{
		MyBeginThread((THREAD)NotifyStorageOfNewUserThread,Item,"NewUser");
		Item = Item->Next;
	}

	return ERROR_SUCCESS;
}
*/
//#endif


/***********************************************************************************************************************/
/***********************************************************************************************************************/

BOOL  VerifyValidStorageType(LPSTR lpStorageName)
{
//ksr from ClientReg.h  ???
#define szStorage_Exchange					"MicrosoftExchangeClient"
#define szStorage_Notes						"LotusNotes"

    if ( !lpStorageName )
        return FALSE;

    if ( strcmp(lpStorageName, szStorage_Notes) == 0 )
        return TRUE;

    if ( strcmp(lpStorageName, szStorage_Exchange) == 0 )
        return TRUE;

    return FALSE;
}


/***********************************************************************************************************************/
/***********************************************************************************************************************/

BOOL CheckDriveIsHidden(LPSTR lpItem, DWORD dwHiddenDrives)
{
    BOOL    bRetValue = FALSE;
/**
#ifdef WIN32
    DWORD   dwDrive = 0;
    DWORD   dwDriveMask = 0;
 

    if ( lpItem )
    {
        // Get the drive letter and translate it to a bit value
        dwDrive = __toascii( *lpItem ) - 'A';
        dwDriveMask = 1 << dwDrive;

        // Is it in the dwHiddenDrives?
        if ( dwDriveMask & dwHiddenDrives )
        {
            bRetValue = TRUE;
        }
    }

#endif // WIN32
**/
    return bRetValue;
}