//------------------------------------------------------------------------------
//
//      Action.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#include "pscan.h"

// ksr
// from nts.h
  /**********************************************************************
  ;  NTS.H -- NLM Specific MACROs (All Macros start with NTx...)
  ;********************************************************************/
  //#define NTxSemaClose(h)             CloseLocalSemaphore(h)
  //#define NTxSemaCreate(i,p)          OpenLocalSemaphore(i)
  //#define NTxSemaOpen(i,p)            OpenLocalSemaphore(i)
  #define NTxSleep(ms)                delay(ms)

/*
#ifndef NLM    
#include <rpc.h>
#endif
*/

//rchinta
// TODO:  Remove this after making the necessary changes to get dec2.h
// fixed to declare DecResult in C style
/////////////////////////////////////////////////////////////////////////////
// DECRESULT Codes

/*
#ifdef WIN32

//#pragma warning(disable: 4100)	// 4100: unreferenced formal parameter
//#include "dec2.h"
//#pragma warning(default: 4100)	// 4100: unreferenced formal parameter

enum DecResult
{
	DECRESULT_UNCHANGED = 0,
	DECRESULT_CHANGED = 1,
	DECRESULT_TO_BE_REPLACED = 2,
	DECRESULT_TO_BE_DELETED = 3,
};

extern PFNSfcIsFileProtected pfnSfcIsFileProtected;

DWORD AddZipEvent(PEVENTBLOCK eb);
DWORD LogInfectionInZip(PEVENTBLOCK eb);

#endif
*/


DWORD TimeOfLastInf=0;
DWORD NumVirusesInTime=0;
//char LogFileName[IMAX_PATH] = {/**/""};
static HANDLE Mutex = 0;

//DWORD LogNotifyQueueEvent(PEVENTBLOCK eb);

/**
#ifdef WIN32
//============================================================================
static void StartCS(void) {
	if (Mutex == 0)
		Mutex = CreateMutex(NULL,FALSE,NULL);

	WaitForSingleObject(Mutex,INFINITE);
}
//============================================================================
static void EndCS(void) {

	ReleaseMutex(Mutex);
}
#endif // WIN32
**/



/******************************************************************************************************/
/*
DWORD GetLoggerStrID(DWORD who) {

	switch (who) {
		case LOGGER_Scheduled: return IDS_LOG_SCH;
		case LOGGER_Manual: return IDS_LOG_MAN;
		case LOGGER_Real_Time: return IDS_LOG_REAL;
		case LOGGER_Console: return IDS_LOG_CON;
		case LOGGER_VPDOWN: return IDS_LOG_VPD;
		case LOGGER_Client: return IDS_LOG_CLI_FOR;
		case LOGGER_Forwarded: return IDS_LOG_SER_FOR;
		case LOGGER_Startup: return IDS_LOG_START;
		case LOGGER_System: return IDS_LOG_SYSTEM;
		}
	return IDS_LOG_INVALID;
}
*/
/******************************************************************************************************/
/*
char *GetLoggerStr(char *out,DWORD who) {

	int i=GetLoggerStrID(who);

	strcpy(out,LS(i));
	if (i == IDS_LOG_INVALID)
		WSprintf(out+strlen(out)," : (%u)",who);

	return out;
}
*/
/*******************************************************************************************************/
/*
char *GetFullLoggerStr(char *out,DWORD who) {

	char str1[64],str2[64];

	if (((who&0xffff) == LOGGER_Client) || ((who&0xffff) == LOGGER_Forwarded))
		WSprintf(out,"%s:%s",GetLoggerStr(str1,who&0xffff),GetLoggerStr(str2,who>>16));
	else
		WSprintf(out,"%s",GetLoggerStr(str1,who));

	return out;
}
*/
/******************************************************************/




#if 0




BOOL isException(HKEY *ihkey,char *skey,char *item) {

// 	DWORD val,dwType;
	DWORD cbData;
	DWORD cc;
	HKEY nhkey=0;
	BOOL ret = FALSE;
	char sitem[IMAX_PATH];
	HKEY hkey = ihkey[0];


	if (!item || *item == 0)
		return FALSE;

	strncpy(sitem,item,sizeof(sitem));
	StrUpper(sitem);

	cbData = sizeof(DWORD);
	cc = RegOpenKey(hkey,skey,&nhkey);
	if (cc == ERROR_SUCCESS) {
GetValue:
		if (RegQueryValueEx(nhkey, sitem, 0, 0, 0, 0) == ERROR_SUCCESS) {
//		if (RegQueryValueEx(nhkey, sitem, 0, &dwType,(LPVOID)&val, &cbData) == ERROR_SUCCESS)
//			cbData = sizeof(DWORD);
//			val++;
//			RegSetValueEx(nhkey, sitem, 0, REG_DWORD,(LPVOID)&val, cbData);
			ret = TRUE;
			}
		RegCloseKey(nhkey);
		}
	else {
		hkey = ihkey[1];
		if (hkey) {
			cc = RegOpenKey(hkey,skey,&nhkey);
			if (cc == ERROR_SUCCESS)
				goto GetValue;
			}
		hkey = GetCommonKey();
		cc = RegOpenKey(hkey,skey,&nhkey);
		if (cc == ERROR_SUCCESS)
			goto GetValue;
		}

	return ret;
}
/******************************************************************************/
BOOL isNodeException(HKEY *ihkey,char *skey,PSTORAGEOBJECT so) {

	char path[IMAX_PATH];
	char *q;
	BOOL ret;

	if (so == NULL)
		return FALSE;

	WSprintf(path,"[%s,%u]",so->Info->Name,so->Node->InstanceID);
	q = path + strlen(path);
	if (so->FullKey)  // for walk scan
		StrCopy(q,so->FullKey);
	else {
		if (((so->Node->Flags&N_RTSNODE)&&(so->Node->Flags&N_MAILNODE)) || so->Node->IO->GetFullKey(so->Node,q) != ERROR_SUCCESS)
			return FALSE;
		}

	ret = isException(ihkey,skey,path);
	
	if (!ret) {
		if (!stricmp(so->Info->Name,"FileSystem")) {
			WSprintf(path,"%s",GetDriveFromInstanceID(so->Node->InstanceID));
			q = path + strlen(path);
			if (so->Node->IO->GetFullKey(so->Node,q) != ERROR_SUCCESS)
				return FALSE;
			ret = isException(ihkey,skey,path);
			}
		}

	return ret;
}
/******************************************************************************/
/******************************************************************************/
/*
FILE *OpenActionFile(char *mode) {

	if (LogFileName[0] == 0)
		WSprintf(LogFileName,"%s\\Action.Log",HomeDir);

	return fopen(LogFileName,mode);
}
*/
/******************************************************************************/
/*
void RecordAction(char *from,char *to,char *act) {

	FILE *file;

	LOCK();

	file = OpenActionFile(/** /"at");

	if (file) {
		fprintf(file,/** /"File [%s] was %s to [%s]\n",from,act,to);
		fclose(file);
		}

	UNLOCK();
}
*/
/******************************************************************************/
DWORD MoveBackup(char *name) {

	char szDst[IMAX_PATH];
	char *cp;
	int count = 0;
	char Ext[MAX_USED_EXT] = ".RB0";
	DWORD ret;

	cp = StrRChar(name,'\\');
	if (cp==NULL)
		return ERROR_NO_PATH1;

	WSprintf(szDst,"%s\\infbak\\",HomeDir);
	if (access(szDst,0))
		CreateDirectory(szDst,NULL);

	strcat(szDst,cp+1);

	cp = StrRChar(name,'.');
	if (cp)
		strcpy(cp,".rb0");


	cp = StrRChar(szDst,'.');
	if (cp==NULL)
		cp = szDst + NumBytes(szDst);

	for (;;) {
		if (access(szDst,0) != 0) {
			ret = MoveFileEx(name,szDst,MOVEFILE_COPY_ALLOWED);
			return ret?ERROR_SUCCESS:ERROR_MOVE_FAILED;
			}

		if (!count)
			StrCopy(cp,Ext);
		else
			WSprintf(cp,/**/".%c%02u",Ext[1],count);
		if (count++ >= 90)
			return ERROR_MAX_COUNT_REACHED;
		}
}
/**********************************************************************************/
DWORD MoveInfectedObject(PEVENTBLOCK eb, DWORD dwFlags) {

	VBININFO     vbi;
	DWORD        cc;
    DWORD        dwOrigAction;
//#ifdef NLM //EA 05/03/2000 fix for STS Defect#333989
	char         szShortPathName[IMAX_PATH]; //EA 05/03/2000 fix for STS Defect#333989
//#endif //EA 05/03/2000 fix for STS Defect#333989

	if (!(eb->so->Flags&FA_SCANNING_FILE))
		return ERROR_ACCESS_DENIED;
/*
#ifdef WIN32
    
    // The virus should be deletable in order for the file to be quarantined
    if ( eb->dwDeleteType == VENOTDELETABLE )
        return ERROR_NOT_DELETABLE;
#endif
*/
	memset(&vbi,0,sizeof(VBININFO));
	vbi.Size = sizeof(VBININFO);
	vbi.Flags = dwFlags;

    // Save the current time
    time(&vbi.ExtraInfo.stVBinTime);

    // Save the status info for the current file
/*
#ifndef NLM  //ML

    // the original file has already been deleted by AP so
    // we have to carry the file times with us and copy
    // them to the vbininfo object
    if( eb->so->Node->Operations & FA_COMING_FROM_NAVAP )
    {
        // MMENDON 07-20-2000:  Need to call stat for AP to get the file size, then 
        // replace the file times with those sent from AP kernel.
        _stat((LPTSTR)((PFILE_ACTION)eb->so->Node->Context)->Process, &vbi.ExtraInfo.stFileStatus);
        vbi.ExtraInfo.stFileStatus.st_atime = (time_t)((PFILE_ACTION)eb->so->Node->Context)->APFileAccessTime;
        vbi.ExtraInfo.stFileStatus.st_mtime = (time_t)((PFILE_ACTION)eb->so->Node->Context)->APFileModifiedTime;
        vbi.ExtraInfo.stFileStatus.st_ctime = (time_t)((PFILE_ACTION)eb->so->Node->Context)->APFileCreateTime;
    }

    else
        _stat(eb->so->Node->Description, &vbi.ExtraInfo.stFileStatus);
#else
*/
	//EA 05/03/2000  begin of fix for STS Defect#333989
	//Basically the wrong date's(Thursday, 01 Jan 1970 00:00:00 GMT) that used to appear on the quarantined files 
	//modified ,created or accessed time is because the stat function would fail to get the correct time on long
	//file name hence called a function "converttoshortname" that will convert the file name into 8.3 format
	//so that the stat function will set the right attributes of the modified created and accessed time to the file
	//that gets quarantined
	memset(szShortPathName, 0, IMAX_PATH); //EA 05/03/2000 fix for STS Defect#333989
	if (ConvertToShortName(szShortPathName,eb->so->Node->Description,IMAX_PATH,NWOS2_NAME_SPACE) == TRUE) //EA 05/03/2000 fix for STS Defect#333989
	{
		stat(szShortPathName, &vbi.ExtraInfo.stFileStatus); //EA 05/03/2000 fix for STS Defect#333989
	} //EA 05/03/2000 fix for STS Defect#333989
	else 
		stat(eb->so->Node->Description, &vbi.ExtraInfo.stFileStatus);
	//EA 05/03/2000  end of fix for STS Defect#333989
//#endif

/*
#ifndef NLM    //ML
    // Create a GUID for this item (used by Scan & Deliver)
    UuidCreate(&vbi.ExtraInfo.stUniqueId);
#endif

#ifndef NLM    //ML
    // Are we coming from AP?
    if ( eb->so->Node->Operations & FA_COMING_FROM_NAVAP )
    {
        // Then get the file name from a different place
	    StrCopy(vbi.Description, (LPTSTR)((PFILE_ACTION)eb->so->Node->Context)->Process );
    }
    else
#endif
*/
    {
        // Get it from the normal location
	    StrCopy(vbi.Description,eb->so->Node->Description);
    }

    // Save the existing real action
    dwOrigAction = eb->RealAction;

    // Make the real action be quarantine if infected
    if ( dwFlags == VBIN_INFECTED )
    {
        eb->RealAction = AC_MOVE;
    }
    else if ( dwFlags == VBIN_BACKUP )
    {
        eb->RealAction = AC_BACKUP;
    }

    // Create the log line
	//GenerateLogLine(vbi.LogLine,eb);

    // Quarantine the file
	cc = VBin_AddItem(&vbi,eb->so);

	if (cc == ERROR_SUCCESS)
    {   
        // Make sure the "manual" bit is ignored.
        DWORD dwTempFlags = dwFlags & 0x00FFFFFF;
		DWORD dwError = ERROR_SUCCESS;

        eb->VBinID = vbi.RecordID;

        switch ( dwTempFlags )
        {
            case VBIN_INFECTED:

		        dwError = eb->so->Node->Functions->RemoveNode(eb->so->Node);

				if ( dwError != ERROR_SUCCESS )
				{
					// We couldn't delete the original file, so we fail
					// the entire operation. Remove the item from Quarantine.

					VBin_Delete(vbi.RecordID);

					cc = ERROR_MOVE_FAILED;
				}

                break;

            case VBIN_BACKUP:
            case VBIN_REPAIRED:
                break;
		}
    }

    // Put back the original real action
    eb->RealAction = dwOrigAction;

	return cc;
}
/******************************************************************************/
DWORD CleanBootSector(PEVENTBLOCK eb) {

	BOOL ret=ERROR_CLEAN_BOOT_FAILED;
	VEDISKINFO di;
	BYTE *CritData;
	DWORD id;
	USEVE

	if (eb->EventData == NULL)
		return ERROR_BAD_PARAM;

	id = atoi((char *)eb->EventData);
/*
#ifdef WIN32
	// Fix for STS#342662.  
	if(id >= 26 && !HWIsNEC())
	{
        // master boot record clean is performed for valid disk
        // numbers 0x80 and 0x81 (the same translation as was used
		// when performing the scan).
		id = 0x80 + id - 26;
	}

	dprintf("In CleanBootSector() - Drive: %08x\n");

#endif
*/
	CritData = malloc(VeInfo->wCriticalDiskDataSize);
	if (CritData) 
	{
		CALLVE;
		ret =VEGetCriticalDiskData(VEhan,id,CritData);
		RETVE;
		if (ret == VEOK) 
		{
			memset(&di,0,sizeof(VEDISKINFO));
			di.wSize = sizeof(VEDISKINFO);
			di.pCriticalDiskData = CritData;

			CALLVE;
			ret = VECleanCriticalDiskData(VEhan,&di);
			RETVE;
			if (ret == VEOK) 
			{
				CALLVE;
				VESetCriticalDiskData(VEhan,CritData);
				RETVE;
				}
			}

		free(CritData);
		}
	return ret;
}
/******************************************************************************/
DWORD CleanInfection(PEVENTBLOCK eb,DWORD FileType) {

	int cc;
	USEVE
	VECLEANINFO vc;
//#ifdef NLM
	int /*old_ns,*/old_ns1;
	BYTE LONGName1[256],LONGName2[256];
//#endif

	memset(&vc,0,sizeof(VECLEANINFO));
	vc.wSize = sizeof(VECLEANINFO);
	vc.dwSigHandle = eb->VirusSigHan;
	vc.dwVirusID = eb->VirusID;
	vc.pszFileName = eb->so->Node->InternalPath;
	vc.dwFileType = FileType;
/*
#ifdef WIN32
	memcpy(&vc.decompFileInfo, eb->pdfi, sizeof(DECOMPFILEINFO));
#endif
*/
	__try {
		if (eb->so->Flags&FA_SCANNING_BOOT_SECTOR) {
			cc = CleanBootSector(eb);
			}
		else if (eb->so->Flags&FA_SCANNING_MEMORY) {
			cc = ERROR_CAN_NOT_CLEAN_MEMORY;
			}
		else if (eb->so->Flags&FA_SCANNING_FILE){
//#ifdef NLM
			//EA 08/23/2000 Start of Fix for STS defects 344524 and 344525 
			//to set write rights to a file before cleaning the file is readonly.
			int setattrib = 0;
			struct stat nstat;
			DWORD ret;
			ret = GetFileState(eb->so->Node->InternalPath,&nstat);
			if (ret == ERROR_SUCCESS)
			{
				dprintf("The file %s was able to get file state now checking for read write access\r\n",eb->so->Node->InternalPath);
				if(access(eb->so->Node->InternalPath, ACCESS_RD | ACCESS_WR) != 0)
				{
					setattrib = 1;
					dprintf("The file %s did not have read and write attributes\r\n",eb->so->Node->InternalPath);
					MakeWriteable(eb->so->Node->InternalPath,0xfffffffc);
					if(access(eb->so->Node->InternalPath, ACCESS_RD | ACCESS_WR) != 0)
					{
						dprintf("After Make writeable the file %s did not have read and write attributes\r\n",eb->so->Node->InternalPath);
					}
					else
						dprintf("After Make writeable The file %s does have read and write attributes\r\n",eb->so->Node->InternalPath);
				}
			}
			//EA 08/23/2000 End of Fix for STS defects 344524 and 344525 
			NWGetNameSpaceEntryName(vc.pszFileName,NWOS2_NAME_SPACE,sizeof(LONGName1),LONGName1);
//#endif            
			CALLVE;
			cc = VECleanFile(VEhan,&vc);
			RETVE;
//#ifdef NLM
			//EA 08/23/2000 Start of Fix for STS defects 344524 and 344525 
			//if attributes have been changed then set it back to its original state after cleaning it
			if(setattrib == 1)
			{
				if(SetFileState(eb->so->Node->InternalPath, &nstat) == ESUCCESS)
					dprintf("The file %s is getting back its old attributes\r\n",eb->so->Node->InternalPath);

			}
			//EA 08/23/2000 End of Fix for STS defects 344524 and 344525 
			if (cc == VEOK) { // move .br0 file
				NWGetNameSpaceEntryName(vc.pszFileName,NWOS2_NAME_SPACE,sizeof(LONGName2),LONGName2);
				if (strcmp(LONGName1,LONGName2)!=0) { //Long name was changed for some reason we must reset it
// FGR
//					old_ns=SetCurrentNameSpace(NWOS2_NAME_SPACE);
					old_ns1=SetTargetNameSpace(NWOS2_NAME_SPACE);
					NWSetNameSpaceEntryName(vc.pszFileName,NWOS2_NAME_SPACE,LONGName1);
					SetTargetNameSpace(old_ns1);
// FGR
//					SetCurrentNameSpace(old_ns);
					}
				}
//#endif                
			}
		else
			cc = ERROR_CAN_NOT_CLEAN;
		}
	__except(1) {
		cc = ERROR_EXCEPTION;
		}

	dprintf("Clean code on %s = %08X\n",eb->so->Node->Name,cc);
	return cc;
}
/******************************************************************************/
DWORD DeleteInfectedFile(PEVENTBLOCK eb) {
/*
#ifdef WIN32
    if (eb->dwDeleteType == VENOTDELETABLE)
        return ERROR_NOT_DELETABLE;
#endif
*/
	if (!(eb->so->Flags&FA_SCANNING_FILE))
		return ERROR_ACCESS_DENIED;

	return eb->so->Node->Functions->RemoveNode(eb->so->Node);
}
/******************************************************************************/
DWORD ActOnEvent(PEVENTBLOCK eb) {

	DWORD times = time(NULL);
	char line[128];
	char str[64];
	int i;
	DWORD ret[2] = {0xffffffff,0xffffffff};
	BOOL bIsFileProtected = FALSE;

	if (eb->so == NULL) // can not act of event with no Storage Node
		return ERROR_NO_SNODE;

	eb->RealAction = AC_BAD;
/*
#ifdef WIN32

	if(pfnSfcIsFileProtected)
	{
		WCHAR wszFileName[_MAX_PATH] = L"";
		DWORD dwRet;

        if ( MultiByteToWideChar(CP_ACP, 0, eb->so->Node->InternalPath, -1, wszFileName, sizeof(wszFileName)/sizeof(wszFileName[0]) ) != 0)
		{
			BOOL bRet = pfnSfcIsFileProtected(NULL, wszFileName);
			dwRet = GetLastError();

			if(bRet)
			{
				bIsFileProtected = TRUE;
			}
		}
	} 

    // Special handling for containers, i.e backup, restore from backup, 
    // move to Quarantine etc.
    if (eb->VirusType&VEFILECOMPRESSED)
    {
       if (eb->pdfi->bIsCompressed && 
            eb->pdfi->dwDepthOfFileToGet == 0 && 
            eb->pdfi->bBackupToQuarantine &&
            eb->pdfi->bFirstProcess &&
            eb->pdfi->dwProcessFlags == DECINFO_STOP_AND_BACKUP)
        {
            // If the option to backup is turned on and if it is a container
            // create a backup regardless of the WantedAction.

            if ( ERROR_SUCCESS == CreateBackup(eb) )
                // Save the VBinID from this event block 
                // for the containers to use it later during restore.
            {
                eb->pdfi->dwVBinID = eb->VBinID;
                eb->dwBackupID = eb->VBinID;
                return ERROR_CREATED_BACKUP_NOLOG;
            }
            else
            {
                eb->pdfi->dwVBinID = 0;
                eb->pdfi->dwProcessFlags = DECINFO_CREATE_BACKUP_FAILED;

                return ERROR_CREATE_BACKUP_FAILED;
            }

        }
        else if (eb->pdfi->bIsCompressed && 
                eb->pdfi->dwDepthOfFileToGet == 0 && 
                eb->pdfi->bBackupToQuarantine &&
                eb->pdfi->dwVBinID && 
                eb->pdfi->dwProcessFlags == DECINFO_RESTORE_FROM_BACKUP)
        {
            // If the option to backup is turned on and if it is a container
            // and if a backup was created restore the container if the container
            // processing failed.
            RestoreFromBackup(eb);
        }
        // Quarantine the top-level containers if any of the items inside the
        // container needs to be Quarantined.
        else if( eb->pdfi->bIsCompressed && 
                 eb->pdfi->dwDepthOfFileToGet == 0 &&
                 eb->pdfi->bQuarantine) {
				if(! bIsFileProtected)
				{
					// Is there a backup ID? 
					if ( eb->pdfi->dwVBinID != 0 )
					{
						// Yep. Keep it around.
						eb->dwBackupID = eb->pdfi->dwVBinID;
					}

					eb->RealAction = (ret[0]=MoveInfectedObject(eb, VBIN_INFECTED))==ERROR_SUCCESS?AC_MOVE:AC_BAD; 
				}
				else // Do not Move files under WFP on Windows 2000
					eb->RealAction = AC_BAD;


                // Finished processing the top-level container for Quarantine operation
                goto ActionsDone;
 
        }
    }
#endif  // end of WIN32
*/
for (i=0;i<2&&eb->RealAction==AC_BAD;i++) {

/*
#ifdef WIN32

		if (eb->VirusType&VEFILECOMPRESSED) {
            
			switch(eb->WantedAction[i]) {
			case AC_MOVE: 
				// Set the flag to indicate that the archive/container needs to be Quarantined
				// if the WantedAction is Quarantine for an infected file within an archive
				if (eb->pdfi->dwDepthOfFileToGet > 0)
				{
                    if ( bIsFileProtected )
                    {
                        // cannot Quarantine files under WFP on Windows 2000
	                    eb->pdfi->wResult = DECRESULT_UNCHANGED;
                        eb->RealAction = AC_BAD;
                    }
                    else
                    {
                        TCHAR szQuarPath[IMAX_PATH] = {0};
						if( !bIsFileProtected && GetQuarantineDir(szQuarPath) == ERROR_SUCCESS &&
                            access(szQuarPath,2) == 0 )
                        {
					      	eb->pdfi->bQuarantine = TRUE;
					        eb->RealAction = AC_MOVE;
                        }
                        else
                        {
                            // cannot Quarantine files if Quarantine directory
                            // is write-protected or does not exist
	                        eb->pdfi->wResult = DECRESULT_UNCHANGED;
                            eb->RealAction = AC_BAD;
                        }
                    }
				}
				break;

			case AC_DEL:
                if(eb->pdfi->bIsCompressed && eb->pdfi->dwDepthOfFileToGet > 0)
                {             
    			    // If we don't have permission to delete the file
			        // ( e.g. it is a subcomponent in a container that can't be updated)
			        // then make the RealAction == AC_BAD (since it cannot be deleted) or
			        // Otherwise, attempt to delete the file.
				    if (eb->pdfi->bCanDelete)
					{
                        if ( bIsFileProtected)
                        {
                            // cannot delete files under WFP on Windows 2000
	                        eb->pdfi->wResult = DECRESULT_UNCHANGED;
                            eb->RealAction = AC_BAD;
                        }
                        else
                        {
					        // Do not the delete the extracted temporary file, but assume that the
					        // decomposer will delete it (since eb->pdfi->wResult = DECRESULT_TO_BE_DELETED)
						    eb->RealAction = AC_DEL;
						    eb->pdfi->dwDeleted++;
    					    eb->pdfi->wResult  = DECRESULT_TO_BE_DELETED;
                        }
					}
				}

				break;

			case AC_NOTHING: 
				eb->RealAction = AC_NOTHING;
				break;

			case AC_REMOVE_MACROS:
                if(eb->pdfi->bIsCompressed && eb->pdfi->dwDepthOfFileToGet > 0)
                {
			        // If we don't have permission to modify the file
			        // (e.g. it is a subcomponent in a container that can't be updated)
			        // then make the RealAction == AC_BAD (since it cannot be repaired).  
			        // Otherwise, attempt to repair the file.
				    if (eb->pdfi->bCanModify)
				    {
                        if ( bIsFileProtected)
                        {
                            // cannot clean files under WFP on Windows 2000
	                        eb->pdfi->wResult = DECRESULT_UNCHANGED;
                            eb->RealAction = AC_BAD;
                        }
                        else
                        {
    					    // Clean the extracted temporary file, but indicate that the
	    				    // decomposer will finish it (since eb->pdfi->wResult = DECRESULT_CHANGED)
                            if((ret[i]=CleanInfection(eb,0))==ERROR_SUCCESS)
                            {
                                eb->RealAction = AC_CLEAN;
					            eb->pdfi->wResult  = DECRESULT_CHANGED;
					            eb->pdfi->dwCleaned++;
                            }
                        }
                    }
				}

				break;

			case AC_CLEAN:
                if(eb->pdfi->bIsCompressed && eb->pdfi->dwDepthOfFileToGet > 0)
                {
			    // If we don't have permission to modify the file
			    // (e.g. it is a subcomponent in a container that can't be updated)
			    // then make the RealAction == AC_BAD (since it cannot be repaired).  
			    // Otherwise, attempt to repair the file.
        			if (eb->pdfi->bCanModify)
				    {
                        if ( bIsFileProtected )
                        {
                            // cannot clean files under WFP on Windows 2000
	                        eb->pdfi->wResult = DECRESULT_UNCHANGED;
                            eb->RealAction = AC_BAD;
                        }
                        else
                        {

     					    // Clean the extracted temporary file, but indicate that the
	    				    // decomposer will finish it (since eb->pdfi->wResult = DECRESULT_CHANGED)
                            if((ret[i]=CleanInfection(eb,0))==ERROR_SUCCESS)
                            {
                                eb->RealAction = AC_CLEAN;
					            eb->pdfi->wResult  = DECRESULT_CHANGED;
					            eb->pdfi->dwCleaned++;
                            }
                        }
                    }
                }

				break;
            }   // End of switch eb->WantedAction[i]
		}
		else	// Process Uncompressed files 
        {
			switch(eb->WantedAction[i]) {
			case AC_MOVE:
                if(!bIsFileProtected && (ret[i]=MoveInfectedObject(eb, VBIN_INFECTED))==ERROR_SUCCESS)
                {
                    eb->RealAction = AC_MOVE;
                    eb->pdfi->bQuarantine = TRUE;       // This is to prevent the scanner (NAV_GLUE layer)
                                                        // from trying to identify if this file is
                                                        // a compressed file after it has been quarantined
                }
                break;

			case AC_DEL:
                if(!bIsFileProtected && (ret[i]=DeleteInfectedFile(eb))==ERROR_SUCCESS)
                {
                    eb->RealAction = AC_DEL;
                    eb->pdfi->bDelete = TRUE;           // This is to prevent the scanner (NAV_GLUE layer)
                                                        // from trying to identify if this file is
                                                        // a compressed file after it has been deleted
                }
                break;

			case AC_NOTHING: eb->RealAction = AC_NOTHING;
                break;

			case AC_REMOVE_MACROS:
                // Create a backup before attempting to repair, if the option to create backup 
                // is turned on in the scan options
                if( !bIsFileProtected && eb->pdfi->bBackupToQuarantine)
                {
                    if( ERROR_SUCCESS == CreateBackup(eb) )
                    {
                        // Save the backup ID
                        eb->dwBackupID = eb->VBinID;

                        if( (ret[i]=CleanInfection(eb, 0))==ERROR_SUCCESS)
                        {
                            eb->RealAction = AC_CLEAN;
                        }
                        else // clean failed
                        {
                            // Restore the original from the backup if the repair failed, 
                            // and a backup was successfully created.
                            // Restore does not delete the backup copy.
                            if(eb->pdfi->bBackupToQuarantine && eb->VBinID)
                                RestoreFromBackup(eb);
                        }
                    }                        
                }                    
                else    // Option to backup before repair is turned off.  Attempt to repair.
                {
                    if( !bIsFileProtected && (ret[i]=CleanInfection(eb, 0))==ERROR_SUCCESS)                  
                        eb->RealAction = AC_CLEAN;                                    
                }
                break;

            case AC_CLEAN:
                // Create a backup before attempting to repair, if the option to create backup 
                // is turned on in the scan options
                if( !bIsFileProtected && eb->pdfi->bBackupToQuarantine)
                {

                    if( ERROR_SUCCESS == CreateBackup(eb) )
                    {
                        // Save the Backup ID
                        eb->dwBackupID = eb->VBinID;

                        if( (ret[i]=CleanInfection(eb, 0))==ERROR_SUCCESS)
                        {
                            eb->RealAction = AC_CLEAN;
                        }
                        else // clean failed
                        {
                            // Restore the original from the backup if the repair failed, 
                            // and a backup was successfully created.
                            // Restore does not delete the backup copy.
                            if(eb->pdfi->bBackupToQuarantine && eb->VBinID)
                                RestoreFromBackup(eb);
                        }
                    }                        
                }                    
                else    // Option to backup before repair is turned off.  Attempt to repair.
                {
                    if( !bIsFileProtected && (ret[i]=CleanInfection(eb, 0))==ERROR_SUCCESS)                  
                        eb->RealAction = AC_CLEAN;                                    
                }
                break;
			}
        }
#else	// !WIN32
*/
		if (eb->VirusType&VEFILECOMPRESSED) {
			#ifndef NLM //EA 09/22
			eb->RealAction = AC_NOTHING;
			#else //EA 09/22
				switch(eb->WantedAction[i]){
				//we try and quarantine the whole zip file if needed EA 09/22
				//EA 08/19/2000 fix for STS 343807 we set FA_BEFORE_OPEN flag so that if quarantining is done succesfully we display access denied rathere than access allowed
				case AC_MOVE: eb->RealAction = (ret[i]=MoveInfectedObject(eb, VBIN_INFECTED))==ERROR_SUCCESS?AC_MOVE:AC_BAD;if( (!(eb->so->Node->Operations&FA_BEFORE_OPEN)) && (eb->RealAction == AC_MOVE) ){ eb->so->Node->Operations |= FA_BEFORE_OPEN;} break;
				case AC_NOTHING: eb->RealAction = AC_NOTHING; break;

				default:
				// Anything else we will just say we failed EA 08/28/2000
				eb->RealAction = AC_BAD;
				break;
	
				}
			#endif //EA 09/22
			
			}
		else switch(eb->WantedAction[i]) {
			//EA 08/19/2000 fix for STS 343807 we set FA_BEFORE_OPEN flag so that if quarantining is done succesfully we display access denied rathere than access allowed
			case AC_MOVE: eb->RealAction = (ret[i]=MoveInfectedObject(eb, VBIN_INFECTED))==ERROR_SUCCESS?AC_MOVE:AC_BAD; if( (!(eb->so->Node->Operations&FA_BEFORE_OPEN)) && (eb->RealAction == AC_MOVE) ){ eb->so->Node->Operations |= FA_BEFORE_OPEN;}break;
			//EA 08/19/2000 fix for STS 343807 we set FA_BEFORE_OPEN flag so that if deletion is done succesfully we display access denied rathere than access allowed
			case AC_DEL:eb->RealAction = (ret[i]=DeleteInfectedFile(eb))==ERROR_SUCCESS?AC_DEL:AC_BAD;if( (!(eb->so->Node->Operations&FA_BEFORE_OPEN)) && (eb->RealAction == AC_DEL) ){ eb->so->Node->Operations |= FA_BEFORE_OPEN;}break;
			case AC_NOTHING: eb->RealAction = AC_NOTHING;break;
			case AC_REMOVE_MACROS:eb->RealAction = (ret[i]=CleanInfection(eb,VEREMOVEALLMACROS))==ERROR_SUCCESS?AC_CLEAN:AC_BAD;break;
			case AC_CLEAN:eb->RealAction = (ret[i]=CleanInfection(eb,0))==ERROR_SUCCESS?AC_CLEAN:AC_BAD;break;
			}
//#endif // WIN32
		}

ActionsDone:

	dprintf("Actions for %s %u(%08X), %u(%08X), %u\n",eb->so->Node->Name,eb->WantedAction[0],ret[0],eb->WantedAction[0],ret[1],eb->RealAction);

	if (eb->RealAction == AC_BAD)
		eb->RealAction = AC_NOTHING;

	if ((eb->RealAction == AC_MOVE || eb->RealAction == AC_DEL) && !_GetVal(eb->hKey,"Testing",1)) {
		if (times < TimeOfLastInf+(_GetVal(eb->hKey,"TimeOfVirusSlot",60*1))) {
			if (NumVirusesInTime++ > _GetVal(eb->hKey,"MaxVirusesInSlot",5)) {
				//EVENTBLOCK log;
				//memset(&log,0,sizeof(log));
				eb->WantedAction[0] = AC_NOTHING;
				if ((eb->VirusType&VEFILEMACROVIRUS) == VEFILEMACROVIRUS)
					PutVal(eb->hKey[0],"FirstMacroAction",AC_NOTHING);
				else
					PutVal(eb->hKey[0],"FirstAction",AC_NOTHING);
				wsprintf(line,LS(IDS_TOO_MANY_VIRUSES1),
							//GetLoggerStr(str,eb->logger),
							LS(IDS_TOO_MANY_VIRUSES2),
							LS(IDS_TOO_MANY_VIRUSES3));
				//log.Description = line;
				//log.logger = eb->logger;
				//log.hKey[0] = eb->hKey[0];
				//log.Category = GL_CAT_SUMMARY;
				//log.Event = GL_EVENT_TOO_MANY_VIRUSES;
				//GlobalLog(&log);
				}
			}
		}
	else {
		TimeOfLastInf = times;
		NumVirusesInTime = 0;
		}

	return ERROR_SUCCESS;
}
/*******************************************************************/
BOOL isValidVirus(char *name) {

	if (name == NULL)
		return FALSE;

	if (*name == 0)
		return FALSE;

	while (*name) {
		if (*name != ' ')		//virus names always in english
			return TRUE;
		name++;
		}

	return FALSE;
}
/******************************************************************/
DWORD ActOnInfection(PEVENTBLOCK eb) {

	HKEY hkey=NULL;
	int i;
    DWORD ret = 0; 
/*
#ifdef WIN32
	char CName[NAME_SIZE];
#endif
*/
	if (eb->Time == 0)
		eb->Time = time(NULL);
		
	eb->hKey[1] = NULL;

	if (eb->Event == GL_EVENT_TRAP) {
		if (RegOpenKey(eb->hKey[0],"TrapConfig",&hkey) == ERROR_SUCCESS) {
			eb->hKey[1] = eb->hKey[0];
			eb->hKey[0] = hkey;
			}
		}
	else if (eb->Event == GL_EVENT_INFECTION) {
/*
#ifdef WIN32
		// Do not check for the virus name when performing the action on
		// containers with infected files.
        if ( !(eb->pdfi->bIsCompressed && eb->pdfi->dwDepthOfFileToGet == 0) )  {
		
			if (!isValidVirus(eb->VirusName))  {
				eb->ReturnCode = BAD_VIRUS_NAME;
				return 0;
				}
            }
        if ( !(eb->lpParent) ) {
             GetStr(hMainKey,"Parent",CName,sizeof(CName),"");
             if (*CName)
                eb->lpParent = CName;
            }
#else // !WIN32
*/
		if (!isValidVirus(eb->VirusName)) {
			eb->ReturnCode = BAD_VIRUS_NAME;
			return 0;
			}
//#endif
		}
	else {
		eb->ReturnCode = BAD_VIRUS_NAME;
		return 0;
		}

	eb->hKey[2] = 0;
/*
#ifdef WIN32
	if (eb->so) {

		if (eb->so->Flags & FA_SCANNING_FILE ) {  // Process File Exclusions

            if( (eb->so->Node->Flags & N_FILENODE) && !(eb->so->Node->Flags & N_RTSNODE) ) {  // Process File Exclusions for a Manual Scan

                // Do not check for file exclusions if Prescan exclusions is turned on.
		        if (!_GetVal(eb->hKey, szReg_Val_PrescanExclude, 0) ) {
        
                    // process specific file exclusions for a Manual Scan
                    if(_GetVal(eb->hKey, szReg_Val_ExceptionFiles, 1) && isNodeException(eb->hKey, szReg_Key_NoScanFiles, eb->so)) {
			            eb->ReturnCode = SKIP_INFECTION;

                        dprintf("Excluding Infected file %s since it is in the list of Excluded Files for Manual Scan\n", eb->so->FullKey);
                        
                        // stop processing the container if the container is included in FileExceptions.
                        if(eb->pdfi->bIsCompressed)
                            eb->pdfi->dwProcessFlags = DECINFO_STOP_PROCESS;

    			        goto done;  // The current infected file is excluded from reports and logs
                                    // because it is in the list of excluded files.

                        }   // end of processing File exclusions for a Manual Scan

                    // check for wild card exclusions for a Manual Scan
                    if(_GetVal(eb->hKey, szReg_Val_ExcludedByExtensions, 0)) {

                        // check for wild exclusions for infected files inside containers.
                        if(eb->pdfi->bIsCompressed)
                            {
                            if( (eb->pdfi->dwDepthOfFileToGet > 0) && isExtWanted(eb->so->block->ExcludedExtList, eb->pdfi->lpszExtractTempFile)) {
                                dprintf("Excluding Container %s with Infected file %s since the Container is in the list of Excluded Exts for Manual Scan\n", eb->so->FullKey, eb->pdfi->lpszFileToGet);
                                eb->ReturnCode = SKIP_INFECTION;
                                goto done;
                                }
                            }
                        else if (isExtWanted(eb->so->block->ExcludedExtList, eb->so->FullKey)) {
                            dprintf("Excluding Infected file %s since it is in the list of Excluded Exts for Manual Scan\n", eb->so->FullKey);
 			                eb->ReturnCode = SKIP_INFECTION;
    			            goto done;
                            } // The current infected file is excluded from reports and logs 
                              // because the file extension is in the list of excluded extensions.

                        } // end of processing exclusions by extension

                    }   // end of Prescan Exclude check

                }   // end of exclusion processing for a Manual Scan

            else { // All other types of Scanners, i.e. Real Time Protection, and Mail

                if( _GetVal(eb->hKey, szReg_Val_ExceptionFiles, 1) && isNodeException(eb->hKey, szReg_Key_NoScanFiles, eb->so) ) {
                    eb->ReturnCode = SKIP_INFECTION;
                    goto done;
                    }
                }   // done processing file exclusions

            
			}   // end of exclusion processing for all the Scanners (Manaul, Real Time Protection, and Mail)

		if (eb->Flags&FA_CLEAN_SCAN) {
			eb->WantedAction[0] = AC_CLEAN;
			eb->WantedAction[1] = AC_NOTHING;
			}
		else if ((eb->VirusType&VEFILEMACROVIRUS) == VEFILEMACROVIRUS) {
			if (eb->WantedAction[0] == 0)
				eb->WantedAction[0] = _GetVal(eb->hKey,"FirstMacroAction",AC_CLEAN);
			if (eb->WantedAction[1] == 0)
				eb->WantedAction[1] = _GetVal(eb->hKey,"SecondMacroAction",AC_MOVE);
			}
		else {  // begin Non Macro Viruses
                // Get the Wanted actions for Non-macro infected files or containers
			    if (eb->WantedAction[0] == 0)
				    eb->WantedAction[0] = _GetVal(eb->hKey,"FirstAction",AC_CLEAN);
			    if (eb->WantedAction[1] == 0)
				    eb->WantedAction[1] = _GetVal(eb->hKey,"SecondAction",AC_MOVE);
		    }  // end Non Macro Viruses for WIN32

            // Choose the actions for top-level containers to be AC_NOTHING 
            // (i.e. Leave Alone) since the containers will always be left 
            // alone unless they have to be Quarantined due to infected items. 
            // This is handled in ActOnEvent().
             if (eb->pdfi->bIsCompressed && 
                 eb->pdfi->dwDepthOfFileToGet == 0) {
 
                eb->WantedAction[0] = AC_NOTHING;
                eb->WantedAction[1] = AC_NOTHING;
            }

#else	// !WIN32
*/
	if (eb->so) {

		if ((eb->so->Flags&FA_SCANNING_FILE) && _GetVal(eb->hKey,"HaveExceptionFiles",1) && isNodeException(eb->hKey,"FileExceptions",eb->so)) {  // this still a problem
			eb->ReturnCode = SKIP_INFECTION;
            goto done;
            }

		if (eb->Flags&FA_CLEAN_SCAN) {
			eb->WantedAction[0] = AC_CLEAN;
			eb->WantedAction[1] = AC_NOTHING;
			}
		else if ((eb->VirusType&VEFILEMACROVIRUS) == VEFILEMACROVIRUS) {
			if (eb->WantedAction[0] == 0)
				eb->WantedAction[0] = _GetVal(eb->hKey,"FirstMacroAction",AC_CLEAN);
			if (eb->WantedAction[1] == 0)
				eb->WantedAction[1] = _GetVal(eb->hKey,"SecondMacroAction",AC_MOVE);
			}
		else {  // Non Macro Viruses
			if (eb->WantedAction[0] == 0)
				eb->WantedAction[0] = _GetVal(eb->hKey,"FirstAction",AC_NOTHING);
			if (eb->WantedAction[1] == 0)
				eb->WantedAction[1] = _GetVal(eb->hKey,"SecondAction",AC_NOTHING);
			}
//#endif

	//if ((eb->logger&0xffff) < LOGGER_LOCAL_END)
        {
            if (eb->so->Node->Operations & FA_COMING_FROM_NAVAP)
            {
                if ( eb->so->Flags&FA_SCANNING_BOOT_SECTOR )
                {
                    eb->WantedAction[0] = _GetVal(eb->hKey,szReg_Val_FloppyBRAction,AC_CLEAN);
                    eb->WantedAction[1] = AC_NOTHING;
                    ActOnEvent(eb);
                }
                else
                {
                    // This same functionality is being done above for AP
                    // it shouldn't be done again here.   This also doesn't account
                    // for macro viruses.
                    /*
                      if (eb->WantedAction[0] == 0)
			            eb->WantedAction[0] = _GetVal(eb->hKey,"FirstAction",AC_NOTHING);
		            
                      if (eb->WantedAction[1] == 0)
			            eb->WantedAction[1] = _GetVal(eb->hKey,"SecondAction",AC_NOTHING);
                    */

                    eb->RealAction = ((PFILE_ACTION)eb->so->Node->Context)->action;
/*
#ifndef NLM    //ML
                    if ( ((PFILE_ACTION)eb->so->Node->Context)->Process )
                    {
                        //  If we are here, this file is to be quarantined.  
                        // To determine if the action is quarantine or a backup to
                        // quarantine, the file_action structure has to be checked for
                        // the backup flag.
                        // The behavior of AP back to quarantine is as follows:
                        // if a file is repaired successfully, we will end up here
                        // and the file will be backed up in quarantine.  If the repair
                        // failed, we will never get here and AP will have already restored
                        // the original file.  We will never call RestoreFromBackup() for AP.
                        // This behavior is consistent with Atomic.

                        // MMENDON 04-11-2000:  STS defect #332943
                        //                      Turning on impersonation for AutoProtect.
                        //                      Creating duplicate security token, 
                        //                      so there is no conflict with the
                        //                      primary token.
#if defined(SERVER) && defined(WINNT)

                        HANDLE hDuplicateToken = 0;
                        BOOL bImpersonate = FALSE;
                    
                        if(hAccessToken)
                        {
                            if(DuplicateToken(hAccessToken, SecurityImpersonation, &hDuplicateToken))
                                bImpersonate = ImpersonateLoggedOnUser(hDuplicateToken);
                            if(!bImpersonate)
                                dprintf("AP Quarantine impersonation failed.\n");
                        }
#endif                  // MMENDON 04-11-2000:  End STS defect #332943

                        if(((PFILE_ACTION)eb->so->Node->Context)->Flags & FA_BACKUP_TO_QUARANTINE)
                        {
                            CreateBackup(eb);
                            // because this is a temp file and not the original, after the back up is done 
                            // the temp file needs to be deleted.
                            eb->so->Node->Functions->RemoveNode(eb->so->Node);

                            // Save the backup ID
                            eb->dwBackupID = eb->VBinID;
                        }
                        else
                        {
                            MoveInfectedObject(eb, VBIN_INFECTED);
                            eb->RealAction = AC_MOVE;
                            eb->pdfi->bQuarantine = TRUE;
                        }
                        // MMENDON 04-06-2000:  STS defect #332943
                        //                      Turning off impersonation for files coming from
                        //                      AP, and cleaning up handle.
#if defined(SERVER) && defined(WINNT)

                        if(bImpersonate && hDuplicateToken)
                        {
                            RevertToSelf();
                            CloseHandle(hDuplicateToken);
		                    hDuplicateToken = 0;
                        }
#endif                  // MMENDON 04-06-2000:  End STS defect #332943
                    }

#endif
*/
		        }
            }
            else
            {
		        ret = ActOnEvent(eb);
/*
#ifdef WIN32
                // No logging when creating a backup for a container
                if (ret == ERROR_CREATED_BACKUP_NOLOG ||
                    ret == ERROR_CREATE_BACKUP_FAILED)
                    goto done;
#endif
*/
            }
        }

		if ((eb->so->Node->Operations&FA_BEFORE_OPEN)&&(eb->so->Node->Flags&N_RTSNODE))
		{
			i = _GetVal(eb->hKey,"DenyAccess",1);

			if (i == 0)
				eb->ReturnCode = ALLOW_VIRUS_ACCESS;
			else if (i == 1)
				eb->ReturnCode = DENY_ACCESS;
			else if (i == 2)
				eb->ReturnCode = eb->RealAction==AC_CLEAN?ALLOW_VIRUS_ACCESS:DENY_ACCESS;

			if (eb->ReturnCode == DENY_ACCESS)
			{
				eb->Flags |= EB_ACCESS_DENIED;
			}
		}
		else
			eb->ReturnCode = ALLOW_VIRUS_ACCESS;
		
		}

    MakeSidFalse(eb->pSid);
/*
#ifdef WIN32

	if(eb->pdfi->bIsCompressed)
    {
        ret = LogInfectionInZip(eb);
    }
	else // For infected uncompressed files
#endif
*/
	{
		//LogNotifyQueueEvent(eb);
    	if (eb->so)
	    	eb->so->Node->Functions->NodeHasViruses(eb->so->Node,eb);
	}

done:

	//if (hkey)
	//	RegCloseKey(hkey);
	
/*
#ifdef WIN32
    if (ret == ERROR_CREATED_BACKUP_NOLOG || 
        ret == ERROR_CREATE_BACKUP_FAILED ||
        ret == ERROR_ADDZIPEVENT )
        return ret;
    else
#endif
*/
	    return 0;
}
/*****************************************************************************************************************************/

/*****************************************************************************************************************************/
/******************************************************************************/
DWORD GetVirusMessageReady(char *msgbuf, char *msgfmt, PEVENTBLOCK eb) {

#if defined _DEBUG
	if (!eb || !eb->so || !eb->so->Info || !eb->so->Info->Functions || !eb->so->Info->Functions->FormatMessage)
	{
		dprintf("eb is not fully defined!");
		// so what we deal with it!
	}
#endif
	if (eb->so == NULL || eb->so->Info->Functions->FormatMessage(msgbuf,msgfmt,eb) != ERROR_SUCCESS)
		StrNCopy(msgbuf,msgfmt,MAX_MESSAGE_SIZE);

	return FormatVirusMessage(msgbuf,msgbuf,eb);
}
/******************************************************************************/


#endif //0 




DWORD MakeLocationString(char *str,PEVENTBLOCK eb) {

	if (eb->Flags&N_MAILNODE) {
		StrCopy(str,LS(IDS_IN_MAIL));
		}
	else if (eb->RealAction == AC_MOVE || 
             eb->RealAction == AC_MOVE_CLEAN ||
             eb->RealAction == AC_MOVE_DEL ||
             eb->RealAction == AC_MOVE_NOTHING) {
		StrCopy(str,LS(IDS_IN_VBIN));
		}
	else if (eb->Flags&N_BOOTNODE) {
		StrCopy(str,LS(IDS_IN_BOOT));
		}
	else if (eb->Flags&N_MEMNODE) {
		StrCopy(str,LS(IDS_IN_MEM));
		}
	else if (eb->Flags&N_FILENODE) {
		char *q = StrRChar(eb->Description,'\\');
		if (q)
			*q = 0;
		StrCopy(str,eb->Description);
		if (q)
			*q = '\\';
		}
	else {
		StrCopy(str,"Unknown Storage");
		}
	return ERROR_SUCCESS;
}
DWORD MakeActionString(char *act,PEVENTBLOCK eb) {

	char *lock[10]= {0};
	int LockCount=0;
	int i;
	char *str;
	char *szFail,*szSuccess;
    char *szWanted[2];
    /*
#ifdef WIN32
    char *szContainerAction, *szRealAction;
    char szStillInfected[MAX_PATH] = {0};
#endif
*/

		str = "";

//#ifdef SERVER
		if (eb->Flags&N_MAILNODE)
			str = "";
		else
			str = (eb->Flags&FA_RTSSCAN)?((eb->Flags&EB_ACCESS_DENIED)?LS(IDS_ACCESS_BLK):LS(IDS_ACCESS_ALWD)):"";

//#endif
		szFail    = lock[LockCount++] = LSlock(IDS_ACT_FAILED);
		szSuccess = lock[LockCount++] = LSlock(IDS_ACT_SUCCESS);

        for(i=0; i<2; i++)
        {
            DWORD dwAction = IDS_ACT_UNDEFINED;

            switch(eb->WantedAction[i])
            {
                case AC_MOVE:
            		dwAction = IDS_ACT_MOVE;
                    break;
                case AC_NOTHING:
            		dwAction = IDS_ACT_NOTHING;
                    break;
                case AC_REMOVE_MACROS:
                case AC_CLEAN:
            		dwAction = IDS_ACT_CLEAN;
                    break;
                case AC_DEL:
            		dwAction = IDS_ACT_DEL;
                    break;
                default:
                    break;
            }

            szWanted[i] = lock[LockCount++] = LSlock(dwAction);
        }
/*
#ifdef WIN32
        //Handle the special case: a top-level container that contains infected items
        szContainerAction = lock[LockCount++] = LSlock(IDS_CONTAINER_COMPLETE);

        if( (eb->Category == GL_CAT_INFECTION) && 
             (eb->pdfi->bIsCompressed) &&
             (eb->pdfi->dwDepthOfFileToGet ==0)   )
        {
            if(eb->dwStillInfected) // Contains infections
            {
                //szStillInfected = lock[LockCount++] = LSlock(IDS_REMAINING_INFECTIONS);
                wsprintf(szStillInfected, LS(IDS_REMAINING_INFECTIONS), eb->dwStillInfected);
                //WSprintf(str, szStillInfected, eb->dwStillInfected);

                if(eb->RealAction == AC_MOVE)
                {
                    szRealAction = lock[LockCount++] = LSlock(IDS_ACT_MOVE);
                     WSprintf(act, "%s %s : %s", szRealAction, szSuccess, szStillInfected);
                }
                else
                    WSprintf(act, "%s %s : %s", szWanted[0], szSuccess, szStillInfected);

                str = "";
            }
            else    // No remaining infected files
    		    WSprintf(act,"%s %s", szContainerAction, szSuccess);
                
        }
        else if ( (eb->Category == GL_CAT_INFECTION) && 
                  (eb->pdfi->bIsCompressed) &&
                  (eb->pdfi->dwDepthOfFileToGet > 0)   )
        {       // For infected items inside containers
		    if (eb->WantedAction[0] == eb->RealAction || (eb->RealAction == AC_CLEAN && eb->WantedAction[0] == AC_REMOVE_MACROS))
			    WSprintf(act,"%s %s",szWanted[0],szSuccess);
		    else if (eb->WantedAction[1] == eb->RealAction || (eb->RealAction == AC_CLEAN && eb->WantedAction[1] == AC_REMOVE_MACROS))
			    WSprintf(act,"%s %s : %s %s ",szWanted[0],szFail,szWanted[1],szSuccess);
            else if((eb->WantedAction[0] == AC_CLEAN || eb->WantedAction[0] == AC_REMOVE_MACROS) && eb->RealAction == AC_MOVE_CLEAN)
            {
                szRealAction = lock[LockCount++] = LSlock(IDS_ACT_ZIP_MOVE);
                WSprintf(act,"%s %s : %s", szWanted[0], szSuccess, szRealAction);
            }
            else if(eb->WantedAction[0] == AC_DEL && eb->RealAction == AC_MOVE_DEL)
            {
                szRealAction = lock[LockCount++] = LSlock(IDS_ACT_ZIP_MOVE);
                WSprintf(act,"%s %s : %s", szWanted[0], szSuccess, szRealAction);
            }
            else if(eb->WantedAction[0] == AC_NOTHING && eb->RealAction == AC_MOVE_NOTHING)
            {
                szRealAction = lock[LockCount++] = LSlock(IDS_ACT_ZIP_MOVE);
                WSprintf(act,"%s %s : %s", szWanted[0], szSuccess, szRealAction);
            }
            else if( (eb->WantedAction[1] == AC_CLEAN || eb->WantedAction[1] == AC_REMOVE_MACROS) && eb->RealAction == AC_MOVE_CLEAN)
            {
                szRealAction = lock[LockCount++] = LSlock(IDS_ACT_ZIP_MOVE);
                WSprintf(act,"%s %s : %s %s :%s", szWanted[0], szFail, szWanted[1], szSuccess, szRealAction);
            }
            else if(eb->WantedAction[1] == AC_DEL && eb->RealAction == AC_MOVE_DEL)
            {
                szRealAction = lock[LockCount++] = LSlock(IDS_ACT_ZIP_MOVE);
                WSprintf(act,"%s %s : %s %s : %s", szWanted[0], szFail, szWanted[1], szSuccess,szRealAction);
            }
            else if(eb->WantedAction[1] == AC_NOTHING && eb->RealAction == AC_MOVE_NOTHING)
            {
                szRealAction = lock[LockCount++] = LSlock(IDS_ACT_ZIP_MOVE);
                WSprintf(act,"%s %s : %s %s : %s", szWanted[0], szFail, szWanted[1], szSuccess,szRealAction);
            }
            else
                WSprintf(act,"%s %s : %s %s ", szWanted[0], szFail, szWanted[1], szFail);
        }
        else    // For normal infected items
        {
#endif
*/
		if (eb->WantedAction[0] == eb->RealAction || (eb->RealAction == AC_CLEAN && eb->WantedAction[0] == AC_REMOVE_MACROS))
			WSprintf(act,/**/"%s %s : %s",szWanted[0],szSuccess,str);
		else if (eb->WantedAction[1] == eb->RealAction || (eb->RealAction == AC_CLEAN && eb->WantedAction[1] == AC_REMOVE_MACROS))
			WSprintf(act,/**/"%s %s : %s %s : %s",szWanted[0],szFail,szWanted[1],szSuccess,str);
		else
			WSprintf(act,/**/"%s %s : %s %s : %s",szWanted[0],szFail,szWanted[1],szFail,str);
/*
#ifdef WIN32
        }
#endif
*/
	for (i=0;i<=LockCount;i++)
		LSfree(lock[i]);

	return ERROR_SUCCESS;
}



DWORD FormatVirusMessage(char *msgbuf, char *msgfmt, PEVENTBLOCK eb) {

	char *p[10],*cp,buf[MAX_MESSAGE_SIZE];
//	char str1[64],str2[64];
	char act[128];
	//char log[128];
	char date[64];
	char location[IMAX_PATH];
	char ComputerName[NAME_SIZE];
	char UserName[NAME_SIZE];
	char VirusName[NAME_SIZE];
	int i;
	char *lock[10];
	int LockCount=0;
	int id=0;
//	VTIME vt;
	char status[64];    // This needs to be big enough to hold the largest
                        // status string in acta.str, after it's been
                        // formatted. Better leave some room for translated
                        // status strings.

//	char *q;

	if(!*msgfmt) {
		*msgbuf = '\0';
		return 1;
		}

	GetNames(eb->pSid,UserName,ComputerName);
	StrCopy(date,ctime((time_t*)&eb->Time));
	if (date[strlen(date)-1] == '\n')
		date[strlen(date)-1] = 0;
		
//	vt = vtime(eb->Time);
//	q = (char *)&vt;
//	wsprintf(date,"%02X%02X%02X%02X%02X%02X",q[0],q[1],q[2],q[3],q[4],q[5]);
/*
#ifdef WIN32

    if ( (eb->Category == GL_CAT_INFECTION) &&
         (eb->pdfi->bIsCompressed) && 
         (eb->pdfi->dwDepthOfFileToGet == 0))
    {
        if(eb->dwStillInfected)
        {
            wsprintf(status, LS(IDS_REMAINING_INFECTIONS), eb->dwStillInfected);
        }
        else
        {
            wsprintf(status, "%s", LS(IDS_NO_INFECTIONS) );
        }
    }
    else if (eb->RealAction == AC_CLEAN)
		StrCopy(status,LS(IDS_ACT_CLEAN));
	else if (eb->RealAction == AC_DEL)
		StrCopy(status,LS(IDS_DELETED));
	else
		StrCopy(status,LS(IDS_INFECTED));
#else
*/
	if (eb->RealAction == AC_CLEAN)
		StrCopy(status,LS(IDS_ACT_CLEAN));
	else if (eb->RealAction == AC_DEL)
		StrCopy(status,LS(IDS_DELETED));
	else
		StrCopy(status,LS(IDS_INFECTED));
//#endif

	StrNCopy(buf,msgfmt,MAX_MESSAGE_SIZE);
	cp = buf;
	for(i=0; i<10; i++)
		p[i] = "";
	i = 0;

	for(i=0;cp&&i<10;cp++) {
		cp = StrChar(cp,'~');
		if(!cp || !*cp)
			break;		// not found
		cp++;

		switch(*cp) {
			case 'c':case 'C':*cp = 's'; cp[-1] = '%';
				p[i++] = location;
				break;
			case 't':case 'T':*cp = 's'; cp[-1] = '%';
				p[i++] = date;
				break;
			case 'z':case 'Z':*cp = 's'; cp[-1] = '%';
				p[i++] = status;
				break;
			case 'b':case 'B':*cp = 's'; cp[-1] = '%';
				p[i++] = eb->so?eb->so->Info->Name:"";
				break;
			case 'S':case 's':*cp = 's'; cp[-1] = '%';
				p[i++] = ComputerName;
				break;
			case 'v':case 'V':*cp = 's'; cp[-1] = '%';
				WSprintf(VirusName,"%s%s",
						(lock[LockCount++] = LSlock(IDS_EVENT_VIRUS_NAME)),
						eb->VirusName);
				p[i++] = VirusName;
				break;
			case 'f':case 'F':*cp = 's';  cp[-1] = '%';
				if (eb->so)
					p[i++] = eb->so->Node->Name;
				else
					p[i++] = eb->Description;
				break;
			//case 'l':case 'L':*cp = 's'; cp[-1] = '%';
			//	p[i++] = log;
			//	break;
			case 'e':case 'E':*cp = 's';  cp[-1] = '%';
				switch (eb->Event) {
					case GL_EVENT_INFECTION : id = IDS_EVENT_INFECTION ; break;
					case GL_EVENT_TRAP      : id = IDS_EVENT_TRAP      ; break;
					}
				p[i++] = lock[LockCount++] = LSlock(id);
				break;
			case 'a':case 'A':*cp = 's'; cp[-1] = '%';
				p[i++] = act;
				break;
			case 'p':case 'P':*cp = 's'; cp[-1] = '%';
				p[i++] = eb->Description;
				break;
			case 'n':case 'N':*cp = 's'; cp[-1] = '%';
				p[i++] = UserName;
				break;
			case 'r':case 'R':*cp = 's'; cp[-1] = '%';
				if (eb->Access&FA_DELETE)      p[i++] = lock[LockCount++] = LSlock(IDS_DELETE);
				else if (eb->Access&FA_WRITE)  p[i++] = lock[LockCount++] = LSlock(IDS_WRITE);
				else if (eb->Access&FA_READ)   p[i++] = lock[LockCount++] = LSlock(IDS_READ);
				else if (eb->Access&FA_EXEC)   p[i++] = lock[LockCount++] = LSlock(IDS_EXEC);
				else	p[i++] = "";
				break;
			}
		}

	cp = buf;
	while(cp) {
		cp = StrChar(cp,'\\');
		if(!cp || !*cp)
			break;
		if (cp[1] == 'n') {
			memmove(cp,cp+1,NumBytes(cp+1)+1);
			cp[0] = '\n';
			}
		else if (cp[1] == '\\') {
			memmove(cp,cp+1,NumBytes(cp+1)+1);
			}
		cp=NextChar (cp);		//MLR fixed
		}
	MakeActionString(act,eb);
	MakeLocationString(location,eb);

	//GetFullLoggerStr(log,eb->logger);
	
/*
#ifdef WIN32
		_snprintf(msgbuf,MAX_MESSAGE_SIZE-1,buf,p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7],p[8],p[9]);
		msgbuf[MAX_MESSAGE_SIZE-1]=0;
#else
*/
	if (strlen(buf) + strlen(p[0]) + strlen(p[1]) + strlen(p[2]) + strlen(p[3]) + strlen(p[4]) +
		strlen(p[5]) + strlen(p[6]) + strlen(p[7]) + strlen(p[8]) + strlen(p[9]) > MAX_MESSAGE_SIZE) {
		StrCopy(msgbuf,"STRING OVERFLOW");
		}
	else
		Sprintf(msgbuf,buf,p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7],p[8],p[9]);
//#endif

	for (i=0;i<LockCount;i++)
		LSfree(lock[i]);

	return ERROR_SUCCESS;
}


/******************************************************************************/

PEVENTBLOCK HeadEvent = NULL;
HANDLE hSemEvent;


/**
#ifdef WIN32
typedef struct {
	char filename[IMAX_PATH];
	HANDLE han;
	DWORD (*Infection)(PEVENTBLOCK);
	} EXTENDER;

EXTENDER Extenders[10];
BOOL ExtendersUp=FALSE;
DWORD LastTimeExtenderUsed=0;
/******************************************************************************
DWORD LoadExtenders(void) {

	HKEY hkey;
	DWORD index=0;
	char key[32];
	DWORD use=0;
	HKEY hekey;
	char str[128];

	memset(Extenders,0,sizeof(Extenders));


	if (RegOpenKey(hMainKey,"ActionExtenders",&hkey) == ERROR_SUCCESS) 
    {
		while (RegEnumKey(hkey,index++,key,sizeof(key)) == ERROR_SUCCESS) 
        {
			if (RegOpenKey(hkey,key,&hekey) == ERROR_SUCCESS) 
            {
#if defined SERVER
				if (!GetVal(hekey,"ServiceHooks",1))
#elif defined CLISCAN
				if (!GetVal(hekey,"ClientHooks",0))
#endif
				{
					RegCloseKey(hekey);
					continue;
				}

				WSprintf(Extenders[use].filename,"%s\\%s",HomeDir,key);
				Extenders[use].han = LoadLibrary(Extenders[use].filename);
				if (Extenders[use].han != NULL) 
                {
					GetStr(hekey,"InfectionProcName",str,sizeof(str),"");
					if (*str)
						Extenders[use].Infection = (DWORD (*)(PEVENTBLOCK))GetProcAddress(Extenders[use].han,str);
					else
						Extenders[use].Infection = (DWORD (*)(PEVENTBLOCK))GetProcAddress(Extenders[use].han,(LPCSTR)GetVal(hekey,"InfectionProcOrdnal",0));

					if (Extenders[use].Infection) 
                    {
						use++;
					}
					else 
                    {
						FreeLibrary(Extenders[use].han);
						memset(&Extenders[use],0,sizeof(EXTENDER));
					}
				}
				RegCloseKey(hekey);
			}
		}
		RegCloseKey(hkey);
	}

	ExtendersUp = TRUE;
	return ERROR_SUCCESS;
}
/******************************************************************************
DWORD UnLoadExtenders(void) {

	int i;

	for (i=0;i<10;i++) {
		if (Extenders[i].han)
			FreeLibrary(Extenders[i].han);
		memset(&Extenders[i],0,sizeof(EXTENDER));
		}

	ExtendersUp = FALSE;
	return ERROR_SUCCESS;
}
#endif // WIN32
*/


/******************************************************************************/

void EventThread(void *nothing) 
{
	PEVENTBLOCK cur,next;
	int i;
	BOOL BadMom;

//#ifdef SERVER
	char CName[NAME_SIZE];
//#endif

	REF(nothing);
	
	// ksr
	//hSemEvent = NTxSemaCreate(0,NULL);
	hSemEvent = OpenLocalSemaphore( 0 );

//#ifdef NLM
    EventThreadRunning = TRUE;
//#endif

//#ifdef SERVER
/* ksr   Transport not needed ????
	for (i=0;i<10&&!TransportSystemOK;i++)  // give transport 10 sec to come up after that give up.
		NTxSleep(1000);
		*/
//#endif

	while( SystemRunning ) 
   {
    /**
#ifdef WIN32	// using WIN32 API for WIN32 which is what NTS would have provided.
		if (hSemEvent != 0)
			WaitForSingleObject(hSemEvent,1000);
#else */
		// ksr
		//NTsSemaTimedWait(&hSemEvent,1000);
		TimedWaitOnLocalSemaphore( hSemEvent, 1000 );
//#endif
		if( SystemRunning ) 
		{
			LOCK();
			cur = HeadEvent;                // pick up the current block of events
			HeadEvent = NULL;
			UNLOCK();
			BadMom=FALSE;
			while( cur ) 
         {
				next = cur->Next;

            // double check that the system is still up - it may well not be, time is passing
            // and things change, especially after I have already sent the first  event and 
            // am working on the next one
            if( SystemRunning )
            {
            	// ksr ????   
			   	//if (GetVal(hMainKey,"Type",0))
				 		cur->Flags |= EB_FROM_CLIENT;

			    	//if (cur->Flags&EB_LOG) 
               //{
//#ifdef SERVER
                    // check SystemRunning again so I don't try anything
                    // time consuming
					    
					    /* ksr   SendCOM_FORWARD_LOG needed ???
					    if( !BadMom && SystemRunning && 
	                         //(_GetVal(cur->hKey,/** /"ForwardLogs",1) ||
					         //(_GetVal(cur->hKey,/** /"ForwardScanLogs",1) &&
					         (cur->Event == GL_EVENT_SCAN_START || 
	                          cur->Event == GL_EVENT_SCAN_STOP  || 
	                          cur->Event == GL_EVENT_SCAN_ABORT ||
	                          cur->Event == GL_EVENT_INFECTION ) )  //) ) 
	                {
					        //GetStr(hMainKey,"Parent",CName,sizeof(CName),"");
					        if (*CName)
	                        {
					            if (SendCOM_FORWARD_LOG(CName,cur) != ERROR_SUCCESS)
						            BadMom = TRUE;
	                        }
					    }
	                */
	                    // Adding this check so that we don't send AMS alerts on secondary servers with AMS
	                    // installed.  Without this "AMS" check, when you change primary servers, the
	                    // secondary servers would still perform AMS actions.
					    //if (_GetVal(cur->hKey,/**/"AMS",0))  
					    //if (_GetVal(cur->hKey,/**/"AMSonLogEvents",1))
					    
					    /** ksr AMS ???
  	                {
                        if ( IsAmsActive( TRUE ) )          // Check value, and load if settings changed.
                            AMSSendAlert(cur);
                    }
                    */
//#endif
            // }
			   // else 
             {
				    //if (_GetVal(cur->hKey,/**/"MessageBox",1))
					    StartBox(cur);  // ???
					    
//#ifdef SERVER
				  if( SystemRunning //&& _GetVal(cur->hKey,"SendReport",0)
											) 
              {
					    //CBA_Addr address;
					    //GetData(cur->hKey[1]?cur->hKey[1]:cur->hKey[0],"ReportAddress",&address,sizeof(address),NULL,NULL);
					    cur->Flags |= EB_REPORT;
					    //SendCOM_VIRUS_FOUND((char *)&address,cur);
					    cur->Flags &= ~EB_REPORT;
					}
/**
#ifdef WIN32
					if (SystemRunning && cur->Flags&FA_RTSSCAN) 
                    {
					    NotifyRTSViewers(cur);
					}
#endif
*/
					/** ksr   AMS ???
					if (SystemRunning //&& _GetVal(cur->hKey,/** /"AMS",0)
					)
                    {
                        if ( IsAmsActive( TRUE ) )     // Check value, and load if settings changed.
                            AMSSendAlert(cur);
                    }
              */

					/* SendVirusAlert ???  ksr
					if (SystemRunning && !BadMom //&& _GetVal(cur->hKey,/** /"AlertParent",1)
					      )
                    {
					    if (SendVirusAlert(cur) != ERROR_SUCCESS)
						    BadMom = TRUE;
                    }
               */
//#endif
/*
#ifdef CLISCAN
					if (SystemRunning && _GetVal(cur->hKey,/** /"AlertParent",1))
					    SendVirusAlertIPC(cur);

#endif
*/
/**
#ifdef WIN32
					if (SystemRunning && GetVal(hMainKey,"AdministratorOnly\\General\\RunBrowser",0)) 
              {
					    char str[IMAX_PATH];
					    ShellExecute(NULL,NULL,GetStr(hMainKey,"AdministratorOnly\\General\\URL",str,sizeof(str),"http://www.intel.com"),NULL,"",SW_SHOWNORMAL);
					}

					if (SystemRunning && _GetVal(cur->hKey,"HaveExtenders",0)) 
              {
					    if (!ExtendersUp)
						    LoadExtenders();

					    for (i=0;i<10;i++)
                  {
						    if (Extenders[i].Infection)
							    Extenders[i].Infection(cur);
                        }

					    LastTimeExtenderUsed = time(NULL);
					}
#endif // WIN32
*/
				}
			}
			DestroyCopyOfEvent(cur);
			cur = next;
			// ksr ???
			//ThreadSwitch();
		}
	}
	else 
    { // system has shutdown, check queue and empty it.
		LOCK();
		cur = HeadEvent;
		HeadEvent = NULL;
		UNLOCK();
		BadMom=FALSE;
		while (cur) 
      {
			next = cur->Next;
			DestroyCopyOfEvent(cur);
			cur = next;
		}
	}
	
		/*
#ifdef WIN32
		if (ExtendersUp && time(NULL)-LastTimeExtenderUsed > 60*60)
			UnLoadExtenders();
#endif // WIN32
*/
	}	
	/*
#ifdef WIN32
	UnLoadExtenders();
#endif // WIN32

#ifdef NLM
*/
	//The following block was added by EA and BNM to clean up the event queue
	//when we shutdown before emptying the whole list. This will prevent memory leak
	//which causes the error message "rtvscan has ## unreleased resources" on NetWare
	//servers. This was causing PAL memory certification test to fail at Novell.
	LOCK();
	cur = HeadEvent;
	HeadEvent = NULL;
	UNLOCK();
	BadMom=FALSE;
	while (cur) 
   {
		next = cur->Next;
		DestroyCopyOfEvent(cur);
		cur = next;
		// ksr ???
		//ThreadSwitch();
	}

    EventThreadRunning = FALSE;
//#endif

	// 4/20/00 CLB - We've updated to the new Maple code so we don't need to have this
	// #ifdef any more...both platforms NTxSemaClose take a handle, not a pointer-to-a-handle.

//#ifdef NLM    
    // ksr
    // now in NAVCleanUp
    // NTxSemaClose(&hSemEvent); 
    // CloseLocalSemaphore( hSemEvent );
    
//#else
    // With the Maple library version this takes a HANDLE not a HANDLE *.
    // 2/15/2000 jon allee
    //NTxSemaClose(hSemEvent);
//#endif
}


/******************************************************************************/

DWORD QueueEvent(PEVENTBLOCK eb) 
{
// we don't want to insert this event into the queus until after we know 
// the system is still running otherwise we may try to free it twice and abend
	
	if( !SystemRunning ) 
	{
		DestroyCopyOfEvent( eb );
		return ERROR_SUCCESS;
	}

	LOCK(); 
	eb->Next = HeadEvent; 
	HeadEvent = eb;
	UNLOCK();

	if( hSemEvent )
/*
#ifdef CLISCAN
		// using WIN32 API to remove CLISCAN's dependency on NTS.LIB
		ReleaseSemaphore(hSemEvent, 1, NULL);
#else
*/
		// ksr
		//NTsSemaSignal(&hSemEvent);
		SignalLocalSemaphore( hSemEvent );
//#endif

	else 
	{
		MyBeginThread( EventThread,NULL, "RTV Do Events" );
		NTxSleep(50);
/*
#ifdef CLISCAN
		// using WIN32 API to remove CLISCAN's dependency on NTS.LIB
		ReleaseSemaphore(hSemEvent, 1, NULL);
#else
*/
		// ksr
		//NTsSemaSignal(&hSemEvent);
		SignalLocalSemaphore( hSemEvent );
//#endif
		}

	return ERROR_SUCCESS;
}



#if 0



///////////////////////////////////////////////////////////////////////////////
//
// Function name: CreateBackup
//
// Description  : Creates a backup copy of a file in Quarantine.  
//
// Return type  : DWORD - ERROR_SUCCESS if a backup is successfully created.
//
///////////////////////////////////////////////////////////////////////////////
// 6/10/99 - RCHINTA: Created a Stub to be implemented later
// 6/23/99 - TCASHIN: Hooked up the stub to the quarantine functions.
///////////////////////////////////////////////////////////////////////////////
DWORD CreateBackup(PEVENTBLOCK eb)
{
    DWORD       dwRetValue = ERROR_SUCCESS;
    char        line[MAX_PATH+100];
    //EVENTBLOCK  log = {0};

    dwRetValue = MoveInfectedObject(eb, VBIN_BACKUP);

    if ( dwRetValue != ERROR_SUCCESS )
    {
        // Write a log record saying we are unable to create a backup.
        TCHAR szQuarPath[IMAX_PATH] = {0};

        // Determine if the failure is due to the absence of a Quarantine
        // directory or due to the Quarantine directory being write-protected or
        // for some other reason.
        if( GetQuarantineDir(szQuarPath) == ERROR_SUCCESS &&
            access(szQuarPath,2) != 0 )
        {
            wsprintf(line, LS(IDS_ERROR_ACCESS_QUAR_DIR), eb->Description);
        }
        else
            wsprintf(line,LS(IDS_ERROR_CREATING_BACKUP), eb->Description);

        dprintf(line);
			/*
        log.Description = line;
        log.logger = eb->logger;
        log.hKey[0] = eb->hKey[0];
        log.Category = GL_CAT_SUMMARY;
        log.Event = GL_EVENT_BACKUP;
        GlobalLog(&log);
        */
    }

    return dwRetValue;

}


///////////////////////////////////////////////////////////////////////////////
//
// Function name: RestoreFromBackup
//
// Description  : Restores the orginal from the backup copy saved in Quarantine.  
//
// Return type  : DWORD - ERROR_SUCCESS if a backup is successfully restored.
//
///////////////////////////////////////////////////////////////////////////////
// 6/10/99 - RCHINTA: Created a Stub to be implemented later
// 6/23/99 - TCASHIN: Hooked up the stub to the quarantine functions.
///////////////////////////////////////////////////////////////////////////////
DWORD RestoreFromBackup(PEVENTBLOCK pEventBlk)
{
    DWORD       dwRetValue = ERROR_SUCCESS;
    char        line[MAX_PATH+100];
    //EVENTBLOCK  log = {0};
    

	// if this is an email storage obj
	if (pEventBlk->so->Info->Type & IT_MAIL)
		// restore the file using the internal (i.e. temp) filename
	    dwRetValue = VBin_Extract( pEventBlk->VBinID, pEventBlk->so->Node->InternalPath, FALSE );
	else // else restore using the filename stored in the header of the vbin file
		dwRetValue = VBin_Extract( pEventBlk->VBinID, NULL, FALSE );

    if ( dwRetValue != ERROR_SUCCESS )
    {
        // Write a log record saying we're unable to restore after the clean failed.
        wsprintf(line,LS(IDS_ERROR_RESTORING_BACKUP),pEventBlk->Description);

        dprintf(line);
			/*
        log.Description = line;
        log.logger = pEventBlk->logger;
        log.hKey[0] = pEventBlk->hKey[0];
        log.Category = GL_CAT_SUMMARY;
        log.Event = GL_EVENT_BACKUP;
        GlobalLog(&log);*/
    }

    return dwRetValue;
}

/*
#ifdef WIN32
///////////////////////////////////////////////////////////////////////////////
//
// Function name: AddZipEvent
//
// Description  : Creates a copy of the event block to add to the list of event
//                blocks that is used to keep track of infected items inside
//                containers.  
//
// Return type  : DWORD - ERROR_SUCCESS copy of event block was successfully created.
//
///////////////////////////////////////////////////////////////////////////////
// 11/10/2000 - RCHINTA: Created
///////////////////////////////////////////////////////////////////////////////
DWORD AddZipEvent(PEVENTBLOCK eb) {

	PEVENTBLOCK cur = NULL;
    DWORD dwRet = ERROR_SUCCESS;

#ifdef _DEBUG
    if(GetVal(hMainKey, _T("ProductControl\\SimulateOutOfMemory"), 0) == 1)
    {
        // Currently, when this error is encountered the scanning of the container
        // will be stopped and the log will indicate that the file was ommitted 
        // and reports the number of infections but no details about the infection.
        // More sophisticated mechanisms of handling memory errors can be used if
        // necessary.
        dprintf("Simulated Out of memory error\n");
        dwRet = ERROR_MEMORY;
        goto Done;
    }
#endif

	dwRet = CreateCopyOfEvent(eb, &cur);
	if(dwRet == ERROR_SUCCESS )
	{
		cur->Next = eb->so->block->ZipHeadEvent; 
		eb->so->block->ZipHeadEvent = cur;
	}
	
Done:
	return dwRet;
}

///////////////////////////////////////////////////////////////////////////////
//
// Function name: LogInfectionInZip
//
// Description  : Logs the information related to infected items inside containers.  
//                Instead of logging the information for the infected item when
//                it is detected, the information for each infected item is
//                added to a list.  After completely scanning and processing the 
//                container the list is traversed and the information is logged.
//                This will ensure that the results for the infected items inside
//                containers will be accurate (i.e. success or failure of incorporating 
//                the changes to the infected items or Quarantine of the container etc).
//
// Return type  : DWORD - ERROR_SUCCESS if logging is successfull.
//
///////////////////////////////////////////////////////////////////////////////
// 11/10/2000 - RCHINTA: Created 
///////////////////////////////////////////////////////////////////////////////
// Special Handling for infections inside a container
DWORD LogInfectionInZip(PEVENTBLOCK eb)
{
    DWORD dwRet = ERROR_SUCCESS;

    // For infected items inside containers, add to a ZipEventBlock list 
    // to process later (i.e. after the scanning all the items in the container)
	if(eb->pdfi->dwDepthOfFileToGet > 0)
	{
        dwRet = AddZipEvent(eb);

		if( ERROR_SUCCESS != dwRet )
        {
            // AddZipEvent() fails due to (memory) errors (currently).
            eb->pdfi->dwProcessFlags = DECINFO_ERROR_ADDZIPEVENT;
            dwRet = ERROR_ADDZIPEVENT;
        }
         
	}
    else    // Handle logging of events for the top-level container along
	{       // with the results of any infected items inside the container.
		PEVENTBLOCK curEb, last;

        // Iterate through the list of event blocks for
        // each infected item inside the container.			
		curEb = eb->so->block->ZipHeadEvent;
		while(curEb)
		{		
			dprintf("Unwinding Container results: %s\n", curEb->Description);

            // Did the decomposer processing result in a modified file?
            if (  !(eb->pdfi->wResult == DECRESULT_CHANGED ||
                    eb->pdfi->wResult == DECRESULT_TO_BE_REPLACED) )
            {
                if(curEb->RealAction == AC_CLEAN || curEb->RealAction == AC_DEL)
                    curEb->RealAction = AC_NOTHING;
 		    }

            // if the top-level container has been Quarantined, change the
            // Real Action of the infected item to reflect the actions
            // taken (cleaned/deleted/left alone and quarantined)
            if(eb->pdfi->bQuarantine)
            {
                switch(curEb->RealAction)
                {
                    case AC_CLEAN:
                        // Was the container Quarantined with the cleaned file?
                        if(eb->RealAction == AC_MOVE)
                        {
                            // The container was Quarantined (due to some other
                            // infected item(s)).
                            curEb->RealAction = AC_MOVE_CLEAN;
                        }
                        else
                        {
                            // The infected item was cleaned and the container 
                            // was not Quarantined.
                            curEb->RealAction = AC_CLEAN;
                        }

                        break;

                    case AC_DEL:
                        // Was the container Quarantined with the deleted file?
                        if(eb->RealAction == AC_MOVE)
                        {
                            // The container was Quarantined (due to some other
                            // infected item(s)).
                            curEb->RealAction = AC_MOVE_DEL;
                        }
                        else
                        {
                            // The infected item was deleted and the container 
                            // was not Quarantined.
                            curEb->RealAction = AC_DEL;
                        }
                        break;

                    case AC_MOVE:
                        if(eb->RealAction == AC_MOVE)
                            curEb->RealAction = AC_MOVE;
                        else
                            curEb->RealAction = AC_NOTHING;

                        break;

                    case AC_NOTHING:
                    case AC_BAD:
                    default:

                        if(eb->RealAction == AC_MOVE)
                            curEb->RealAction = AC_MOVE_NOTHING;
                        else
                            curEb->RealAction = AC_NOTHING;
                }

            }
            // Now, log the results for the current infected item inside
            // the container
			LogNotifyQueueEvent(curEb);


            // This call was specifically postponed for infected items inside
            // containers (in Callback()) to be handled here.
			if(eb->so->block->cbVirus)
				eb->so->block->cbVirus(eb->so->block, curEb);

            // used by mail scanners 
            if (eb->so)
		        eb->so->Node->Functions->NodeHasViruses(eb->so->Node, curEb);
			
			last = curEb;

			curEb = curEb->Next;

            // Destroy the copy of the event block in the list for the current
            // infected item.
			DestroyCopyOfEvent(last);
		}

		eb->so->block->ZipHeadEvent = NULL;

        if(eb->pdfi->dwProcessFlags == DECINFO_ERROR_ADDZIPEVENT)
        {
            // Add another log line to indicate that the container was not fully
            // scanned due to memory errors
            char line[MAX_PATH + 100] = "";
            EVENTBLOCK log = {0};

            wsprintf(line,LS(IDS_ERROR_ADDZIPEVENT),eb->Description);

            dprintf(line);

            log.Description = line;
            log.logger = eb->logger;
            log.hKey[0] = eb->hKey[0];
            log.Category = GL_CAT_SUMMARY;
            log.Event = GL_EVENT_FILE_NOT_OPEN; // TODO: Is this an appropriate category?
            GlobalLog(&log);
        }

		// Log the results for the top level container
		LogNotifyQueueEvent(eb);

        // This call was specifically postponed for containers (in Callback()) to
        // be handled here.
		if(eb->so->block->cbVirus)
			eb->so->block->cbVirus(eb->so->block, eb);

        // used for mail nodes
        if (eb->so)
		    eb->so->Node->Functions->NodeHasViruses(eb->so->Node,eb);

	}
    
    return dwRet;

}

#endif
*/

///////////////////////////////////////////////////////////////////////////////
//
// Function name: LogNotifyQueueEvent
//
// Description  : Handles all the logging and reporting related activity for 
//                infections. 
//
// Return type  : DWORD - ERROR_SUCCESS if a backup is successfully restored.
//
///////////////////////////////////////////////////////////////////////////////
// 11/10/2000 - RCHINTA: Created this function to reuse the code.
///////////////////////////////////////////////////////////////////////////////
/*
DWORD LogNotifyQueueEvent(PEVENTBLOCK eb)
{
	PEVENTBLOCK cur;
    DWORD dwRet = ERROR_SUCCESS;

	LogEngine(eb);

    dwRet = CreateCopyOfEvent(eb,&cur);

	if ( dwRet == ERROR_SUCCESS) 
	{
		if (_GetVal(eb->hKey,/** /"MessageBox",1)) 
		{
			cur->Special = (DWORD)malloc(MAX_MESSAGE_SIZE);

			if (cur->Special) 
			{
				char tmp[MAX_MESSAGE_SIZE];
				GetVirusMessageReady((char *)cur->Special,_GetStr(eb->hKey,/** /"MessageText",tmp,sizeof(tmp),LS(IDS_DEF_FORMAT)),eb);
			}
		}

		QueueEvent(cur);
	}
    
    return dwRet;

}
*/
#endif // 0



