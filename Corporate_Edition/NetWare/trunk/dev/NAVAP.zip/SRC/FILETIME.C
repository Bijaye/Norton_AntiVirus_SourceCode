//------------------------------------------------------------------------------
//
//      FileTime.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////////
//
// filetime.cpp - This file contains functions for saving and restoring
//                file time data for all platforms.
//
//                This code was ported to the NAVCORP code base from
//                Odyssey and added the NLM platform.
//
//////////////////////////////////////////////////////////////////////////

//#include <tchar.h>
#include "filetime.h"


//////////////////////////////////////////////////////////////////////////
// Local function prototypes
//////////////////////////////////////////////////////////////////////////
/*
#ifdef WIN32
BOOL GetLastAccessDateNT ( LPCTSTR szFileName, FILETIME *lpFileTime );
BOOL MyIsWinNT();
#endif // WIN32


//////////////////////////////////////////////////////////////////////////
//
// Function:    IsWinNT()
//
// Description:
//
// Determines if the current platform is Windows NT. This is local to this
// file to avoid build issues with various projects.
//
//////////////////////////////////////////////////////////////////////////
#ifdef WIN32
BOOL MyIsWinNT( void )
{
    OSVERSIONINFO os;
    os.dwOSVersionInfoSize = sizeof( OSVERSIONINFO );
    GetVersionEx( &os );
    return (BOOL)( os.dwPlatformId == VER_PLATFORM_WIN32_NT );
}
#endif
*/

//////////////////////////////////////////////////////////////////////////
//
// Function:    SaveLastAccessTime()
//
// Description:
//
//  Stores a file's last-accessed date/time stamp so it can be
//  restored after we do whatever it needs to do with the file.
//
// Input:
//
//  lpszFileName: [in] Full path to the file
//  prTimeInfo: [out] Info used by RestoreLastAccessTime() later on.
//
// Returns:
//
//  Nothing - All meaningful info is returned in the parameters.
//
// Notes:
//
//  The caller can call RestoreLastAccessTime() without having to check
//  whether this fn succeeded.
//
//  If the caller calls RestoreLastAccessTime(), the filespec and NONAV
//  struct *must* be at the same locations as when this fn is called.
//  If not, the caller will have to change the FILETIMEDATA struct members 
//  to the correct values.
//
//////////////////////////////////////////////////////////////////////////
// 1/14/98 Mike Dunn -- function created
// 6/7/00  TCashin - ported from Odyssey
//////////////////////////////////////////////////////////////////////////

void SaveLastAccessTime ( LPTSTR lpszFileName, LPFILETIMEDATA prTimeInfo )
{
/**
#ifdef WIN32

    HANDLE hFile = NULL;


    // Check for valid parameters
    if ( !prTimeInfo || !lpszFileName )
        return;

    // Init struct values
    prTimeInfo->bMustChangeAttrs = FALSE;
    prTimeInfo->bLastAccessTimeSaved = FALSE;
    prTimeInfo->lpszFilespec = lpszFileName;

                                        // First get the file's last-accessed
                                        // date & time.
                                        // If this fails, then we'll bail
                                        // out silently because there are more
                                        // important things in life to worry
                                        // about, like viruses.

    if ( MyIsWinNT() )
    {
        if ( GetLastAccessDateNT ( lpszFileName,
                                   &prTimeInfo->ftimeLastAccessTime ) )
        {
            prTimeInfo->bLastAccessTimeSaved = TRUE;
        }
    }
    else
    {
                                        // On 95 we need an open file handle...

        hFile = CreateFile( lpszFileName, 
                            GENERIC_READ, 
                            FILE_SHARE_READ, 
                            NULL, 
                            OPEN_EXISTING,
                            FILE_ATTRIBUTE_READONLY, 
                            NULL);
          
        if ( INVALID_HANDLE_VALUE != hFile )
        {
            prTimeInfo->bLastAccessTimeSaved =
                GetFileTime ( hFile, NULL, &prTimeInfo->ftimeLastAccessTime, NULL );

            CloseHandle ( hFile );
        }
    }

                                        // Now read in the file's attributes.
                                        // If this fails, then *pbMustChangeAttrs
                                        // remains FALSE.

    if ( prTimeInfo->bLastAccessTimeSaved )
    {
        DWORD dwAttributes = 0;
                                        // Only check the attrs if we were
                                        // able to get the last accessed
                                        // date earlier.

        dwAttributes = GetFileAttributes( lpszFileName );

        if ( dwAttributes != 0xFFFFFFFF )
        {
            prTimeInfo->uFileAttrs = dwAttributes;

            prTimeInfo->bMustChangeAttrs =
                ( (prTimeInfo->uFileAttrs) & FILE_ATTRIBUTE_READONLY ) ? TRUE : FALSE;
        }
    }

#else // end WIN32 ... begin NLM
**/

    // Check for valid parameters
    if ( !prTimeInfo || !lpszFileName )
        return;

    // Init struct values
    prTimeInfo->bLastAccessTimeSaved = FALSE;
    prTimeInfo->lpszFilespec = lpszFileName;

    // Get the stat data for the file
    if ( stat(lpszFileName, &prTimeInfo->file_stat_buffer) == 0 )
    {
        prTimeInfo->bLastAccessTimeSaved = TRUE;
    }
    
    return;

//#endif // WIN32
}


//////////////////////////////////////////////////////////////////////////
//
// Function:    RestoreLastAccessTime()
//
// Description:
//
//  Restores a file's last-accessed date/time stamp that had earlier been
//  saved by SaveLastAccessTime().
//
// Input:
//
//  prTimeInfo: [in] Info saved during SaveLastAccessTime().
//
// Returns:
//
//  Nothing - We can't do anything meaningful if this function fails anyway.
//
// Note:
//
//  It's up to the caller to make sure that the LASTACCESSTIMEINFO struct
//  was set by a matched call to SaveLastAccessTime().
//
//  This fn assumes that the caller is done using the file (for the
//  time being at least) and has NO more open handles on the file.
//
//  See also notes for SaveLastAccessTime().
//
//////////////////////////////////////////////////////////////////////////
// 1/14/98 Mike Dunn -- function created
// 6/7/00  TCashin - ported from Odyssey
//////////////////////////////////////////////////////////////////////////


void RestoreLastAccessTime ( LPFILETIMEDATA prTimeInfo )
{
/**
#ifdef WIN32

    BOOL    bAttrsChanged = FALSE;
    HANDLE  hFile = NULL;


    if ( !prTimeInfo )
        return;

    if ( !prTimeInfo->bLastAccessTimeSaved )
    {
        return;                         // See ya!  There's nothing for us
    }                                   // to do here.

                                        // Clear the file's RO attribute
                                        // if necessary.  If this fails,
                                        // then we won't be able to set the
                                        // date so we might as well bail out.
    if ( prTimeInfo->bMustChangeAttrs )
    {
        if ( SetFileAttributes( prTimeInfo->lpszFilespec, 
                                (prTimeInfo->uFileAttrs) & ~FILE_ATTRIBUTE_READONLY) )
        {
            bAttrsChanged = TRUE;
        }
        else
        {
            return;
        }
    }
                                        // Now open the file and set its
                                        // last accessed date.  If this
                                        // fails, then there isn't a whole
                                        // lot we can do about it, and we'll
                                        // fail silently.

    hFile = CreateFile( prTimeInfo->lpszFilespec, 
                        GENERIC_WRITE, 
                        FILE_SHARE_READ|FILE_SHARE_WRITE, 
                        NULL, 
                        OPEN_EXISTING,
                        FILE_ATTRIBUTE_READONLY, 
                        NULL);

    if ( INVALID_HANDLE_VALUE != hFile )
    {
        SetFileTime ( hFile, NULL, &prTimeInfo->ftimeLastAccessTime, NULL );
        CloseHandle ( hFile );
    }

                                        // Restore the file's attributes if
                                        // we changed 'em earlier.

    if ( bAttrsChanged )
    {
        SetFileAttributes ( prTimeInfo->lpszFilespec, prTimeInfo->uFileAttrs );
    }

#else // end WIN32 ... begin NLM
**/

    if ( !prTimeInfo )
        return;

    if ( !prTimeInfo->bLastAccessTimeSaved )
    {
        return;                         // See ya!  There's nothing for us
    }                                   // to do here.


	prTimeInfo->fix_time_buffer.actime = prTimeInfo->file_stat_buffer.st_atime;
    prTimeInfo->fix_time_buffer.modtime = prTimeInfo->file_stat_buffer.st_mtime;

	utime(prTimeInfo->lpszFilespec, &prTimeInfo->fix_time_buffer);
    
//#endif // WIN32
}


/**
#if defined(WIN32)

// This stuff is needed for run-time linking to functionality
// only available on WinNT systems.

typedef BOOL (WINAPI *LPFNGETFILEATTRIBUTESEX)( LPCTSTR, GET_FILEEX_INFO_LEVELS, LPVOID );
#define GETFILEATTRIBUTESEXW    _T("GetFileAttributesExW")
#define GETFILEATTRIBUTESEXA    _T("GetFileAttributesExA")


///////////////////////////////////////////////////////////////////////////
//
// Function:    GetLastAccessDateNT()
//
// Description:
//
//  Reads a file's last accessed date w/o changing that date.  This function
//  exists because for NT we have to use a different API, and it must be
//  done before the file is opened, cuz opening a file changes the last
//  accessed date.  (This is a totally different procedure than on 95.)
//
// Input:
//
//  szFileName: [in] Fully-qualified path to the file.
//  lpFileTime: [out] Receives the last accessed date if the function is
//                    successful.
//
// Returns:
//
//  TRUE if successful, FALSE if not.
//
///////////////////////////////////////////////////////////////////////////
// 1/2/98 Mike Dunn -- swiped from avapi.cpp
// 6/7/00 TCashin - ported from Odyssey
///////////////////////////////////////////////////////////////////////////

BOOL GetLastAccessDateNT ( LPCTSTR szFileName, FILETIME *lpFileTime )
{
       WIN32_FILE_ATTRIBUTE_DATA attribData;
static LPFNGETFILEATTRIBUTESEX   pGetFileAttributes = NULL;

    if ( !MyIsWinNT() )
        return FALSE;

    // Get pointer to GetFileAttributesEx function
    if( pGetFileAttributes == NULL )
    {
        HMODULE hKernel32 = GetModuleHandle( _T("KERNEL32"));

        if( hKernel32 == NULL )
            return FALSE;

#ifdef UNICODE
        pGetFileAttributes = (LPFNGETFILEATTRIBUTESEX)
                             GetProcAddress( hKernel32,
                                             GETFILEATTRIBUTESEXW );
#else
        pGetFileAttributes = (LPFNGETFILEATTRIBUTESEX)
                             GetProcAddress( hKernel32,
                                             GETFILEATTRIBUTESEXA );

#endif
        if( pGetFileAttributes == NULL )
            return FALSE;
    }


    // Get extended file attributes
    if( pGetFileAttributes(szFileName, GetFileExInfoStandard, &attribData) )
    {
        // Save off last file access.
        *lpFileTime = attribData.ftLastAccessTime;
        return TRUE;
    }

    return FALSE;
}

#endif  // defined(SYM_WIN32)
**/


