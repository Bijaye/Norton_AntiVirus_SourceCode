//------------------------------------------------------------------------------
//
//      Callback.c 
//
//
//      ANSIL Project
//
//              ANSIL for NetWare
//
//              Symantec Corporation, Copyright (c) 2001
//              All rights reserved. 
//
//      
//      Description:
//
//              
//
//      Author:
//
//
//
//      Modifications:
//              July-29-2001     Kamy Rahimi -  kamy@CrossColors.com
//              Modified to detach NAVAP.nlm for ANSIL 
//
//
//------------------------------------------------------------------------------

#include "pscan.h"
#include "filetime.h"

//#ifndef NLM //EA- 09/13 ci.h not for the Xwing product it has a #define registry value
//#include "..\..\..\..\..\Norton_AntiVirus\Iliad\shared\include\ci.h"


#include "W:\Norton_AntiVirus\Iliad\shared\include\ci.h"


//#endif //EA - 09/13

/**
#ifdef WIN32
extern PFNProcessCanUpdateRegKey       pfnProcessCanUpdateRegKey;
extern PFNSfcIsFileProtected		   pfnSfcIsFileProtected;
#endif
**/

/***************************************************************************************************/
char LastInfectedFile[IMAX_PATH];
DWORD LastInfectionTime=0;
VTIME TimeOfLastVirus;
/*******************************************************************************************/




//#if 0




/*****************************************************************************************************/

DWORD DoTheScan(PSTORAGEOBJECT so,DWORD ScanType) 
{

	BOOL flag = FALSE;
	BOOL WriteProtected = FALSE;
	DWORD cc;
	VEFILEINFO vi;
	USEVE
    EVENTBLOCK inf;
    FILETIMEDATA filetimeinfo = {0};
	BOOL bResetState = FALSE;
	BOOL bIsFileProtected = FALSE;	// could be TRUE only on Windows 2000

    // Save the file's last access time so we can restore it after the scan 
    SaveLastAccessTime(so->Node->InternalPath, &filetimeinfo);
    
    if ((so->Flags&FA_WALKSCAN) && (so->Node->Flags&N_FILENODE)) {
		flag = TRUE;
		if (so->block->WriteCheck == 0) {
			if (so->Node->IO->access(so->Node,55) == 0)
				so->block->WriteCheck = 1;
			else
				so->block->WriteCheck = 2;
			}
		if (so->block->WriteCheck == 2)
			WriteProtected = TRUE;
		if (so->block->FileState && !WriteProtected)
			{

			cc = so->Node->IO->GetState(so->Node,so->block->FileState);
/**
#ifdef WIN32
			if(cc == ERROR_SUCCESS)
				bResetState = TRUE;
#endif // end WIN32
**/

//#ifdef NLM
			if(cc == 0)	// on NLM GetState() is using stat() which returns for success.
				bResetState = TRUE;
//#endif
			}
		}

	dprintf("Scanning [%s  {%s}\n",so->Node->Description,so->Node->InternalPath);

	so->Flags &= ~FA_SCANNING_MASK;
	so->Flags |= FA_SCANNING_FILE;
	so->ReturnCode = 0;

	so->Node->IO->access(so->Node,0); // make sure storage is backed by someting real

	memset(&vi,0,sizeof(VEFILEINFO));

	vi.wSize = sizeof(VEFILEINFO);

	if (VeInfo->wSize == sizeof(VEINFO10)) {
		vi.pszFileName = so->Node->InternalPath;
		ScanType &= 0x7ff;
		}
	else if (VeInfo->wSize == sizeof(VEINFO)) {
		vi.fileContext = (pVEFILECONTEXT)so->Node;
		vi.dwFileType = VEUSEFILEIOTABLE;
		}
	else
		return P_VERSION_MISMATCH;

	vi.dwScanType = ScanType;
	vi.appContext = (VECONTEXT)so;
	vi.wZipDepth = (WORD)((so->Flags&FA_WALKSCAN) ? so->block->ZipDepth : so->Info->RTSData->ZipDepth);
/*
#ifndef NLM
    if(so->Flags&FA_WALKSCAN)
    {
        vi.bBackupToQuarantine = so->block->dwBackupToQuarantine;
        if(so->block->ZipHeadEvent)
        {
       		PEVENTBLOCK curEb, nextEb;
            // Iterate through the list of event blocks for
            // each infected item inside a container if for some
            // reason the list was not freed after scanning the (previous)
            // container (example, an exception etc.).			
		    curEb = so->block->ZipHeadEvent;
		    while(curEb)
		    {		
                nextEb = curEb->Next;
                DestroyCopyOfEvent(curEb);
                curEb = nextEb;
            }
        }

        so->block->ZipHeadEvent = NULL;
    }
	else if((so->Flags&FA_RTSSCAN)&&
			(so->Node->Flags&(N_RTSNODE|N_MAILNODE))==(N_RTSNODE|N_MAILNODE))
		{
		// must read this option from registry (because so->block is NULL)
		// Exchange and other mail storages do not have a backup setting, so use the filesystem RTS backup setting
		HKEY hkey;
		// HKLM,Software\\Intel\\LANDesk\\VirusProtect6\\CurrentVersion\\Storages\\FileSystem\\RealTimeScan
		if(RegOpenKey( HKEY_LOCAL_MACHINE, REGHEADER"\\"REG_VP_REALTIME_KEY, &hkey ) !=ERROR_SUCCESS)
			vi.bBackupToQuarantine = 1;
		else 
			{
			vi.bBackupToQuarantine = GetVal(hkey, szReg_Val_BackupToQuarantine, 1);
			RegCloseKey(hkey);
			}
		}
	else
		{
		// must read this option from registry (because so->block is NULL)
		// we probably being called via a results view call (i.e. history view, or scan results view),
		// so the block ptr is NULL.
		// just set the value to TRUE until I figure out which reg key I should query...
		vi.bBackupToQuarantine = 1;
		}
#endif
*/

/*
	RequestPatternUsage(PATTUSE);
*/

	__try {
		CALLVE;
		///cc = VEScanFile(VEhan,&vi);
		printf( " --->  Calling  VEScanFile() ......" );
		RETVE;
		}
		
		
/*
#ifndef NLM
	__except(1) {
		dprintf("  (Exception!! in VEScanFile)]\n");
		cc = VEEXCEPTION;
		}
#endif
*/

	//RequestPatternUsage(PATTDONE);

//rchinta
/**
#ifdef WIN32
	// Add the files within a container to the count of files scanned.
	// Do not count the top level container here since it will be counted
	// later.
	if ((so->Flags & FA_WALKSCAN) && vi.bIsCompressed && so->block)
    {
		so->block->Scanned += vi.wNumFilesScanned - 1;

        // For the top-level container with no (detected) infected items, add a log record 
        // to indicate the files that were skipped (due to problems during extraction) 
        // This count takes into account only the files inside containers that need to be scanned
        // based on prescan exclusions when prescan exclusions are turned on.

        if(vi.wNumVirusFound == 0  && vi.wFilesOmitted > 0)
        {
		    EVENTBLOCK log;
		    char line[IMAX_PATH];

		    WSprintf(line, LS(IDS_ERR_FILES_OMITTED_INZIP), vi.wFilesOmitted, so->Node->Description);

            dprintf(line);

		    memset(&log,0,sizeof(log));
		    log.Description = line;
		    log.logger = so->block->logger;
		    log.hKey[0] = so->block->hkey;
		    log.Category = GL_CAT_SUMMARY;
		    log.Event = GL_EVENT_FILE_NOT_OPEN;
            so->block->NotOpen += vi.wFilesOmitted;
		    GlobalLog(&log);            
        }

    }

	if(pfnSfcIsFileProtected)
	{
		WCHAR wszFileName[IMAX_PATH] = L"";
		DWORD dwRet;

        if(MultiByteToWideChar(CP_ACP, 0, so->Node->InternalPath, -1, wszFileName, sizeof(wszFileName)/sizeof(wszFileName[0]) ) != 0)
		{
			BOOL bRet = pfnSfcIsFileProtected(NULL, wszFileName);
			dwRet = GetLastError();

			if(bRet)
			{
				bIsFileProtected = TRUE;
			}
			else
            {
                // We expect to get ERROR_FILE_NOT_FOUND if the file is not under
                // Windows File Protection. Display any other errors.

                if ( dwRet != ERROR_FILE_NOT_FOUND )
                {
				    dprintf("Failed to determine if the %s is under Windows File Protection, Error: %d\n", so->Node->InternalPath, dwRet);				
                }
            }
		}
		else
			dprintf("Failed to convert %s from ANSI to UNICODE before determining if the file under WFP\n", so->Node->InternalPath);
	}

#endif
**/
	// Do not restore file access time for files under Windows File Protection on Windows 2000
	// bIsFileProtected could be TRUE only for Windows 2000
	if (flag && so->block->FileState && !WriteProtected && bResetState  && !bIsFileProtected)
		so->Node->IO->SetState(so->Node,so->block->FileState);

    // This information is obtained after a scan of a file.
    if (so->block && so->block->cbScanInfo)
    {
    	if ((so->Flags&FA_SCANNING_FILE)) 
            inf.Description = so->Node->Description;

	    inf.Size = sizeof(EVENTBLOCK);
	    inf.pSid = (PSID)&so->Node->Sid;
	    inf.Access = so->Node->Operations&(FA_READ|FA_WRITE|FA_EXEC|FA_DELETE);
	    inf.so = so;
	    inf.Flags = so->Node->Flags | so->Flags;

//#if defined (WIN32) || defined (NLM) //EA 05/15/2000 it will never come here but when cbScanInfo fn gets implemented we need to do it
        inf.DefVersionInfo = vi.DefVersionInfo;
//#endif
	    
	    if (so->Flags&FA_WALKSCAN) {
		    inf.ScanID = so->block->ScanID;
		    inf.GroupID = so->block->GroupID;
		    //inf.hKey[0]= so->block->hkey;
		    inf.Handle = &so->block->InfHan;
		    //inf.logger = so->block->logger;
		    }

        so->block->cbScanInfo(so->block, &inf);
    }

    // Put the file's times back as they were before the scan 
    // if the file is not under Windows File Protection
    if ( !bIsFileProtected )
    {
        RestoreLastAccessTime(&filetimeinfo);
    }

	return cc;
}



//#endif


/********************************************************************************************************/



